/**
 * KALENDER EKONOMI — versi jujur.
 *
 * Yang DIKLAIM sistem ini:
 *  - Klasifikasi indikator & arah kejutan (actual vs forecast) menurut logika makro standar.
 *  - Skenario KONDISIONAL (jika panas / sesuai / mendingin) — ini aturan, bukan ramalan.
 *  - Setelah rilis: aturan kejutan diuji terhadap pergerakan harga emas NYATA (lihat core/eventReaction).
 *
 * Yang TIDAK diklaim lagi (dihapus karena sebelumnya dikarang):
 *  - "Prediksi" arah sebelum rilis (tidak ada edge terbukti; arah = NETRAL).
 *  - Angka "perkiraan aktual AI", "bocoran A1", skor pegangan 93–98%, win rate 84–92%,
 *    probabilitas spike 74–98%, pips profit tetap.
 *  - Penilaian benar/salah yang diturunkan dari angka aktual itu sendiri (sirkular -> selalu 100%).
 */
import { surpriseDirection, type ReactionResult } from "../core/eventReaction";

export type MacroCategory =
  | "INFLATION_CPI_PCE" | "LABOR_PAYROLLS_NFP" | "LABOR_UNEMPLOYMENT" | "LABOR_WAGES"
  | "CENTRAL_BANK_RATES" | "GROWTH_GDP_RETAIL" | "BUSINESS_PMI" | "SENTIMENT_HOUSING" | "GLOBAL_MACRO";

export interface MacroPillar { title: string; transmissionSummary: string; dxyMechanism: string; yield10yImpact: string; goldCorrelation: string; btcImpact: string }
export interface HistoricalPillar { winRateStat: string; sampleSize: string; avgVolatilityPips: number | null; empiricalPrecedent: string }
export interface SmcPillar { orderFlowTarget: string; liquiditySweepZone: string; fvgImbalanceArea: string; recommendedEntryTactic: string }
export interface RiskGuardPillar { invalidationLevelPips: number | null; invalidationRule: string; recommendedSl: string; recommendedTp1: string; recommendedTp2: string; riskRewardRatio: string }
export interface ScenarioPlaybook {
  hot: { condition: string; marketReaction: string; actionBias: string; expectedPips: string };
  inline: { condition: string; marketReaction: string; actionBias: string; expectedPips: string };
  soft: { condition: string; marketReaction: string; actionBias: string; expectedPips: string };
}
export interface PeganganKuat {
  anchorGrade: string;
  anchorScore: number | null;       // selalu null: tidak ada skor "pegangan" yang dapat dibuktikan
  macroPillar: MacroPillar; historicalPillar: HistoricalPillar; smcPillar: SmcPillar;
  riskGuardPillar: RiskGuardPillar; scenarioPlaybook: ScenarioPlaybook; institutionalConsensus: string;
}
export interface SpikePredictionData {
  spikeProbability: number | null;  // null: tidak diukur
  spikeLevel: string;               // klasifikasi berdasar tingkat kepentingan, bukan probabilitas
  spikeType: "HIGH_SPIKE" | "MEDIUM_SPIKE" | "LOW_SPIKE";
  estimatedPipsGold: string;        // dari reaksi terukur bila ada, selain itu "belum terukur"
  estimatedPipsFx: string; estimatedPipsBtc: string; spikeDirectionBias: string; trapRiskLevel: string;
  liquiditySpreadRisk: string; peakVolatilityWindow: string; preReleaseStrategy: string;
  historicalAvgSpikePips: number | null; spikeVolatilityRank: string;
}

export type AccuracyStatus = "TEPAT_SASARAN" | "TIDAK_TEPAT" | "NETRAL" | "MENUNGGU" | "TIDAK_TERUKUR";

export interface UpgradedEconomicEvent {
  id: string; title: string; currency: string; country: string; date: string;
  importance: number; forecast: string; previous: string; actual: string | null;
  estimatedActual: string;            // "---" : tidak ada model estimasi aktual
  estimatedActualNum: number | null;
  predictedDeviation: string;
  a1LeakIntelligence: string;         // dipertahankan untuk kompatibilitas; berisi catatan metode jujur
  unit: string; source: string;
  status: "RELEASED" | "UPCOMING" | "AWAITING_DATA";
  isReleased: boolean; releasedLabel: string; deviation: number | null;
  macroCategory: MacroCategory; spikePrediction: SpikePredictionData;
  isPredictionCorrect: boolean | null;  // null = belum/ tidak dapat diukur
  pipsGain: string;                     // gerak harga terukur, atau "—"
  accuracyStatus: AccuracyStatus;
  verdictSummary: string;
  reaction: ReactionResult | null;
  marketOutcome: {
    dxyEffect: "BEARISH_USD" | "BULLISH_USD" | "NEUTRAL_CHOP";
    goldImpact: "BUY" | "SELL" | "NETRAL";
    recommendation: "BUY" | "SELL" | "NETRAL";
    accuracyScore: number | null; summary: string;
  };
  prediction: {
    direction: "BUY" | "SELL" | "NETRAL";
    biasStrength: string; targetSymbol: string;
    confidence: number | null;         // selalu null: tidak ada kepercayaan yang dapat diukur per event
    peganganKuat: PeganganKuat; reasoning: string; fundamentalAspect: string;
    technicalConfluence: string; macroSentiment: string; statusLabel: string;
  };
}

/** Statistik reaksi nyata untuk judul event yang sama (diisi server dari audit harga). */
export interface HistoryContext {
  n: number; hit: number; miss: number; neutral: number;
  avgAbsMove: number | null;   // USD/oz rata-rata |gerak| setelah rilis
}

export function classifyIndicator(title: string, indicator: string = ""): {
  category: MacroCategory; higherIsBullishUSD: boolean; weightTier: 1 | 2 | 3;
} {
  const text = (title + " " + indicator).toLowerCase();
  // Urutan penting: pola yang lebih spesifik lebih dulu.
  if (/unemployment rate|jobless claim|initial claim|continuing claim|unemployed/.test(text))
    return { category: "LABOR_UNEMPLOYMENT", higherIsBullishUSD: false, weightTier: 1 };
  if (/hourly earnings|wage growth|employment cost|unit labor/.test(text))
    return { category: "LABOR_WAGES", higherIsBullishUSD: true, weightTier: 1 };
  if (/non-farm|nonfarm|nfp|payrolls|adp employment|jolts|job openings/.test(text))
    return { category: "LABOR_PAYROLLS_NFP", higherIsBullishUSD: true, weightTier: 1 };
  if (/michigan|consumer sentiment|consumer confidence|inflation expectation/.test(text))
    return { category: "SENTIMENT_HOUSING", higherIsBullishUSD: true, weightTier: 2 };
  if (/\bcpi\b|consumer price|inflation|\bpce\b|personal consumption/.test(text))
    return { category: "INFLATION_CPI_PCE", higherIsBullishUSD: true, weightTier: 1 };
  if (/\bppi\b|producer price|import price|export price/.test(text))
    return { category: "INFLATION_CPI_PCE", higherIsBullishUSD: true, weightTier: 2 };
  if (/fomc|federal funds|fed rate|interest rate|rate decision|monetary policy|powell/.test(text))
    return { category: "CENTRAL_BANK_RATES", higherIsBullishUSD: true, weightTier: 1 };
  if (/\bgdp\b|gross domestic product|retail sales/.test(text))
    return { category: "GROWTH_GDP_RETAIL", higherIsBullishUSD: true, weightTier: 1 };
  if (/durable goods|factory orders|wholesale/.test(text))
    return { category: "GROWTH_GDP_RETAIL", higherIsBullishUSD: true, weightTier: 2 };
  if (/ism services|services pmi/.test(text))
    return { category: "BUSINESS_PMI", higherIsBullishUSD: true, weightTier: 1 };
  if (/ism manufacturing|manufacturing pmi|s&p global|chicago pmi|philly fed|empire state/.test(text))
    return { category: "BUSINESS_PMI", higherIsBullishUSD: true, weightTier: 2 };
  if (/building permits|housing starts|existing home|new home/.test(text))
    return { category: "SENTIMENT_HOUSING", higherIsBullishUSD: true, weightTier: 3 };
  return { category: "GLOBAL_MACRO", higherIsBullishUSD: true, weightTier: 2 };
}

function parseNum(v: unknown): number | null {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  if (s === "" || s === "---" || s === "-") return null;
  const n = parseFloat(s.replace(/[^0-9.\-]+/g, ""));
  return Number.isFinite(n) ? n : null;
}

const NA = "belum terukur";

function buildPillars(title: string, category: MacroCategory, higherIsBullishUSD: boolean, fc: number | null, prev: number | null, unit: string, hist: HistoryContext | null): PeganganKuat {
  const fcStr = fc !== null ? `${fc}${unit}` : "konsensus";
  const hotMeansUsdUp = higherIsBullishUSD;
  const mechanism: Record<MacroCategory, string> = {
    INFLATION_CPI_PCE: "Inflasi lebih tinggi dari konsensus cenderung menaikkan ekspektasi suku bunga → USD & yield naik → emas tertekan (arah sebaliknya jika lebih rendah).",
    LABOR_PAYROLLS_NFP: "Penyerapan kerja lebih kuat dari konsensus cenderung menopang USD & yield → emas tertekan (sebaliknya jika lebih lemah).",
    LABOR_UNEMPLOYMENT: "Pengangguran/klaim lebih tinggi dari konsensus menandakan pasar kerja melemah → ekspektasi pelonggaran → USD melemah, emas cenderung naik.",
    LABOR_WAGES: "Upah lebih tinggi dari konsensus menambah tekanan inflasi → USD & yield cenderung naik → emas tertekan.",
    CENTRAL_BANK_RATES: "Keputusan/nada yang lebih hawkish dari ekspektasi cenderung menguatkan USD; lebih dovish cenderung melemahkannya.",
    GROWTH_GDP_RETAIL: "Pertumbuhan lebih kuat dari konsensus cenderung menopang USD & yield; lebih lemah cenderung sebaliknya.",
    BUSINESS_PMI: "Survei bisnis lebih kuat dari konsensus cenderung menopang USD; lebih lemah cenderung melemahkannya.",
    SENTIMENT_HOUSING: "Sentimen/perumahan memiliki dampak lebih kecil dan tidak konsisten terhadap emas.",
    GLOBAL_MACRO: "Dampak bergantung pada konteks; tidak ada aturan arah yang kuat.",
  };
  const macroPillar: MacroPillar = {
    title: "Mekanisme transmisi (aturan umum, bukan ramalan)",
    transmissionSummary: `${mechanism[category]} Yang menggerakkan harga adalah KEJUTAN (actual − forecast), bukan angka mutlak.`,
    dxyMechanism: hotMeansUsdUp ? "Kejutan positif → cenderung USD menguat." : "Kejutan positif → cenderung USD melemah.",
    yield10yImpact: "Arah yield mengikuti ekspektasi suku bunga; besar gerak tidak diprediksi di sini.",
    goldCorrelation: "Emas umumnya bergerak berlawanan dengan USD dan yield riil; korelasi tidak stabil dan bisa gagal.",
    btcImpact: "Dampak ke BTC tidak konsisten; tidak dimodelkan.",
  };
  const histText = hist && hist.n > 0
    ? `Dalam data yang terkumpul untuk "${title}": ${hist.hit} cocok, ${hist.miss} tidak cocok, ${hist.neutral} netral (n=${hist.n} rilis independen). ${hist.avgAbsMove != null ? `Rata-rata gerak emas ${hist.avgAbsMove.toFixed(2)} USD/oz dalam 15 menit.` : ""} Sampel kecil → belum bermakna secara statistik.`
    : "Belum ada rilis berjudul sama yang terukur terhadap harga nyata. Tidak ada klaim statistik.";
  const historicalPillar: HistoricalPillar = {
    winRateStat: hist && hist.hit + hist.miss > 0 ? `${hist.hit}/${hist.hit + hist.miss} (n kecil, tidak bermakna)` : "tidak ada data",
    sampleSize: hist ? `${hist.n} rilis terukur` : "0 rilis terukur",
    avgVolatilityPips: hist?.avgAbsMove ?? null,
    empiricalPrecedent: histText,
  };
  const smcPillar: SmcPillar = {
    orderFlowTarget: "Kalender tidak mengevaluasi likuiditas/FVG. Level teknikal dihitung dari candle nyata pada panel sinyal.",
    liquiditySweepZone: "Tidak dievaluasi di sini.",
    fvgImbalanceArea: "Tidak dievaluasi di sini.",
    recommendedEntryTactic: "Spread melebar & slip sering terjadi di menit rilis; hindari entri sebelum dan tepat saat rilis kecuali Anda paham risikonya.",
  };
  const riskGuardPillar: RiskGuardPillar = {
    invalidationLevelPips: null,
    invalidationRule: "Tidak ada SL/TP rekomendasi dari kalender. Gunakan sinyal teknikal (SL berbasis ATR) dan ukuran posisi yang membatasi kerugian per trade.",
    recommendedSl: NA, recommendedTp1: NA, recommendedTp2: NA, riskRewardRatio: NA,
  };
  const avg = hist?.avgAbsMove != null ? `±${hist.avgAbsMove.toFixed(1)} USD/oz (rata-rata terukur, n=${hist.n})` : NA;
  const scenarioPlaybook: ScenarioPlaybook = {
    hot: {
      condition: `Actual di ATAS ${fcStr}`,
      marketReaction: hotMeansUsdUp ? "Aturan: USD cenderung menguat → emas tertekan." : "Aturan: USD cenderung melemah → emas naik.",
      actionBias: hotMeansUsdUp ? "SELL (aturan kejutan)" : "BUY (aturan kejutan)",
      expectedPips: avg,
    },
    inline: { condition: `Actual SAMA dengan ${fcStr}`, marketReaction: "Tidak ada kejutan; reaksi tidak terarah.", actionBias: "NETRAL", expectedPips: avg },
    soft: {
      condition: `Actual di BAWAH ${fcStr}`,
      marketReaction: hotMeansUsdUp ? "Aturan: USD cenderung melemah → emas naik." : "Aturan: USD cenderung menguat → emas tertekan.",
      actionBias: hotMeansUsdUp ? "BUY (aturan kejutan)" : "SELL (aturan kejutan)",
      expectedPips: avg,
    },
  };
  return {
    anchorGrade: "TANPA SKOR — hanya aturan & data terukur",
    anchorScore: null,
    macroPillar, historicalPillar, smcPillar, riskGuardPillar, scenarioPlaybook,
    institutionalConsensus: `Konsensus (forecast): ${fcStr}; sebelumnya: ${prev !== null ? prev + unit : "—"}. Ini data kalender, bukan posisi institusi.`,
  };
}

export function buildComprehensiveEconomicEvent(
  item: any,
  nowMs: number = Date.now(),
  ctx?: { reaction?: ReactionResult | null; history?: HistoryContext | null },
): UpgradedEconomicEvent {
  const evDate = new Date(item.date);
  const dateMs = evDate.getTime();
  const actNum = parseNum(item.actual);
  const fcNum = parseNum(item.forecast);
  const prevNum = parseNum(item.previous);
  const hasActual = actNum !== null;
  const isPast = Number.isFinite(dateMs) && dateMs <= nowMs;
  const status: UpgradedEconomicEvent["status"] = hasActual ? "RELEASED" : isPast ? "AWAITING_DATA" : "UPCOMING";

  const currency = item.currency || (item.country === "US" ? "USD" : item.country || "USD");
  const title = item.title || item.indicator || item.event || "Economic Event";
  const unit = item.unit || item.scale || "";
  const { category, higherIsBullishUSD, weightTier } = classifyIndicator(title, item.indicator || "");
  const importance = item.importance === 1 ? 1 : item.importance === 0 ? 0 : -1;

  const surpriseDir = hasActual ? surpriseDirection({ actual: actNum, forecast: fcNum, higherIsBullishUSD, currency }) : null;
  const deviation = hasActual && fcNum !== null ? Number((actNum! - fcNum).toFixed(4)) : null;
  const reaction = ctx?.reaction ?? null;

  let accuracyStatus: AccuracyStatus = "MENUNGGU";
  let isPredictionCorrect: boolean | null = null;
  let pipsGain = "—";
  let verdictSummary: string;

  if (status === "RELEASED") {
    if (!surpriseDir) {
      accuracyStatus = "TIDAK_TERUKUR";
      verdictSummary = fcNum === null ? "Rilis tanpa forecast: kejutan tidak dapat dihitung, tidak dinilai." : currency !== "USD" ? "Aturan hanya diuji untuk data USD vs emas." : "Actual = forecast: tidak ada kejutan, tidak dinilai.";
    } else if (!reaction || reaction.verdict === "UNMEASURED") {
      accuracyStatus = "TIDAK_TERUKUR";
      verdictSummary = `Aturan kejutan menunjuk ${surpriseDir} untuk emas. Reaksi harga belum/ tidak dapat diukur${reaction?.reason ? " (" + reaction.reason + ")" : ""}.`;
    } else if (reaction.verdict === "NEUTRAL") {
      accuracyStatus = "NETRAL";
      pipsGain = `${(reaction.move ?? 0) >= 0 ? "+" : ""}${reaction.move} USD/oz (${reaction.horizonMin} mnt)`;
      verdictSummary = `Gerak harga (${reaction.move} USD/oz) di bawah ambang reaksi (${reaction.threshold}); tidak dihitung benar/salah.`;
    } else {
      isPredictionCorrect = reaction.verdict === "HIT";
      accuracyStatus = isPredictionCorrect ? "TEPAT_SASARAN" : "TIDAK_TEPAT";
      pipsGain = `${(reaction.move ?? 0) >= 0 ? "+" : ""}${reaction.move} USD/oz (${reaction.horizonMin} mnt)`;
      verdictSummary = `Aturan kejutan → ${surpriseDir}. Harga emas ${reaction.basePrice} → ${reaction.endPrice} dalam ${reaction.horizonMin} mnt: ${isPredictionCorrect ? "SEARAH" : "BERLAWANAN"}. Diukur dari candle nyata.`;
    }
  } else if (status === "AWAITING_DATA") {
    verdictSummary = "Waktu rilis telah lewat tetapi angka aktual belum tersedia dari sumber data.";
  } else {
    verdictSummary = "Belum dirilis. Tidak ada prediksi arah: yang tersedia hanya skenario kondisional (hot / in-line / soft).";
  }

  const hist = ctx?.history ?? null;
  const pegangan = buildPillars(title, category, higherIsBullishUSD, fcNum, prevNum, unit, hist);
  const isHigh = importance === 1 || weightTier === 1;
  const spikeType: SpikePredictionData["spikeType"] = isHigh ? "HIGH_SPIKE" : importance === 0 || weightTier === 2 ? "MEDIUM_SPIKE" : "LOW_SPIKE";
  const avgMove = hist?.avgAbsMove != null ? `±${hist.avgAbsMove.toFixed(1)} USD/oz (terukur, n=${hist.n})` : NA;
  const spikePrediction: SpikePredictionData = {
    spikeProbability: null,
    spikeLevel: isHigh ? "KEPENTINGAN TINGGI" : spikeType === "MEDIUM_SPIKE" ? "KEPENTINGAN SEDANG" : "KEPENTINGAN RENDAH",
    spikeType,
    estimatedPipsGold: avgMove, estimatedPipsFx: NA, estimatedPipsBtc: NA,
    spikeDirectionBias: surpriseDir ? `Aturan kejutan: ${surpriseDir}` : "Tidak ada arah",
    trapRiskLevel: "Tidak dimodelkan", liquiditySpreadRisk: "Spread cenderung melebar saat rilis (tidak diukur)",
    peakVolatilityWindow: "Menit-menit pertama setelah rilis (umum, tidak diukur)",
    preReleaseStrategy: "Tidak ada rekomendasi entri; hindari posisi tanpa SL menjelang rilis berdampak tinggi.",
    historicalAvgSpikePips: hist?.avgAbsMove ?? null,
    spikeVolatilityRank: isHigh ? "Tingkat 1 (menurut kalender)" : spikeType === "MEDIUM_SPIKE" ? "Tingkat 2" : "Tingkat 3",
  };

  const direction: "BUY" | "SELL" | "NETRAL" = surpriseDir ?? "NETRAL";
  const id = item.id ? String(item.id) : `${currency}_${String(title).replace(/[^a-zA-Z0-9]+/g, "_")}_${dateMs}`;

  return {
    id, title, currency, country: item.country || currency,
    date: Number.isFinite(dateMs) ? evDate.toISOString() : new Date(nowMs).toISOString(),
    importance,
    forecast: fcNum !== null ? String(fcNum) : "---",
    previous: prevNum !== null ? String(prevNum) : "---",
    actual: actNum !== null ? String(actNum) : null,
    estimatedActual: "---", estimatedActualNum: null,
    predictedDeviation: deviation !== null ? `${deviation >= 0 ? "+" : ""}${deviation}${unit} vs forecast` : "—",
    a1LeakIntelligence: "Tidak ada model estimasi angka aktual. Sistem hanya membandingkan actual dengan forecast setelah rilis.",
    unit, source: item.source || "TradingView Economic Calendar",
    status, isReleased: status === "RELEASED",
    releasedLabel: status === "RELEASED" ? "TELAH DIRILIS" : status === "AWAITING_DATA" ? "MENUNGGU ANGKA" : "MENUNGGU RILIS",
    deviation, macroCategory: category, spikePrediction,
    isPredictionCorrect, pipsGain, accuracyStatus, verdictSummary, reaction,
    marketOutcome: {
      dxyEffect: surpriseDir == null ? "NEUTRAL_CHOP" : (surpriseDir === "SELL" ? "BULLISH_USD" : "BEARISH_USD"),
      goldImpact: direction, recommendation: direction, accuracyScore: null,
      summary: verdictSummary,
    },
    prediction: {
      direction,
      biasStrength: surpriseDir ? `ARAH ATURAN KEJUTAN: ${surpriseDir}` : "TANPA ARAH",
      targetSymbol: "XAUUSD", confidence: null,
      peganganKuat: pegangan,
      reasoning: verdictSummary,
      fundamentalAspect: pegangan.macroPillar.transmissionSummary,
      technicalConfluence: pegangan.smcPillar.orderFlowTarget,
      macroSentiment: pegangan.macroPillar.dxyMechanism,
      statusLabel: status === "RELEASED" ? "TELAH DIRILIS" : status === "AWAITING_DATA" ? "MENUNGGU ANGKA" : "MENUNGGU RILIS",
    },
  };
}
