/** Candle standar: t = waktu BUKA candle (ms epoch UTC). */
export interface Candle {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
}

export type Direction = "BUY" | "SELL";

export interface Provenance {
  source: string;       // nama sumber data nyata yang dipakai
  fetchedAt: number;    // kapan diambil (ms)
  note?: string;        // mis. "proxy: PAXG, bukan spot XAUUSD"
}
