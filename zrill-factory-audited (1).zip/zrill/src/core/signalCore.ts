/**
 * SIGNAL CORE v6 — jujur dan dapat diaudit.
 *
 * Prinsip:
 *  1. Input hanya candle/harga/makro NYATA yang diberikan pemanggil. Tidak ada angka bawaan.
 *  2. Setiap faktor menyebut nilai yang dihitung. Faktor yang datanya tidak ada DIKELUARKAN
 *     (bukan diisi default).
 *  3. "score" adalah skor konfluensi heuristik, BUKAN probabilitas. Probabilitas/win-rate hanya
 *     datang dari ledger (hasil terukur) lewat `trackRecord`, dan hanya bila sampel cukup.
 *  4. Boleh menjawab NO_TRADE / DATA_INSUFFICIENT. Tidak pernah memaksa BUY/SELL.
 */
import type { Candle, Direction } from "./types";
import { INTERVAL_MS, aggregate, closedOnly } from "./candles";
import { adx, atr, ema, fairValueGaps, last, macd, marketStructure, recentLiquiditySweep, rsi, swings } from "./indicators";
import type { LedgerSummary } from "./ledger";

export interface Factor {
  key: string;
  name: string;
  /** -1 (bearish) .. +1 (bullish); 0 = netral */
  value: number;
  weight: number;
  detail: string;
}

export interface MacroInput {
  /** perubahan % DXY hari ini (data nyata), null bila tidak tersedia */
  dxyChangePct: number | null;
  /** perubahan yield US10Y dalam bps hari ini (data nyata), null bila tidak tersedia */
  us10yChangeBps: number | null;
  asOf: number;
}

export interface UpcomingEventLite { title: string; dateMs: number; importance: number; currency: string }

export interface AnalyzeInput {
  symbol: string;
  now: number;
  m15: Candle[];
  h1: Candle[];
  h4?: Candle[];            // jika kosong, diagregasi dari h1
  livePrice?: { bid: number; ask: number; updatedAt: number } | null;
  macro?: MacroInput | null;
  events?: UpcomingEventLite[];
  trackRecord?: LedgerSummary | null;
  sources?: string[];
}

export type SignalStatus = "SIGNAL" | "NO_TRADE" | "DATA_INSUFFICIENT";

export interface SignalResult {
  symbol: string;
  generatedAt: number;
  status: SignalStatus;
  direction: Direction | null;
  entry: number | null;
  sl: number | null;
  tp1: number | null;
  tp2: number | null;
  rr1: number | null;
  rr2: number | null;
  atr: number | null;
  score: number;                 // -1..1, heuristik
  agreeing: number;
  totalFactors: number;
  factors: Factor[];
  reasons: string[];             // alasan NO_TRADE / catatan penting
  dataQuality: { ok: boolean; issues: string[]; sources: string[] };
  trackRecord: LedgerSummary | null;
  meaning: string;               // penjelasan arti skor, selalu disertakan
}

export const THRESHOLDS = {
  minScore: 0.35,
  minAgreeing: 3,
  minAdx: 15,
  minH1: 250,
  minM15: 120,
  minH4: 60,
  maxPriceDivergence: 0.005, // 0,5% antara harga live dan close terakhir
  maxLiveAgeMs: 30_000,
  eventBlockBeforeMs: 15 * 60_000,
  eventBlockAfterMs: 30 * 60_000,
  slAtrMin: 1.5,
  slAtrMax: 3.0,
  rr1: 1.5,
  rr2: 2.5,
};

const MEANING =
  "Skor = rata-rata berbobot dari faktor yang bisa dihitung (-1..+1). Ini ukuran keselarasan indikator, " +
  "BUKAN probabilitas menang. Win rate hanya valid dari 'trackRecord' (hasil nyata) dan baru ditampilkan bila sampel cukup.";

function base(symbol: string, now: number): SignalResult {
  return {
    symbol, generatedAt: now, status: "NO_TRADE", direction: null,
    entry: null, sl: null, tp1: null, tp2: null, rr1: null, rr2: null, atr: null,
    score: 0, agreeing: 0, totalFactors: 0, factors: [], reasons: [],
    dataQuality: { ok: false, issues: [], sources: [] }, trackRecord: null, meaning: MEANING,
  };
}

const clamp = (x: number, a = -1, b = 1) => Math.max(a, Math.min(b, x));

export function analyze(input: AnalyzeInput): SignalResult {
  const T = THRESHOLDS;
  const res = base(input.symbol, input.now);
  res.trackRecord = input.trackRecord ?? null;
  res.dataQuality.sources = input.sources ?? [];

  const m15 = closedOnly(input.m15, INTERVAL_MS["15m"], input.now);
  const h1 = closedOnly(input.h1, INTERVAL_MS["1h"], input.now);
  let h4 = input.h4 ? closedOnly(input.h4, INTERVAL_MS["4h"], input.now) : aggregate(h1, INTERVAL_MS["1h"], INTERVAL_MS["4h"]);

  const issues: string[] = [];
  if (h1.length < T.minH1) issues.push(`H1 hanya ${h1.length} candle (butuh ≥${T.minH1})`);
  if (m15.length < T.minM15) issues.push(`M15 hanya ${m15.length} candle (butuh ≥${T.minM15})`);
  if (h4.length < T.minH4) issues.push(`H4 hanya ${h4.length} candle (butuh ≥${T.minH4})`);
  if (issues.length) {
    res.status = "DATA_INSUFFICIENT";
    res.dataQuality.issues = issues;
    res.reasons = ["Data tidak cukup untuk analisis yang dapat dipertanggungjawabkan."];
    return res;
  }

  // Kesegaran data: pasar tutup / feed basi -> jangan menganalisis seolah-olah live
  const h1Age = input.now - (h1[h1.length - 1].t + INTERVAL_MS["1h"]);
  const m15Age = input.now - (m15[m15.length - 1].t + INTERVAL_MS["15m"]);
  if (m15Age > 3 * INTERVAL_MS["15m"] || h1Age > 3 * INTERVAL_MS["1h"]) {
    res.status = "NO_TRADE";
    res.dataQuality.issues = [`Candle terakhir basi (M15 ${Math.round(m15Age / 60000)} mnt, H1 ${Math.round(h1Age / 60000)} mnt) — kemungkinan pasar tutup atau feed terputus`];
    res.reasons = ["Data tidak segar; tidak ada sinyal."];
    return res;
  }

  const lastClose = m15[m15.length - 1].c;
  let price = lastClose;
  if (input.livePrice && input.now - input.livePrice.updatedAt <= T.maxLiveAgeMs) {
    const mid = (input.livePrice.bid + input.livePrice.ask) / 2;
    if (mid > 0 && Math.abs(mid - lastClose) / lastClose <= T.maxPriceDivergence) price = mid;
    else issues.push(`Harga live (${mid.toFixed(2)}) menyimpang >${T.maxPriceDivergence * 100}% dari candle (${lastClose.toFixed(2)}); live diabaikan`);
  }
  const spread = input.livePrice ? Math.max(0, input.livePrice.ask - input.livePrice.bid) : null;

  const closes1 = h1.map((c) => c.c);
  const closes15 = m15.map((c) => c.c);
  const atrH1 = last(atr(h1, 14));
  const adxH1 = adx(h1, 14);
  const adxVal = last(adxH1.adx);
  const ema50 = last(ema(closes1, 50));
  const ema200 = last(ema(closes1, 200));
  const rsiH1 = last(rsi(closes1, 14));
  const mac = macd(closes1);
  const macHist = last(mac.hist);
  const macHistPrev = mac.hist.length >= 2 ? mac.hist[mac.hist.length - 2] : null;

  if (atrH1 == null || !(atrH1 > 0)) {
    res.status = "DATA_INSUFFICIENT";
    res.dataQuality.issues = [...issues, "ATR H1 tidak dapat dihitung"];
    res.reasons = ["Volatilitas tidak terukur."];
    return res;
  }
  res.atr = Number(atrH1.toFixed(4));

  const factors: Factor[] = [];
  const add = (f: Factor) => factors.push({ ...f, value: clamp(f.value) });

  const sH4 = marketStructure(h4, 2, 2);
  add({ key: "htf_structure", name: "Struktur H4", weight: 2, value: sH4.trend === "BULLISH" ? 1 : sH4.trend === "BEARISH" ? -1 : 0, detail: `${sH4.trend} (${sH4.detail})` });

  const sH1 = marketStructure(h1, 3, 3);
  add({ key: "mtf_structure", name: "Struktur H1", weight: 2, value: sH1.trend === "BULLISH" ? 1 : sH1.trend === "BEARISH" ? -1 : 0, detail: `${sH1.trend} (${sH1.detail})` });

  if (ema50 != null && ema200 != null) {
    let v = 0;
    if (price > ema50 && ema50 > ema200) v = 1;
    else if (price < ema50 && ema50 < ema200) v = -1;
    add({ key: "ema_stack", name: "EMA50/EMA200 H1", weight: 1.5, value: v, detail: `harga ${price.toFixed(2)}, EMA50 ${ema50.toFixed(2)}, EMA200 ${ema200.toFixed(2)}` });
  }

  if (macHist != null) {
    const rising = macHistPrev != null && macHist > (macHistPrev as number);
    let v = macHist > 0 ? 0.5 : -0.5;
    if (macHist > 0 && rising) v = 1;
    if (macHist < 0 && macHistPrev != null && !rising) v = -1;
    add({ key: "macd", name: "MACD histogram H1", weight: 1, value: v, detail: `hist ${macHist.toFixed(4)}${macHistPrev != null ? (rising ? " (naik)" : " (turun)") : ""}` });
  }

  if (rsiH1 != null) {
    const v = rsiH1 > 55 ? clamp((rsiH1 - 55) / 15) : rsiH1 < 45 ? -clamp((45 - rsiH1) / 15) : 0;
    add({ key: "rsi", name: "RSI14 H1 (rezim momentum)", weight: 0.5, value: v, detail: `RSI ${rsiH1.toFixed(1)}` });
  }

  const sM15 = marketStructure(m15, 3, 3);
  if (sM15.event) {
    const up = sM15.event.endsWith("UP");
    add({ key: "m15_event", name: "Break struktur M15", weight: 1, value: up ? 1 : -1, detail: sM15.event });
  }

  const sweep = recentLiquiditySweep(m15, 6, 3, 3);
  if (sweep) {
    add({ key: "sweep", name: "Sapuan likuiditas M15", weight: 1, value: sweep.side === "SSL_SWEPT" ? 1 : -1, detail: `${sweep.side} @ ${sweep.level.toFixed(2)}` });
  }

  const gaps = fairValueGaps(m15, 80).filter((g) => !g.mitigated);
  const nearBull = gaps.filter((g) => g.dir === "BULL" && price >= g.bottom - atrH1 && price <= g.top + atrH1);
  const nearBear = gaps.filter((g) => g.dir === "BEAR" && price >= g.bottom - atrH1 && price <= g.top + atrH1);
  if (nearBull.length || nearBear.length) {
    add({ key: "fvg", name: "FVG M15 belum termitigasi di dekat harga", weight: 0.5, value: nearBull.length > nearBear.length ? 1 : nearBear.length > nearBull.length ? -1 : 0, detail: `bull ${nearBull.length}, bear ${nearBear.length}` });
  }

  const isGold = /XAU|GOLD/i.test(input.symbol);
  if (isGold && input.macro && input.now - input.macro.asOf < 6 * 3_600_000) {
    let v = 0, parts = 0;
    const det: string[] = [];
    if (input.macro.dxyChangePct != null) { v += clamp(-input.macro.dxyChangePct / 0.5); parts++; det.push(`DXY ${input.macro.dxyChangePct >= 0 ? "+" : ""}${input.macro.dxyChangePct.toFixed(2)}%`); }
    if (input.macro.us10yChangeBps != null) { v += clamp(-input.macro.us10yChangeBps / 8); parts++; det.push(`US10Y ${input.macro.us10yChangeBps >= 0 ? "+" : ""}${input.macro.us10yChangeBps.toFixed(1)} bps`); }
    if (parts) add({ key: "macro", name: "Makro (DXY & yield, intraday)", weight: 0.75, value: v / parts, detail: det.join(", ") });
  }

  res.factors = factors;
  res.totalFactors = factors.length;
  const wSum = factors.reduce((s, f) => s + f.weight, 0);
  const score = wSum > 0 ? factors.reduce((s, f) => s + f.value * f.weight, 0) / wSum : 0;
  res.score = Number(score.toFixed(3));

  const dir: Direction | null = score > 0 ? "BUY" : score < 0 ? "SELL" : null;
  res.agreeing = dir ? factors.filter((f) => (dir === "BUY" ? f.value > 0 : f.value < 0)).length : 0;

  const reasons: string[] = [];
  if (adxVal != null && adxVal < T.minAdx) reasons.push(`ADX H1 ${adxVal.toFixed(1)} < ${T.minAdx}: pasar sideways, sinyal tren tidak andal`);
  if (!dir || Math.abs(score) < T.minScore) reasons.push(`|skor| ${Math.abs(score).toFixed(2)} < ${T.minScore}: konfluensi lemah`);
  if (dir && res.agreeing < T.minAgreeing) reasons.push(`hanya ${res.agreeing} faktor searah (butuh ≥${T.minAgreeing})`);
  const h4f = factors.find((f) => f.key === "htf_structure");
  if (dir && h4f && ((dir === "BUY" && h4f.value < 0) || (dir === "SELL" && h4f.value > 0))) reasons.push("melawan struktur H4");
  // Indikator lagging (EMA/MACD/RSI/FVG) saja tidak cukup: butuh minimal satu struktur tren (H4 atau H1) searah.
  const h1f = factors.find((f) => f.key === "mtf_structure");
  const structAgree = [h4f, h1f].some((f) => f && ((dir === "BUY" && f.value > 0) || (dir === "SELL" && f.value < 0)));
  if (dir && !structAgree) reasons.push("tidak ada struktur tren (H4/H1) yang searah; indikator lagging saja tidak cukup");
  if (spread != null && spread > atrH1 * 0.2) reasons.push(`spread ${spread.toFixed(2)} terlalu lebar relatif ATR`);

  for (const ev of input.events ?? []) {
    if (ev.importance < 1) continue;
    const dt = ev.dateMs - input.now;
    if (dt <= T.eventBlockBeforeMs && dt >= -T.eventBlockAfterMs) { reasons.push(`rilis berdampak tinggi: ${ev.title} (${dt >= 0 ? "dalam " + Math.round(dt / 60000) + " mnt" : Math.abs(Math.round(dt / 60000)) + " mnt lalu"})`); break; }
  }

  res.dataQuality = { ok: issues.length === 0, issues, sources: input.sources ?? [] };

  if (reasons.length || !dir) {
    res.status = "NO_TRADE";
    res.reasons = reasons;
    return res;
  }

  // Risiko: SL di luar swing pelindung terdekat (H1) + buffer, dibatasi 1.5–3 ATR
  const sw = swings(h1, 3, 3);
  let slDist = T.slAtrMin * atrH1;
  if (dir === "BUY") {
    const prot = [...sw.lows].reverse().find((s) => s.price < price);
    if (prot) slDist = Math.max(slDist, price - prot.price + 0.25 * atrH1);
  } else {
    const prot = [...sw.highs].reverse().find((s) => s.price > price);
    if (prot) slDist = Math.max(slDist, prot.price - price + 0.25 * atrH1);
  }
  slDist = Math.min(slDist, T.slAtrMax * atrH1);
  const sgn = dir === "BUY" ? 1 : -1;
  const entry = dir === "BUY" ? (input.livePrice ? input.livePrice.ask : price) : (input.livePrice ? input.livePrice.bid : price);
  const e = Number(entry.toFixed(2));
  res.status = "SIGNAL";
  res.direction = dir;
  res.entry = e;
  res.sl = Number((e - sgn * slDist).toFixed(2));
  res.tp1 = Number((e + sgn * slDist * T.rr1).toFixed(2));
  res.tp2 = Number((e + sgn * slDist * T.rr2).toFixed(2));
  res.rr1 = T.rr1;
  res.rr2 = T.rr2;
  res.reasons = [`${res.agreeing}/${res.totalFactors} faktor searah ${dir}; skor ${res.score}`];
  return res;
}
