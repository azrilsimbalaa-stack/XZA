import type { Candle } from "./types";

export const INTERVAL_MS: Record<string, number> = {
  "1m": 60_000, "5m": 300_000, "15m": 900_000, "30m": 1_800_000,
  "1h": 3_600_000, "4h": 14_400_000, "1d": 86_400_000,
};

export interface ValidationReport { candles: Candle[]; dropped: number; issues: string[] }

/** Buang candle rusak (NaN, OHLC tidak konsisten, harga <= 0), urutkan, hapus duplikat waktu. */
export function validateCandles(raw: Candle[]): ValidationReport {
  const issues: string[] = [];
  const ok: Candle[] = [];
  let dropped = 0;
  for (const c of raw) {
    const fin = [c.t, c.o, c.h, c.l, c.c].every((x) => Number.isFinite(x));
    if (!fin || c.o <= 0 || c.h <= 0 || c.l <= 0 || c.c <= 0) { dropped++; continue; }
    const hi = Math.max(c.o, c.c), lo = Math.min(c.o, c.c);
    if (c.h < hi - 1e-9 || c.l > lo + 1e-9 || c.h < c.l) { dropped++; continue; }
    ok.push({ ...c, v: Number.isFinite(c.v) && c.v > 0 ? c.v : 0 });
  }
  ok.sort((a, b) => a.t - b.t);
  const uniq: Candle[] = [];
  for (const c of ok) {
    if (uniq.length && uniq[uniq.length - 1].t === c.t) { uniq[uniq.length - 1] = c; dropped++; }
    else uniq.push(c);
  }
  if (dropped > 0) issues.push(`${dropped} candle tidak valid/duplikat dibuang`);
  return { candles: uniq, dropped, issues };
}

/** Candle yang masih berjalan (belum tutup) dikeluarkan supaya indikator tidak repaint. */
export function closedOnly(c: Candle[], intervalMs: number, now = Date.now()): Candle[] {
  if (!c.length) return c;
  const last = c[c.length - 1];
  return last.t + intervalMs > now ? c.slice(0, -1) : c;
}

/** Agregasi ke timeframe lebih besar, bucket selaras epoch UTC. Bucket tak lengkap dibuang. */
export function aggregate(c: Candle[], fromMs: number, toMs: number): Candle[] {
  if (toMs <= fromMs || toMs % fromMs !== 0) return c;
  const per = toMs / fromMs;
  const buckets = new Map<number, Candle[]>();
  for (const x of c) {
    const key = Math.floor(x.t / toMs) * toMs;
    const arr = buckets.get(key);
    if (arr) arr.push(x); else buckets.set(key, [x]);
  }
  const out: Candle[] = [];
  for (const [t, arr] of [...buckets.entries()].sort((a, b) => a[0] - b[0])) {
    if (arr.length < per) continue; // sesi putus / bucket belum penuh
    arr.sort((a, b) => a.t - b.t);
    out.push({
      t,
      o: arr[0].o,
      h: Math.max(...arr.map((x) => x.h)),
      l: Math.min(...arr.map((x) => x.l)),
      c: arr[arr.length - 1].c,
      v: arr.reduce((s, x) => s + x.v, 0),
    });
  }
  return out;
}
