/**
 * AUDIT REAKSI BERITA.
 * Aturan (ditetapkan SEBELUM melihat harga): kejutan = actual - forecast.
 *   - Indikator "higherIsBullishUSD": kejutan positif -> USD kuat -> emas turun (SELL), dan sebaliknya.
 *   - Indikator terbalik (pengangguran, klaim): kejutan positif -> USD lemah -> emas naik (BUY).
 * Hasil diukur dari harga nyata: perubahan close dari candle terakhir yang TUTUP sebelum rilis
 * sampai close pada horizon N menit sesudah rilis. Ini bukan prediksi pra-rilis; ini uji apakah
 * aturan reaksi memang cocok dengan pergerakan harga. Cocok/tidak ditentukan oleh data, bukan label.
 */
import type { Candle, Direction } from "./types";
import { atr } from "./indicators";

export function surpriseDirection(opts: {
  actual: number | null; forecast: number | null; higherIsBullishUSD: boolean; currency: string;
}): Direction | null {
  const { actual, forecast, higherIsBullishUSD, currency } = opts;
  if (currency !== "USD") return null; // aturan hanya diuji untuk emas vs data USD
  if (actual == null || forecast == null || !Number.isFinite(actual) || !Number.isFinite(forecast)) return null;
  if (actual === forecast) return null;
  const surprisePositive = actual > forecast;
  const usdStronger = higherIsBullishUSD ? surprisePositive : !surprisePositive;
  return usdStronger ? "SELL" : "BUY";
}

export type ReactionVerdict = "HIT" | "MISS" | "NEUTRAL" | "UNMEASURED";

export interface ReactionResult {
  verdict: ReactionVerdict;
  expected: Direction | null;
  move: number | null;       // perubahan harga (USD/oz untuk emas), bertanda
  horizonMin: number;
  threshold: number | null;  // gerak minimum agar dianggap reaksi nyata
  basePrice: number | null;
  endPrice: number | null;
  reason?: string;
}

export function measureReaction(opts: {
  candles: Candle[]; intervalMs: number; releaseMs: number; expected: Direction | null;
  horizonMin?: number; thresholdAtrMult?: number;
}): ReactionResult {
  const horizonMin = opts.horizonMin ?? 15;
  const mult = opts.thresholdAtrMult ?? 0.25;
  const base: ReactionResult = {
    verdict: "UNMEASURED", expected: opts.expected, move: null, horizonMin,
    threshold: null, basePrice: null, endPrice: null,
  };
  if (!opts.expected) return { ...base, reason: "tidak ada kejutan terukur (forecast/actual kosong atau sama)" };
  const { candles, intervalMs, releaseMs } = opts;
  const endMs = releaseMs + horizonMin * 60_000;
  // candle dasar: candle terakhir yang sudah TUTUP sebelum rilis
  let baseIdx = -1;
  for (let i = 0; i < candles.length; i++) if (candles[i].t + intervalMs <= releaseMs) baseIdx = i; else break;
  // candle akhir: candle terakhir yang sudah TUTUP pada/ sebelum endMs
  let endIdx = -1;
  for (let i = 0; i < candles.length; i++) if (candles[i].t + intervalMs <= endMs) endIdx = i; else break;
  if (baseIdx < 14 || endIdx <= baseIdx) return { ...base, reason: "candle tidak mencakup jendela rilis" };
  if (candles[baseIdx].t < releaseMs - 3 * intervalMs) return { ...base, reason: "ada celah data sebelum rilis" };
  const a = atr(candles.slice(0, baseIdx + 1), 14);
  const atrVal = a[baseIdx];
  if (atrVal == null) return { ...base, reason: "ATR belum tersedia" };
  const basePrice = candles[baseIdx].c;
  const endPrice = candles[endIdx].c;
  const move = endPrice - basePrice;
  const threshold = atrVal * mult;
  let verdict: ReactionVerdict;
  if (Math.abs(move) < threshold) verdict = "NEUTRAL";
  else verdict = (move > 0 ? "BUY" : "SELL") === opts.expected ? "HIT" : "MISS";
  return { ...base, verdict, move: Number(move.toFixed(4)), threshold: Number(threshold.toFixed(4)), basePrice, endPrice };
}

export interface ReactionSummary {
  hit: number; miss: number; neutral: number; unmeasured: number;
  n: number;               // hit + miss
  rate: number | null;     // hanya bila n >= minSample
  rawRate: number | null;
  minSample: number;
}

export function summarizeReactions(list: ReactionResult[], minSample = 30): ReactionSummary {
  const hit = list.filter((r) => r.verdict === "HIT").length;
  const miss = list.filter((r) => r.verdict === "MISS").length;
  const neutral = list.filter((r) => r.verdict === "NEUTRAL").length;
  const unmeasured = list.filter((r) => r.verdict === "UNMEASURED").length;
  const n = hit + miss;
  return { hit, miss, neutral, unmeasured, n, rawRate: n ? hit / n : null, rate: n >= minSample ? hit / n : null, minSample };
}
