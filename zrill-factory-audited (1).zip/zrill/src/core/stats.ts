/** Interval kepercayaan Wilson 95% untuk proporsi (lebih jujur daripada persen mentah pada n kecil). */
export function wilson95(successes: number, n: number): { low: number; high: number } | null {
  if (n <= 0) return null;
  const z = 1.959964;
  const p = successes / n;
  const d = 1 + (z * z) / n;
  const centre = p + (z * z) / (2 * n);
  const margin = z * Math.sqrt((p * (1 - p)) / n + (z * z) / (4 * n * n));
  return { low: Math.max(0, (centre - margin) / d), high: Math.min(1, (centre + margin) / d) };
}

/** Di bawah ambang ini angka persen TIDAK boleh ditampilkan sebagai "akurasi". */
export const MIN_SAMPLE_FOR_RATE = 30;
