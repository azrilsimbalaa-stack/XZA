/**
 * LEDGER PREDIKSI — satu-satunya sumber "win rate" di sistem ini.
 * Prediksi dicatat SAAT dibuat (sebelum hasil diketahui), lalu diselesaikan hanya
 * dengan candle nyata yang terbentuk sesudahnya. Tidak ada hasil yang dikarang.
 */
import type { Candle, Direction } from "./types";
import { MIN_SAMPLE_FOR_RATE, wilson95 } from "./stats";

export type PredictionStatus = "OPEN" | "WIN" | "LOSS" | "EXPIRED";

export interface Prediction {
  id: string;
  symbol: string;
  direction: Direction;
  entry: number;
  sl: number;
  tp1: number;
  createdAt: number;     // ms
  expiresAt: number;     // ms
  score: number;         // skor konfluensi saat dibuat
  status: PredictionStatus;
  resolvedAt?: number;
  rMultiple?: number;    // +RR bila TP, -1 bila SL, hasil mark-to-market (EXPIRED)
  note?: string;
}

/**
 * Selesaikan satu prediksi dengan candle yang dibuka pada/ sesudah createdAt.
 * Aturan konservatif:
 *  - Jika SL dan TP tersentuh pada candle yang sama -> dianggap LOSS (urutan intrabar tidak diketahui).
 *  - Entry dianggap terisi di harga entry pada saat dibuat (market order).
 *  - Kedaluwarsa tanpa menyentuh keduanya -> EXPIRED dengan R mark-to-market.
 */
export function resolvePrediction(p: Prediction, candles: Candle[], now = Date.now()): Prediction {
  if (p.status !== "OPEN") return p;
  const risk = Math.abs(p.entry - p.sl);
  if (!(risk > 0)) return { ...p, status: "EXPIRED", resolvedAt: now, rMultiple: 0, note: "risiko tidak valid" };
  const reward = Math.abs(p.tp1 - p.entry);
  const buy = p.direction === "BUY";
  let lastClose: number | null = null;
  for (const c of candles) {
    if (c.t < p.createdAt) continue;
    if (c.t > p.expiresAt) break;
    lastClose = c.c;
    const hitSl = buy ? c.l <= p.sl : c.h >= p.sl;
    const hitTp = buy ? c.h >= p.tp1 : c.l <= p.tp1;
    if (hitSl) return { ...p, status: "LOSS", resolvedAt: c.t, rMultiple: -1, note: hitTp ? "SL & TP sama candle -> LOSS (konservatif)" : undefined };
    if (hitTp) return { ...p, status: "WIN", resolvedAt: c.t, rMultiple: reward / risk };
  }
  if (now > p.expiresAt) {
    const r = lastClose == null ? 0 : ((buy ? lastClose - p.entry : p.entry - lastClose) / risk);
    return { ...p, status: "EXPIRED", resolvedAt: p.expiresAt, rMultiple: Number(r.toFixed(3)) };
  }
  return p;
}

export interface LedgerSummary {
  n: number;                 // WIN+LOSS (hasil tegas)
  wins: number;
  losses: number;
  expired: number;
  open: number;
  winRate: number | null;    // null bila n < MIN_SAMPLE_FOR_RATE
  rawWinRate: number | null; // selalu dihitung bila n>0, untuk transparansi
  ci95: { low: number; high: number } | null;
  avgR: number | null;       // rata-rata R seluruh hasil tegas + expired
  sufficient: boolean;
  minSample: number;
}

export function summarize(list: Prediction[]): LedgerSummary {
  const wins = list.filter((p) => p.status === "WIN").length;
  const losses = list.filter((p) => p.status === "LOSS").length;
  const expired = list.filter((p) => p.status === "EXPIRED").length;
  const open = list.filter((p) => p.status === "OPEN").length;
  const n = wins + losses;
  const rs = list.filter((p) => p.status !== "OPEN" && typeof p.rMultiple === "number").map((p) => p.rMultiple as number);
  const sufficient = n >= MIN_SAMPLE_FOR_RATE;
  return {
    n, wins, losses, expired, open,
    rawWinRate: n > 0 ? wins / n : null,
    winRate: sufficient ? wins / n : null,
    ci95: n > 0 ? wilson95(wins, n) : null,
    avgR: rs.length ? rs.reduce((a, b) => a + b, 0) / rs.length : null,
    sufficient,
    minSample: MIN_SAMPLE_FOR_RATE,
  };
}
