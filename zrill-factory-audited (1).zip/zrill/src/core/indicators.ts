/**
 * Indikator teknikal murni (tanpa I/O, tanpa data bawaan).
 * Semua fungsi mengembalikan array sepanjang input; nilai sebelum periode
 * pemanasan (warm-up) = null. Tidak ada angka default yang dikarang.
 */
import type { Candle } from "./types";

export type Series = (number | null)[];

export function sma(values: number[], period: number): Series {
  const out: Series = new Array(values.length).fill(null);
  if (period <= 0 || values.length < period) return out;
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= period) sum -= values[i - period];
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

/** EMA diawali SMA(period) pertama (konvensi standar). */
export function ema(values: number[], period: number): Series {
  const out: Series = new Array(values.length).fill(null);
  if (period <= 0 || values.length < period) return out;
  const k = 2 / (period + 1);
  let prev = 0;
  for (let i = 0; i < period; i++) prev += values[i];
  prev /= period;
  out[period - 1] = prev;
  for (let i = period; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

/** RSI Wilder. */
export function rsi(closes: number[], period = 14): Series {
  const out: Series = new Array(closes.length).fill(null);
  if (closes.length <= period) return out;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d >= 0) gain += d; else loss -= d;
  }
  gain /= period; loss /= period;
  out[period] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    gain = (gain * (period - 1) + (d > 0 ? d : 0)) / period;
    loss = (loss * (period - 1) + (d < 0 ? -d : 0)) / period;
    out[i] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  }
  return out;
}

export function trueRange(c: Candle[], i: number): number {
  if (i === 0) return c[0].h - c[0].l;
  const pc = c[i - 1].c;
  return Math.max(c[i].h - c[i].l, Math.abs(c[i].h - pc), Math.abs(c[i].l - pc));
}

/** ATR Wilder. */
export function atr(c: Candle[], period = 14): Series {
  const out: Series = new Array(c.length).fill(null);
  if (c.length <= period) return out;
  let sum = 0;
  for (let i = 1; i <= period; i++) sum += trueRange(c, i);
  let prev = sum / period;
  out[period] = prev;
  for (let i = period + 1; i < c.length; i++) {
    prev = (prev * (period - 1) + trueRange(c, i)) / period;
    out[i] = prev;
  }
  return out;
}

/** ADX + DI (Wilder). */
export function adx(c: Candle[], period = 14): { adx: Series; plusDI: Series; minusDI: Series } {
  const n = c.length;
  const A: Series = new Array(n).fill(null);
  const P: Series = new Array(n).fill(null);
  const M: Series = new Array(n).fill(null);
  if (n < period * 2 + 1) return { adx: A, plusDI: P, minusDI: M };
  let trS = 0, pS = 0, mS = 0;
  for (let i = 1; i <= period; i++) {
    const up = c[i].h - c[i - 1].h;
    const dn = c[i - 1].l - c[i].l;
    trS += trueRange(c, i);
    pS += up > dn && up > 0 ? up : 0;
    mS += dn > up && dn > 0 ? dn : 0;
  }
  const dx: number[] = [];
  const calc = (i: number) => {
    const pdi = trS === 0 ? 0 : (100 * pS) / trS;
    const mdi = trS === 0 ? 0 : (100 * mS) / trS;
    P[i] = pdi; M[i] = mdi;
    const s = pdi + mdi;
    dx.push(s === 0 ? 0 : (100 * Math.abs(pdi - mdi)) / s);
  };
  calc(period);
  for (let i = period + 1; i < n; i++) {
    const up = c[i].h - c[i - 1].h;
    const dn = c[i - 1].l - c[i].l;
    trS = trS - trS / period + trueRange(c, i);
    pS = pS - pS / period + (up > dn && up > 0 ? up : 0);
    mS = mS - mS / period + (dn > up && dn > 0 ? dn : 0);
    calc(i);
  }
  // dx[k] berkorespondensi dengan indeks period + k
  if (dx.length >= period) {
    let a = 0;
    for (let k = 0; k < period; k++) a += dx[k];
    a /= period;
    A[period * 2 - 1] = a;
    for (let k = period; k < dx.length; k++) {
      a = (a * (period - 1) + dx[k]) / period;
      A[period + k] = a;
    }
  }
  return { adx: A, plusDI: P, minusDI: M };
}

export function macd(closes: number[], fast = 12, slow = 26, signal = 9) {
  const ef = ema(closes, fast);
  const es = ema(closes, slow);
  const line: Series = closes.map((_, i) => (ef[i] != null && es[i] != null ? (ef[i] as number) - (es[i] as number) : null));
  const firstIdx = line.findIndex((x) => x != null);
  const sig: Series = new Array(closes.length).fill(null);
  if (firstIdx >= 0) {
    const sub = line.slice(firstIdx) as number[];
    const se = ema(sub, signal);
    for (let i = 0; i < se.length; i++) sig[firstIdx + i] = se[i];
  }
  const hist: Series = line.map((x, i) => (x != null && sig[i] != null ? x - (sig[i] as number) : null));
  return { line, signal: sig, hist };
}

export interface Swing { i: number; price: number; t: number }

/**
 * Swing high/low fraktal: high[i] adalah maksimum ketat di jendela [i-left, i+right].
 * Swing baru terkonfirmasi setelah `right` candle berikutnya -> tidak ada look-ahead
 * jika dipakai hanya pada indeks <= n-1-right.
 */
export function swings(c: Candle[], left = 3, right = 3): { highs: Swing[]; lows: Swing[] } {
  const highs: Swing[] = [], lows: Swing[] = [];
  for (let i = left; i < c.length - right; i++) {
    let isH = true, isL = true;
    for (let k = 1; k <= left && (isH || isL); k++) {
      if (c[i - k].h >= c[i].h) isH = false;
      if (c[i - k].l <= c[i].l) isL = false;
    }
    for (let k = 1; k <= right && (isH || isL); k++) {
      if (c[i + k].h > c[i].h) isH = false;
      if (c[i + k].l < c[i].l) isL = false;
    }
    if (isH) highs.push({ i, price: c[i].h, t: c[i].t });
    if (isL) lows.push({ i, price: c[i].l, t: c[i].t });
  }
  return { highs, lows };
}

export type Trend = "BULLISH" | "BEARISH" | "RANGE";

/** Struktur pasar dari dua swing terakhir tiap sisi: HH+HL = bullish, LH+LL = bearish. */
export function marketStructure(c: Candle[], left = 3, right = 3) {
  const { highs, lows } = swings(c, left, right);
  let trend: Trend = "RANGE";
  let detail = "swing tidak cukup";
  if (highs.length >= 2 && lows.length >= 2) {
    const h1 = highs[highs.length - 1], h0 = highs[highs.length - 2];
    const l1 = lows[lows.length - 1], l0 = lows[lows.length - 2];
    const hh = h1.price > h0.price, hl = l1.price > l0.price;
    const lh = h1.price < h0.price, ll = l1.price < l0.price;
    if (hh && hl) { trend = "BULLISH"; detail = "HH + HL"; }
    else if (lh && ll) { trend = "BEARISH"; detail = "LH + LL"; }
    else detail = hh ? "HH tanpa HL" : lh ? "LH tanpa LL" : "campuran";
  }
  const last = c[c.length - 1];
  const lastHigh = highs[highs.length - 1];
  const lastLow = lows[lows.length - 1];
  // BOS: close menembus swing terakhir searah tren; CHoCH: menembus berlawanan.
  let event: "BOS_UP" | "BOS_DOWN" | "CHOCH_UP" | "CHOCH_DOWN" | null = null;
  if (last && lastHigh && last.c > lastHigh.price) event = trend === "BEARISH" ? "CHOCH_UP" : "BOS_UP";
  else if (last && lastLow && last.c < lastLow.price) event = trend === "BULLISH" ? "CHOCH_DOWN" : "BOS_DOWN";
  return { trend, detail, event, lastHigh: lastHigh ?? null, lastLow: lastLow ?? null, highs, lows };
}

export interface FVG { i: number; dir: "BULL" | "BEAR"; top: number; bottom: number; mitigated: boolean }

/** Fair Value Gap 3-candle; `mitigated` bila harga sesudahnya masuk ke dalam gap. */
export function fairValueGaps(c: Candle[], lookback = 80): FVG[] {
  const out: FVG[] = [];
  const start = Math.max(2, c.length - lookback);
  for (let i = start; i < c.length; i++) {
    const a = c[i - 2], b = c[i];
    if (b.l > a.h) out.push({ i, dir: "BULL", top: b.l, bottom: a.h, mitigated: false });
    else if (b.h < a.l) out.push({ i, dir: "BEAR", top: a.l, bottom: b.h, mitigated: false });
  }
  for (const g of out) {
    for (let j = g.i + 1; j < c.length; j++) {
      if (g.dir === "BULL" && c[j].l <= g.top) { g.mitigated = true; break; }
      if (g.dir === "BEAR" && c[j].h >= g.bottom) { g.mitigated = true; break; }
    }
  }
  return out;
}

/** Sapuan likuiditas pada `window` candle terakhir: wick menembus swing lalu close kembali. */
export function recentLiquiditySweep(c: Candle[], window = 6, left = 3, right = 3) {
  const { highs, lows } = swings(c, left, right);
  const n = c.length;
  for (let i = n - 1; i >= Math.max(1, n - window); i--) {
    for (let k = highs.length - 1; k >= 0; k--) {
      const s = highs[k];
      if (s.i >= i) continue;
      if (c[i].h > s.price && c[i].c < s.price) return { side: "BSL_SWEPT" as const, level: s.price, at: c[i].t };
      break;
    }
    for (let k = lows.length - 1; k >= 0; k--) {
      const s = lows[k];
      if (s.i >= i) continue;
      if (c[i].l < s.price && c[i].c > s.price) return { side: "SSL_SWEPT" as const, level: s.price, at: c[i].t };
      break;
    }
  }
  return null;
}

export function last<T>(s: (T | null)[]): T | null {
  for (let i = s.length - 1; i >= 0; i--) if (s[i] != null) return s[i] as T;
  return null;
}
