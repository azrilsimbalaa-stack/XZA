import { randomUUID } from "crypto";
import type { Candle } from "../core/types";
import { resolvePrediction, summarize, type LedgerSummary, type Prediction } from "../core/ledger";
import type { SignalResult } from "../core/signalCore";
import { loadJson, saveJson } from "./jsonStore";

const FILE = "ledger.json";
const MAX_KEEP = 2000;
let list: Prediction[] = loadJson<Prediction[]>(FILE, []);

/** Cegah duplikasi: satu prediksi OPEN per simbol+arah dalam jendela 4 jam. */
const DEDUPE_MS = 4 * 3_600_000;
const HORIZON_MS = 24 * 3_600_000; // kedaluwarsa 24 jam

export function recordSignal(sig: SignalResult): Prediction | null {
  if (sig.status !== "SIGNAL" || !sig.direction || sig.entry == null || sig.sl == null || sig.tp1 == null) return null;
  const dup = list.find((p) => p.status === "OPEN" && p.symbol === sig.symbol && p.direction === sig.direction && sig.generatedAt - p.createdAt < DEDUPE_MS);
  if (dup) return dup;
  const p: Prediction = {
    id: randomUUID(), symbol: sig.symbol, direction: sig.direction,
    entry: sig.entry, sl: sig.sl, tp1: sig.tp1,
    createdAt: sig.generatedAt, expiresAt: sig.generatedAt + HORIZON_MS,
    score: sig.score, status: "OPEN",
  };
  list.push(p);
  if (list.length > MAX_KEEP) list = list.slice(-MAX_KEEP);
  saveJson(FILE, list);
  return p;
}

export function openSymbols(): string[] {
  return Array.from(new Set(list.filter((p) => p.status === "OPEN").map((p) => p.symbol)));
}

/** Selesaikan semua prediksi OPEN untuk satu simbol memakai candle nyata (M5 disarankan). */
export function resolveOpen(symbol: string, candles: Candle[], now = Date.now()): number {
  let changed = 0;
  list = list.map((p) => {
    if (p.symbol !== symbol || p.status !== "OPEN") return p;
    const r = resolvePrediction(p, candles, now);
    if (r.status !== p.status) changed++;
    return r;
  });
  if (changed) saveJson(FILE, list);
  return changed;
}

export function getSummary(symbol?: string): LedgerSummary {
  return summarize(symbol ? list.filter((p) => p.symbol === symbol) : list);
}

export function getRecent(symbol?: string, limit = 30): Prediction[] {
  return (symbol ? list.filter((p) => p.symbol === symbol) : list).slice(-limit).reverse();
}
