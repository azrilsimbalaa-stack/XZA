/**
 * Feed harga live TradingView (WebSocket). Perbaikan dari versi lama:
 *  - TIDAK ada lagi harga gelombang-sinus/FALLBACK_PRICES: tanpa data nyata -> null.
 *  - Data basi (> maxAgeMs) dianggap tidak ada (pasar tutup / feed putus).
 *  - Panjang frame heartbeat dikoreksi (sebelumnya salah -> koneksi sering putus).
 *  - Venue disimpan terpisah (BTC Binance/Coinbase/Bitstamp tidak lagi saling menimpa).
 *  - Reconnect dengan backoff eksponensial dan timer dibersihkan.
 */
import WebSocket from "ws";

export interface TradingViewPrice {
  symbol: string;
  tradingviewSymbol: string;
  price: number;
  bid: number;
  ask: number;
  ch: number | null;
  chp: number | null;
  volume: number | null;
  high: number | null;
  low: number | null;
  open: number | null;
  updatedAt: number;
  ageMs: number;
}

/** Venue utama per simbol internal; venue lain hanya untuk cross-check. */
const PRIMARY: Record<string, string> = {
  XAUUSD: "OANDA:XAUUSD",
  BTCUSD: "BINANCE:BTCUSDT",
  ETHUSD: "BINANCE:ETHUSDT",
  EURUSD: "OANDA:EURUSD",
  GBPUSD: "OANDA:GBPUSD",
  USDJPY: "OANDA:USDJPY",
  AUDUSD: "OANDA:AUDUSD",
};
const CROSSCHECK: Record<string, string[]> = { BTCUSD: ["COINBASE:BTCUSD", "BITSTAMP:BTCUSD"] };

interface Raw {
  lp?: number; bid?: number; ask?: number; ch?: number; chp?: number; volume?: number;
  high?: number; low?: number; open?: number; updatedAt: number;
}
const venue: Record<string, Raw> = {};

const SUBSCRIBE = Array.from(new Set([...Object.values(PRIMARY), ...Object.values(CROSSCHECK).flat()]));

let ws: WebSocket | null = null;
let hb: NodeJS.Timeout | null = null;
let retry: NodeJS.Timeout | null = null;
let attempt = 0;
let connectedAt = 0;
let lastMessageAt = 0;
let started = false;

const frame = (m: string, p: unknown[]) => { const j = JSON.stringify({ m, p }); return `~m~${j.length}~m~${j}`; };
const session = () => "qs_" + Array.from({ length: 12 }, () => "abcdefghijklmnopqrstuvwxyz"[Math.floor(Math.random() * 26)]).join("");

export function initTradingViewEngine() {
  if (started) return;
  started = true;
  connect();
}

function armWatchdog() {
  if (hb) clearTimeout(hb);
  hb = setTimeout(() => { try { ws?.terminate(); } catch { /* ignore */ } }, 45_000);
}

function scheduleReconnect() {
  if (hb) { clearTimeout(hb); hb = null; }
  if (retry) return;
  const delay = Math.min(30_000, 1000 * 2 ** Math.min(attempt, 5));
  attempt++;
  retry = setTimeout(() => { retry = null; connect(); }, delay);
}

function connect() {
  const s = session();
  try {
    ws = new WebSocket("wss://data.tradingview.com/socket.io/websocket", { headers: { Origin: "https://data.tradingview.com" } });
  } catch (e) {
    console.error("[TV] gagal membuat koneksi:", (e as Error).message);
    scheduleReconnect();
    return;
  }
  const sock = ws;
  sock.on("open", () => {
    attempt = 0;
    connectedAt = Date.now();
    armWatchdog();
    sock.send(frame("quote_create_session", [s]));
    sock.send(frame("quote_set_fields", [s, "lp", "volume", "ch", "chp", "bid", "ask", "high_price", "low_price", "open_price"]));
    for (const sym of SUBSCRIBE) sock.send(frame("quote_add_symbols", [s, sym]));
  });
  sock.on("message", (data: WebSocket.Data) => {
    lastMessageAt = Date.now();
    armWatchdog();
    const str = data.toString();
    // Satu pesan bisa memuat banyak frame: ~m~LEN~m~PAYLOAD
    let pos = 0;
    while (pos < str.length) {
      const m = /^~m~(\d+)~m~/.exec(str.slice(pos));
      if (!m) break;
      const len = parseInt(m[1], 10);
      const start = pos + m[0].length;
      const payload = str.slice(start, start + len);
      pos = start + len;
      if (payload.startsWith("~h~")) {
        // Balas heartbeat: panjang = panjang "~h~<id>" (bug lama memakai panjang <id> saja)
        if (sock.readyState === WebSocket.OPEN) sock.send(`~m~${payload.length}~m~${payload}`);
        continue;
      }
      if (!payload.startsWith("{")) continue;
      try {
        const j = JSON.parse(payload);
        if (j.m === "qsd" && j.p?.[1]?.n) {
          const name: string = j.p[1].n;
          const v = j.p[1].v || {};
          const cur = venue[name] ?? { updatedAt: 0 };
          if (typeof v.lp === "number") cur.lp = v.lp;
          if (typeof v.bid === "number") cur.bid = v.bid;
          if (typeof v.ask === "number") cur.ask = v.ask;
          if (typeof v.ch === "number") cur.ch = v.ch;
          if (typeof v.chp === "number") cur.chp = v.chp;
          if (typeof v.volume === "number") cur.volume = v.volume;
          if (typeof v.high_price === "number") cur.high = v.high_price;
          if (typeof v.low_price === "number") cur.low = v.low_price;
          if (typeof v.open_price === "number") cur.open = v.open_price;
          if (typeof v.lp === "number" || typeof v.bid === "number" || typeof v.ask === "number") cur.updatedAt = Date.now();
          venue[name] = cur;
        }
      } catch { /* frame rusak diabaikan */ }
    }
  });
  sock.on("error", (err: Error) => console.error("[TV] WS error:", err.message));
  sock.on("close", () => { console.warn("[TV] WS tertutup, mencoba ulang..."); scheduleReconnect(); });
}

function norm(symbol: string): string {
  return symbol.toUpperCase().replace(/[^A-Z]/g, "").replace(/USDT$/, "USD");
}

/**
 * Harga live nyata untuk simbol internal, atau null bila belum ada / basi.
 * bid/ask hanya diisi dari data feed; jika feed tidak memberi bid/ask, kembalikan null
 * (UI tidak boleh mengarang spread).
 */
export function getTradingViewPrice(symbol: string, maxAgeMs = 20_000): (TradingViewPrice & { hasQuoteSides: boolean }) | null {
  const sym = norm(symbol);
  const name = PRIMARY[sym];
  if (!name) return null;
  const raw = venue[name];
  if (!raw || raw.updatedAt === 0) return null;
  const ageMs = Date.now() - raw.updatedAt;
  if (ageMs > maxAgeMs) return null;
  const price = raw.lp ?? (raw.bid != null && raw.ask != null ? (raw.bid + raw.ask) / 2 : raw.bid ?? raw.ask);
  if (price == null || !(price > 0)) return null;
  const hasSides = raw.bid != null && raw.ask != null && raw.bid > 0 && raw.ask >= raw.bid;
  return {
    symbol: sym, tradingviewSymbol: name, price,
    bid: hasSides ? (raw.bid as number) : price,
    ask: hasSides ? (raw.ask as number) : price,
    ch: raw.ch ?? null, chp: raw.chp ?? null, volume: raw.volume ?? null,
    high: raw.high ?? null, low: raw.low ?? null, open: raw.open ?? null,
    updatedAt: raw.updatedAt, ageMs, hasQuoteSides: hasSides,
  };
}

/** Selisih (%) antara venue utama dan venue pembanding — untuk mendeteksi data aneh. */
export function crossCheck(symbol: string): { venue: string; price: number; diffPct: number }[] {
  const sym = norm(symbol);
  const main = getTradingViewPrice(sym);
  if (!main) return [];
  const out: { venue: string; price: number; diffPct: number }[] = [];
  for (const name of CROSSCHECK[sym] ?? []) {
    const r = venue[name];
    if (r?.lp && Date.now() - r.updatedAt < 20_000) out.push({ venue: name, price: r.lp, diffPct: ((r.lp - main.price) / main.price) * 100 });
  }
  return out;
}

export function getAllTradingViewPrices(): Record<string, TradingViewPrice> {
  const out: Record<string, TradingViewPrice> = {};
  for (const sym of Object.keys(PRIMARY)) {
    const p = getTradingViewPrice(sym);
    if (p) { const { hasQuoteSides: _h, ...rest } = p; out[sym] = rest; }
  }
  return out;
}

export function getFeedStatus() {
  return {
    connected: ws?.readyState === WebSocket.OPEN,
    connectedAt: connectedAt || null,
    lastMessageAgeMs: lastMessageAt ? Date.now() - lastMessageAt : null,
    reconnectAttempts: attempt,
    liveSymbols: Object.keys(getAllTradingViewPrices()),
  };
}
