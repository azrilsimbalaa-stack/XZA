/**
 * Lapisan data pasar. Aturan keras:
 *  - Hanya data yang benar-benar diambil dari sumber eksternal. Jika semua sumber gagal,
 *    lempar MarketDataError — TIDAK PERNAH mengarang candle atau harga.
 *  - Setiap hasil membawa provenance (sumber, waktu ambil, catatan proxy).
 *  - Input pengguna di-whitelist sebelum masuk ke URL.
 */
import type { Candle, Provenance } from "../core/types";
import { INTERVAL_MS, aggregate, validateCandles } from "../core/candles";

export class MarketDataError extends Error {
  constructor(message: string, public attempts: string[] = []) { super(message); }
}

export const SYMBOLS = ["XAUUSD", "BTCUSD", "ETHUSD", "EURUSD", "GBPUSD", "USDJPY", "AUDUSD"] as const;
export type SymbolId = (typeof SYMBOLS)[number];

export function normalizeSymbol(raw: unknown): SymbolId | null {
  if (typeof raw !== "string") return null;
  const s = raw.toUpperCase().replace(/[^A-Z]/g, "").replace(/USDT$/, "USD");
  return (SYMBOLS as readonly string[]).includes(s) ? (s as SymbolId) : null;
}

export const INTERVALS = ["1m", "5m", "15m", "30m", "1h", "4h", "1d"] as const;
export type IntervalId = (typeof INTERVALS)[number];
export function normalizeInterval(raw: unknown): IntervalId | null {
  return typeof raw === "string" && (INTERVALS as readonly string[]).includes(raw) ? (raw as IntervalId) : null;
}

export function clampLimit(raw: unknown, def = 300, max = 1000): number {
  const n = typeof raw === "string" ? parseInt(raw, 10) : typeof raw === "number" ? raw : NaN;
  if (!Number.isFinite(n) || n <= 0) return def;
  return Math.min(max, n);
}

const UA = "Mozilla/5.0 (compatible; ZrillFactory/6.0)";

async function getJson(url: string, timeoutMs = 5000): Promise<any> {
  const r = await fetch(url, { headers: { "User-Agent": UA, Accept: "application/json" }, signal: AbortSignal.timeout(timeoutMs) });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const text = await r.text();
  try { return JSON.parse(text); } catch { throw new Error("respons bukan JSON"); }
}

export interface CandleResult { candles: Candle[]; provenance: Provenance; issues: string[]; attempts: string[] }

type Fetcher = (sym: SymbolId, interval: IntervalId, limit: number) => Promise<{ candles: Candle[]; note?: string }>;

const fromBinance = (pair: string, note?: string): Fetcher => async (_s, interval, limit) => {
  const data = await getJson(`https://api.binance.com/api/v3/klines?symbol=${pair}&interval=${interval}&limit=${limit}`);
  if (!Array.isArray(data)) throw new Error("format Binance tak dikenal");
  return { candles: data.map((k: any[]) => ({ t: Number(k[0]), o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5] })), note };
};

const CB_GRAN: Partial<Record<IntervalId, number>> = { "1m": 60, "5m": 300, "15m": 900, "1h": 3600, "1d": 86400 };
const fromCoinbase = (product: string): Fetcher => async (_s, interval, limit) => {
  const g = CB_GRAN[interval];
  if (!g) throw new Error(`Coinbase tidak mendukung ${interval}`);
  const data = await getJson(`https://api.exchange.coinbase.com/products/${product}/candles?granularity=${g}`);
  if (!Array.isArray(data)) throw new Error("format Coinbase tak dikenal");
  // [time(s), low, high, open, close, volume]
  const c = data.map((k: number[]) => ({ t: k[0] * 1000, o: k[3], h: k[2], l: k[1], c: k[4], v: k[5] }));
  return { candles: c.sort((a, b) => a.t - b.t).slice(-limit) };
};

const Y_INT: Record<IntervalId, { i: string; range: string }> = {
  "1m": { i: "1m", range: "5d" }, "5m": { i: "5m", range: "1mo" }, "15m": { i: "15m", range: "1mo" },
  "30m": { i: "30m", range: "1mo" }, "1h": { i: "60m", range: "6mo" }, "4h": { i: "60m", range: "6mo" }, "1d": { i: "1d", range: "2y" },
};
const fromYahoo = (ticker: string, note?: string): Fetcher => async (_s, interval, limit) => {
  const cfg = Y_INT[interval];
  const data = await getJson(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?interval=${cfg.i}&range=${cfg.range}`, 6000);
  const r = data?.chart?.result?.[0];
  const ts: number[] = r?.timestamp ?? [];
  const q = r?.indicators?.quote?.[0];
  if (!ts.length || !q) throw new Error("Yahoo tanpa data");
  let c: Candle[] = [];
  for (let i = 0; i < ts.length; i++) {
    if (q.open?.[i] == null || q.high?.[i] == null || q.low?.[i] == null || q.close?.[i] == null) continue;
    c.push({ t: ts[i] * 1000, o: q.open[i], h: q.high[i], l: q.low[i], c: q.close[i], v: q.volume?.[i] ?? 0 });
  }
  if (interval === "4h") c = aggregate(c, INTERVAL_MS["1h"], INTERVAL_MS["4h"]);
  return { candles: c.slice(-limit), note };
};

function chain(sym: SymbolId): { name: string; fn: Fetcher }[] {
  switch (sym) {
    case "XAUUSD":
      return [
        { name: "Yahoo XAUUSD=X", fn: fromYahoo("XAUUSD=X") },
        { name: "Yahoo GC=F (futures emas, proxy)", fn: fromYahoo("GC=F", "proxy: futures COMEX, bukan spot XAUUSD") },
        { name: "Binance PAXGUSDT (token emas, proxy)", fn: fromBinance("PAXGUSDT", "proxy: PAXG, bukan spot XAUUSD") },
      ];
    case "BTCUSD":
      return [
        { name: "Binance BTCUSDT", fn: fromBinance("BTCUSDT", "kuotasi USDT") },
        { name: "Coinbase BTC-USD", fn: fromCoinbase("BTC-USD") },
        { name: "Yahoo BTC-USD", fn: fromYahoo("BTC-USD") },
      ];
    case "ETHUSD":
      return [
        { name: "Binance ETHUSDT", fn: fromBinance("ETHUSDT", "kuotasi USDT") },
        { name: "Coinbase ETH-USD", fn: fromCoinbase("ETH-USD") },
        { name: "Yahoo ETH-USD", fn: fromYahoo("ETH-USD") },
      ];
    default:
      return [{ name: `Yahoo ${sym}=X`, fn: fromYahoo(`${sym}=X`) }];
  }
}

const cache = new Map<string, { at: number; value: CandleResult }>();
const TTL: Record<IntervalId, number> = { "1m": 5_000, "5m": 10_000, "15m": 20_000, "30m": 30_000, "1h": 45_000, "4h": 90_000, "1d": 300_000 };

export async function fetchCandles(sym: SymbolId, interval: IntervalId, limit = 300): Promise<CandleResult> {
  const key = `${sym}|${interval}|${limit}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL[interval]) return hit.value;

  const attempts: string[] = [];
  for (const src of chain(sym)) {
    try {
      const got = await src.fn(sym, interval, limit);
      const v = validateCandles(got.candles);
      if (v.candles.length < Math.min(30, limit)) { attempts.push(`${src.name}: hanya ${v.candles.length} candle valid`); continue; }
      const value: CandleResult = {
        candles: v.candles,
        issues: v.issues,
        attempts,
        provenance: { source: src.name, fetchedAt: Date.now(), note: got.note },
      };
      cache.set(key, { at: Date.now(), value });
      return value;
    } catch (e: any) {
      attempts.push(`${src.name}: ${e?.message || "gagal"}`);
    }
  }
  throw new MarketDataError(`Semua sumber data gagal untuk ${sym} ${interval}`, attempts);
}

/** Candle pada jendela waktu tertentu (untuk audit reaksi berita). Hanya Yahoo/Binance. */
export async function fetchCandlesWindow(sym: SymbolId, interval: IntervalId, startMs: number, endMs: number): Promise<CandleResult> {
  const attempts: string[] = [];
  const s = Math.floor(startMs / 1000), e = Math.ceil(endMs / 1000);
  const yTicker = (t: string, note?: string) => async (): Promise<{ candles: Candle[]; note?: string }> => {
    const cfg = Y_INT[interval];
    const data = await getJson(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(t)}?interval=${cfg.i}&period1=${s}&period2=${e}`, 6000);
    const r = data?.chart?.result?.[0];
    const ts: number[] = r?.timestamp ?? [];
    const q = r?.indicators?.quote?.[0];
    if (!ts.length || !q) throw new Error("Yahoo tanpa data");
    const c: Candle[] = [];
    for (let i = 0; i < ts.length; i++) {
      if (q.open?.[i] == null || q.high?.[i] == null || q.low?.[i] == null || q.close?.[i] == null) continue;
      c.push({ t: ts[i] * 1000, o: q.open[i], h: q.high[i], l: q.low[i], c: q.close[i], v: q.volume?.[i] ?? 0 });
    }
    return { candles: c, note };
  };
  const list: { name: string; fn: () => Promise<{ candles: Candle[]; note?: string }> }[] = [];
  if (sym === "XAUUSD") {
    list.push({ name: "Yahoo XAUUSD=X", fn: yTicker("XAUUSD=X") });
    list.push({ name: "Yahoo GC=F (proxy)", fn: yTicker("GC=F", "proxy: futures COMEX") });
    list.push({ name: "Binance PAXGUSDT (proxy)", fn: async () => {
      const d = await getJson(`https://api.binance.com/api/v3/klines?symbol=PAXGUSDT&interval=${interval}&startTime=${startMs}&endTime=${endMs}&limit=1000`);
      if (!Array.isArray(d)) throw new Error("format Binance tak dikenal");
      return { candles: d.map((k: any[]) => ({ t: Number(k[0]), o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5] })), note: "proxy: PAXG" };
    } });
  } else {
    list.push({ name: `Yahoo ${sym}`, fn: yTicker(sym === "BTCUSD" ? "BTC-USD" : sym === "ETHUSD" ? "ETH-USD" : `${sym}=X`) });
  }
  for (const src of list) {
    try {
      const got = await src.fn();
      const v = validateCandles(got.candles);
      if (!v.candles.length) { attempts.push(`${src.name}: kosong`); continue; }
      return { candles: v.candles, issues: v.issues, attempts, provenance: { source: src.name, fetchedAt: Date.now(), note: got.note } };
    } catch (e: any) { attempts.push(`${src.name}: ${e?.message || "gagal"}`); }
  }
  throw new MarketDataError(`Tidak ada data jendela untuk ${sym}`, attempts);
};

export interface MacroQuote { symbol: string; price: number; prevClose: number; changePct: number; changeAbs: number; asOf: number }

async function yahooQuote(ticker: string): Promise<MacroQuote> {
  const data = await getJson(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?interval=1d&range=5d`, 5000);
  const meta = data?.chart?.result?.[0]?.meta;
  const price = meta?.regularMarketPrice;
  const prev = meta?.chartPreviousClose ?? meta?.previousClose;
  const t = meta?.regularMarketTime;
  if (![price, prev, t].every((x) => typeof x === "number" && Number.isFinite(x)) || prev <= 0) throw new Error("kuotasi tidak lengkap");
  return { symbol: ticker, price, prevClose: prev, changeAbs: price - prev, changePct: ((price - prev) / prev) * 100, asOf: t * 1000 };
}

export interface MacroSnapshot {
  dxy: MacroQuote | null;
  us10y: MacroQuote | null;
  us10yChangeBps: number | null;
  errors: string[];
  provenance: Provenance;
}

let macroCache: { at: number; v: MacroSnapshot } | null = null;
export async function fetchMacro(): Promise<MacroSnapshot> {
  if (macroCache && Date.now() - macroCache.at < 30_000) return macroCache.v;
  const errors: string[] = [];
  const [dxy, tnx] = await Promise.all([
    yahooQuote("DX-Y.NYB").catch((e) => { errors.push(`DXY: ${e.message}`); return null; }),
    yahooQuote("^TNX").catch((e) => { errors.push(`US10Y: ${e.message}`); return null; }),
  ]);
  let us10y = tnx;
  // ^TNX historis dikutip x10 (mis. 42.8 = 4.28%). Normalisasi hanya bila nilainya jelas di luar rentang yield wajar.
  if (us10y && us10y.price > 25) us10y = { ...us10y, price: us10y.price / 10, prevClose: us10y.prevClose / 10, changeAbs: us10y.changeAbs / 10 };
  const bps = us10y ? us10y.changeAbs * 100 : null;
  const v: MacroSnapshot = { dxy, us10y, us10yChangeBps: bps, errors, provenance: { source: "Yahoo Finance (DX-Y.NYB, ^TNX)", fetchedAt: Date.now() } };
  macroCache = { at: Date.now(), v };
  return v;
}
