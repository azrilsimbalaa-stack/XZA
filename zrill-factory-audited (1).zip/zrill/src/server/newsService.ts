/**
 * Berita nyata dari sumber publik. Tidak ada berita cadangan/fiktif: bila sumber gagal,
 * daftar kosong + pesan error. Label sentimen = heuristik kata kunci (reliabilitas RENDAH)
 * dan TIDAK dipakai sebagai input sinyal.
 */
export interface NewsItem {
  id: string; title: string; source: string; url: string; publishedAt: number;
  body: string; category: "CRYPTO" | "FOREX";
  sentiment: "POSITIF" | "NEGATIF" | "NETRAL"; sentimentMethod: "keyword-heuristic";
}

const POS = ["surge", "soar", "rally", "gains", "jumps", "record high", "approval approved", "rate cut", "dovish"];
const NEG = ["plunge", "crash", "slump", "tumbles", "falls", "selloff", "sell-off", "ban", "lawsuit", "hack", "rate hike", "hawkish"];
const has = (t: string, words: string[]) => words.some((w) => new RegExp(`\\b${w.replace(/[-\s]/g, "[-\\s]")}\\b`, "i").test(t));

function label(text: string): NewsItem["sentiment"] {
  const p = has(text, POS), n = has(text, NEG);
  return p && !n ? "POSITIF" : n && !p ? "NEGATIF" : "NETRAL";
}

async function j(url: string): Promise<any> {
  const r = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(5000) });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return JSON.parse(await r.text());
}

const stripHtml = (s: string) => s.replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
const safeUrl = (u: unknown) => (typeof u === "string" && /^https?:\/\//i.test(u) ? u : "");

export async function getNews() {
  const errors: string[] = [];
  const [crypto, forex] = await Promise.all([
    j("https://min-api.cryptocompare.com/data/v2/news/?lang=EN").then((d) => {
      if (!Array.isArray(d?.Data)) throw new Error("format tak dikenal");
      return d.Data.slice(0, 12).map((it: any): NewsItem => ({
        id: `cc-${it.id}`, title: String(it.title || ""), source: it.source_info?.name || "CryptoCompare",
        url: safeUrl(it.url), publishedAt: (Number(it.published_on) || 0) * 1000,
        body: stripHtml(String(it.body || "")).slice(0, 200), category: "CRYPTO",
        sentiment: label(`${it.title} ${it.body || ""}`), sentimentMethod: "keyword-heuristic",
      }));
    }).catch((e) => { errors.push(`CryptoCompare: ${e.message}`); return [] as NewsItem[]; }),
    j("https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fwww.investing.com%2Frss%2Fnews_25.rss").then((d) => {
      if (!Array.isArray(d?.items)) throw new Error("format tak dikenal");
      return d.items.slice(0, 12).map((it: any, i: number): NewsItem => ({
        id: `inv-${i}-${new Date(it.pubDate || 0).getTime()}`, title: String(it.title || ""), source: "Investing.com",
        url: safeUrl(it.link), publishedAt: it.pubDate ? new Date(it.pubDate.replace(" ", "T") + "Z").getTime() || 0 : 0,
        body: stripHtml(String(it.description || "")).slice(0, 200), category: "FOREX",
        sentiment: label(`${it.title} ${it.description || ""}`), sentimentMethod: "keyword-heuristic",
      }));
    }).catch((e) => { errors.push(`Investing.com RSS: ${e.message}`); return [] as NewsItem[]; }),
  ]);
  return { cryptoNews: crypto, forexNews: forex, errors, fetchedAt: Date.now() };
}
