/**
 * Kalender ekonomi nyata (TradingView) + audit reaksi harga emas.
 * Tidak ada jadwal/angka cadangan: jika sumber gagal, kembalikan status UNAVAILABLE
 * (atau cache terakhir yang ditandai stale beserta umurnya).
 */
import { buildComprehensiveEconomicEvent, classifyIndicator, type HistoryContext, type UpgradedEconomicEvent } from "../services/institutionalCalendarEngine";
import { measureReaction, surpriseDirection, summarizeReactions, type ReactionResult } from "../core/eventReaction";
import { INTERVAL_MS } from "../core/candles";
import { fetchCandlesWindow } from "./marketData";
import { loadJson, saveJson } from "./jsonStore";

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36";
const HORIZON_MIN = 15;
const REACTIONS_FILE = "reactions.json";

interface StoredReaction { r: ReactionResult; source: string; at: number }
const reactions: Record<string, StoredReaction> = loadJson(REACTIONS_FILE, {});

let raw: { at: number; items: any[] } | null = null;
let lastError: string | null = null;

async function fetchRaw(): Promise<any[]> {
  const from = new Date(Date.now() - 30 * 86_400_000).toISOString();
  const to = new Date(Date.now() + 14 * 86_400_000).toISOString();
  const url = `https://economic-calendar.tradingview.com/events?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&countries=US`;
  const r = await fetch(url, { headers: { "User-Agent": UA, Origin: "https://www.tradingview.com", Referer: "https://www.tradingview.com/" }, signal: AbortSignal.timeout(6000) });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const j: any = await r.json();
  if (!j || !Array.isArray(j.result)) throw new Error("format kalender tak dikenal");
  return j.result.filter((x: any) => String(x.currency || x.country || "").toUpperCase().match(/^(USD|US)$/));
}

/** Hanya satu event (tertinggi kepentingannya) per timestamp rilis -> sampel independen. */
function independentKey(it: any): string { return String(new Date(it.date).getTime()); }

let resolving = false;
async function resolveReactions(items: any[]) {
  if (resolving) return;
  resolving = true;
  try {
    const now = Date.now();
    const need = items.filter((it) => {
      if (reactions[String(it.id)]) return false;
      const t = new Date(it.date).getTime();
      if (!Number.isFinite(t) || t > now - (HORIZON_MIN + 10) * 60_000) return false;
      if (t < now - 28 * 86_400_000) return false;
      const { higherIsBullishUSD } = classifyIndicator(it.title || "", it.indicator || "");
      const a = parseFloat(String(it.actual)), f = parseFloat(String(it.forecast));
      const dir = surpriseDirection({ actual: Number.isFinite(a) ? a : null, forecast: Number.isFinite(f) ? f : null, higherIsBullishUSD, currency: "USD" });
      return dir !== null && (it.importance ?? -1) >= 0;
    }).slice(0, 12); // batasi beban per siklus; sisanya menyusul siklus berikutnya
    const byTime = new Map<number, any>();
    for (const it of need) { const t = new Date(it.date).getTime(); const cur = byTime.get(t); if (!cur || (it.importance ?? -1) > (cur.importance ?? -1)) byTime.set(t, it); }
    for (const [t, it] of byTime) {
      try {
        const win = await fetchCandlesWindow("XAUUSD", "5m", t - 4 * 3_600_000, t + 2 * 3_600_000);
        const { higherIsBullishUSD } = classifyIndicator(it.title || "", it.indicator || "");
        const dir = surpriseDirection({ actual: parseFloat(String(it.actual)), forecast: parseFloat(String(it.forecast)), higherIsBullishUSD, currency: "USD" });
        const r = measureReaction({ candles: win.candles, intervalMs: INTERVAL_MS["5m"], releaseMs: t, expected: dir, horizonMin: HORIZON_MIN });
        reactions[String(it.id)] = { r, source: win.provenance.source + (win.provenance.note ? ` (${win.provenance.note})` : ""), at: Date.now() };
      } catch (e: any) {
        // gagal ambil harga -> jangan simpan (akan dicoba lagi), jangan mengarang
        console.warn("[calendar] reaksi tertunda:", e?.message);
      }
    }
    saveJson(REACTIONS_FILE, reactions);
  } finally { resolving = false; }
}

export interface CalendarPayload {
  status: "OK" | "STALE" | "UNAVAILABLE";
  result: UpgradedEconomicEvent[];
  source: string;
  fetchedAt: number | null;
  ageMs: number | null;
  error?: string;
  summary: {
    total: number; released: number; upcoming: number; highImpact: number;
    reactionAudit: ReturnType<typeof summarizeReactions> & { independentReleases: number; priceSource: string | null; note: string };
  };
}

export async function getCalendar(): Promise<CalendarPayload> {
  const now = Date.now();
  if (!raw || now - raw.at > 8_000) {
    try { raw = { at: now, items: await fetchRaw() }; lastError = null; }
    catch (e: any) { lastError = e?.message || "gagal"; }
  }
  if (!raw) {
    return { status: "UNAVAILABLE", result: [], source: "TradingView Economic Calendar", fetchedAt: null, ageMs: null, error: lastError ?? "tidak ada data",
      summary: emptySummary() };
  }
  const items = raw.items;
  void resolveReactions(items);

  // Konteks historis per judul dari reaksi terukur (satu per timestamp independen)
  const perTitle = new Map<string, ReactionResult[]>();
  const seen = new Set<string>();
  const sorted = [...items].sort((a, b) => (b.importance ?? -1) - (a.importance ?? -1));
  for (const it of sorted) {
    const k = independentKey(it);
    const s = reactions[String(it.id)];
    if (!s || seen.has(k)) continue;
    seen.add(k);
    const arr = perTitle.get(it.title) ?? [];
    arr.push(s.r);
    perTitle.set(it.title, arr);
  }
  const histFor = (title: string): HistoryContext | null => {
    const arr = perTitle.get(title);
    if (!arr?.length) return null;
    const sm = summarizeReactions(arr);
    const moves = arr.filter((r) => r.move != null).map((r) => Math.abs(r.move as number));
    return { n: arr.length, hit: sm.hit, miss: sm.miss, neutral: sm.neutral, avgAbsMove: moves.length ? moves.reduce((a, b) => a + b, 0) / moves.length : null };
  };

  const events = items.map((it) => buildComprehensiveEconomicEvent(it, now, { reaction: reactions[String(it.id)]?.r ?? null, history: histFor(it.title) }));
  events.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Ringkasan audit: satu event per timestamp rilis (yang kepentingannya tertinggi)
  const indep: ReactionResult[] = [];
  const seen2 = new Set<string>();
  for (const it of sorted) {
    const k = independentKey(it);
    if (seen2.has(k)) continue;
    const s = reactions[String(it.id)];
    if (s) { seen2.add(k); indep.push(s.r); }
  }
  const audit = summarizeReactions(indep);
  const srcs = Array.from(new Set(Object.values(reactions).map((x) => x.source)));
  const stale = now - raw.at > 60_000;
  return {
    status: stale ? "STALE" : "OK",
    result: events,
    source: "TradingView Economic Calendar (US/USD)",
    fetchedAt: raw.at, ageMs: now - raw.at,
    error: stale ? lastError ?? undefined : undefined,
    summary: {
      total: events.length,
      released: events.filter((e) => e.isReleased).length,
      upcoming: events.filter((e) => e.status === "UPCOMING").length,
      highImpact: events.filter((e) => e.importance === 1).length,
      reactionAudit: {
        ...audit, independentReleases: indep.length, priceSource: srcs.length ? srcs.join("; ") : null,
        note: `Menguji aturan kejutan (actual vs forecast) terhadap gerak emas ${HORIZON_MIN} mnt setelah rilis. Persen baru ditampilkan bila n ≥ ${audit.minSample}. Ini BUKAN akurasi prediksi pra-rilis.`,
      },
    },
  };
}

function emptySummary(): CalendarPayload["summary"] {
  return { total: 0, released: 0, upcoming: 0, highImpact: 0, reactionAudit: { ...summarizeReactions([]), independentReleases: 0, priceSource: null, note: "Data kalender tidak tersedia." } };
}
