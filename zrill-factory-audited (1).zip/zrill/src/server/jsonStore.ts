import fs from "fs";
import path from "path";

const DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");

export function loadJson<T>(name: string, fallback: T): T {
  try {
    return JSON.parse(fs.readFileSync(path.join(DIR, name), "utf-8")) as T;
  } catch {
    return fallback;
  }
}

/** Tulis atomik (tmp + rename) agar file tidak rusak bila proses mati di tengah. */
export function saveJson(name: string, data: unknown): void {
  try {
    fs.mkdirSync(DIR, { recursive: true });
    const tmp = path.join(DIR, `${name}.${process.pid}.tmp`);
    fs.writeFileSync(tmp, JSON.stringify(data));
    fs.renameSync(tmp, path.join(DIR, name));
  } catch (e) {
    console.error(`[store] gagal menyimpan ${name}:`, (e as Error).message);
  }
}
