import { analyze, type SignalResult } from "../core/signalCore";
import { aggregate, INTERVAL_MS } from "../core/candles";
import { fetchCandles, fetchMacro, type SymbolId } from "./marketData";
import { getTradingViewPrice } from "./tradingviewService";
import { getCalendar } from "./calendarService";
import { getSummary, recordSignal } from "./ledgerStore";

/** Semua data diambil di server dari sumber nyata; klien tidak boleh menyuplai candle/harga. */
export async function analyzeSymbol(sym: SymbolId): Promise<SignalResult & { recorded: boolean; priceSource: string | null }> {
  const now = Date.now();
  const sources: string[] = [];
  const [m15r, h1r] = await Promise.all([fetchCandles(sym, "15m", 300), fetchCandles(sym, "1h", 500)]);
  sources.push(`M15: ${m15r.provenance.source}${m15r.provenance.note ? " [" + m15r.provenance.note + "]" : ""}`);
  sources.push(`H1: ${h1r.provenance.source}${h1r.provenance.note ? " [" + h1r.provenance.note + "]" : ""}`);
  const h4 = aggregate(h1r.candles, INTERVAL_MS["1h"], INTERVAL_MS["4h"]);

  const live = getTradingViewPrice(sym);
  if (live) sources.push(`Harga live: TradingView ${live.tradingviewSymbol}`);

  let macro = null;
  if (sym === "XAUUSD") {
    const m = await fetchMacro().catch(() => null);
    if (m && (m.dxy || m.us10y)) {
      macro = { dxyChangePct: m.dxy?.changePct ?? null, us10yChangeBps: m.us10yChangeBps, asOf: Math.max(m.dxy?.asOf ?? 0, m.us10y?.asOf ?? 0) };
      sources.push(m.provenance.source);
    }
  }

  const cal = await getCalendar().catch(() => null);
  const events = (cal?.result ?? []).filter((e) => e.status === "UPCOMING" || e.status === "RELEASED")
    .map((e) => ({ title: e.title, dateMs: new Date(e.date).getTime(), importance: e.importance, currency: e.currency }));

  const sig = analyze({
    symbol: sym, now, m15: m15r.candles, h1: h1r.candles, h4,
    livePrice: live && live.hasQuoteSides ? { bid: live.bid, ask: live.ask, updatedAt: live.updatedAt } : live ? { bid: live.price, ask: live.price, updatedAt: live.updatedAt } : null,
    macro, events: cal && cal.status !== "UNAVAILABLE" ? events : undefined,
    trackRecord: getSummary(sym), sources,
  });
  if (!cal || cal.status === "UNAVAILABLE") {
    // Tanpa kalender, risiko rilis berita tidak dapat diverifikasi -> jangan keluarkan sinyal.
    sig.dataQuality.issues.push("Kalender tidak tersedia: filter berita tidak dapat diverifikasi");
    sig.dataQuality.ok = false;
    if (sig.status === "SIGNAL") {
      sig.status = "NO_TRADE"; sig.direction = null; sig.entry = sig.sl = sig.tp1 = sig.tp2 = sig.rr1 = sig.rr2 = null;
      sig.reasons = ["Filter berita tidak dapat diverifikasi (kalender tidak tersedia)."];
    }
  }
  const rec = recordSignal(sig);
  return { ...sig, recorded: !!rec, priceSource: live ? live.tradingviewSymbol : null };
}
