/**
 * Verifikasi kode membership yang BENAR: format PLAN.YYYYMMDD.SIG
 *  SIG = 10 hex pertama HMAC-SHA256(MEMBERSHIP_SECRET, "PLAN.YYYYMMDD").
 * Versi lama menerima kode 8 karakter apa pun dan kode override yang tertanam di source.
 */
import { createHmac, timingSafeEqual } from "crypto";

export type Plan = "WEEKLY" | "BIWEEKLY" | "MONTHLY";
const PLANS: Plan[] = ["WEEKLY", "BIWEEKLY", "MONTHLY"];

export function signCode(plan: Plan, expiry: string, secret: string): string {
  const body = `${plan}.${expiry}`;
  return `${body}.${createHmac("sha256", secret).update(body).digest("hex").slice(0, 10)}`;
}

export function verifyCode(code: unknown, secret: string | undefined, now = Date.now()):
  { ok: true; plan: Plan; expiry: string } | { ok: false; status: number; error: string } {
  if (!secret) return { ok: false, status: 501, error: "Verifikasi membership belum dikonfigurasi (MEMBERSHIP_SECRET kosong)" };
  if (typeof code !== "string" || code.length > 64) return { ok: false, status: 400, error: "Kode tidak valid" };
  const m = /^(WEEKLY|BIWEEKLY|MONTHLY)\.(\d{8})\.([0-9a-f]{10})$/.exec(code.trim());
  if (!m) return { ok: false, status: 400, error: "Kode tidak valid" };
  const [, plan, expiry, sig] = m;
  const expected = signCode(plan as Plan, expiry, secret).split(".")[2];
  const a = Buffer.from(sig), b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return { ok: false, status: 400, error: "Kode tidak valid" };
  const y = +expiry.slice(0, 4), mo = +expiry.slice(4, 6) - 1, d = +expiry.slice(6, 8);
  const end = Date.UTC(y, mo, d, 23, 59, 59);
  if (!PLANS.includes(plan as Plan) || !Number.isFinite(end)) return { ok: false, status: 400, error: "Kode tidak valid" };
  if (now > end) return { ok: false, status: 403, error: "Kode kedaluwarsa" };
  return { ok: true, plan: plan as Plan, expiry };
}
