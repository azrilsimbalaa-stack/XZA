# Karantina

Berisi kode LAMA yang tidak ikut build karena menghasilkan data/klaim karangan atau berbahaya.
Disimpan (bukan dihapus) agar bisa Anda tinjau; **jangan dipulihkan ke `src/`**.

- `src/services/precisionSignalEngine.ts`, `chartPatternEngine.ts`, `realtimeFundamentalStreamEngine.ts`, `assetNewsIntelligenceService.ts`, `workers/smcWorker.ts`, `components/*` — skor/win rate/probabilitas tertanam, berita & pernyataan tokoh nyata fiktif, latensi `Math.random`. Tidak diimpor kode aktif.
- `src/services/institutionalCalendarEngine.OLD.ts`, `root/server.OLD.ts`, `root/App.OLD.tsx` — versi sebelum audit (untuk diff).
- `root/vinzx_bundle.js`, `root/*.cjs`, `root/dump.txt`, `root/patch*` — build usang & skrip tambal sulam.
- `public/project-source.zip` — zip terpotong/rusak yang sebelumnya disajikan publik.
- `vendor/tradingview-*-repo` — repo pihak ketiga yang tidak dipakai aplikasi.
