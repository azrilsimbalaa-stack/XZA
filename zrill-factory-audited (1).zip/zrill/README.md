# Zrill Factory

Dashboard kalender ekonomi + analisis teknikal XAUUSD/kripto. Prinsip proyek: **tidak ada angka dikarang**.
Kode hanya berisi logika; data berasal dari sumber nyata dan, bila tidak ada, sistem berkata "tidak ada".

## Menjalankan
```
npm install
cp .env.example .env     # isi MEMBERSHIP_SECRET bila memakai verifikasi kode
npm run dev              # http://localhost:3000
npm test                 # 37 tes (logika murni, ledger, kalender, "tanpa data = tanpa karangan")
npm run lint             # typecheck (butuh npm install)
```

## Arsitektur
| Lapisan | File | Tugas |
|---|---|---|
| Inti murni | `src/core/*` | Indikator, struktur pasar, FVG, sinyal, ledger, uji reaksi berita. Tanpa I/O, tanpa data bawaan. |
| Data | `src/server/marketData.ts`, `tradingviewService.ts` | Candle & harga nyata dengan provenance. Semua gagal → error, bukan data karangan. |
| Kalender | `src/server/calendarService.ts`, `src/services/institutionalCalendarEngine.ts` | Kalender TradingView + uji aturan kejutan terhadap harga emas nyata. |
| Ledger | `src/server/ledgerStore.ts` | Satu-satunya sumber win rate: prediksi dicatat saat dibuat, diselesaikan oleh candle nyata. |

## Cara membaca keluaran (penting)
- **`score` sinyal = keselarasan indikator (−1..+1), bukan probabilitas.**
- **Win rate** hanya muncul dari `/api/ledger` dan baru berupa persen bila n ≥ 30 (disertai interval Wilson 95%).
- **Kalender**: sebelum rilis arah = NETRAL (hanya skenario hot/in-line/soft). Setelah rilis, aturan *kejutan* (actual vs forecast) diuji ke gerak emas 15 menit; di bawah n = 30 tidak ada persen.
- Sinyal bisa `NO_TRADE` (konfluensi lemah, sideways, melawan H4, rilis berita dekat, data basi, kalender tak tersedia) atau `DATA_INSUFFICIENT`.
- Proksi emas (futures GC=F / PAXG) selalu diberi label di `provenance.note`.

## Batas yang jujur
Ambang sinyal (`THRESHOLDS`) adalah heuristik **belum tervalidasi**. Jangan percaya sebelum ledger Anda mengumpulkan sampel cukup.
Hasil ledger sedikit optimistis ≤ 1 candle M5 (candle yang berjalan saat sinyal dibuat dilewati). Ini bukan nasihat keuangan.

Detail audit: `AUDIT.md`. Kode lama yang dikarantina: `_quarantine/` (tidak ikut build).
