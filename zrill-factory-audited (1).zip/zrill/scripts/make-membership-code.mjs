// Pemakaian: MEMBERSHIP_SECRET=... node scripts/make-membership-code.mjs MONTHLY 20261231
import { createHmac } from "crypto";
const [plan, expiry] = process.argv.slice(2);
const secret = process.env.MEMBERSHIP_SECRET;
if (!secret || !["WEEKLY", "BIWEEKLY", "MONTHLY"].includes(plan) || !/^\d{8}$/.test(expiry || "")) {
  console.error("Pemakaian: MEMBERSHIP_SECRET=... node scripts/make-membership-code.mjs <WEEKLY|BIWEEKLY|MONTHLY> <YYYYMMDD>");
  process.exit(1);
}
const body = `${plan}.${expiry}`;
console.log(`${body}.${createHmac("sha256", secret).update(body).digest("hex").slice(0, 10)}`);
