import test from "node:test";
import assert from "node:assert/strict";
import fs from "fs";
import os from "os";
import path from "path";

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), "zrill-"));

import { MarketDataError, clampLimit, fetchCandles, fetchMacro, normalizeInterval, normalizeSymbol } from "../src/server/marketData";
import { getCalendar } from "../src/server/calendarService";
import { HOUR } from "./helpers";

const realFetch = globalThis.fetch;
const jsonRes = (body: unknown, ok = true) => new Response(JSON.stringify(body), { status: ok ? 200 : 500 });
test.afterEach(() => { globalThis.fetch = realFetch; });

test("whitelist simbol/interval/limit — input berbahaya ditolak", () => {
  assert.equal(normalizeSymbol("xauusd"), "XAUUSD");
  assert.equal(normalizeSymbol("BTCUSDT"), "BTCUSD");
  assert.equal(normalizeSymbol("XAUUSD&limit=1/../../x"), null);
  assert.equal(normalizeSymbol({} as any), null);
  assert.equal(normalizeInterval("5m"), "5m"); assert.equal(normalizeInterval("5m;rm"), null);
  assert.equal(clampLimit("999999"), 1000); assert.equal(clampLimit("abc"), 300); assert.equal(clampLimit("-5"), 300);
});

test("SEMUA sumber gagal -> MarketDataError; tidak ada candle karangan", async () => {
  globalThis.fetch = (async () => { throw new Error("jaringan putus"); }) as any;
  await assert.rejects(() => fetchCandles("XAUUSD", "1h", 100), (e: any) => e instanceof MarketDataError && e.attempts.length >= 3);
  await assert.rejects(() => fetchCandles("BTCUSD", "30m", 100), MarketDataError);
});

test("sumber pertama gagal -> jatuh ke sumber berikut, provenance mencatat sumber nyata + catatan proxy", async () => {
  const t0 = Math.floor(Date.now() / 3_600_000) * 3_600_000 - 200 * 3_600_000;
  const ts = Array.from({ length: 150 }, (_, i) => Math.floor((t0 + i * 3_600_000) / 1000));
  const q = { open: ts.map((_, i) => 2000 + i), high: ts.map((_, i) => 2002 + i), low: ts.map((_, i) => 1998 + i), close: ts.map((_, i) => 2001 + i), volume: ts.map(() => 5) };
  globalThis.fetch = (async (url: string) => {
    if (url.includes("XAUUSD%3DX") || url.includes("XAUUSD=X")) return jsonRes({}, false);          // sumber 1 gagal
    if (url.includes("GC%3DF") || url.includes("GC=F")) return jsonRes({ chart: { result: [{ timestamp: ts, indicators: { quote: [q] } }] } });
    throw new Error("tak terduga " + url);
  }) as any;
  const r = await fetchCandles("XAUUSD", "1h", 150);
  assert.match(r.provenance.source, /GC=F/);
  assert.match(r.provenance.note ?? "", /proxy/);
  assert.equal(r.candles.length, 150);
  assert.ok(r.attempts.length >= 1);
});

test("candle rusak dari sumber dibuang; jika sisa terlalu sedikit sumber dianggap gagal", async () => {
  const bad = Array.from({ length: 60 }, (_, i) => [Date.now() - i * 60000, "10", "9", "11", "10", "1"]); // high<low
  globalThis.fetch = (async () => jsonRes(bad)) as any;
  await assert.rejects(() => fetchCandles("BTCUSD", "1m", 60), MarketDataError);
});

test("makro: bila gagal -> null + daftar error (tanpa DXY/yield karangan)", async () => {
  globalThis.fetch = (async () => { throw new Error("x"); }) as any;
  const m = await fetchMacro();
  assert.equal(m.dxy, null); assert.equal(m.us10y, null); assert.equal(m.us10yChangeBps, null);
  assert.ok(m.errors.length >= 1);
});

test("kalender: sumber gagal -> UNAVAILABLE dan result KOSONG (versi lama mengisi jadwal NFP/CPI/FOMC palsu)", async () => {
  globalThis.fetch = (async () => { throw new Error("blocked"); }) as any;
  const c = await getCalendar();
  assert.equal(c.status, "UNAVAILABLE");
  assert.equal(c.result.length, 0);
  assert.equal(c.summary.reactionAudit.n, 0);
  assert.equal(c.summary.reactionAudit.rate, null);
});

test("kalender end-to-end: reaksi harga diukur dari candle nyata (stub), audit tidak menampilkan persen saat n kecil", async () => {
  const now = Date.now();
  const rel = Math.floor((now - 3 * HOUR) / 300_000) * 300_000; // selaras 5 menit
  const iso = new Date(rel).toISOString();
  const tv = { result: [
    { id: "cpi1", title: "Core CPI MoM", currency: "USD", country: "US", importance: 1, forecast: 0.3, previous: 0.2, actual: 0.5, unit: "%", date: iso },
    { id: "nfp-future", title: "Non Farm Payrolls", currency: "USD", country: "US", importance: 1, forecast: 150, previous: 140, actual: null, unit: "K", date: new Date(now + 2 * HOUR).toISOString() },
  ] };
  // candle 5m nyata-stub: harga turun setelah rilis (selaras aturan SELL untuk CPI panas)
  const start = rel - 4 * HOUR;
  const ts: number[] = [], o: number[] = [], h: number[] = [], l: number[] = [], c: number[] = [];
  for (let t = start; t < rel + 2 * HOUR; t += 300_000) {
    const px = t < rel ? 2000 + ((t / 300_000) % 2 ? 0.4 : -0.4) : 2000 - 0.5 * ((t - rel) / 300_000);
    ts.push(Math.floor(t / 1000)); o.push(px); h.push(px + 0.6); l.push(px - 0.6); c.push(px);
  }
  globalThis.fetch = (async (url: string) => {
    if (url.includes("economic-calendar.tradingview.com")) return jsonRes(tv);
    if (url.includes("finance/chart")) return jsonRes({ chart: { result: [{ timestamp: ts, indicators: { quote: [{ open: o, high: h, low: l, close: c, volume: ts.map(() => 1) }] } }] } });
    throw new Error("tak terduga " + url);
  }) as any;
  const first = await getCalendar();
  assert.equal(first.status, "OK");
  await new Promise((r) => setTimeout(r, 300)); // beri waktu resolver latar belakang
  const second = await getCalendar();
  const cpi = second.result.find((e) => e.id === "cpi1")!;
  assert.equal(cpi.prediction.direction, "SELL");
  assert.equal(cpi.reaction?.verdict, "HIT", JSON.stringify(cpi.reaction));
  assert.equal(cpi.isPredictionCorrect, true);
  assert.match(cpi.pipsGain, /USD\/oz/);
  const nfp = second.result.find((e) => e.id === "nfp-future")!;
  assert.equal(nfp.status, "UPCOMING"); assert.equal(nfp.isPredictionCorrect, null); assert.equal(nfp.prediction.direction, "NETRAL");
  assert.equal(second.summary.reactionAudit.hit, 1);
  assert.equal(second.summary.reactionAudit.rate, null, "n=1 tidak boleh menjadi persen akurasi");
});
