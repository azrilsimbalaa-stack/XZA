import type { Candle } from "../src/core/types";

/** PRNG deterministik (LCG) khusus fixture uji. */
export function rng(seed: number) {
  let s = seed >>> 0;
  return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
}

/**
 * Bangun deret M15 sintetis KHUSUS UJI: drift + gelombang + noise kecil.
 * Dipakai hanya untuk menguji perilaku fungsi, tidak pernah di jalur produksi.
 */
export function buildM15(opts: { bars: number; endMs: number; start: number; drift: number; amp: number; period: number; noise: number; seed?: number }): Candle[] {
  const r = rng(opts.seed ?? 7);
  const step = 900_000;
  const t0 = opts.endMs - opts.bars * step;
  const out: Candle[] = [];
  const f = (i: number) => opts.start + opts.drift * i + opts.amp * Math.sin((2 * Math.PI * i) / opts.period);
  let prev = f(0);
  for (let i = 0; i < opts.bars; i++) {
    const o = prev;
    const c = f(i + 1) + (r() - 0.5) * opts.noise;
    const h = Math.max(o, c) + r() * opts.noise;
    const l = Math.min(o, c) - r() * opts.noise;
    out.push({ t: t0 + i * step, o, h, l, c, v: 100 });
    prev = c;
  }
  return out;
}

export const HOUR = 3_600_000;
/** Titik akhir selaras jam penuh agar agregasi H1/H4 punya bucket lengkap. */
export function alignedNow(): number {
  return Math.floor(Date.UTC(2026, 5, 10, 12, 0, 0) / (4 * HOUR)) * (4 * HOUR) + 4 * HOUR + 60_000;
}
