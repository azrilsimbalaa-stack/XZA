import test from "node:test";
import assert from "node:assert/strict";
import { analyze, THRESHOLDS } from "../src/core/signalCore";
import { aggregate } from "../src/core/candles";
import { buildComprehensiveEconomicEvent } from "../src/services/institutionalCalendarEngine";
import { signCode, verifyCode } from "../src/server/membership";
import { HOUR, alignedNow, buildM15 } from "./helpers";

const NOW = alignedNow();

function series(kind: "up" | "down" | "flat") {
  const drift = kind === "up" ? 0.5 : kind === "down" ? -0.5 : 0;
  const all = buildM15({ bars: 2000, endMs: NOW - 60_000, start: kind === "down" ? 4000 : 2000, drift: drift / 4, amp: 6, period: 96, noise: 0.4 });
  const h1 = aggregate(all, 900_000, HOUR);
  return { m15: all.slice(-300), h1 };
}

test("DATA_INSUFFICIENT bila candle kurang — tidak memaksa sinyal", () => {
  const { m15, h1 } = series("up");
  const r = analyze({ symbol: "XAUUSD", now: NOW, m15: m15.slice(-20), h1: h1.slice(-30) });
  assert.equal(r.status, "DATA_INSUFFICIENT");
  assert.equal(r.direction, null); assert.equal(r.entry, null);
  assert.ok(r.dataQuality.issues.length > 0);
});

test("data basi (pasar tutup/feed putus) -> NO_TRADE", () => {
  const { m15, h1 } = series("up");
  const r = analyze({ symbol: "XAUUSD", now: NOW + 5 * HOUR, m15, h1 });
  assert.equal(r.status, "NO_TRADE");
  assert.match(r.dataQuality.issues[0], /basi/);
});

test("tren naik: bila SIGNAL maka BUY & geometri SL<entry<TP1<TP2; arah mengikuti skor", () => {
  const { m15, h1 } = series("up");
  const r = analyze({ symbol: "XAUUSD", now: NOW, m15, h1 });
  assert.ok(r.score > 0, `skor harus positif pada tren naik, dapat ${r.score}`);
  if (r.status === "SIGNAL") {
    assert.equal(r.direction, "BUY");
    assert.ok(r.sl! < r.entry! && r.entry! < r.tp1! && r.tp1! < r.tp2!);
    const risk = r.entry! - r.sl!;
    assert.ok(Math.abs((r.tp1! - r.entry!) / risk - THRESHOLDS.rr1) < 0.02);
    assert.ok(risk >= THRESHOLDS.slAtrMin * r.atr! - 0.02 && risk <= THRESHOLDS.slAtrMax * r.atr! + 0.02);
  }
});

test("tren turun: skor negatif; bila SIGNAL maka SELL dengan SL di atas entry", () => {
  const { m15, h1 } = series("down");
  const r = analyze({ symbol: "XAUUSD", now: NOW, m15, h1 });
  assert.ok(r.score < 0);
  if (r.status === "SIGNAL") {
    assert.equal(r.direction, "SELL");
    assert.ok(r.sl! > r.entry! && r.entry! > r.tp1! && r.tp1! > r.tp2!);
  }
});

test("sideways tidak menghasilkan SIGNAL", () => {
  const { m15, h1 } = series("flat");
  const r = analyze({ symbol: "XAUUSD", now: NOW, m15, h1 });
  assert.notEqual(r.status, "SIGNAL", JSON.stringify({ s: r.score, reasons: r.reasons }));
});

test("rilis berdampak tinggi dekat -> NO_TRADE dengan alasan", () => {
  const { m15, h1 } = series("up");
  const free = analyze({ symbol: "XAUUSD", now: NOW, m15, h1 });
  const blocked = analyze({ symbol: "XAUUSD", now: NOW, m15, h1, events: [{ title: "CPI", dateMs: NOW + 5 * 60_000, importance: 1, currency: "USD" }] });
  if (free.status === "SIGNAL") {
    assert.equal(blocked.status, "NO_TRADE");
    assert.ok(blocked.reasons.some((x) => /CPI/.test(x)));
  }
  const lowImp = analyze({ symbol: "XAUUSD", now: NOW, m15, h1, events: [{ title: "x", dateMs: NOW + 5 * 60_000, importance: 0, currency: "USD" }] });
  assert.equal(lowImp.status, free.status);
});

test("faktor makro hanya masuk jika datanya ada; tanpa data = faktor tidak ada (bukan default)", () => {
  const { m15, h1 } = series("up");
  const none = analyze({ symbol: "XAUUSD", now: NOW, m15, h1, macro: null });
  assert.ok(!none.factors.some((f) => f.key === "macro"));
  const withM = analyze({ symbol: "XAUUSD", now: NOW, m15, h1, macro: { dxyChangePct: -0.4, us10yChangeBps: -6, asOf: NOW - 60_000 } });
  assert.ok(withM.factors.find((f) => f.key === "macro")!.value > 0);
  const stale = analyze({ symbol: "XAUUSD", now: NOW, m15, h1, macro: { dxyChangePct: -0.4, us10yChangeBps: -6, asOf: NOW - 12 * HOUR } });
  assert.ok(!stale.factors.some((f) => f.key === "macro"), "makro basi harus dibuang");
  const btc = analyze({ symbol: "BTCUSD", now: NOW, m15, h1, macro: { dxyChangePct: -0.4, us10yChangeBps: -6, asOf: NOW } });
  assert.ok(!btc.factors.some((f) => f.key === "macro"));
});

test("harga live menyimpang jauh dari candle diabaikan & dilaporkan", () => {
  const { m15, h1 } = series("up");
  const r = analyze({ symbol: "XAUUSD", now: NOW, m15, h1, livePrice: { bid: 99999, ask: 100000, updatedAt: NOW - 1000 } });
  assert.ok(r.dataQuality.issues.some((x) => /menyimpang/.test(x)));
});

test("hasil analisis tidak memuat klaim akurasi/probabilitas bawaan; track record hanya dari ledger", () => {
  const { m15, h1 } = series("up");
  const r = analyze({ symbol: "XAUUSD", now: NOW, m15, h1 });
  const blob = JSON.stringify(r);
  assert.doesNotMatch(blob, /confidence|winRate|akurasi|AAA|guarantee|terverifikasi/i);
  assert.equal(r.trackRecord, null);
  assert.match(r.meaning, /BUKAN probabilitas/);
});

// ---------- Regresi bug sirkular kalender ----------
const rel = { id: "e1", title: "US Core CPI (MoM)", currency: "USD", country: "US", importance: 1, forecast: "0.3", previous: "0.2", actual: "0.5", unit: "%", date: new Date(NOW - 3 * HOUR).toISOString() };

test("kalender: rilis TANPA reaksi harga terukur TIDAK PERNAH dinilai benar (bug lama: selalu 100%)", () => {
  const ev = buildComprehensiveEconomicEvent(rel, NOW);
  assert.equal(ev.isPredictionCorrect, null);
  assert.equal(ev.accuracyStatus, "TIDAK_TERUKUR");
  assert.equal(ev.pipsGain, "—");
  assert.equal(ev.prediction.confidence, null);
  assert.equal(ev.prediction.peganganKuat.anchorScore, null);
  assert.equal(ev.spikePrediction.spikeProbability, null);
});

test("kalender: nilai benar/salah HANYA dari reaksi harga yang diukur", () => {
  const base = { horizonMin: 15, threshold: 1, basePrice: 2000, expected: "SELL" as const };
  const hit = buildComprehensiveEconomicEvent(rel, NOW, { reaction: { ...base, verdict: "HIT", move: -6, endPrice: 1994 } });
  assert.equal(hit.isPredictionCorrect, true);
  const miss = buildComprehensiveEconomicEvent(rel, NOW, { reaction: { ...base, verdict: "MISS", move: 6, endPrice: 2006 } });
  assert.equal(miss.isPredictionCorrect, false);
  const neu = buildComprehensiveEconomicEvent(rel, NOW, { reaction: { ...base, verdict: "NEUTRAL", move: 0.1, endPrice: 2000.1 } });
  assert.equal(neu.isPredictionCorrect, null); assert.equal(neu.accuracyStatus, "NETRAL");
});

test("kalender: CPI di atas forecast -> aturan SELL emas; pengangguran di atas forecast -> BUY", () => {
  assert.equal(buildComprehensiveEconomicEvent(rel, NOW).prediction.direction, "SELL");
  const u = buildComprehensiveEconomicEvent({ ...rel, id: "u", title: "US Unemployment Rate", forecast: "4.0", actual: "4.3" }, NOW);
  assert.equal(u.prediction.direction, "BUY");
});

test("kalender: sebelum rilis arah = NETRAL, tidak ada angka aktual 'perkiraan AI', tanpa forecast tidak default BUY", () => {
  const up = buildComprehensiveEconomicEvent({ ...rel, actual: null, date: new Date(NOW + HOUR).toISOString() }, NOW);
  assert.equal(up.status, "UPCOMING");
  assert.equal(up.prediction.direction, "NETRAL");
  assert.equal(up.estimatedActual, "---");
  const noFc = buildComprehensiveEconomicEvent({ ...rel, actual: null, forecast: null, date: new Date(NOW + HOUR).toISOString() }, NOW);
  assert.equal(noFc.prediction.direction, "NETRAL");
});

test("kalender: waktu lewat tanpa angka aktual = MENUNGGU ANGKA, bukan 'dirilis'", () => {
  const ev = buildComprehensiveEconomicEvent({ ...rel, actual: null }, NOW);
  assert.equal(ev.status, "AWAITING_DATA"); assert.equal(ev.isReleased, false);
});

test("kalender: tidak ada klaim akurasi/win rate hardcode di keluaran", () => {
  const ev = buildComprehensiveEconomicEvent(rel, NOW);
  assert.doesNotMatch(JSON.stringify(ev), /9[0-9]\.[0-9]%|100%|BULLSEYE|Bloomberg|bocoran|A1 Institutional/i);
});

// ---------- Membership ----------
test("membership: kode valid lolos; dirusak/ kedaluwarsa/ tanpa secret ditolak; kode lama 8-karakter ditolak", () => {
  const secret = "rahasia-uji-panjang";
  const code = signCode("MONTHLY", "20261231", secret);
  const ok = verifyCode(code, secret, Date.UTC(2026, 10, 11));
  assert.equal(ok.ok, true);
  assert.equal(verifyCode(code.slice(0, -1) + (code.endsWith("0") ? "1" : "0"), secret, Date.UTC(2026, 10, 11)).ok, false);
  const exp = verifyCode(code, secret, Date.UTC(2027, 0, 2));
  assert.equal(exp.ok, false); assert.equal((exp as any).status, 403);
  assert.equal((verifyCode(code, undefined) as any).status, 501);
  for (const legacy of ["WEEK1", "AZR_OVERRIDE", "AZRIL", "ABCDEFGH", "AZR_MONTHLY"]) assert.equal(verifyCode(legacy, secret).ok, false);
  assert.equal(verifyCode(code, "secret-lain", Date.UTC(2026, 10, 11)).ok, false);
});
