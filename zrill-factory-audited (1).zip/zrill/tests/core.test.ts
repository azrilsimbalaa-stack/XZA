import test from "node:test";
import assert from "node:assert/strict";
import { adx, atr, ema, fairValueGaps, macd, marketStructure, rsi, sma, swings } from "../src/core/indicators";
import { aggregate, closedOnly, validateCandles } from "../src/core/candles";
import { resolvePrediction, summarize, type Prediction } from "../src/core/ledger";
import { wilson95 } from "../src/core/stats";
import { measureReaction, summarizeReactions, surpriseDirection } from "../src/core/eventReaction";
import type { Candle } from "../src/core/types";

const mk = (t: number, o: number, h: number, l: number, c: number): Candle => ({ t, o, h, l, c, v: 1 });

test("sma/ema nilai acuan benar & warm-up = null", () => {
  assert.deepEqual(sma([1, 2, 3, 4, 5], 3), [null, null, 2, 3, 4]);
  const e = ema([1, 2, 3, 4, 5], 3);
  assert.equal(e[1], null);
  assert.equal(e[2], 2);               // SMA awal
  assert.equal(e[3], 3);               // 4*0.5 + 2*0.5
  assert.equal(e[4], 4);
});

test("RSI: naik terus = 100, turun terus = 0, tanpa angka bawaan saat data pendek", () => {
  const up = rsi(Array.from({ length: 30 }, (_, i) => 100 + i), 14);
  assert.equal(up[29], 100);
  const dn = rsi(Array.from({ length: 30 }, (_, i) => 100 - i), 14);
  assert.equal(dn[29], 0);
  assert.ok(rsi([1, 2, 3], 14).every((x) => x === null));
});

test("ATR range konstan = range itu; deret pendek = null", () => {
  const c = Array.from({ length: 40 }, (_, i) => mk(i * 60000, 100, 102, 98, 100));
  assert.ok(Math.abs((atr(c, 14)[39] as number) - 4) < 1e-9);
  assert.ok(atr(c.slice(0, 10), 14).every((x) => x === null));
});

test("ADX tinggi pada tren lurus, rendah pada zigzag", () => {
  const trend = Array.from({ length: 80 }, (_, i) => mk(i, 100 + i, 101 + i, 99.5 + i, 100.8 + i));
  assert.ok((adx(trend, 14).adx[79] as number) > 40);
  const zig = Array.from({ length: 80 }, (_, i) => { const b = 100 + (i % 2 ? 1 : -1); return mk(i, b, b + 0.6, b - 0.6, b); });
  assert.ok((adx(zig, 14).adx[79] as number) < 20);
});

test("MACD histogram = line - signal", () => {
  const closes = Array.from({ length: 80 }, (_, i) => 100 + Math.sin(i / 5) * 3 + i * 0.1);
  const m = macd(closes);
  const i = 79;
  assert.ok(Math.abs((m.hist[i] as number) - ((m.line[i] as number) - (m.signal[i] as number))) < 1e-12);
});

test("swing & struktur: HH+HL = BULLISH, LH+LL = BEARISH", () => {
  const path = [10, 12, 14, 12, 11, 13, 16, 13, 12, 15, 19, 15, 14, 17, 21, 17, 16, 18, 20];
  const c = path.map((p, i) => mk(i, p, p + 0.2, p - 0.2, p));
  assert.equal(marketStructure(c, 1, 1).trend, "BULLISH");
  const d = path.map((p) => 40 - p).map((p, i) => mk(i, p, p + 0.2, p - 0.2, p));
  assert.equal(marketStructure(d, 1, 1).trend, "BEARISH");
  assert.ok(swings(c, 1, 1).highs.length >= 2);
});

test("FVG bullish terdeteksi dan status mitigasi benar", () => {
  const c = [mk(0, 10, 11, 9, 10.5), mk(1, 10.5, 14, 10.4, 13.8), mk(2, 13.8, 15, 12, 14.5), mk(3, 14.5, 16, 14, 15.5)];
  const g = fairValueGaps(c, 10).filter((x) => x.dir === "BULL");
  assert.equal(g.length, 1);
  assert.equal(g[0].bottom, 11); assert.equal(g[0].top, 12);
  assert.equal(g[0].mitigated, false);
  const c2 = [...c, mk(4, 15.5, 15.6, 11.5, 12)];
  assert.equal(fairValueGaps(c2, 10).find((x) => x.dir === "BULL")!.mitigated, true);
});

test("validateCandles membuang NaN, OHLC tak konsisten, harga<=0, duplikat; mengurutkan", () => {
  const r = validateCandles([
    mk(3000, 1, 2, 0.5, 1.5), mk(1000, 1, 2, 0.5, 1.5), mk(1000, 1, 3, 0.5, 1.5),
    mk(2000, NaN, 2, 1, 1), mk(4000, 5, 4, 1, 3) /* high<open */, mk(5000, 0, 1, 0, 0),
  ]);
  assert.deepEqual(r.candles.map((c) => c.t), [1000, 3000]);
  assert.equal(r.candles[0].h, 3); // duplikat: yang terakhir menang
});

test("closedOnly membuang candle yang masih berjalan; aggregate membuang bucket tak penuh", () => {
  const H = 3_600_000;
  const c = [mk(0, 1, 2, 0, 1), mk(H, 1, 2, 0, 1)];
  assert.equal(closedOnly(c, H, H + 1000).length, 1);
  assert.equal(closedOnly(c, H, 2 * H + 1).length, 2);
  const h1 = Array.from({ length: 9 }, (_, i) => mk(i * H, 1 + i, 2 + i, i, 1.5 + i));
  const h4 = aggregate(h1, H, 4 * H);
  assert.equal(h4.length, 2); // bucket ke-3 hanya 1 candle -> dibuang
  assert.equal(h4[0].o, 1); assert.equal(h4[0].c, 4.5); assert.equal(h4[0].h, 5); assert.equal(h4[0].l, 0);
});

const P = (over: Partial<Prediction> = {}): Prediction => ({
  id: "x", symbol: "XAUUSD", direction: "BUY", entry: 100, sl: 98, tp1: 103,
  createdAt: 1000, expiresAt: 100000, score: 0.5, status: "OPEN", ...over,
});

test("ledger: WIN / LOSS / SL&TP sama candle = LOSS / EXPIRED mark-to-market", () => {
  const win = resolvePrediction(P(), [mk(1000, 100, 101, 99, 100.5), mk(2000, 100.5, 103.2, 100, 103)], 5000);
  assert.equal(win.status, "WIN"); assert.equal(win.rMultiple, 1.5);
  const loss = resolvePrediction(P(), [mk(1000, 100, 100.5, 97.9, 98)], 5000);
  assert.equal(loss.status, "LOSS"); assert.equal(loss.rMultiple, -1);
  const both = resolvePrediction(P(), [mk(1000, 100, 104, 97, 100)], 5000);
  assert.equal(both.status, "LOSS");
  const exp = resolvePrediction(P(), [mk(1000, 100, 101, 99.5, 101)], 200000);
  assert.equal(exp.status, "EXPIRED"); assert.equal(exp.rMultiple, 0.5);
  const sell = resolvePrediction(P({ direction: "SELL", sl: 102, tp1: 97 }), [mk(1000, 100, 100.5, 96.9, 97)], 5000);
  assert.equal(sell.status, "WIN");
});

test("ledger: candle sebelum createdAt diabaikan (tanpa look-ahead/ look-behind)", () => {
  const r = resolvePrediction(P({ createdAt: 5000 }), [mk(1000, 100, 110, 90, 100)], 6000);
  assert.equal(r.status, "OPEN");
});

test("summarize: persen TIDAK diberikan bila n < 30; Wilson melebar pada n kecil", () => {
  const mkList = (w: number, l: number) => [
    ...Array.from({ length: w }, () => P({ status: "WIN", rMultiple: 1.5 })),
    ...Array.from({ length: l }, () => P({ status: "LOSS", rMultiple: -1 })),
  ];
  const small = summarize(mkList(9, 1));
  assert.equal(small.winRate, null); assert.equal(small.sufficient, false);
  assert.equal(small.rawWinRate, 0.9);
  assert.ok(small.ci95!.low < 0.6); // 9/10 tidak berarti "90% pasti"
  const big = summarize(mkList(18, 12));
  assert.equal(big.winRate, 0.6); assert.equal(big.sufficient, true);
  assert.equal(summarize([]).winRate, null);
  assert.equal(wilson95(0, 0), null);
});

test("surpriseDirection: tabel kebenaran, tanpa forecast = null", () => {
  const base = { currency: "USD" };
  assert.equal(surpriseDirection({ ...base, actual: 3.5, forecast: 3.0, higherIsBullishUSD: true }), "SELL");
  assert.equal(surpriseDirection({ ...base, actual: 2.5, forecast: 3.0, higherIsBullishUSD: true }), "BUY");
  assert.equal(surpriseDirection({ ...base, actual: 4.5, forecast: 4.0, higherIsBullishUSD: false }), "BUY"); // pengangguran naik
  assert.equal(surpriseDirection({ ...base, actual: 3, forecast: 3, higherIsBullishUSD: true }), null);
  assert.equal(surpriseDirection({ ...base, actual: 3, forecast: null, higherIsBullishUSD: true }), null);
  assert.equal(surpriseDirection({ currency: "EUR", actual: 3, forecast: 2, higherIsBullishUSD: true }), null);
});

function flat(n: number, startMs: number, step: number, price: number): Candle[] {
  return Array.from({ length: n }, (_, i) => mk(startMs + i * step, price, price + 1, price - 1, price));
}

test("measureReaction: HIT / MISS / NEUTRAL dari harga nyata; jendela tak lengkap = UNMEASURED", () => {
  const M5 = 300_000;
  const release = 100 * M5;
  const before = flat(100, 0, M5, 2000);                  // candle 0..99 tutup sebelum rilis
  const after = (px: number) => Array.from({ length: 6 }, (_, i) => mk(release + i * M5, px, px + 0.5, px - 0.5, px));
  const hit = measureReaction({ candles: [...before, ...after(1995)], intervalMs: M5, releaseMs: release, expected: "SELL" });
  assert.equal(hit.verdict, "HIT"); assert.equal(hit.basePrice, 2000); assert.equal(hit.endPrice, 1995);
  const miss = measureReaction({ candles: [...before, ...after(2005)], intervalMs: M5, releaseMs: release, expected: "SELL" });
  assert.equal(miss.verdict, "MISS");
  const neutral = measureReaction({ candles: [...before, ...after(2000.05)], intervalMs: M5, releaseMs: release, expected: "SELL" });
  assert.equal(neutral.verdict, "NEUTRAL");
  const gap = measureReaction({ candles: before, intervalMs: M5, releaseMs: release, expected: "SELL" });
  assert.equal(gap.verdict, "UNMEASURED");
  assert.equal(measureReaction({ candles: [...before, ...after(1990)], intervalMs: M5, releaseMs: release, expected: null }).verdict, "UNMEASURED");
  const sm = summarizeReactions([hit, miss, neutral, gap]);
  assert.equal(sm.n, 2); assert.equal(sm.rate, null); assert.equal(sm.rawRate, 0.5);
});
