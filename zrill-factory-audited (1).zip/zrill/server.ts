import express from "express";
import path from "path";
import cors from "cors";
import { initTradingViewEngine, getTradingViewPrice, getAllTradingViewPrices, getFeedStatus, crossCheck } from "./src/server/tradingviewService";
import { MarketDataError, SYMBOLS, clampLimit, fetchCandles, fetchMacro, normalizeInterval, normalizeSymbol } from "./src/server/marketData";
import { getCalendar } from "./src/server/calendarService";
import { getNews } from "./src/server/newsService";
import { analyzeSymbol } from "./src/server/analyzeService";
import { getRecent, getSummary, openSymbols, resolveOpen } from "./src/server/ledgerStore";
import { verifyCode } from "./src/server/membership";

const PORT = parseInt(process.env.PORT || "3000", 10);
const isProd = process.env.NODE_ENV === "production";
const ALLOWED = (process.env.ALLOWED_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean);

/** Rate limit sederhana per IP (in-memory). */
function rateLimit(max: number, windowMs: number): express.RequestHandler {
  const hits = new Map<string, { n: number; reset: number }>();
  setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (v.reset < now) hits.delete(k); }, windowMs).unref();
  return (req, res, next) => {
    const key = req.ip || "unknown";
    const now = Date.now();
    const h = hits.get(key);
    if (!h || h.reset < now) { hits.set(key, { n: 1, reset: now + windowMs }); return next(); }
    if (++h.n > max) { res.setHeader("Retry-After", Math.ceil((h.reset - now) / 1000)); return res.status(429).json({ error: "Terlalu banyak permintaan" }); }
    next();
  };
}

function fail(res: express.Response, e: unknown) {
  if (e instanceof MarketDataError) return res.status(503).json({ error: e.message, attempts: e.attempts, data: null });
  console.error(e);
  return res.status(500).json({ error: "Kesalahan internal" });
}

async function startServer() {
  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", 1);
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "no-referrer");
    next();
  });
  app.use(cors({ origin: (origin, cb) => cb(null, !origin || ALLOWED.includes(origin)) }));
  app.use(express.json({ limit: "20kb" }));
  app.use("/api", rateLimit(120, 60_000));

  initTradingViewEngine();

  // ---- Kesehatan & harga live (nyata atau 404; tidak pernah mengarang) ----
  app.get("/api/health", (_req, res) => res.json({ ok: true, serverTime: Date.now(), tradingview: getFeedStatus(), symbols: SYMBOLS }));

  app.get("/api/tradingview/prices", (_req, res) =>
    res.json({ prices: getAllTradingViewPrices(), source: "TRADINGVIEW_WEBSOCKET", timestamp: Date.now() }));

  app.get("/api/tradingview/price", (req, res) => {
    const sym = normalizeSymbol(req.query.symbol ?? "XAUUSD");
    if (!sym) return res.status(400).json({ error: "Simbol tidak didukung", supported: SYMBOLS });
    const p = getTradingViewPrice(sym);
    if (!p) return res.status(404).json({ error: "Tidak ada harga live yang segar (pasar tutup atau feed terputus)", symbol: sym, feed: getFeedStatus() });
    res.json({
      symbol: sym, price: p.price,
      bid: p.hasQuoteSides ? p.bid : null, ask: p.hasQuoteSides ? p.ask : null,
      ch: p.ch, chp: p.chp, volume: p.volume, high: p.high, low: p.low, open: p.open,
      source: "TRADINGVIEW_WEBSOCKET", venue: p.tradingviewSymbol, updatedAt: p.updatedAt, ageMs: p.ageMs,
      crossCheck: crossCheck(sym),
    });
  });

  // ---- Candle nyata dengan provenance ----
  app.get("/api/klines", async (req, res) => {
    const sym = normalizeSymbol(req.query.symbol ?? "XAUUSD");
    const interval = normalizeInterval(req.query.interval ?? "1m");
    if (!sym || !interval) return res.status(400).json({ error: "symbol/interval tidak valid", supported: { symbols: SYMBOLS } });
    try {
      const r = await fetchCandles(sym, interval, clampLimit(req.query.limit, 300, 1000));
      res.setHeader("Cache-Control", "public, max-age=2");
      res.json({ symbol: sym, interval, provenance: r.provenance, issues: r.issues, candles: r.candles });
    } catch (e) { fail(res, e); }
  });

  // ---- Makro nyata (DXY, US10Y) ----
  app.get("/api/macro", async (_req, res) => {
    const m = await fetchMacro();
    res.json(m);
  });

  // ---- Kalender nyata + audit reaksi harga ----
  app.get("/api/calendar", async (_req, res) => {
    const c = await getCalendar();
    res.status(c.status === "UNAVAILABLE" ? 502 : 200).json({ ...c, timestamp: c.fetchedAt ?? Date.now(), serverTimeIso: new Date().toISOString() });
  });

  // ---- Berita nyata (tanpa cadangan fiktif) ----
  app.get("/api/news/realtime", async (_req, res) => res.json(await getNews()));

  // ---- Analisis: server mengambil data sendiri; klien hanya memilih simbol ----
  app.post("/api/ai/analyze", rateLimit(20, 60_000), async (req, res) => {
    const sym = normalizeSymbol(req.body?.symbol?.id ?? req.body?.symbol ?? "XAUUSD");
    if (!sym) return res.status(400).json({ error: "Simbol tidak didukung", supported: SYMBOLS });
    try { res.json(await analyzeSymbol(sym)); } catch (e) { fail(res, e); }
  });

  // ---- Ledger: satu-satunya sumber win rate ----
  app.get("/api/ledger", (req, res) => {
    const sym = req.query.symbol ? normalizeSymbol(req.query.symbol) : null;
    if (req.query.symbol && !sym) return res.status(400).json({ error: "Simbol tidak didukung" });
    res.json({
      summary: getSummary(sym ?? undefined), recent: getRecent(sym ?? undefined, 30),
      method: "Prediksi dicatat saat dibuat; hasil ditentukan HANYA oleh candle M5 nyata sesudahnya (SL dan TP di candle sama = LOSS). Win rate tidak ditampilkan sebelum n ≥ minSample.",
    });
  });

  // ---- Membership: HMAC bertanda tangan, bukan kode tertanam ----
  app.post("/api/auth/verify-membership", rateLimit(10, 60_000), (req, res) => {
    const r = verifyCode(req.body?.code, process.env.MEMBERSHIP_SECRET);
    if (!r.ok) return res.status(r.status).json({ error: r.error });
    res.json({ plan: r.plan, expiry: r.expiry });
  });

  // Penyelesai prediksi terbuka (latar belakang)
  setInterval(async () => {
    for (const s of openSymbols()) {
      const sym = normalizeSymbol(s);
      if (!sym) continue;
      try { const r = await fetchCandles(sym, "5m", 1000); resolveOpen(sym, r.candles); } catch { /* coba lagi siklus berikut */ }
    }
  }, 60_000).unref();

  app.use("/api", (_req, res) => res.status(404).json({ error: "Endpoint tidak ada" }));

  if (!isProd) {
    const { createServer } = await import("vite");
    const vite = await createServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    const dist = path.join(process.cwd(), "dist");
    app.use(express.static(dist));
    // Express 4: '*all' (sintaks Express 5) sebelumnya membuat fallback SPA rusak
    app.get(/^\/(?!api\/).*/, (_req, res) => res.sendFile(path.join(dist, "index.html")));
  }

  app.listen(PORT, "0.0.0.0", () => console.log(`Server berjalan di http://localhost:${PORT}`));
}

startServer();
