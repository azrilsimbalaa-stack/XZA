# Laporan Audit Zrill Factory

## A. Data/klaim palsu yang ditemukan dan dihapus
| # | Lokasi lama | Masalah | Perbaikan |
|---|---|---|---|
| 1 | `server.ts` candle | Bila sumber gagal, candle random-walk (`Math.random`) disajikan sebagai pasar nyata | `marketData.ts`: semua gagal → HTTP 503 + daftar percobaan |
| 2 | `tradingviewService` | Tanpa feed, harga gelombang sinus ~4430 dikembalikan sebagai "live" | Mengembalikan `null`; data > 20 dtk dianggap basi |
| 3 | `server.ts` `generateMockAnalysis` | confidence 98, "AAA+", 50 alasan "terkonfirmasi" tanpa pengecekan | Dihapus; `/api/ai/analyze` memakai `signalCore` |
| 4 | `/api/news/realtime` | "Pernyataan live" Trump/Warsh/Bessent/JPMorgan/Goldman karangan, DXY & yield dari `tickSeed`, probabilitas 93.6% | Berita nyata saja; gagal → daftar kosong + error |
| 5 | Kalender fallback | NFP/CPI/FOMC 5.25% fiktif bertanggal "sekarang"; `accuracyRate` 96/89 | `UNAVAILABLE` + result kosong |
| 6 | `institutionalCalendarEngine` | **Akurasi sirkular**: arah "prediksi" diturunkan dari angka aktual lalu dibandingkan dengan dirinya sendiri → selalu 100% | Dinilai hanya dari gerak harga emas nyata; tak terukur = `null` |
| 7 | Engine kalender | `pipsGain` "+180 Pips", anchorScore 93–98, win rate 84–92%, spike 74–98%, "bocoran A1 14 indikator", FVG M15 "terbuka" tanpa cek | Dihapus / `null` |
| 8 | `App.tsx` | "+2,480 Pips Profit", "100% Terlindungi", fallback hit rate 96, `\|\| 95.0`, `\|\| "+180 Pips"`, `!== false` = "benar", harga awal 2685.4, spread `±0.3` rekaan | Tiga keadaan benar/salah/tidak-terukur; angka dari server atau "—" |
| 9 | `precisionSignalEngine` (5.2 rb baris) dkk | DXY 103.85/105.70 menurut boolean, skor pilar tetap 96/94/95, "policy rate 5.25%", `probabilityScore` 85–94 per cabang | Dikarantina; diganti `signalCore` |

## B. Bug teknis
- Heartbeat TradingView salah panjang frame → koneksi sering putus. Diperbaiki.
- Tiga venue BTC menimpa key yang sama (bid/ask campur antar bursa). Venue dipisah + cross-check.
- Granularity Coinbase 4h/30m tidak ada (4h=21600 sebenarnya 6 jam). Sekarang ditolak → pindah sumber.
- `app.get('*all')` sintaks Express 5 pada Express 4 → fallback SPA produksi rusak. Diperbaiki.
- Input `symbol/interval/limit` masuk URL tanpa validasi. Kini di-whitelist.
- Candle terakhir dipatch dengan harga instrumen berbeda (PAXG vs XAUUSD). Dihapus.
- Volume Yahoo `|| 100` rekaan. Dihapus. Candle yang belum tutup kini dikeluarkan (anti-repaint).
- Prediksi pra-rilis memakai `forecast − previous` sebagai arah emas (tidak punya dasar; yang bergerak adalah kejutan) dan default BUY. Diganti NETRAL + aturan kejutan.
- `isReleased` benar walau angka aktual kosong. Kini `AWAITING_DATA`.

## C. Keamanan
- `/api/auth/verify-membership` meloloskan kode 8 karakter apa pun + kode override tertanam → diganti HMAC bertanda tangan (`MEMBERSHIP_SECRET`).
- Endpoint MCP palsu (`/api/mcp/execute` selalu "COMPLETED", status "ACTIVE") → dihapus.
- `firestore.rules`: baca/tulis publik tanpa login → tulis klien ditutup, baca butuh auth, settings hanya milik uid sendiri.
- CORS terbuka → same-origin + `ALLOWED_ORIGINS`; rate limit; header keamanan; body 20 KB.
- `public/project-source.zip` (rusak) menyajikan source secara publik → dikarantina.

## D. Upgrade
- `signalCore`: 8 faktor nyata (struktur H4/H1, EMA50/200, MACD, RSI, BOS/CHoCH M15, sapuan likuiditas, FVG, makro DXY+yield nyata). Faktor tanpa data **dikeluarkan**. Gerbang: data cukup/segar, ADX, ≥3 faktor searah, ≥1 struktur searah, tidak melawan H4, spread, jendela rilis berita. SL berbasis swing+ATR.
- **Ledger prediksi** + Wilson 95%; **audit reaksi berita** terhadap harga nyata dengan sampel independen per timestamp.
- Layak tampil hanya bila n ≥ 30.

## E. Yang TIDAK bisa saya buktikan di sini (jujur)
1. Sandbox tanpa internet/`node_modules`: **feed live (TradingView/Yahoo/Binance/Coinbase) belum diuji**. Jalur data diuji dengan stub `fetch`, bukan endpoint sungguhan. Format respons Yahoo/Binance/TV mengikuti kode lama yang berjalan, tetapi uji sendiri.
2. `npm run build` & typecheck penuh belum bisa dijalankan; kode baru bersih dari error selain modul yang tak terpasang, sintaks semua file valid.
3. WebSocket TradingView tidak diuji (perbaikan heartbeat didasarkan pada format protokol, belum diverifikasi live).
4. **Ambang sinyal belum tervalidasi.** Tidak ada klaim win rate sampai ledger Anda memilikinya. Sinyal pertama bisa saja rugi.
5. Yahoo `XAUUSD=X`/GC=F dan PAXG adalah proksi, bukan spot OANDA.
