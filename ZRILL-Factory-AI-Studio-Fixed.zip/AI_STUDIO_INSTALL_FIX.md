# Google AI Studio dependency-install compatibility fix

## Changes
- Removed the duplicate Vite declaration. Vite is a build-time tool and is now declared once, under `devDependencies`.
- Declared the supported Node.js baseline as `>=20.0.0` in both `package.json` and the root lockfile metadata.
- Kept the existing dependency versions/ranges and application feature code unchanged.
- Kept the nested `tradingview-mcp-repo` package as a separate project; it is not configured as an npm workspace and is not pulled into the root install.

## Verification
- `npm ci --dry-run --ignore-scripts --no-audit --no-fund --offline`: PASS. npm accepted the package/lockfile pair and resolved the install plan (425 packages).
- `npm test`: PASS — 22 tests, 0 failures.
- `npm run lint`: NOT VERIFIED because dependencies could not be installed in this environment.
- `npm run build`: NOT VERIFIED because Vite is not installed in this environment.
- Actual `npm ci` could not complete because the environment's connection to the npm registry timed out. This is separate from the package/lockfile consistency check.

## Google AI Studio
Import the updated ZIP and retry dependency installation. If AI Studio still fails, export/copy its full npm error log; a generic install-failed banner alone does not identify a registry, runtime, or package-resolution failure.
