import React from "react";
import { RealtimeMacroSMCFusion } from "../services/realtimeFundamentalStreamEngine";

interface RealtimeFundamentalSMCFusionCardProps {
  fusionData?: RealtimeMacroSMCFusion;
  symbol: { id: string; name?: string; basePrice?: number };
  currentPrice: number;
  direction?: "BUY" | "SELL" | "WAIT";
  timeframe?: string;
  onRefresh?: () => void;
}

export const RealtimeFundamentalSMCFusionCard: React.FC<RealtimeFundamentalSMCFusionCardProps> = () => (
  <div className="p-4 rounded-2xl bg-[#0a1220] border border-amber-500/30 text-white">
    <div className="text-sm font-bold text-amber-300">DATA FUNDAMENTAL / SMC BELUM TERSEDIA</div>
    <p className="mt-2 text-xs text-gray-400">
      DXY, yield, ETF flow, order book, order block, dan FVG tidak ditampilkan sebagai live karena provider dan timestamp sumber belum terhubung serta diverifikasi. Tidak ada angka simulasi.
    </p>
  </div>
);
