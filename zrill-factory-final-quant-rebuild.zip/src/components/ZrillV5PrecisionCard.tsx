import React from "react";
import { ZrillV5CoreAnalysis } from "../services/precisionSignalEngine";

interface ZrillV5PrecisionCardProps {
  zrillCore?: ZrillV5CoreAnalysis;
  symbol: string;
  isBuy: boolean;
  currentPrice: number;
  timeframe: string;
  copyToClipboard?: (text: string) => Promise<boolean>;
}

export const ZrillV5PrecisionCard: React.FC<ZrillV5PrecisionCardProps> = ({ zrillCore }) => {
  if (!zrillCore) return null;
  return (
    <div id="zrill-v5-precision-card" className="rounded-xl border border-amber-500/30 bg-slate-900/95 p-4 text-xs text-slate-300">
      <div className="font-bold text-amber-300">LEGACY WIN-RATE MODEL DISABLED</div>
      <p className="mt-2">Model lama menggunakan confidence dan estimasi win-rate yang belum memiliki kalibrasi out-of-sample. Nilai tersebut tidak ditampilkan. Gunakan Quantitative Core v2; evidence score-nya bukan probabilitas menang.</p>
    </div>
  );
};
