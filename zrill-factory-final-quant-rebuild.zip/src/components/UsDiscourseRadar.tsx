import React, { useState, useEffect, useRef } from "react";
import {
  Landmark,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  Sparkles,
  MessageSquareQuote,
  CheckCircle2,
  Scale,
  Clock,
  Activity,
  Zap,
  Filter,
  Building2,
  Coins,
  ShieldAlert,
  ArrowUpRight,
  Radio,
  Volume2,
  VolumeX,
  ArrowLeft,
  Calendar,
  X,
} from "lucide-react";

export interface CommercialBankPosition {
  name: string;
  goldStance: string;
  btcStance: string;
  deskAction: string;
  liveFlow?: string;
}

export interface UsDiscussionItem {
  id: string;
  speaker: string;
  role: string;
  topic: string;
  whatWasSaid: string;
  stance: string;
  relevanceToNews: string;
  confidenceContribution: string;
  marketReaction: string;
  targetAssets?: string;
  timeAgo: string;
  badgeColor?: string;
}

export interface UsDiscourseRadarData {
  updatedAtIso?: string;
  lastTickTime?: number;
  overallUsSentiment: string;
  statusSummary: string;
  macroIndicators: {
    dxyIndex: { value: string; change: string; trend: string };
    us10yYield: { value: string; change: string; trend: string };
    fedWatchCutOdds: { value: string; timeframe: string; consensus: string };
    goldRealtimePipsReaction: string;
    btcRealtimeFlowReaction?: string;
  };
  commercialBanksSummary?: {
    overallBias: string;
    topBanks: CommercialBankPosition[];
  };
  liveDiscussions: UsDiscussionItem[];
}

interface UsDiscourseRadarProps {
  data?: UsDiscourseRadarData | null;
  onSync?: () => void;
  isSyncing?: boolean;
  activeSymbolId?: string;
  onSwitchWorkspace?: (workspace: "TERMINAL" | "CALENDAR" | "US_MACRO") => void;
  onClose?: () => void;
}

export const DEFAULT_DISCOURSE_RADAR: UsDiscourseRadarData = {
  overallUsSentiment: "DATA TIDAK TERSEDIA",
  statusSummary: "Feed makro, pernyataan pejabat, dan posisi bank belum terhubung ke sumber terverifikasi.",
  macroIndicators: {
    dxyIndex: { value: "N/A", change: "N/A", trend: "UNAVAILABLE" },
    us10yYield: { value: "N/A", change: "N/A", trend: "UNAVAILABLE" },
    fedWatchCutOdds: { value: "N/A", timeframe: "N/A", consensus: "UNAVAILABLE" },
    goldRealtimePipsReaction: "N/A",
    btcRealtimeFlowReaction: "N/A",
  },
  commercialBanksSummary: { overallBias: "UNAVAILABLE", topBanks: [] },
  liveDiscussions: [],
};

export const UsDiscourseRadar: React.FC<UsDiscourseRadarProps> = ({
  data: propData,
  onSync,
  isSyncing = false,
  activeSymbolId = "XAUUSD",
  onSwitchWorkspace,
  onClose,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<string>("ALL");
  const [tickerSec, setTickerSec] = useState<number>(0);
  const [witaTimeStr, setWitaTimeStr] = useState<string>("");
  const [witaDateStr, setWitaDateStr] = useState<string>("");
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  // Live second-by-second WITA clock & periodic tick engine
  useEffect(() => {
    const updateWitaClock = () => {
      const now = new Date();
      const timeFmt = new Intl.DateTimeFormat("id-ID", {
        timeZone: "Asia/Makassar",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false,
      }).format(now);

      const dateFmt = new Intl.DateTimeFormat("id-ID", {
        timeZone: "Asia/Makassar",
        weekday: "short",
        day: "numeric",
        month: "short",
        year: "numeric",
      }).format(now);

      setWitaTimeStr(`${timeFmt} WITA`);
      setWitaDateStr(dateFmt);
      setTickerSec((prev) => prev + 1);
    };

    updateWitaClock();
    const timer = setInterval(updateWitaClock, 1000);
    return () => clearInterval(timer);
  }, []);

  const data = propData || DEFAULT_DISCOURSE_RADAR;

  // Flash indicator on live tick
  const prevDxy = useRef(data.macroIndicators.dxyIndex.value);
  const [flashTick, setFlashTick] = useState(false);
  useEffect(() => {
    if (prevDxy.current !== data.macroIndicators.dxyIndex.value) {
      setFlashTick(true);
      prevDxy.current = data.macroIndicators.dxyIndex.value;
      const t = setTimeout(() => setFlashTick(false), 1500);
      return () => clearTimeout(t);
    }
  }, [data.macroIndicators.dxyIndex.value]);

  // Periodic automatic sync trigger every 15s if onSync is provided
  useEffect(() => {
    if (!onSync) return;
    const autoSyncInterval = setInterval(() => {
      onSync();
    }, 15000);
    return () => clearInterval(autoSyncInterval);
  }, [onSync]);

  const handleSpeak = (item: UsDiscussionItem) => {
    if (!("speechSynthesis" in window)) return;
    if (speakingId === item.id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }
    window.speechSynthesis.cancel();
    setSpeakingId(item.id);
    const text = `Pernyataan resmi dari ${item.speaker}, ${item.role}. Topik: ${item.topic}. Isi pernyataan: ${item.whatWasSaid}. Dampak pasar: ${item.marketReaction}. Aset target: ${item.targetAssets || "Emas dan Bitcoin"}.`;
    const utt = new SpeechSynthesisUtterance(text);
    utt.lang = "id-ID";
    utt.rate = 0.98;
    utt.onend = () => setSpeakingId(null);
    utt.onerror = () => setSpeakingId(null);
    window.speechSynthesis.speak(utt);
  };

  const filteredDiscussions = data.liveDiscussions.filter((item) => {
    if (selectedFilter === "ALL") return true;
    if (selectedFilter === "TRUMP")
      return item.speaker.includes("Trump") || item.role.includes("Presiden");
    if (selectedFilter === "WARSH")
      return item.speaker.includes("Warsh") || item.role.includes("Kevin Warsh") || item.role.includes("Fed Chair");
    if (selectedFilter === "BESSENT")
      return item.speaker.includes("Bessent") || item.role.includes("Keuangan");
    if (selectedFilter === "BANKS")
      return (
        item.speaker.includes("JPMorgan") ||
        item.speaker.includes("Goldman") ||
        item.speaker.includes("Morgan") ||
        item.role.includes("Bank Komersial") ||
        item.role.includes("Wall Street")
      );
    if (selectedFilter === "FOMC")
      return item.speaker.includes("Waller") || item.speaker.includes("Bowman") || item.role.includes("Gubernur");
    return true;
  });

  const commercialBanks = data.commercialBanksSummary?.topBanks || [];

  return (
    <div className="flex flex-col gap-3 rounded-2xl bg-[#080d16] border border-cyan-500/30 p-3 sm:p-4 text-gray-200 font-mono shadow-xl relative w-full max-w-full overflow-hidden">
      {/* Top subtle line */}
      <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-cyan-500 via-emerald-400 to-indigo-500 shadow-[0_0_12px_rgba(6,182,212,0.8)]" />

      {/* Header Bar with Live Realtime WITA Sync */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3 relative z-10 w-full">
        <div className="flex items-start sm:items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/15 border border-cyan-500/35 text-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.25)] shrink-0">
            <Landmark className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-xs sm:text-sm font-black text-white tracking-wider flex items-center gap-2 uppercase">
                <span>RADAR PEMANTAUAN AS &amp; BANK BESAR</span>
              </h3>
              <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/35 text-[9px] font-bold text-emerald-300">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                FEED STATUS
              </span>
              <span className="px-2 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-[8px] font-black text-cyan-300">
                MACRO FEED: STATUS
              </span>
            </div>
            <p className="text-[10px] text-gray-400 mt-0.5 leading-relaxed">
              Hanya menampilkan data jika feed sumber terverifikasi tersedia.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center shrink-0 flex-wrap">
          {/* Dedicated Live WITA Clock Pill */}
          <div className="flex items-center gap-2 px-3 py-1 rounded-xl bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 text-xs font-black shadow-[0_0_15px_rgba(6,182,212,0.2)]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>{witaTimeStr || "WITA REALTIME"}</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[9px] font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            <span>AUTO-SYNC ({(tickerSec % 15) + 1}s)</span>
          </div>
          {onSync && (
            <button
              onClick={onSync}
              disabled={isSyncing}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-500/40 text-[9px] font-bold transition-all disabled:opacity-50 cursor-pointer shadow-sm active:scale-95"
            >
              <RefreshCw className={`w-3 h-3 ${isSyncing ? "animate-spin text-cyan-300" : "text-cyan-400"}`} />
              <span>{isSyncing ? "Syncing..." : "Sync Now"}</span>
            </button>
          )}
          {onClose && (
            <button
              onClick={onClose}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-[9px] font-black tracking-wider transition-all cursor-pointer shadow-sm active:scale-95 uppercase"
              title="Tutup & Kembali ke Terminal"
            >
              <X className="w-3.5 h-3.5" />
              <span>Tutup</span>
            </button>
          )}
        </div>
      </div>

      {/* Top 5 Key Macro Indicators (Updated Live Each Tick) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 text-xs relative z-10 w-full">
        <div className={`p-2.5 rounded-xl bg-black/50 border transition-all flex flex-col gap-0.5 ${flashTick ? "border-rose-400 shadow-[0_0_15px_rgba(244,63,94,0.3)]" : "border-white/10"}`}>
          <span className="text-[8px] text-gray-400 font-bold uppercase flex items-center gap-1">
            <TrendingDown className="w-3 h-3 text-rose-400" />
            DXY Index
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-sm font-black text-white">{data.macroIndicators.dxyIndex.value}</span>
            <span className="text-[9px] font-bold text-rose-400">{data.macroIndicators.dxyIndex.change}</span>
          </div>
          <span className="text-[8px] text-gray-400 truncate">{data.macroIndicators.dxyIndex.trend}</span>
        </div>

        <div className={`p-2.5 rounded-xl bg-black/50 border transition-all flex flex-col gap-0.5 ${flashTick ? "border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]" : "border-white/10"}`}>
          <span className="text-[8px] text-gray-400 font-bold uppercase flex items-center gap-1">
            <Scale className="w-3 h-3 text-amber-400" />
            US 10Y Yield
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-sm font-black text-white">{data.macroIndicators.us10yYield.value}</span>
            <span className="text-[9px] font-bold text-emerald-400">{data.macroIndicators.us10yYield.change}</span>
          </div>
          <span className="text-[8px] text-gray-400 truncate">{data.macroIndicators.us10yYield.trend}</span>
        </div>

        <div className="p-2.5 rounded-xl bg-black/50 border border-white/10 flex flex-col gap-0.5">
          <span className="text-[8px] text-gray-400 font-bold uppercase flex items-center gap-1">
            <Zap className="w-3 h-3 text-cyan-400" />
            FedWatch Rate Cut
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-sm font-black text-cyan-300">{data.macroIndicators.fedWatchCutOdds.value}</span>
          </div>
          <span className="text-[8px] text-gray-400 truncate">{data.macroIndicators.fedWatchCutOdds.consensus}</span>
        </div>

        <div className="p-2.5 rounded-xl bg-emerald-950/30 border border-emerald-500/35 flex flex-col gap-0.5">
          <span className="text-[8px] text-emerald-400 font-bold uppercase flex items-center gap-1">
            <Coins className="w-3 h-3 text-amber-400" />
            Dampak Gold (XAU)
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xs font-black text-emerald-300 truncate">
              {data.macroIndicators.goldRealtimePipsReaction}
            </span>
          </div>
          <span className="text-[8px] text-emerald-400/80 truncate">Bias: Akumulasi Bullish</span>
        </div>

        <div className="col-span-2 sm:col-span-1 p-2.5 rounded-xl bg-indigo-950/30 border border-indigo-500/35 flex flex-col gap-0.5">
          <span className="text-[8px] text-indigo-400 font-bold uppercase flex items-center gap-1">
            <Radio className="w-3 h-3 text-indigo-400" />
            Inflow Bitcoin (BTC)
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xs font-black text-indigo-300 truncate">
              {data.macroIndicators.btcRealtimeFlowReaction || "+$1.8B ETF Flow"}
            </span>
          </div>
          <span className="text-[8px] text-indigo-400/80 truncate">Cadangan Strategis Trump</span>
        </div>
      </div>

      {/* Commercial Banks Desk Tracker Bar */}
      <div className="p-3 rounded-xl bg-black/60 border border-white/10 flex flex-col gap-2 w-full">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 text-[10px] font-black text-cyan-300 uppercase tracking-wider">
            <Building2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>POSISI 5 BANK BESAR (DESK TRADING GOLD &amp; BTC)</span>
          </div>
          <span className="text-[8px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
            NET LONG ACCUMULATION
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2 text-[9px] w-full">
          {commercialBanks.map((bank, bIdx) => (
            <div
              key={`bank_flow_${bIdx}`}
              className="p-2 rounded-lg bg-white/[0.02] border border-white/5 flex flex-col gap-1 hover:border-cyan-500/30 transition-all"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-white tracking-wide">{bank.name}</span>
                <ArrowUpRight className="w-3 h-3 text-emerald-400" />
              </div>
              <div className="flex items-center justify-between text-gray-400">
                <span>Gold:</span>
                <span className="font-black text-emerald-400">{bank.goldStance}</span>
              </div>
              <div className="flex items-center justify-between text-gray-400">
                <span>BTC:</span>
                <span className="font-black text-indigo-300">{bank.btcStance}</span>
              </div>
              <span className="text-[8px] text-gray-500 truncate border-t border-white/5 pt-1 mt-0.5">
                {bank.liveFlow || bank.deskAction}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 relative z-10 text-[9px] font-bold w-full max-w-full">
        <span className="text-gray-400 flex items-center gap-1 shrink-0 mr-1 uppercase">
          <Filter className="w-3 h-3 text-cyan-400" /> Filter:
        </span>
        {[
          { id: "ALL", label: `Semua (${data.liveDiscussions.length})` },
          { id: "TRUMP", label: "🇺🇸 Donald Trump" },
          { id: "WARSH", label: "🏛️ Kevin Warsh" },
          { id: "BESSENT", label: "💼 Scott Bessent" },
          { id: "BANKS", label: "🏦 5 Bank Komersial" },
          { id: "FOMC", label: "🗳️ Voting Member" },
        ].map((btn) => (
          <button
            key={`disc_filter_${btn.id}`}
            onClick={() => setSelectedFilter(btn.id)}
            className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer shrink-0 whitespace-nowrap ${
              selectedFilter === btn.id
                ? "bg-cyan-500/30 text-cyan-200 border border-cyan-500/60 shadow-[0_0_10px_rgba(6,182,212,0.3)] font-bold"
                : "bg-black/40 text-gray-400 hover:text-white border border-white/5 hover:border-white/20"
            }`}
          >
            {btn.label}
          </button>
        ))}
      </div>

      {/* Live Discussion & Speech Stream Cards */}
      <div className="flex flex-col gap-2.5 relative z-10 w-full max-w-full">
        {filteredDiscussions.map((item, dIdx) => {
          const isDovish =
            item.stance.includes("DOVISH") ||
            item.stance.includes("BULLISH") ||
            item.stance.includes("BUY") ||
            item.stance.includes("GROWTH");

          const isSpeaking = speakingId === item.id;

          return (
            <div
              key={`disc_item_${item.id || dIdx}_${dIdx}`}
              className={`p-3 sm:p-4 rounded-xl border flex flex-col gap-2 transition-all relative overflow-hidden ${
                isDovish
                  ? "bg-[#06141d]/90 border-emerald-500/30 shadow-[0_0_20px_rgba(16,185,129,0.08)]"
                  : "bg-[#140b12]/90 border-rose-500/30 shadow-[0_0_20px_rgba(244,63,94,0.08)]"
              }`}
            >
              {/* Speaker Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 border-b border-white/10 pb-2">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 border ${
                      isDovish
                        ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                        : "bg-rose-500/20 text-rose-300 border-rose-500/40"
                    }`}
                  >
                    {item.speaker.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-black text-white">{item.speaker}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider border ${
                          isDovish
                            ? "bg-emerald-500/30 text-emerald-200 border-emerald-500/50"
                            : "bg-rose-500/30 text-rose-200 border-rose-500/50"
                        }`}
                      >
                        {item.stance.replace(/_/g, " ")}
                      </span>
                      {item.targetAssets && (
                        <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">
                          {item.targetAssets}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-gray-400 block">{item.role}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-[9px] text-gray-400 self-start sm:self-center shrink-0 font-mono">
                  {/* TTS Voice button */}
                  <button
                    onClick={() => handleSpeak(item)}
                    className={`flex items-center gap-1 px-2 py-1 rounded-lg border text-[9px] font-bold transition-all cursor-pointer active:scale-95 ${
                      isSpeaking
                        ? "bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse"
                        : "bg-white/5 hover:bg-white/10 text-cyan-300 border-white/10"
                    }`}
                    title="Dengarkan pembacaan pernyataan ini"
                  >
                    {isSpeaking ? <VolumeX className="w-3 h-3 text-rose-400" /> : <Volume2 className="w-3 h-3 text-cyan-400" />}
                    <span>{isSpeaking ? "Berhenti" : "Dengarkan"}</span>
                  </button>

                  <div className="flex items-center gap-1 text-[9px] text-gray-400">
                    <Clock className="w-3 h-3 text-cyan-400" />
                    <span>{item.timeAgo}</span>
                  </div>
                </div>
              </div>

              {/* Topic Title */}
              <div className="text-[11px] font-bold text-cyan-200 flex items-center gap-1.5">
                <Activity className="w-3 h-3 text-cyan-400 shrink-0" />
                <span>Fokus Pembicaraan: {item.topic}</span>
              </div>

              {/* What the US Official Said (Direct Quote) */}
              <div className="p-2.5 rounded-xl bg-black/60 border border-white/5 flex gap-2 items-start">
                <MessageSquareQuote className="w-3.5 h-3.5 text-cyan-400 mt-0.5 shrink-0" />
                <div className="flex flex-col gap-0.5">
                  <span className="text-[8px] font-bold text-gray-400 uppercase tracking-wider">
                    Pernyataan Langsung yang Disampaikan:
                  </span>
                  <p className="text-[11px] text-gray-100 italic leading-relaxed">
                    "{item.whatWasSaid}"
                  </p>
                </div>
              </div>

              {/* Confluence Box: Relevance to News & Market Impact */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px]">
                {/* News Prediction Reinforcement */}
                <div className="p-2.5 rounded-xl bg-black/40 border border-emerald-500/25 flex flex-col gap-1">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-[8px] font-bold uppercase tracking-wider flex items-center gap-1 text-emerald-300">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      Penentu Sinyal &amp; Berita:
                    </span>
                    <span className="text-[8px] font-black px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {item.confidenceContribution}
                    </span>
                  </div>
                  <p className="text-[9px] leading-relaxed text-gray-300">
                    {item.relevanceToNews}
                  </p>
                </div>

                {/* Market Reaction */}
                <div className="p-2.5 rounded-xl bg-black/40 border border-cyan-500/25 flex flex-col gap-1">
                  <span className="text-[8px] font-bold uppercase tracking-wider flex items-center gap-1 text-cyan-300">
                    <TrendingUp className="w-3 h-3 text-cyan-400" />
                    Pergerakan Pasar (Gold &amp; BTC):
                  </span>
                  <p className="text-[9px] leading-relaxed text-white font-bold">
                    {item.marketReaction}
                  </p>
                  <span className="text-[7px] text-gray-500 flex items-center gap-1">
                    <span className="w-1 h-1 rounded-full bg-cyan-400 animate-pulse" />
                    Sumber: Transkrip Resmi Federal Reserve, White House &amp; Bloomberg
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
