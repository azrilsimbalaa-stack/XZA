import React from "react";
import { PrecisionSignalResult } from "../services/precisionSignalEngine";
import { RiskCalculatorConfig } from "./GacorRiskCalculator";

interface SupremeSignalAnalysisDashboardProps {
  currentSignal: PrecisionSignalResult | null;
  activeSymbol: { id: string; name: string };
  activeTimeframe: { id: string; name: string };
  currentPrice: number;
  onRefreshSignal?: () => void;
  isGenerating?: boolean;
  onSelectTimeframe?: (tf: string) => void;
  isOpen?: boolean;
  onClose?: () => void;
  isEmbedded?: boolean;
  riskCalculatorConfig?: RiskCalculatorConfig;
  onChangeRiskCalculatorConfig?: (config: RiskCalculatorConfig) => void;
}

export const SupremeSignalAnalysisDashboard: React.FC<SupremeSignalAnalysisDashboardProps> = ({
  isOpen = true,
  onClose,
}) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
      <div className="w-full max-w-xl rounded-2xl border border-amber-500/30 bg-[#0b0f19] p-5 text-white shadow-2xl">
        <div className="text-sm font-black text-amber-300">ANALISIS LANJUTAN BELUM TERSEDIA</div>
        <p className="mt-2 text-xs leading-relaxed text-slate-300">
          MTF, order-flow institusional, DRL, AMD/PO3, dan probabilitas belum memiliki pipeline sumber data serta validasi independen. Panel ini tidak menerbitkan angka sintetis. Quantitative Core v2 hanya dapat memberikan hasil setelah OHLCV dan quote bertimestamp lolos validasi.
        </p>
        {onClose && <button onClick={onClose} className="mt-4 rounded-lg border border-slate-600 px-3 py-2 text-xs font-bold text-slate-200">Tutup</button>}
      </div>
    </div>
  );
};
