import React, { useState } from "react";
import {
  TrendingUp,
  TrendingDown,
  Target,
  Shield,
  Zap,
  HelpCircle,
  Activity,
  ArrowRight,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Sliders,
  Bell,
  BellRing,
  Volume2,
} from "lucide-react";
import { DetectedChartPattern } from "../services/chartPatternEngine";

interface ChartPatternPredictionCardProps {
  activePattern: DetectedChartPattern | null;
  allPatterns?: DetectedChartPattern[];
  currentPrice: number;
  symbol?: string;
  timeframe?: string;
  notificationEnabled?: boolean;
  onToggleNotification?: () => void;
  onTestNotification?: () => void;
}

export const ChartPatternPredictionCard: React.FC<ChartPatternPredictionCardProps> = ({
  activePattern,
  allPatterns = [],
  currentPrice,
  symbol = "XAUUSD",
  timeframe = "M5",
  notificationEnabled = true,
  onToggleNotification,
  onTestNotification,
}) => {
  const [showAllPills, setShowAllPills] = useState(false);
  const [selectedPatternId, setSelectedPatternId] = useState<string | null>(null);

  const displayPattern =
    (selectedPatternId ? allPatterns.find((p) => p.id === selectedPatternId) : activePattern) ||
    activePattern;

  const patternDefinitions = [
    {
      name: "Double Bottom",
      type: "BULLISH",
      desc: "Dua titik rendah yang hampir sama, lalu breakout di atas leher (neckline).",
      action: "BUY setelah breakout",
    },
    {
      name: "Double Top",
      type: "BEARISH",
      desc: "Dua titik tinggi yang hampir sama, lalu breakdown di bawah leher.",
      action: "SELL setelah breakdown",
    },
    {
      name: "Head & Shoulders",
      type: "BEARISH",
      desc: "Tiga puncak, yang tengah lebih tinggi, lalu breakdown di leher.",
      action: "SELL setelah breakdown",
    },
    {
      name: "Inverse H&S",
      type: "BULLISH",
      desc: "Tiga lembah, yang tengah lebih rendah, lalu breakout di leher.",
      action: "BUY setelah breakout",
    },
    {
      name: "Bullish Flag",
      type: "BULLISH",
      desc: "Konsolidasi setelah tren naik, lalu breakout ke atas.",
      action: "BUY setelah breakout",
    },
    {
      name: "Bearish Flag",
      type: "BEARISH",
      desc: "Konsolidasi setelah tren turun, lalu breakdown ke bawah.",
      action: "SELL setelah breakdown",
    },
  ];

  const hasPermission =
    typeof window !== "undefined" &&
    "Notification" in window &&
    Notification.permission === "granted";

  return (
    <div id="chart-pattern-prediction-card" className="bg-[#0b101b] border border-slate-800/80 rounded-xl p-3.5 text-xs shadow-lg space-y-3">
      {/* Header Bar */}
      <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-800/60 pb-2.5">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-bold text-white text-sm tracking-tight flex items-center gap-1.5">
              Prediksi Pola Klasik & Breakout/Breakdown
            </h4>
            <p className="text-[10px] text-slate-400">
              Deteksi otomatis 6 pola geometris & notifikasi penembusan leher (neckline)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Desktop Push Notification Toggle */}
          {onToggleNotification && (
            <button
              id="pattern-notif-toggle-btn"
              onClick={onToggleNotification}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-bold text-[10px] border transition-all cursor-pointer ${
                notificationEnabled && hasPermission
                  ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-[0_0_12px_rgba(16,185,129,0.2)]"
                  : notificationEnabled
                  ? "bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse"
                  : "bg-slate-800/80 text-slate-400 border-slate-700/50 hover:text-slate-200"
              }`}
              title="Aktifkan notifikasi desktop saat terjadi breakout atau breakdown dari pola terdeteksi"
            >
              {notificationEnabled && hasPermission ? (
                <BellRing className="w-3 h-3 text-emerald-400 shrink-0" />
              ) : (
                <Bell className="w-3 h-3 text-amber-400 shrink-0" />
              )}
              <span>
                {!hasPermission
                  ? "🔔 Izinkan Notif Breakout"
                  : notificationEnabled
                  ? "🔔 Notif Breakout: AKTIF"
                  : "🔕 Notif: OFF"}
              </span>
            </button>
          )}

          {/* Test Alert Button */}
          {onTestNotification && (
            <button
              id="pattern-test-notif-btn"
              onClick={onTestNotification}
              className="px-2 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[10px] font-semibold transition-colors flex items-center gap-1"
              title="Kirim notifikasi desktop uji coba untuk penembusan pola klasik"
            >
              <span>Test Alert</span>
            </button>
          )}

          {/* Kamus Pola Trigger */}
          <button
            id="pattern-dictionary-toggle-btn"
            onClick={() => setShowAllPills(!showAllPills)}
            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-300 border border-slate-700/50 text-[10px] transition-colors"
          >
            <Sliders className="w-3 h-3 text-slate-400" />
            <span>Kamus Pola</span>
            {showAllPills ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>
      </div>

      {/* Kamus 6 Definisi Sederhana (Collapsible) */}
      {showAllPills && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-2.5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
          {patternDefinitions.map((item) => (
            <div
              key={item.name}
              className={`p-2 rounded border ${
                displayPattern?.name === item.name
                  ? "bg-indigo-950/40 border-indigo-500/50"
                  : "bg-slate-950/40 border-slate-800/60"
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-slate-200 text-[11px]">{item.name}</span>
                <span
                  className={`text-[9px] px-1.5 py-0.2 rounded font-semibold ${
                    item.type === "BULLISH"
                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                      : "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                  }`}
                >
                  {item.action}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 leading-tight">{item.desc}</p>
            </div>
          ))}
        </div>
      )}

      {/* Main Pattern Prediction Display */}
      {displayPattern ? (
        <div className="space-y-2.5">
          {/* Active Pattern Banner */}
          <div
            className={`p-3 rounded-lg border ${
              displayPattern.type === "BULLISH"
                ? "bg-emerald-950/20 border-emerald-500/30"
                : "bg-rose-950/20 border-rose-500/30"
            }`}
          >
            <div className="flex items-center justify-between flex-wrap gap-2 mb-1.5">
              <div className="flex items-center gap-2">
                {displayPattern.type === "BULLISH" ? (
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-rose-400" />
                )}
                <span className="font-extrabold text-white text-sm">
                  {displayPattern.name}
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider border ${
                    displayPattern.status === "BREAKOUT_CONFIRMED"
                      ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                      : displayPattern.status === "BREAKDOWN_CONFIRMED"
                      ? "bg-rose-500/20 text-rose-300 border-rose-500/40"
                      : "bg-amber-500/20 text-amber-300 border-amber-500/40"
                  }`}
                >
                  {displayPattern.statusLabel}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] text-slate-400">Validasi statistik:</span>
                <span className="font-bold text-amber-300 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                  {displayPattern.probabilityScore == null ? "BELUM DIKALIBRASI" : `${displayPattern.probabilityScore}%`}
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              <span className="text-slate-400">Definisi: </span>
              {displayPattern.definition}
            </p>
          </div>

          {/* Prediction Metric Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-lg p-2">
              <div className="flex items-center gap-1 text-[10px] text-slate-400 mb-0.5">
                <Shield className="w-3 h-3 text-indigo-400" />
                <span>Leher (Neckline)</span>
              </div>
              <div className="font-mono font-bold text-white text-xs">
                ${displayPattern.necklinePrice.toFixed(2)}
              </div>
              <div className="text-[9px] text-slate-500">
                {displayPattern.distanceToNecklinePips} pips dari harga saat ini
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800/80 rounded-lg p-2">
              <div className="flex items-center gap-1 text-[10px] text-slate-400 mb-0.5">
                <Zap className="w-3 h-3 text-amber-400" />
                <span>Rekomendasi</span>
              </div>
              <div
                className={`font-mono font-bold text-xs ${
                  displayPattern.actionRecommendation.includes("BUY")
                    ? "text-emerald-400"
                    : "text-rose-400"
                }`}
              >
                {displayPattern.actionRecommendation}
              </div>
              <div className="text-[9px] text-slate-500">
                R:R {displayPattern.riskRewardRatio}
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800/80 rounded-lg p-2">
              <div className="flex items-center gap-1 text-[10px] text-slate-400 mb-0.5">
                <Target className="w-3 h-3 text-emerald-400" />
                <span>Target Proyeksi</span>
              </div>
              <div className="font-mono font-bold text-emerald-400 text-xs">
                ${displayPattern.targetPrice.toFixed(2)}
              </div>
              <div className="text-[9px] text-slate-500">Measured Move</div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800/80 rounded-lg p-2">
              <div className="flex items-center gap-1 text-[10px] text-slate-400 mb-0.5">
                <Activity className="w-3 h-3 text-rose-400" />
                <span>Stop Loss Batas</span>
              </div>
              <div className="font-mono font-bold text-rose-400 text-xs">
                ${displayPattern.stopLossPrice.toFixed(2)}
              </div>
              <div className="text-[9px] text-slate-500">Invalidasi Pola</div>
            </div>
          </div>

          {/* Prediction & Execution Guide */}
          <div className="bg-slate-900/40 border border-slate-800/60 rounded-lg p-2.5 flex items-start gap-2">
            <div className="p-1 rounded bg-amber-500/10 border border-amber-500/20 text-amber-400 mt-0.5 shrink-0">
              <ArrowRight className="w-3 h-3" />
            </div>
            <div className="space-y-0.5">
              <span className="font-semibold text-slate-200 text-[11px]">
                {displayPattern.predictionSummary}
              </span>
              <p className="text-[10px] text-slate-400">
                {displayPattern.tradingGuideline}
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-slate-900/40 border border-dashed border-slate-800 rounded-lg p-3 text-center space-y-1">
          <p className="text-slate-300 font-medium text-[11px]">
            Memindai Pembentukan 6 Pola Klasik (M1 - D1)...
          </p>
          <p className="text-slate-500 text-[10px]">
            Sistem memantau secara real-time: Double Bottom, Double Top, H&S, Inverse H&S, Bullish Flag, dan Bearish Flag untuk memprediksi momen penembusan leher (breakout / breakdown).
          </p>
        </div>
      )}
    </div>
  );
};
