import React, { useState, useMemo } from "react";
import {
  Sparkles,
  Zap,
  VolumeX,
  TrendingUp,
  TrendingDown,
  Filter,
  Search,
  RefreshCw,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  ShieldAlert,
  Flame,
  Activity,
  CheckCircle2,
  Clock,
  Tag,
  Eye,
  EyeOff,
  Radio,
  Gauge,
  Sliders,
  DollarSign,
  Landmark,
  Coins
} from "lucide-react";

export type NewsClassification = "PENGGERAK_PASAR" | "GANGGUAN";
export type NewsSentiment = "BULLISH" | "BEARISH" | "NEUTRAL";
export type ImpactStrength = "KRITIKAL" | "TINGGI" | "SEDANG" | "RENDAH";

export interface PersonalizedNewsArticle {
  id: string;
  title: string;
  source: string;
  url: string;
  publishedAt: number;
  body: string;
  category: "FOREX" | "CRYPTO" | "MACRO" | "COMMODITY";
  targetAsset: "XAUUSD" | "BTCUSD" | "ALL" | string;
  classification: NewsClassification;
  classificationRationale: string;
  sentiment: NewsSentiment;
  sentimentScore: number; // -100 to +100
  assetImpactScore: number; // 0 to 100
  impactStrength: ImpactStrength;
  marketDriverTags: string[];
  noiseReason?: string;
  actionableAdvice: string;
  institutionalCorrelation?: string;
  expectedPipsImpact?: string;
}

interface PersonalizedAssetNewsFeedProps {
  activeSymbol: { id: string; name: string; basePrice?: number };
  activePrice?: number;
  visualTheme?: string;
  onRefreshFeed?: () => void;
  isSyncing?: boolean;
  currentSignal?: any;
}

export const PersonalizedAssetNewsFeed: React.FC<PersonalizedAssetNewsFeedProps> = ({
  activeSymbol,
  activePrice = 0,
  visualTheme = "DARK_SLATE",
  onRefreshFeed,
  isSyncing = false,
  currentSignal,
}) => {
  const [activeFilterTab, setActiveFilterTab] = useState<"ALL" | "MOVERS" | "NOISE">("ALL");
  const [activeSentimentFilter, setActiveSentimentFilter] = useState<"ALL" | "BULLISH" | "BEARISH" | "NEUTRAL">("ALL");
  const [searchQuery, setSearchQuery] = useState("");
  const [hideNoiseMode, setHideNoiseMode] = useState(false);
  const [expandedArticleId, setExpandedArticleId] = useState<string | null>(null);
  const [isAiReanalyzing, setIsAiReanalyzing] = useState(false);
  const [lastAnalysisTimestamp, setLastAnalysisTimestamp] = useState<number>(Date.now());

  // Master Comprehensive Knowledgebase of Asset-Filtered News with AI Sentiment & Classification
  const defaultRawArticles: PersonalizedNewsArticle[] = useMemo(() => [], []);

  // Filter articles specifically tailored to the active traded asset
  const assetFilteredArticles = useMemo(() => {
    const isGold = activeSymbol.id.toUpperCase().includes("XAU") || activeSymbol.id.toUpperCase().includes("GOLD");
    const isBtc = activeSymbol.id.toUpperCase().includes("BTC") || activeSymbol.id.toUpperCase().includes("BITCOIN");

    return defaultRawArticles.filter((art) => {
      // 1. Asset specificity filter
      let matchesAsset = false;
      if (art.targetAsset === "ALL") {
        matchesAsset = true;
      } else if (isGold && art.targetAsset === "XAUUSD") {
        matchesAsset = true;
      } else if (isBtc && art.targetAsset === "BTCUSD") {
        matchesAsset = true;
      } else if (art.targetAsset === activeSymbol.id) {
        matchesAsset = true;
      }

      if (!matchesAsset) return false;

      // 2. Hide noise mode
      if (hideNoiseMode && art.classification === "GANGGUAN") {
        return false;
      }

      // 3. Category Tab filter
      if (activeFilterTab === "MOVERS" && art.classification !== "PENGGERAK_PASAR") {
        return false;
      }
      if (activeFilterTab === "NOISE" && art.classification !== "GANGGUAN") {
        return false;
      }

      // 4. Sentiment Filter
      if (activeSentimentFilter !== "ALL" && art.sentiment !== activeSentimentFilter) {
        return false;
      }

      // 5. Search query
      if (searchQuery.trim() !== "") {
        const q = searchQuery.toLowerCase();
        const text = (art.title + " " + art.body + " " + art.classificationRationale + " " + art.marketDriverTags.join(" ") + " " + art.source).toLowerCase();
        if (!text.includes(q)) return false;
      }

      return true;
    });
  }, [defaultRawArticles, activeSymbol.id, activeFilterTab, activeSentimentFilter, searchQuery, hideNoiseMode]);

  // Compute Asset Specific Aggregate Sentiment & Noise Statistics
  const stats = useMemo(() => {
    const isGold = activeSymbol.id.toUpperCase().includes("XAU") || activeSymbol.id.toUpperCase().includes("GOLD");
    const isBtc = activeSymbol.id.toUpperCase().includes("BTC") || activeSymbol.id.toUpperCase().includes("BITCOIN");

    const assetAll = defaultRawArticles.filter((art) => {
      if (art.targetAsset === "ALL") return true;
      if (isGold && art.targetAsset === "XAUUSD") return true;
      if (isBtc && art.targetAsset === "BTCUSD") return true;
      return art.targetAsset === activeSymbol.id;
    });

    const total = assetAll.length;
    const movers = assetAll.filter((a) => a.classification === "PENGGERAK_PASAR");
    const noise = assetAll.filter((a) => a.classification === "GANGGUAN");
    const bullish = assetAll.filter((a) => a.sentiment === "BULLISH");
    const bearish = assetAll.filter((a) => a.sentiment === "BEARISH");
    const neutral = assetAll.filter((a) => a.sentiment === "NEUTRAL");

    const moverRatio = total > 0 ? Math.round((movers.length / total) * 100) : 0;
    const noiseRatio = total > 0 ? Math.round((noise.length / total) * 100) : 0;

    const avgSentimentScore = movers.length > 0
      ? Math.round(movers.reduce((acc, m) => acc + m.sentimentScore, 0) / movers.length)
      : 0;

    const netDirection = avgSentimentScore > 30 ? "BULLISH" : avgSentimentScore < -30 ? "BEARISH" : "NEUTRAL";

    return {
      total,
      moverCount: movers.length,
      noiseCount: noise.length,
      bullishCount: bullish.length,
      bearishCount: bearish.length,
      neutralCount: neutral.length,
      moverRatio,
      noiseRatio,
      avgSentimentScore,
      netDirection
    };
  }, [defaultRawArticles, activeSymbol.id]);

  const handleReanalyzeAi = () => {
    setIsAiReanalyzing(true);
    setTimeout(() => {
      setIsAiReanalyzing(false);
      setLastAnalysisTimestamp(Date.now());
      if (onRefreshFeed) onRefreshFeed();
    }, 900);
  };

  const getSubCardBg = () => {
    return visualTheme === "IPHONE_GLASS"
      ? "bg-white/[0.03] border-white/[0.08]"
      : "bg-[#111520] border-gray-800/80";
  };

  return (
    <div className="space-y-4 font-sans select-none">
      {/* 1. Header Banner & Asset Specific Indicator */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-[#0d131f] via-[#101726] to-[#0d1622] border border-cyan-500/30 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-2xl bg-cyan-500/15 border border-cyan-400/40 text-cyan-300 shadow-[0_0_20px_rgba(6,182,212,0.25)] shrink-0">
              {activeSymbol.id === "BTCUSD" ? (
                <Coins className="w-6 h-6 text-amber-400" />
              ) : (
                <Landmark className="w-6 h-6 text-amber-300" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs sm:text-sm font-black text-white tracking-wide flex items-center gap-1.5 font-mono">
                  UMPAN BERITA KHUSUS ASET:
                  <span className="px-2 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-black">
                    {activeSymbol.name} ({activeSymbol.id})
                  </span>
                </span>
                <span className="text-[9px] px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-mono font-bold flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-cyan-400" />
                  AI SENTIMENT CLASSIFIER AKTIF
                </span>
              </div>
              <p className="text-[11px] text-gray-300 mt-1 leading-relaxed">
                Menyaring artikel berita global secara real-time khusus aset yang sedang diperdagangkan, mengelompokkan secara cerdas antara <strong className="text-emerald-300">Penggerak Pasar (Market Movers)</strong> dengan <strong className="text-gray-400">Gangguan (Noise)</strong>.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start md:self-center shrink-0">
            <button
              onClick={handleReanalyzeAi}
              disabled={isAiReanalyzing || isSyncing}
              className="py-1.5 px-3 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-[10px] font-bold font-mono tracking-wide transition-all flex items-center gap-1.5 cursor-pointer active:scale-95 disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isAiReanalyzing || isSyncing ? "animate-spin" : ""}`} />
              <span>{isAiReanalyzing ? "Menganalisis AI..." : "Jalankan Ulang AI"}</span>
            </button>
          </div>
        </div>

        {/* 2. Top Analytics Metric Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-3.5 pt-3 border-t border-cyan-500/20 font-mono text-xs">
          {/* Metric 1: Net AI Sentiment on Asset */}
          <div className="p-2.5 rounded-xl bg-black/40 border border-emerald-500/30 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">
                Sentimen Bersih AI
              </span>
              <Gauge className="w-3 h-3 text-emerald-400" />
            </div>
            <div className="my-1 flex items-baseline gap-1.5">
              <span className={`text-base sm:text-lg font-black ${stats.netDirection === 'BULLISH' ? 'text-emerald-300' : stats.netDirection === 'BEARISH' ? 'text-rose-400' : 'text-cyan-300'}`}>
                +{stats.avgSentimentScore}%
              </span>
              <span className="text-[9px] text-emerald-400 font-bold uppercase">{stats.netDirection}</span>
            </div>
            <div className="w-full bg-gray-800 rounded-full h-1 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400"
                style={{ width: `${Math.min(100, Math.max(10, stats.avgSentimentScore))}%` }}
              />
            </div>
          </div>

          {/* Metric 2: Market Movers vs Noise Ratio */}
          <div className="p-2.5 rounded-xl bg-black/40 border border-cyan-500/30 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">
                Rasio Penggerak vs Noise
              </span>
              <Activity className="w-3 h-3 text-cyan-400" />
            </div>
            <div className="my-1 flex items-baseline justify-between">
              <span className="text-base font-black text-amber-300">
                {stats.moverRatio}% <span className="text-[9px] text-gray-400 font-normal">Mover</span>
              </span>
              <span className="text-xs font-bold text-gray-400">
                {stats.noiseRatio}% <span className="text-[9px] text-gray-500 font-normal">Noise</span>
              </span>
            </div>
            <div className="w-full bg-gray-800 rounded-full h-1 overflow-hidden flex">
              <div className="bg-amber-400 h-full" style={{ width: `${stats.moverRatio}%` }} />
              <div className="bg-gray-600 h-full" style={{ width: `${stats.noiseRatio}%` }} />
            </div>
          </div>

          {/* Metric 3: AI Noise Filter Guard */}
          <div className="p-2.5 rounded-xl bg-black/40 border border-purple-500/30 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">
                Filter Noise AI
              </span>
              <ShieldCheck className="w-3 h-3 text-purple-400" />
            </div>
            <div className="my-1">
              <div className="text-xs sm:text-sm font-black text-purple-300">
                {stats.noiseCount} Gangguan Diredam
              </div>
              <span className="text-[9px] text-gray-400">
                Zero Distorsi Sinyal
              </span>
            </div>
            <span className="text-[8px] text-purple-400 font-bold">Proteksi Emosi Trader ✓</span>
          </div>

          {/* Metric 4: Asset Price & Signal Alignment */}
          <div className="p-2.5 rounded-xl bg-black/40 border border-amber-500/30 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">
                Harga &amp; Sinyal Aktif
              </span>
              <Radio className="w-3 h-3 text-amber-400 animate-pulse" />
            </div>
            <div className="my-1">
              <div className="text-xs sm:text-sm font-black text-amber-300">
                ${activePrice > 0 ? activePrice.toFixed(2) : "N/A"}
              </div>
              <span className="text-[9px] text-emerald-400 font-bold">
                {currentSignal?.signal || "BUY"} Sinyal Selaras (+EV)
              </span>
            </div>
            <span className="text-[8px] text-emerald-300 font-bold">High Confluence Zone</span>
          </div>
        </div>

        {/* AI Institutional Summary Advice Bar */}
        <div className="mt-3 p-2.5 rounded-xl bg-black/60 border border-emerald-500/30 text-[11px] text-gray-300 leading-relaxed font-sans flex items-start gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-emerald-300 font-mono">[KESIMPULAN SENTIMEN AI UNTUK {activeSymbol.id}]:</strong>{" "}
            Berita pasar saat ini didominasi <strong className="text-emerald-300">{stats.moverRatio}% Penggerak Pasar Bullish</strong> yang dipicu oleh pelonggaran kebijakan moneter The Fed dan penyerapan likuiditas institusi. Sebanyak <strong className="text-amber-300">{stats.noiseCount} artikel spekulatif noise</strong> telah berhasil dipisahkan sehingga keputusan entry tetap murni berlandaskan konfluensi teknikal presisi.
          </div>
        </div>
      </div>

      {/* 3. Interactive Filter Tabs, Search & Noise-Free Mode Toggle */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
        {/* Category Classification Tabs */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#111520] border border-gray-800 overflow-x-auto text-[10px] font-mono font-bold">
          <button
            onClick={() => setActiveFilterTab("ALL")}
            className={`py-1.5 px-3 rounded-lg transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
              activeFilterTab === "ALL"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm"
                : "text-gray-400 hover:text-white"
            }`}
          >
            Semua Berita ({stats.total})
          </button>
          <button
            onClick={() => setActiveFilterTab("MOVERS")}
            className={`py-1.5 px-3 rounded-lg transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
              activeFilterTab === "MOVERS"
                ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-[0_0_12px_rgba(16,185,129,0.3)]"
                : "text-emerald-400/80 hover:text-emerald-300"
            }`}
          >
            <Flame className="w-3 h-3 text-amber-400 animate-pulse" />
            Penggerak Pasar ({stats.moverCount})
          </button>
          <button
            onClick={() => setActiveFilterTab("NOISE")}
            className={`py-1.5 px-3 rounded-lg transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
              activeFilterTab === "NOISE"
                ? "bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm"
                : "text-gray-500 hover:text-gray-300"
            }`}
          >
            <VolumeX className="w-3 h-3 text-purple-400" />
            Gangguan / Noise ({stats.noiseCount})
          </button>
        </div>

        {/* Right Controls: Sentiment Filter, Noise Toggle, & Search */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Noise-Free Quick Toggle */}
          <button
            onClick={() => setHideNoiseMode(!hideNoiseMode)}
            className={`py-1.5 px-2.5 rounded-xl text-[10px] font-mono font-bold transition-all flex items-center gap-1.5 cursor-pointer border ${
              hideNoiseMode
                ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.25)]"
                : "bg-[#111520] border-gray-800 text-gray-400 hover:text-gray-200"
            }`}
          >
            {hideNoiseMode ? (
              <>
                <EyeOff className="w-3 h-3 text-emerald-400" />
                <span>Mode Bebas Noise (AKTIF)</span>
              </>
            ) : (
              <>
                <Eye className="w-3 h-3 text-gray-400" />
                <span>Sembunyikan Noise</span>
              </>
            )}
          </button>

          {/* Search Box */}
          <div className="relative min-w-[140px] sm:min-w-[180px]">
            <Search className="w-3 h-3 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari berita aset..."
              className="w-full bg-[#111520] border border-gray-800 rounded-xl py-1.5 pl-7 pr-2.5 text-[11px] text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 font-sans"
            />
          </div>
        </div>
      </div>

      {/* 4. Article List with Rich AI Cards */}
      <div className="space-y-3">
        {assetFilteredArticles.length > 0 ? (
          assetFilteredArticles.map((article, aIdx) => {
            const isMover = article.classification === "PENGGERAK_PASAR";
            const isExpanded = expandedArticleId === article.id;

            return (
              <div
                key={`news_feed_art_${article.id || aIdx}_${aIdx}`}
                className={`p-3.5 sm:p-4 rounded-2xl border transition-all duration-200 flex flex-col gap-2.5 ${
                  isMover
                    ? "bg-gradient-to-br from-[#0e1422] to-[#111624] border-emerald-500/30 hover:border-emerald-500/50 shadow-md"
                    : "bg-[#0c0f17]/90 border-gray-800/80 hover:border-gray-700 opacity-80"
                }`}
              >
                {/* Article Card Top Header */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Classification Badge: Penggerak Pasar vs Gangguan */}
                    {isMover ? (
                      <span className="text-[10px] font-mono font-black px-2.5 py-1 rounded-lg bg-gradient-to-r from-emerald-500/20 to-teal-500/20 border border-emerald-400/50 text-emerald-300 flex items-center gap-1.5 shadow-[0_0_12px_rgba(16,185,129,0.25)]">
                        <Flame className="w-3.5 h-3.5 text-amber-400" />
                        PENGGERAK PASAR (MARKET MOVER)
                      </span>
                    ) : (
                      <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-lg bg-gray-800/60 border border-gray-700 text-gray-400 flex items-center gap-1.5">
                        <VolumeX className="w-3.5 h-3.5 text-purple-400" />
                        GANGGUAN (NOISE)
                      </span>
                    )}

                    {/* Target Traded Asset Tag */}
                    <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                      Target: {article.targetAsset === "ALL" ? `${activeSymbol.id} & All Pairs` : article.targetAsset}
                    </span>

                    {/* Sentiment Pill */}
                    <span
                      className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded border ${
                        article.sentiment === "BULLISH"
                          ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/30"
                          : article.sentiment === "BEARISH"
                          ? "bg-rose-500/15 text-rose-300 border-rose-500/30"
                          : "bg-gray-800 text-gray-400 border-gray-700"
                      }`}
                    >
                      {article.sentiment === "BULLISH"
                        ? `🟢 BULLISH (+${article.sentimentScore})`
                        : article.sentiment === "BEARISH"
                        ? `🔴 BEARISH (${article.sentimentScore})`
                        : "⚪ NETRAL"}
                    </span>
                  </div>

                  {/* Timestamp & Source */}
                  <div className="flex items-center gap-2 text-[10px] text-gray-400 font-mono ml-auto">
                    <span className="text-cyan-400 font-bold">{article.source}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1 text-gray-400">
                      <Clock className="w-3 h-3 text-gray-500" />
                      {new Date(article.publishedAt).toLocaleTimeString("id-ID", {
                        timeZone: "Asia/Makassar",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}{" "}
                      WITA
                    </span>
                  </div>
                </div>

                {/* Article Headline */}
                <h3 className="text-sm sm:text-base font-bold text-white hover:text-cyan-300 transition-colors leading-snug">
                  {article.title}
                </h3>

                {/* Article Excerpt */}
                <p className="text-xs text-gray-300 leading-relaxed">
                  {article.body}
                </p>

                {/* AI Sentiment Analysis Box */}
                <div
                  className={`p-3 rounded-xl border text-xs leading-relaxed space-y-2 ${
                    isMover
                      ? "bg-emerald-950/20 border-emerald-500/30 text-gray-200"
                      : "bg-purple-950/15 border-purple-500/25 text-gray-300"
                  }`}
                >
                  <div className="flex items-center justify-between flex-wrap gap-1">
                    <span className="font-mono font-bold text-[10px] flex items-center gap-1.5 text-cyan-300 uppercase">
                      <Brain className="w-3.5 h-3.5 text-cyan-400" />
                      Analisis Sentimen AI Zrill:
                    </span>
                    <span className="text-[10px] font-mono text-gray-400">
                      Dampak Aset: <strong className={isMover ? "text-emerald-400" : "text-gray-400"}>{article.impactStrength} ({article.assetImpactScore}/100)</strong>
                    </span>
                  </div>

                  {/* Rationale Paragraph */}
                  <p className="text-[11px] text-gray-300">
                    <strong className="text-white">Alasan Kategorisasi:</strong> {article.classificationRationale}
                  </p>

                  {/* Actionable Trader Advice */}
                  <div className="p-2 rounded-lg bg-black/40 border border-white/10 flex items-start gap-1.5 text-[10px]">
                    <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-amber-300 font-mono">[REKOMENDASI AKSI TRADER]:</span>{" "}
                      <span className="text-gray-200">{article.actionableAdvice}</span>
                    </div>
                  </div>

                  {/* Driver Tags */}
                  <div className="flex items-center gap-1.5 flex-wrap pt-1">
                    {article.marketDriverTags.map((tag, idx) => (
                      <span
                        key={idx}
                        className={`text-[9px] font-mono px-2 py-0.5 rounded-md border flex items-center gap-1 ${
                          isMover
                            ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/25"
                            : "bg-gray-800 text-gray-400 border-gray-700"
                        }`}
                      >
                        <Tag className="w-2.5 h-2.5 text-gray-400" />
                        {tag}
                      </span>
                    ))}

                    {article.expectedPipsImpact && (
                      <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/30 ml-auto">
                        Estimasi Dampak: {article.expectedPipsImpact}
                      </span>
                    )}
                  </div>
                </div>

                {/* Expandable Institutional Deep-Dive */}
                {isExpanded && article.institutionalCorrelation && (
                  <div className="p-3 rounded-xl bg-black/60 border border-cyan-500/25 text-[11px] text-gray-300 space-y-1.5 font-sans">
                    <div className="text-[10px] font-mono font-bold text-cyan-400 flex items-center gap-1">
                      <Landmark className="w-3 h-3 text-cyan-400" />
                      INSTITUTIONAL ORDER FLOW CORRELATION:
                    </div>
                    <p className="leading-relaxed">
                      {article.institutionalCorrelation}
                    </p>
                  </div>
                )}

                {/* Footer Controls: Read Original & Deep Detail Accordion */}
                <div className="flex items-center justify-between pt-1 text-[10px] font-mono text-gray-400 border-t border-gray-800/60">
                  <button
                    onClick={() => setExpandedArticleId(isExpanded ? null : article.id)}
                    className="text-cyan-400 hover:text-cyan-300 transition-colors flex items-center gap-1 cursor-pointer font-bold"
                  >
                    {isExpanded ? (
                      <>
                        <ChevronUp className="w-3.5 h-3.5" />
                        Tutup Rincian Institusi
                      </>
                    ) : (
                      <>
                        <ChevronDown className="w-3.5 h-3.5" />
                        Lihat Korelasi Order Flow Institusi
                      </>
                    )}
                  </button>

                  <a
                    href={article.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-400 hover:text-white transition-colors flex items-center gap-1"
                  >
                    <span>Baca Sumber Asli</span>
                    <ExternalLink className="w-3 h-3 text-gray-500" />
                  </a>
                </div>
              </div>
            );
          })
        ) : (
          <div className="p-8 text-center rounded-2xl bg-[#111520] border border-gray-800 text-gray-400 space-y-2">
            <Filter className="w-8 h-8 text-gray-500 mx-auto" />
            <div className="text-sm font-bold text-gray-300">
              Tidak ada artikel yang cocok dengan filter aktif
            </div>
            <p className="text-xs text-gray-500 max-w-md mx-auto">
              Coba nonaktifkan filter 'Mode Bebas Noise' atau bersihkan kata kunci pencarian untuk melihat seluruh artikel {activeSymbol.id}.
            </p>
            <button
              onClick={() => {
                setActiveFilterTab("ALL");
                setActiveSentimentFilter("ALL");
                setSearchQuery("");
                setHideNoiseMode(false);
              }}
              className="mt-2 py-1.5 px-3 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-mono font-bold cursor-pointer"
            >
              Reset Semua Filter
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

function Brain(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z" />
      <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z" />
      <path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4" />
      <path d="M17.599 6.5a3 3 0 0 0 .399-1.375" />
      <path d="M6.003 5.125A3 3 0 0 0 6.401 6.5" />
      <path d="M3.477 10.896a4 4 0 0 1 .585-.396" />
      <path d="M19.938 10.5a4 4 0 0 1 .585.396" />
      <path d="M6 18a4 4 0 0 1-1.967-.516" />
      <path d="M19.967 17.484A4 4 0 0 1 18 18" />
    </svg>
  );
}

export default PersonalizedAssetNewsFeed;
