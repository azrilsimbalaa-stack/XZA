import React from "react";
import { AmdPhaseAnalysis } from "../services/precisionSignalEngine";

interface AmdPhaseAnalysisCardProps {
  amdAnalysis?: AmdPhaseAnalysis;
  symbol: string;
  isBuy: boolean;
  currentPrice: number;
}

export const AmdPhaseAnalysisCard: React.FC<AmdPhaseAnalysisCardProps> = ({ amdAnalysis }) => {
  if (!amdAnalysis) return null;
  return (
    <div className="rounded-xl border border-amber-500/30 bg-slate-900/90 p-4 text-xs text-slate-300">
      <div className="font-bold text-amber-300">AMD / PO3 TIMELINE UNAVAILABLE</div>
      <p className="mt-2">Urutan fase historis tidak ditampilkan. Panel ini belum menerima rangkaian OHLCV terverifikasi yang cukup untuk membangun timeline tanpa simulasi.</p>
    </div>
  );
};
