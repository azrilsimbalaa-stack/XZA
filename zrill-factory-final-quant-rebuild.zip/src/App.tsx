import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  Clock,
  Filter,
  Search,
  X,
  CheckCircle2,
  XCircle,
  Flame,
  Zap,
  ArrowRight,
  ArrowUpRight,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Bell,
  Play,
  Target,
  Sparkles,
  Scale,
} from "lucide-react";
import {
  buildComprehensiveEconomicEvent,
  UpgradedEconomicEvent,
} from "./services/institutionalCalendarEngine";

// Audio chime generator using Web Audio API for push & spike notifications
function playAlertChime() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(587.33, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.18);
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.65);
  } catch (e) {
    // Ignore autoplay restriction before user interaction
  }
}

// WITA Timezone (Asia/Makassar, UTC+8) Helpers
function getWitaYMD(msOrIso: number | string = Date.now()): string {
  const d = new Date(msOrIso);
  return d.toLocaleDateString("en-CA", { timeZone: "Asia/Makassar" });
}

function shiftWitaYMD(ymd: string, daysOffset: number): string {
  const [y, m, d] = ymd.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + daysOffset, 12, 0, 0));
  return dt.toISOString().slice(0, 10);
}

const DAY_NAMES_SHORT = ["MIN", "SEN", "SEL", "RAB", "KAM", "JUM", "SAB"];
const DAY_NAMES_FULL = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
const MONTH_NAMES_FULL = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember"
];

function getWitaDayOfWeek(ymd: string): number {
  const [y, m, d] = ymd.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  return dt.getUTCDay();
}

function formatWitaDateFull(ymd: string): string {
  try {
    const [y, m, d] = ymd.split("-").map(Number);
    const dt = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
    const dayName = DAY_NAMES_FULL[dt.getUTCDay()];
    const monthName = MONTH_NAMES_FULL[m - 1];
    return `${dayName}, ${d} ${monthName} ${y} (WITA)`;
  } catch {
    return ymd;
  }
}

function getMondayOfWeek(ymd: string): string {
  const [y, m, d] = ymd.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  const day = dt.getUTCDay();
  const diffToMonday = day === 0 ? -6 : 1 - day;
  return shiftWitaYMD(ymd, diffToMonday);
}

// Relative day label calculator (WITA Timezone Asia/Makassar)
function getRelativeDayLabel(
  dateStr: string,
  nowMs: number
): { label: "HARI INI" | "BESOK" | "KEMARIN" | "MENDATANG" | "LEWAT"; badgeClass: string } {
  try {
    const evYmd = getWitaYMD(dateStr);
    const nowYmd = getWitaYMD(nowMs);

    const evDateOnly = new Date(evYmd + "T00:00:00Z").getTime();
    const nowDateOnly = new Date(nowYmd + "T00:00:00Z").getTime();
    const diffDays = Math.round((evDateOnly - nowDateOnly) / (24 * 3600 * 1000));

    if (diffDays === 0) {
      return { label: "HARI INI", badgeClass: "bg-emerald-500/25 text-emerald-300 border-emerald-500/40" };
    } else if (diffDays === 1) {
      return { label: "BESOK", badgeClass: "bg-blue-500/25 text-blue-300 border-blue-500/40" };
    } else if (diffDays === -1) {
      return { label: "KEMARIN", badgeClass: "bg-purple-500/25 text-purple-300 border-purple-500/40" };
    } else if (diffDays > 1) {
      return { label: "MENDATANG", badgeClass: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30" };
    } else {
      return { label: "LEWAT", badgeClass: "bg-gray-800/60 text-gray-400 border-gray-700/50" };
    }
  } catch {
    return { label: "HARI INI", badgeClass: "bg-emerald-500/25 text-emerald-300 border-emerald-500/40" };
  }
}

// Countdown ticker digital: kotak per unit bg-black/60 px-2 py-0.5 rounded-lg border border-white/10 font-mono
function CountdownTicker({ targetMs, nowMs }: { targetMs: number; nowMs: number }) {
  const diffMs = Math.max(0, targetMs - nowMs);
  const totalSec = Math.floor(diffMs / 1000);
  const hours = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  const isUrgent = diffMs <= 5 * 60 * 1000 && diffMs > 0;

  const pad = (n: number) => n.toString().padStart(2, "0");

  if (diffMs <= 0) {
    return (
      <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono text-[10px] font-bold">
        Baru saja dirilis
      </span>
    );
  }

  return (
    <div className="flex items-center gap-1 font-mono text-xs">
      <div className="bg-black/60 px-2 py-0.5 rounded-lg border border-white/10 flex items-baseline gap-0.5">
        <span className="text-amber-300 font-black">{pad(hours)}</span>
        <span className="text-[8px] text-gray-400 uppercase">J</span>
      </div>
      <span className="text-amber-400 font-black animate-pulse">:</span>
      <div className="bg-black/60 px-2 py-0.5 rounded-lg border border-white/10 flex items-baseline gap-0.5">
        <span className="text-amber-300 font-black">{pad(mins)}</span>
        <span className="text-[8px] text-gray-400 uppercase">M</span>
      </div>
      <span className="text-amber-400 font-black animate-pulse">:</span>
      <div
        className={`bg-black/60 px-2 py-0.5 rounded-lg border flex items-baseline gap-0.5 ${
          isUrgent ? "border-rose-500/60 bg-rose-950/40 animate-pulse" : "border-white/10"
        }`}
      >
        <span className={`font-black ${isUrgent ? "text-rose-400 animate-ping inline-block" : "text-amber-300"}`}>
          {pad(secs)}
        </span>
        <span className={`text-[8px] uppercase ${isUrgent ? "text-rose-300" : "text-gray-400"}`}>D</span>
      </div>
    </div>
  );
}

export default function App() {
  const [economicEvents, setEconomicEvents] = useState<UpgradedEconomicEvent[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncTimestamp, setLastSyncTimestamp] = useState<number>(Date.now());
  const [nowTicker, setNowTicker] = useState<number>(Date.now());

  // Today in WITA
  const todayWitaYMD = useMemo(() => getWitaYMD(nowTicker), [nowTicker]);

  // Date range bounds: 30 days past to 90 days future
  const minAllowedYMD = useMemo(() => shiftWitaYMD(todayWitaYMD, -30), [todayWitaYMD]);
  const maxAllowedYMD = useMemo(() => shiftWitaYMD(todayWitaYMD, 90), [todayWitaYMD]);

  // Date Picker state
  const [dateMode, setDateMode] = useState<"SINGLE" | "WEEK">("SINGLE");
  const [selectedDate, setSelectedDate] = useState<string>(todayWitaYMD);
  const [selectedWeekMonday, setSelectedWeekMonday] = useState<string>(() => getMondayOfWeek(getWitaYMD(Date.now())));
  const [stripAnchorDate, setStripAnchorDate] = useState<string>(todayWitaYMD);
  const [isCalendarPopupOpen, setIsCalendarPopupOpen] = useState<boolean>(false);
  const [popupViewYearMonth, setPopupViewYearMonth] = useState<{ year: number; month: number }>(() => {
    const [y, m] = getWitaYMD(Date.now()).split("-").map(Number);
    return { year: y, month: m - 1 };
  });
  const [autoWeekendShiftNotice, setAutoWeekendShiftNotice] = useState<string>("");

  const calendarButtonRef = useRef<HTMLButtonElement | null>(null);
  const calendarPopupRef = useRef<HTMLDivElement | null>(null);

  // Live XAU/USD Gold spot ticker state
  const [livePrice, setLivePrice] = useState<{ price: number; bid: number; ask: number; ch: number; chp: number }>({
    price: 2685.4,
    bid: 2685.1,
    ask: 2685.7,
    ch: 14.8,
    chp: 0.55,
  });

  // Radar Tier-1 mode toggle
  const [radarActive, setRadarActive] = useState<boolean>(true);

  // Filters
  const [statusFilter, setStatusFilter] = useState<"ALL" | "RELEASED" | "UPCOMING">("ALL");
  const [impactFilter, setImpactFilter] = useState<"ALL" | "HIGH" | "MEDIUM" | "LOW">("ALL");
  const [spikeFilter, setSpikeFilter] = useState<"ALL" | "HIGH_SPIKE" | "LOW_SPIKE">("ALL");
  const [accuracyFilter, setAccuracyFilter] = useState<"ALL" | "TEPAT" | "MELESET">("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Notification states
  const [spikeNotificationEnabled, setSpikeNotificationEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem("zrill_spike_notif_enabled") === "true";
    } catch {
      return true;
    }
  });

  const [activeSpikeAlert, setActiveSpikeAlert] = useState<{
    id: string;
    title: string;
    currency: string;
    minutesLeft: number;
    timeStr: string;
    estimatedPips: string;
  } | null>(null);

  // Selected event modal for deep 4-Pilar Pegangan Kuat & Scenario Playbook
  const [selectedEventModal, setSelectedEventModal] = useState<UpgradedEconomicEvent | null>(null);

  // Expanded cards inline accordion tracker
  const [expandedCardIds, setExpandedCardIds] = useState<Record<string, boolean>>({});

  const toggleCardExpand = (id: string) => {
    setExpandedCardIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Close calendar popup on click outside or Escape key
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        calendarPopupRef.current &&
        !calendarPopupRef.current.contains(event.target as Node) &&
        calendarButtonRef.current &&
        !calendarButtonRef.current.contains(event.target as Node)
      ) {
        setIsCalendarPopupOpen(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setIsCalendarPopupOpen(false);
      }
    };

    if (isCalendarPopupOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isCalendarPopupOpen]);

  // 1-Second Global Clock Ticker for Live Countdown & WITA Synchronization
  useEffect(() => {
    const timer = setInterval(() => {
      setNowTicker(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Fetch official calendar from `/api/calendar`
  const fetchCalendar = async (isBackground = false) => {
    if (!isBackground) setIsSyncing(true);
    try {
      const res = await fetch(`/api/calendar?t=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        if (data && Array.isArray(data.result) && data.result.length > 0) {
          const list: UpgradedEconomicEvent[] = data.result.map((item: any) => {
            if (item.id && item.estimatedActual && item.spikePrediction) {
              return item as UpgradedEconomicEvent;
            }
            return buildComprehensiveEconomicEvent(item, Date.now());
          });

          // Smart Equality Guard: Only update state if data actually changed to prevent re-render flickers
          setEconomicEvents((prev) => {
            if (prev.length !== list.length) return list;
            let isDifferent = false;
            for (let i = 0; i < prev.length; i++) {
              if (
                prev[i].id !== list[i].id ||
                prev[i].actual !== list[i].actual ||
                prev[i].forecast !== list[i].forecast ||
                prev[i].isReleased !== list[i].isReleased ||
                prev[i].estimatedActual !== list[i].estimatedActual
              ) {
                isDifferent = true;
                break;
              }
            }
            return isDifferent ? list : prev;
          });

          setLastSyncTimestamp(data.timestamp || Date.now());
        }
      }
    } catch (err) {
      console.warn("Calendar fetch error, keeping cached state:", err);
    } finally {
      setIsLoading(false);
      setIsSyncing(false);
    }
  };

  // Live Price Polling from TradingView
  useEffect(() => {
    const fetchLivePrice = async () => {
      try {
        const res = await fetch("/api/tradingview/price?symbol=XAUUSD");
        if (res.ok) {
          const p = await res.json();
          if (p && p.price > 0) {
            const nextPrice = Number(p.price.toFixed(2));
            const nextBid = Number((p.bid || p.price - 0.3).toFixed(2));
            const nextAsk = Number((p.ask || p.price + 0.3).toFixed(2));
            const nextCh = Number((p.ch || 0).toFixed(2));
            const nextChp = Number((p.chp || 0).toFixed(2));

            setLivePrice((prev) => {
              if (
                prev.price === nextPrice &&
                prev.bid === nextBid &&
                prev.ask === nextAsk &&
                prev.ch === nextCh &&
                prev.chp === nextChp
              ) {
                return prev;
              }
              return {
                price: nextPrice,
                bid: nextBid,
                ask: nextAsk,
                ch: nextCh,
                chp: nextChp,
              };
            });
          }
        }
      } catch {}
    };

    fetchLivePrice();
    const interval = setInterval(fetchLivePrice, 4000);
    return () => clearInterval(interval);
  }, []);

  // Initial fetch and auto-refresh every 8 seconds
  useEffect(() => {
    fetchCalendar();
    const interval = setInterval(() => {
      fetchCalendar(true);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  // Weekend auto-shift rule:
  // If today is Saturday or Sunday and there are no events on today, automatically move to next weekday with events
  useEffect(() => {
    if (economicEvents.length === 0) return;
    const dayOfWeek = getWitaDayOfWeek(todayWitaYMD);
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      const todayEvents = economicEvents.filter((e) => getWitaYMD(e.date) === todayWitaYMD);
      if (todayEvents.length === 0) {
        // Find next day with events
        const futureDays = [1, 2, 3, 4, 5, 6, 7];
        for (const offset of futureDays) {
          const nextYmd = shiftWitaYMD(todayWitaYMD, offset);
          const hasEvents = economicEvents.some((e) => getWitaYMD(e.date) === nextYmd);
          if (hasEvents) {
            setSelectedDate(nextYmd);
            setStripAnchorDate(nextYmd);
            setAutoWeekendShiftNotice("Pasar tutup, menampilkan hari kerja berikutnya");
            break;
          }
        }
      }
    }
  }, [economicEvents, todayWitaYMD]);

  // Spike Alert Watcher: Detect high-spike event within 5 minutes of release
  const alertedIdsRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    if (!spikeNotificationEnabled || economicEvents.length === 0) return;

    economicEvents.forEach((ev) => {
      const isHighSpike =
        ev.spikePrediction?.spikeType === "HIGH_SPIKE" ||
        ev.importance === 1 ||
        /cpi|nfp|fomc|fed|unemployment|gdp|pce/i.test(ev.title || "");

      if (!isHighSpike) return;

      const evTime = new Date(ev.date).getTime();
      const diffMs = evTime - nowTicker;
      const diffMins = Math.floor(diffMs / (60 * 1000));

      if (diffMs > 0 && diffMins <= 5 && !alertedIdsRef.current.has(ev.id)) {
        alertedIdsRef.current.add(ev.id);
        const witaTimeStr = new Date(ev.date).toLocaleTimeString("id-ID", {
          timeZone: "Asia/Makassar",
          hour: "2-digit",
          minute: "2-digit",
        });

        setActiveSpikeAlert({
          id: ev.id,
          title: ev.title,
          currency: ev.currency,
          minutesLeft: Math.max(1, diffMins),
          timeStr: witaTimeStr,
          estimatedPips: ev.spikePrediction?.estimatedPipsGold || "N/A",
        });

        playAlertChime();

        if (typeof window !== "undefined" && "Notification" in window && Notification.permission === "granted") {
          try {
            new Notification(`PENGINGAT RILIS HIGH IMPACT DALAM ${diffMins} MENIT!`, {
              body: `[${ev.currency}] ${ev.title} (${witaTimeStr} WITA). Tidak ada estimasi volatilitas terkalibrasi. Periksa spread dan risiko sebelum mengambil keputusan.`,
              icon: "/zrill-logo.png",
            });
          } catch (e) {}
        }
      }
    });
  }, [nowTicker, economicEvents, spikeNotificationEnabled]);

  // Test Notification Trigger
  const triggerTestAlert = () => {
    playAlertChime();
    setActiveSpikeAlert({
      id: "test-alert",
      title: "TEST NOTIFIKASI — BUKAN DATA EKONOMI",
      currency: "TEST",
      minutesLeft: 0,
      timeStr: new Date().toLocaleTimeString("id-ID", {
        timeZone: "Asia/Makassar",
        hour: "2-digit",
        minute: "2-digit",
      }),
      estimatedPips: "N/A",
    });

    if (typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission === "granted") {
        try {
          new Notification("Test Notifikasi Spike Tinggi Berhasil", {
            body: "Sistem audio dan notifikasi desktop kalender aktif dan siap memberikan alert 5 menit sebelum rilis berita.",
            icon: "/zrill-logo.png",
          });
        } catch (e) {}
      } else {
        Notification.requestPermission();
      }
    }
  };

  // Accuracy Statistics Calculation
  const stats = useMemo(() => {
    const releasedList = economicEvents.filter(
      (e) => e.actual !== null && e.actual !== "---" && e.actual !== "N/A"
    );
    // Macro surprise direction is not a trading outcome. No calibrated prediction ledger is connected.
    const accurateList: typeof releasedList = [];
    const missedList: typeof releasedList = [];
    const upcomingList = economicEvents.filter(
      (e) => !e.isReleased && (e.actual === null || e.actual === "---" || e.actual === "N/A") && new Date(e.date).getTime() > nowTicker
    );
    const highImpactCount = economicEvents.filter((e) => e.importance === 1).length;
    const hitRate: number | null = null;

    return {
      total: economicEvents.length,
      releasedCount: releasedList.length,
      upcomingCount: upcomingList.length,
      accurateCount: accurateList.length,
      missedCount: missedList.length,
      highImpactCount,
      hitRate,
    };
  }, [economicEvents, nowTicker]);

  // Tier-1 Featured Event (for Section 2: Radar Berita Tier-1)
  const tier1FeaturedEvent = useMemo(() => {
    if (!radarActive) return null;
    const highImpacts = economicEvents.filter(
      (e) => e.importance === 1 || e.spikePrediction?.spikeType === "HIGH_SPIKE" || /cpi|nfp|fomc|fed/i.test(e.title)
    );
    if (highImpacts.length === 0) return economicEvents[0] || null;

    const upcoming = highImpacts
      .filter((e) => new Date(e.date).getTime() > nowTicker)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    if (upcoming.length > 0) return upcoming[0];

    const past = highImpacts
      .filter((e) => new Date(e.date).getTime() <= nowTicker)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    return past[0] || highImpacts[0];
  }, [economicEvents, nowTicker, radarActive]);

  // Aggregate event counts and highest impact per date (WITA)
  const dateMetaMap = useMemo(() => {
    const map = new Map<string, { count: number; maxImpact: number }>();
    economicEvents.forEach((ev) => {
      const ymd = getWitaYMD(ev.date);
      const curr = map.get(ymd) || { count: 0, maxImpact: -2 };
      const impactVal = ev.importance;
      map.set(ymd, {
        count: curr.count + 1,
        maxImpact: Math.max(curr.maxImpact, impactVal),
      });
    });
    return map;
  }, [economicEvents]);

  // 7-Day horizontal strip days
  const stripDays = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => shiftWitaYMD(stripAnchorDate, i));
  }, [stripAnchorDate]);

  // Week days for "Minggu Ini" or "Minggu Depan" (Mon - Fri)
  const weekDays = useMemo(() => {
    return Array.from({ length: 5 }, (_, i) => shiftWitaYMD(selectedWeekMonday, i));
  }, [selectedWeekMonday]);

  // Date step handlers
  const handlePrevDay = () => {
    setAutoWeekendShiftNotice("");
    if (dateMode === "WEEK") {
      const prevMonday = shiftWitaYMD(selectedWeekMonday, -7);
      if (prevMonday < minAllowedYMD) return;
      setSelectedWeekMonday(prevMonday);
      setSelectedDate(prevMonday);
      setStripAnchorDate(prevMonday);
    } else {
      const prevYmd = shiftWitaYMD(selectedDate, -1);
      if (prevYmd < minAllowedYMD) return;
      setSelectedDate(prevYmd);
      if (prevYmd < stripAnchorDate) {
        setStripAnchorDate(shiftWitaYMD(stripAnchorDate, -1));
      }
    }
  };

  const handleNextDay = () => {
    setAutoWeekendShiftNotice("");
    if (dateMode === "WEEK") {
      const nextMonday = shiftWitaYMD(selectedWeekMonday, 7);
      if (nextMonday > maxAllowedYMD) return;
      setSelectedWeekMonday(nextMonday);
      setSelectedDate(nextMonday);
      setStripAnchorDate(nextMonday);
    } else {
      const nextYmd = shiftWitaYMD(selectedDate, 1);
      if (nextYmd > maxAllowedYMD) return;
      setSelectedDate(nextYmd);
      if (nextYmd > shiftWitaYMD(stripAnchorDate, 6)) {
        setStripAnchorDate(shiftWitaYMD(stripAnchorDate, 1));
      }
    }
  };

  const handleSelectDate = (ymd: string) => {
    if (ymd < minAllowedYMD || ymd > maxAllowedYMD) return;
    setAutoWeekendShiftNotice("");
    setDateMode("SINGLE");
    setSelectedDate(ymd);
    // Keep within strip if outside
    if (ymd < stripAnchorDate) {
      setStripAnchorDate(ymd);
    } else if (ymd > shiftWitaYMD(stripAnchorDate, 6)) {
      setStripAnchorDate(shiftWitaYMD(ymd, -6));
    }
    setIsCalendarPopupOpen(false);
  };

  const handleSelectQuick = (type: "TODAY" | "TOMORROW" | "DAY_AFTER" | "THIS_WEEK" | "NEXT_WEEK") => {
    setAutoWeekendShiftNotice("");
    if (type === "TODAY") {
      setDateMode("SINGLE");
      setSelectedDate(todayWitaYMD);
      setStripAnchorDate(todayWitaYMD);
    } else if (type === "TOMORROW") {
      const tom = shiftWitaYMD(todayWitaYMD, 1);
      setDateMode("SINGLE");
      setSelectedDate(tom);
      setStripAnchorDate(todayWitaYMD);
    } else if (type === "DAY_AFTER") {
      const da = shiftWitaYMD(todayWitaYMD, 2);
      setDateMode("SINGLE");
      setSelectedDate(da);
      setStripAnchorDate(todayWitaYMD);
    } else if (type === "THIS_WEEK") {
      const thisMon = getMondayOfWeek(todayWitaYMD);
      setDateMode("WEEK");
      setSelectedWeekMonday(thisMon);
      setSelectedDate(thisMon);
      setStripAnchorDate(thisMon);
    } else if (type === "NEXT_WEEK") {
      const nextMon = shiftWitaYMD(getMondayOfWeek(todayWitaYMD), 7);
      setDateMode("WEEK");
      setSelectedWeekMonday(nextMon);
      setSelectedDate(nextMon);
      setStripAnchorDate(nextMon);
    }
    setIsCalendarPopupOpen(false);
  };

  const resetToToday = () => {
    setAutoWeekendShiftNotice("");
    setDateMode("SINGLE");
    setSelectedDate(todayWitaYMD);
    setStripAnchorDate(todayWitaYMD);
    setStatusFilter("ALL");
    setImpactFilter("ALL");
    setSpikeFilter("ALL");
    setAccuracyFilter("ALL");
    setSearchQuery("");
  };

  // Filtered Events with date and criteria matching
  const filteredEvents = useMemo(() => {
    return economicEvents.filter((ev) => {
      const evYmd = getWitaYMD(ev.date);

      // 1. Date Filter (SINGLE vs WEEK)
      if (dateMode === "SINGLE") {
        if (evYmd !== selectedDate) return false;
      } else {
        if (!weekDays.includes(evYmd)) return false;
      }

      // 2. Status Filter
      const evTime = new Date(ev.date).getTime();
      const isNowReleased = ev.actual !== null && ev.actual !== "---" && ev.actual !== "N/A";

      if (statusFilter === "RELEASED" && !isNowReleased) return false;
      if (statusFilter === "UPCOMING" && isNowReleased) return false;

      // 3. Impact Filter
      if (impactFilter !== "ALL") {
        const imp = ev.importance === 1 ? "HIGH" : ev.importance === 0 ? "MEDIUM" : "LOW";
        if (imp !== impactFilter) return false;
      }

      // 4. Spike Filter
      if (spikeFilter !== "ALL") {
        const isHighSpike =
          ev.spikePrediction?.spikeType === "HIGH_SPIKE" ||
          ev.importance === 1 ||
          /cpi|consumer price|nfp|non-farm|fomc|interest rate|fed rate|unemployment|gdp|pce/i.test(
            ev.title || ""
          );
        if (spikeFilter === "HIGH_SPIKE" && !isHighSpike) return false;
        if (spikeFilter === "LOW_SPIKE" && isHighSpike) return false;
      }

      // 5. Accuracy Filter
      if (accuracyFilter === "TEPAT") {
        if (!isNowReleased) return false;
        if (ev.isPredictionCorrect !== true || ev.accuracyStatus !== "TEPAT_SASARAN") return false;
      }
      if (accuracyFilter === "MELESET") {
        if (!isNowReleased) return false;
        if (ev.isPredictionCorrect !== false || ev.accuracyStatus !== "TIDAK_TEPAT") return false;
      }

      // 6. Search Text Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = (ev.title || "").toLowerCase().includes(q);
        const matchesCountry = (ev.country || "").toLowerCase().includes(q);
        const matchesCurrency = (ev.currency || "").toLowerCase().includes(q);
        const matchesSource = (ev.source || "").toLowerCase().includes(q);
        if (!matchesTitle && !matchesCountry && !matchesCurrency && !matchesSource) return false;
      }

      return true;
    });
  }, [
    economicEvents,
    dateMode,
    selectedDate,
    weekDays,
    statusFilter,
    impactFilter,
    spikeFilter,
    accuracyFilter,
    searchQuery,
    nowTicker,
  ]);

  // Chronological sort for events on selected date / today
  const sortedEvents = useMemo(() => {
    return [...filteredEvents].sort((a, b) => {
      const timeA = new Date(a.date).getTime();
      const timeB = new Date(b.date).getTime();

      // For today: show upcoming first, then released
      if (dateMode === "SINGLE" && selectedDate === todayWitaYMD) {
        const isReleasedA = a.isReleased || (a.actual !== null && a.actual !== "---") || timeA <= nowTicker;
        const isReleasedB = b.isReleased || (b.actual !== null && b.actual !== "---") || timeB <= nowTicker;
        if (!isReleasedA && isReleasedB) return -1;
        if (isReleasedA && !isReleasedB) return 1;
      }

      return timeA - timeB;
    });
  }, [filteredEvents, dateMode, selectedDate, todayWitaYMD, nowTicker]);

  // Selected date / week summary metrics
  const selectedDateSummary = useMemo(() => {
    const list = filteredEvents;
    const highCount = list.filter((e) => e.importance === 1).length;
    const medCount = list.filter((e) => e.importance === 0).length;
    const lowCount = list.filter((e) => e.importance === -1).length;

    // Nearest high impact on selected date
    const highEvents = list
      .filter((e) => e.importance === 1)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    let nearestHighTime = "Tidak ada High Impact";
    if (highEvents.length > 0) {
      nearestHighTime = new Date(highEvents[0].date).toLocaleTimeString("id-ID", {
        timeZone: "Asia/Makassar",
        hour: "2-digit",
        minute: "2-digit",
      }) + " WITA";
    }

    return {
      total: list.length,
      highCount,
      medCount,
      lowCount,
      nearestHighTime,
    };
  }, [filteredEvents]);

  // Display label for selected date or week
  const selectedDateDisplayLabel = useMemo(() => {
    if (dateMode === "WEEK") {
      const monStr = formatWitaDateFull(selectedWeekMonday).split(",")[1].trim().replace(" (WITA)", "");
      const friStr = formatWitaDateFull(shiftWitaYMD(selectedWeekMonday, 4)).replace(" (WITA)", "");
      return `Pekan: ${monStr} s/d ${friStr} (WITA)`;
    }
    return formatWitaDateFull(selectedDate);
  }, [dateMode, selectedDate, selectedWeekMonday]);

  // Monthly calendar popup days generator
  const popupCalendarDays = useMemo(() => {
    const { year, month } = popupViewYearMonth;
    const firstDay = new Date(Date.UTC(year, month, 1, 12, 0, 0)).getUTCDay();
    const mondayOffset = (firstDay + 6) % 7;
    const totalDays = new Date(Date.UTC(year, month + 1, 0, 12, 0, 0)).getUTCDate();

    const cells: {
      dayNum: number | null;
      ymd: string | null;
      hasEvents: boolean;
      maxImpact: number;
      isWeekend: boolean;
      isToday: boolean;
      isSelected: boolean;
      isDisabled: boolean;
    }[] = [];

    // Empty lead cells
    for (let i = 0; i < mondayOffset; i++) {
      cells.push({
        dayNum: null,
        ymd: null,
        hasEvents: false,
        maxImpact: -2,
        isWeekend: false,
        isToday: false,
        isSelected: false,
        isDisabled: true,
      });
    }

    // Days of month
    for (let d = 1; d <= totalDays; d++) {
      const ymd = `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      const dayOfWeek = getWitaDayOfWeek(ymd);
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      const meta = dateMetaMap.get(ymd);
      const isDisabled = ymd < minAllowedYMD || ymd > maxAllowedYMD;
      const isToday = ymd === todayWitaYMD;
      const isSelected = dateMode === "SINGLE" && ymd === selectedDate;

      cells.push({
        dayNum: d,
        ymd,
        hasEvents: !!meta && meta.count > 0,
        maxImpact: meta ? meta.maxImpact : -2,
        isWeekend,
        isToday,
        isSelected,
        isDisabled,
      });
    }

    return cells;
  }, [popupViewYearMonth, dateMetaMap, minAllowedYMD, maxAllowedYMD, todayWitaYMD, dateMode, selectedDate]);

  return (
    <div className="min-h-screen w-full overflow-x-hidden text-gray-300 font-sans flex flex-col items-center p-2 sm:p-4 bg-[#090c12] bg-radar-grid relative z-0">
      <div className="w-full max-w-5xl mx-auto flex flex-col gap-4 pb-24 relative z-10 px-2 sm:px-4">

        {/* ========================================================================= */}
        {/* 1. HEADER FEED KALENDER */}
        {/* ========================================================================= */}
        <section className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-black/80 to-blue-950/40 border border-amber-500/50 font-mono text-[11px] shadow-lg flex flex-col gap-2.5">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-white/10 pb-2.5">
            {/* Sisi Kiri */}
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 shadow-[0_0_15px_rgba(245,158,11,0.25)] shrink-0">
                <Flame className="w-5 h-5 text-amber-400 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xs sm:text-sm font-black text-amber-400 tracking-wider uppercase">
                    FEED KALENDER EKONOMI &amp; RADAR ZRILL
                  </h1>
                  <span className="text-[10px] font-black font-mono px-2.5 py-0.5 rounded-lg border bg-emerald-500/25 text-emerald-300 border-emerald-500/40 flex items-center gap-1.5 shadow-[0_0_12px_rgba(16,185,129,0.25)]">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    {stats.total} DATA KALENDER TERHUBUNG
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-0.5 text-[10px] text-gray-400 flex-wrap">
                  <span>Sumber Resmi:</span>
                  <a
                    href="https://www.tradingview.com/economic-calendar/"
                    target="_blank"
                    rel="noreferrer"
                    className="text-cyan-400 hover:text-cyan-300 underline underline-offset-2 flex items-center gap-0.5 font-bold"
                  >
                    <span>TradingView Economic Calendar</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </a>
                  <span className="text-gray-600">&bull;</span>
                  <span className="text-amber-300 font-bold">
                    Auto-Refresh: {Math.max(0, Math.floor((nowTicker - lastSyncTimestamp) / 1000))}s lalu
                  </span>
                </div>
              </div>
            </div>

            {/* Sisi Kanan: Kotak Harga Live & Tombol Aksi */}
            <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
              <div className="bg-black/60 rounded-xl border border-amber-500/30 px-3 py-1.5 flex items-center gap-3 shadow-inner">
                <div>
                  <span className="text-[8px] uppercase font-bold text-gray-400 block font-mono">
                    SPOT XAU/USD
                  </span>
                  <span className="text-sm font-black font-mono text-amber-300 tracking-tight">
                    ${livePrice.price.toFixed(2)}
                  </span>
                </div>
                <div className="border-l border-white/10 pl-2.5 flex flex-col text-[9px] font-mono">
                  <div className="text-emerald-400 font-bold flex items-center gap-1">
                    <span>B: {livePrice.bid.toFixed(2)}</span>
                  </div>
                  <div className="text-rose-400 font-bold flex items-center gap-1">
                    <span>A: {livePrice.ask.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => fetchCalendar()}
                disabled={isSyncing}
                title="Sinkronisasi Data Kalender"
                className="p-2 rounded-xl bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/40 cursor-pointer transition-all active:scale-95 disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${isSyncing ? "animate-spin" : ""}`} />
              </button>
            </div>
          </div>

          {/* Di bawahnya: Kotak Catatan ShieldCheck */}
          <div className="bg-amber-500/10 border border-amber-500/30 text-[10px] p-2 rounded-xl text-amber-200/90 flex items-center gap-2 font-mono">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              Jadwal rilis &amp; deviasi resmi realtime dari server bursa global (WITA Synchronized). Transmisi makro
              dan kalkulasi bias terintegrasi otomatis.
            </span>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* 2. RADAR BERITA TIER-1 */}
        {/* ========================================================================= */}
        {tier1FeaturedEvent && (
          <section className="p-4 rounded-2xl border-2 border-amber-500/60 bg-gradient-to-r from-red-950/60 via-black/90 to-amber-950/60 shadow-[0_0_30px_rgba(245,158,11,0.25)] flex flex-col gap-3 font-mono">
            {/* Header Radar */}
            <div className="flex items-center justify-between border-b border-white/10 pb-2.5 flex-wrap gap-2">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300">
                  <Zap className="w-4 h-4 text-amber-400 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs sm:text-sm font-black text-white uppercase tracking-wider">
                      RADAR BERITA TIER-1 MAKRO EKONOMI
                    </span>
                    <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-rose-500/30 text-rose-200 border border-rose-500/50">
                      HIGH IMPACT ACTIVE
                    </span>
                  </div>
                  <span className="text-[10px] text-gray-400">
                    Fokus utama pasar global &amp; katalis lonjakan volatilitas (XAUUSD &amp; DXY)
                  </span>
                </div>
              </div>

              {/* Tombol Toggle Mode */}
              <button
                onClick={() => setRadarActive(!radarActive)}
                className="px-2.5 py-1.5 rounded-xl border text-[10px] font-bold flex items-center gap-1.5 cursor-pointer transition-all bg-black/50 border-white/10 hover:border-white/20"
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    radarActive ? "bg-emerald-400 animate-ping" : "bg-gray-500"
                  }`}
                />
                <span className="text-gray-300">{radarActive ? "RADAR: AKTIF" : "RADAR: STANDBY"}</span>
              </button>
            </div>

            {/* Sorotan Event Tier-1 Aktif */}
            <div className="p-3 rounded-xl bg-black/60 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-mono font-bold bg-black/50 px-2.5 py-1 rounded-lg border border-white/10 shadow-inner text-gray-200 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                    {new Date(tier1FeaturedEvent.date).toLocaleTimeString("id-ID", {
                      timeZone: "Asia/Makassar",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}{" "}
                    WITA
                  </span>
                  <span className="text-[10px] font-black font-mono px-2.5 py-0.5 rounded-lg border bg-blue-500/25 text-blue-300 border-blue-500/40">
                    {tier1FeaturedEvent.currency}
                  </span>
                  <span className="text-[10px] font-black font-mono px-2.5 py-0.5 rounded-lg border bg-rose-500/25 text-rose-300 border-rose-500/40 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
                    TIER-1 HIGH IMPACT
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white mt-1">{tier1FeaturedEvent.title}</h3>
                <span className="text-[10px] text-gray-400">
                  Estimasi Volatilitas:{" "}
                  <strong className="text-amber-300 font-black">
                    {tier1FeaturedEvent.spikePrediction?.estimatedPipsGold || "N/A — belum terkalibrasi"}
                  </strong>
                </span>
              </div>

              {/* Ticker Digital & Bias */}
              <div className="flex flex-col sm:items-end gap-1.5 shrink-0">
                <span className="text-[8px] uppercase font-bold text-gray-400">
                  {new Date(tier1FeaturedEvent.date).getTime() > nowTicker
                    ? "HITUNG MUNDUR RILIS:"
                    : "STATUS RILIS:"}
                </span>
                {new Date(tier1FeaturedEvent.date).getTime() > nowTicker ? (
                  <CountdownTicker targetMs={new Date(tier1FeaturedEvent.date).getTime()} nowMs={nowTicker} />
                ) : (
                  <span className="px-3 py-1 rounded-lg bg-emerald-500/25 text-emerald-300 border border-emerald-500/50 text-xs font-black">
                    SELESAI DIRILIS
                  </span>
                )}
                <span
                  className={`text-[10px] font-black px-2.5 py-0.5 rounded-lg border flex items-center gap-1.5 uppercase ${
                    tier1FeaturedEvent.prediction.direction === "BUY"
                      ? "bg-emerald-500/25 text-emerald-300 border-emerald-500/40"
                      : "bg-rose-500/25 text-rose-300 border-rose-500/40"
                  }`}
                >
                  <Zap className="w-3 h-3 fill-current" />
                  BIAS PREDIKSI: {tier1FeaturedEvent.prediction.direction}
                </span>
              </div>
            </div>
          </section>
        )}

        {/* ========================================================================= */}
        {/* 3. BANNER NOTIFIKASI SPIKE TINGGI */}
        {/* ========================================================================= */}
        <section className="p-3 rounded-2xl bg-gradient-to-r from-[#1c080e]/90 via-[#10060d]/80 to-[#0c0818]/90 border border-rose-500/40 text-[10px] font-mono shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse shrink-0">
              <Bell className="w-4 h-4 text-rose-400" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-black text-white uppercase tracking-wider">
                  NOTIFIKASI PUSH DESKTOP SPIKE TINGGI
                </span>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-rose-500/30 text-rose-200 border border-rose-500/50">
                  ALERT 5 MENIT SEBELUM RILIS
                </span>
              </div>
              <span className="text-[10px] text-gray-300">
                Peringatan push desktop &amp; audio instan 5 menit sebelum rilis berita berdampak lonjakan harga tinggi
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => {
                const next = !spikeNotificationEnabled;
                setSpikeNotificationEnabled(next);
                try {
                  localStorage.setItem("zrill_spike_notif_enabled", String(next));
                } catch {}
                if (next && typeof window !== "undefined" && "Notification" in window && Notification.permission !== "granted") {
                  Notification.requestPermission();
                }
              }}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all text-xs cursor-pointer shadow-sm ${
                spikeNotificationEnabled
                  ? "bg-rose-500/30 text-rose-200 border border-rose-500/70 shadow-[0_0_15px_rgba(244,63,94,0.3)]"
                  : "bg-gray-800 text-gray-400 border border-gray-700 hover:text-white"
              }`}
            >
              <Bell className="w-3.5 h-3.5" />
              <span>{spikeNotificationEnabled ? "Push Alert: Aktif" : "Push Alert: Nonaktif"}</span>
            </button>

            <button
              onClick={triggerTestAlert}
              className="px-3 py-1.5 rounded-xl bg-black/60 border border-white/20 text-cyan-300 hover:border-cyan-400 font-bold transition-all text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Play className="w-3 h-3 text-cyan-400 fill-cyan-400" />
              <span>Test Alert</span>
            </button>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* 4. HUD VALIDASI PREDIKSI */}
        {/* ========================================================================= */}
        <section className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-black/80 to-blue-950/40 border border-emerald-500/40 flex flex-col gap-2.5 shadow-xl font-mono text-[10px]">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-2">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.3)]">
                <Target className="w-5 h-5 text-emerald-400 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-black text-white tracking-wide">
                    STATUS VALIDASI MODEL PREDIKSI
                  </span>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[9px] font-black border border-emerald-500/40 animate-pulse">
                    CALIBRATION UNAVAILABLE
                  </span>
                </div>
                <span className="text-[9px] text-gray-400">
                  Akurasi prediksi belum dihitung: belum ada ledger prediksi terkalibrasi dan outcome harga terverifikasi.
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-500/60 flex items-center gap-2 shadow-md">
                <span className="text-[9px] text-gray-300 font-bold uppercase">AKURASI TERUJI:</span>
                <span className="text-base font-black text-emerald-400 font-mono">
                  {stats.hitRate == null ? "N/A" : `${stats.hitRate}%`} AKURASI TERUJI
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px]">
            <div className="p-2 rounded-xl bg-black/60 border border-emerald-500/30 flex items-center justify-between">
              <div>
                <span className="text-[8px] text-gray-400 block uppercase font-bold">PREDIKSI TERVERIFIKASI:</span>
                <span className="text-xs font-black text-emerald-400">
                  {stats.accurateCount} prediksi teruji (belum tersedia)
                </span>
              </div>
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            </div>

            <div className="p-2 rounded-xl bg-black/60 border border-rose-500/30 flex items-center justify-between">
              <div>
                <span className="text-[8px] text-gray-400 block uppercase font-bold">PREDIKSI TIDAK SESUAI:</span>
                <span className="text-xs font-black text-rose-400">
                  {stats.missedCount} prediksi gagal (belum tersedia)
                </span>
              </div>
              <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
            </div>

            <div className="p-2 rounded-xl bg-black/60 border border-cyan-500/30 flex items-center justify-between">
              <div>
                <span className="text-[8px] text-gray-400 block uppercase font-bold">AKUMULASI PIPS NEWS:</span>
                <span className="text-xs font-black text-cyan-300">N/A — belum ada ledger hasil transaksi</span>
              </div>
              <Zap className="w-4 h-4 text-cyan-400 shrink-0" />
            </div>

            <div className="p-2 rounded-xl bg-black/60 border border-purple-500/30 flex items-center justify-between">
              <div>
                <span className="text-[8px] text-gray-400 block uppercase font-bold">PROTEKSI MODAL SL:</span>
                <span className="text-xs font-black text-purple-300">Tidak dapat dijamin — gunakan manajemen risiko</span>
              </div>
              <ShieldCheck className="w-4 h-4 text-purple-400 shrink-0" />
            </div>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* 5. BAR PEMILIH SUMBER & FILTER (DENGAN PEMILIH TANGGAL NEWS DI PALING ATAS) */}
        {/* ========================================================================= */}
        <section className="p-2.5 rounded-xl bg-gradient-to-r from-blue-950/30 via-black/40 to-emerald-950/20 border border-blue-500/20 text-[10px] font-mono flex flex-col gap-2.5 shadow-md">

          {/* PEMILIH TANGGAL UNTUK MELIHAT NEWS MENDATANG */}
          <div className="p-2.5 rounded-xl bg-black/40 border border-cyan-500/20 font-mono text-[10px] flex flex-col gap-2 relative">
            {/* Baris 1: Label + Tombol Cepat + Tombol Buka Kalender */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-2">
              <div className="flex items-center gap-1.5 text-cyan-300 font-bold text-xs">
                <Calendar className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Pilih Tanggal News</span>
              </div>

              <div className="flex items-center gap-1.5 flex-wrap relative">
                <button
                  onClick={() => handleSelectQuick("TODAY")}
                  className={`px-2.5 py-1 rounded-md font-bold text-xs transition-all cursor-pointer ${
                    dateMode === "SINGLE" && selectedDate === todayWitaYMD
                      ? "bg-cyan-500/30 text-cyan-300 border border-cyan-500/50 shadow-sm"
                      : "text-gray-400 hover:text-white bg-black/20"
                  }`}
                >
                  Hari Ini
                </button>
                <button
                  onClick={() => handleSelectQuick("TOMORROW")}
                  className={`px-2.5 py-1 rounded-md font-bold text-xs transition-all cursor-pointer ${
                    dateMode === "SINGLE" && selectedDate === shiftWitaYMD(todayWitaYMD, 1)
                      ? "bg-cyan-500/30 text-cyan-300 border border-cyan-500/50 shadow-sm"
                      : "text-gray-400 hover:text-white bg-black/20"
                  }`}
                >
                  Besok
                </button>
                <button
                  onClick={() => handleSelectQuick("DAY_AFTER")}
                  className={`px-2.5 py-1 rounded-md font-bold text-xs transition-all cursor-pointer ${
                    dateMode === "SINGLE" && selectedDate === shiftWitaYMD(todayWitaYMD, 2)
                      ? "bg-cyan-500/30 text-cyan-300 border border-cyan-500/50 shadow-sm"
                      : "text-gray-400 hover:text-white bg-black/20"
                  }`}
                >
                  Lusa
                </button>
                <button
                  onClick={() => handleSelectQuick("THIS_WEEK")}
                  className={`px-2.5 py-1 rounded-md font-bold text-xs transition-all cursor-pointer ${
                    dateMode === "WEEK" && selectedWeekMonday === getMondayOfWeek(todayWitaYMD)
                      ? "bg-cyan-500/30 text-cyan-300 border border-cyan-500/50 shadow-sm"
                      : "text-gray-400 hover:text-white bg-black/20"
                  }`}
                >
                  Minggu Ini
                </button>
                <button
                  onClick={() => handleSelectQuick("NEXT_WEEK")}
                  className={`px-2.5 py-1 rounded-md font-bold text-xs transition-all cursor-pointer ${
                    dateMode === "WEEK" && selectedWeekMonday === shiftWitaYMD(getMondayOfWeek(todayWitaYMD), 7)
                      ? "bg-cyan-500/30 text-cyan-300 border border-cyan-500/50 shadow-sm"
                      : "text-gray-400 hover:text-white bg-black/20"
                  }`}
                >
                  Minggu Depan
                </button>

                <div className="relative">
                  <button
                    ref={calendarButtonRef}
                    onClick={() => setIsCalendarPopupOpen(!isCalendarPopupOpen)}
                    className="px-2.5 py-1 rounded-md font-bold text-xs transition-all cursor-pointer bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 flex items-center gap-1.5"
                  >
                    <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Buka Kalender</span>
                  </button>

                  {/* Popup Kalender Bulanan */}
                  {isCalendarPopupOpen && (
                    <div
                      ref={calendarPopupRef}
                      className="absolute top-full right-0 mt-2 z-40 bg-[#0b0f19] border border-cyan-500/40 rounded-2xl p-3 shadow-[0_0_40px_rgba(6,182,212,0.2)] w-[calc(100vw-2rem)] max-w-xs sm:w-72 font-mono text-[11px]"
                    >
                      {/* Header Bulan Popup */}
                      <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-white/10">
                        <span className="text-xs font-black text-white uppercase">
                          {MONTH_NAMES_FULL[popupViewYearMonth.month]} {popupViewYearMonth.year}
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setPopupViewYearMonth((prev) => {
                                const m = prev.month === 0 ? 11 : prev.month - 1;
                                const y = prev.month === 0 ? prev.year - 1 : prev.year;
                                return { year: y, month: m };
                              });
                            }}
                            className="p-1 rounded bg-black/50 border border-white/10 hover:bg-white/10 cursor-pointer"
                            title="Bulan Sebelumnya"
                          >
                            <ChevronLeft className="w-3.5 h-3.5 text-gray-300" />
                          </button>
                          <button
                            onClick={() => {
                              setPopupViewYearMonth((prev) => {
                                const m = prev.month === 11 ? 0 : prev.month + 1;
                                const y = prev.month === 11 ? prev.year + 1 : prev.year;
                                return { year: y, month: m };
                              });
                            }}
                            className="p-1 rounded bg-black/50 border border-white/10 hover:bg-white/10 cursor-pointer"
                            title="Bulan Berikutnya"
                          >
                            <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
                          </button>
                        </div>
                      </div>

                      {/* Header Hari (Senin kolom pertama) */}
                      <div className="grid grid-cols-7 gap-1 text-center font-bold text-[9px] text-gray-400 mb-1">
                        <span>SEN</span>
                        <span>SEL</span>
                        <span>RAB</span>
                        <span>KAM</span>
                        <span>JUM</span>
                        <span className="text-gray-500">SAB</span>
                        <span className="text-gray-500">MIN</span>
                      </div>

                      {/* Grid Tanggal */}
                      <div className="grid grid-cols-7 gap-1">
                        {popupCalendarDays.map((cell, cIdx) => {
                          if (cell.dayNum === null || !cell.ymd) {
                            return <div key={`empty_${cIdx}`} className="w-8 h-8" />;
                          }

                          return (
                            <button
                              key={`pcal_${cell.ymd}`}
                              disabled={cell.isDisabled}
                              onClick={() => cell.ymd && handleSelectDate(cell.ymd)}
                              className={`w-8 h-8 rounded-lg text-[11px] flex flex-col items-center justify-center transition-all cursor-pointer relative ${
                                cell.isDisabled
                                  ? "opacity-40 cursor-not-allowed text-gray-600"
                                  : cell.isSelected
                                    ? "bg-cyan-500/30 border border-cyan-500/60 text-cyan-200 font-bold shadow-[0_0_12px_rgba(6,182,212,0.3)]"
                                    : cell.isToday
                                      ? "border border-emerald-500/50 text-emerald-300 hover:bg-emerald-500/10 font-bold"
                                      : cell.isWeekend
                                        ? "text-gray-500 hover:text-white hover:bg-white/5"
                                        : "text-gray-300 hover:text-white hover:bg-white/10"
                              }`}
                            >
                              <span>{cell.dayNum}</span>
                              {cell.hasEvents && (
                                <span
                                  className={`w-1 h-1 rounded-full absolute bottom-1 ${
                                    cell.maxImpact === 1
                                      ? "bg-rose-500"
                                      : cell.maxImpact === 0
                                        ? "bg-amber-500"
                                        : "bg-gray-400"
                                  }`}
                                />
                              )}
                            </button>
                          );
                        })}
                      </div>

                      {/* Footer Kalender Popup */}
                      <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center justify-between text-[9px] text-gray-400">
                        <div className="flex items-center gap-2">
                          <span className="flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" /> High
                          </span>
                          <span className="flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" /> Med
                          </span>
                          <span className="flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-gray-400" /> Low
                          </span>
                        </div>
                        <button
                          onClick={() => {
                            const [y, m] = todayWitaYMD.split("-").map(Number);
                            setPopupViewYearMonth({ year: y, month: m - 1 });
                            handleSelectDate(todayWitaYMD);
                          }}
                          className="text-cyan-400 hover:text-cyan-300 underline font-bold cursor-pointer"
                        >
                          Hari Ini
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Baris 2: Strip 7 Hari dengan Panah Kiri dan Kanan */}
            <div className="flex items-center gap-1.5 w-full">
              <button
                onClick={handlePrevDay}
                disabled={dateMode === "WEEK" ? selectedWeekMonday <= minAllowedYMD : selectedDate <= minAllowedYMD}
                className={`p-1.5 rounded-lg bg-black/50 border border-white/10 hover:bg-white/10 active:scale-95 shrink-0 transition-all ${
                  (dateMode === "WEEK" ? selectedWeekMonday <= minAllowedYMD : selectedDate <= minAllowedYMD)
                    ? "opacity-40 cursor-not-allowed"
                    : "cursor-pointer"
                }`}
                title="Hari Sebelumnya"
              >
                <ChevronLeft className="w-4 h-4 text-gray-300" />
              </button>

              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1 flex-1">
                {stripDays.map((ymd) => {
                  const meta = dateMetaMap.get(ymd);
                  const isSelected = dateMode === "SINGLE" && selectedDate === ymd;
                  const isToday = ymd === todayWitaYMD;
                  const isDisabled = ymd < minAllowedYMD || ymd > maxAllowedYMD;
                  const [y, m, dNum] = ymd.split("-").map(Number);
                  const dt = new Date(Date.UTC(y, m - 1, dNum, 12, 0, 0));
                  const shortDay = DAY_NAMES_SHORT[dt.getUTCDay()];
                  const eventCount = meta ? meta.count : 0;
                  const maxImpact = meta ? meta.maxImpact : -2;

                  return (
                    <button
                      key={`strip_${ymd}`}
                      disabled={isDisabled}
                      onClick={() => handleSelectDate(ymd)}
                      className={`min-w-[56px] p-2 rounded-xl border text-center transition-all shrink-0 flex flex-col items-center justify-between ${
                        isDisabled
                          ? "opacity-40 cursor-not-allowed bg-black/20 border-gray-900 text-gray-600"
                          : isSelected
                            ? "bg-cyan-500/20 border-cyan-500/60 text-cyan-200 shadow-[0_0_15px_rgba(6,182,212,0.25)] cursor-pointer"
                            : "bg-[#151a25] border-gray-800 text-gray-400 hover:border-cyan-500/40 cursor-pointer"
                      }`}
                    >
                      {isToday ? (
                        <span className="text-[8px] font-black text-emerald-300 leading-tight">
                          HARI INI
                        </span>
                      ) : (
                        <span className="text-[8px] uppercase font-bold text-gray-400 leading-tight">
                          {shortDay}
                        </span>
                      )}

                      <span className="text-sm font-black text-white my-0.5">
                        {dNum}
                      </span>

                      <div className="flex items-center gap-1 text-[9px] text-gray-300">
                        {maxImpact === 1 ? (
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                        ) : maxImpact === 0 ? (
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                        ) : maxImpact === -1 ? (
                          <span className="w-1.5 h-1.5 rounded-full bg-gray-400" />
                        ) : null}
                        <span>{eventCount}</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              <button
                onClick={handleNextDay}
                disabled={dateMode === "WEEK" ? selectedWeekMonday >= maxAllowedYMD : selectedDate >= maxAllowedYMD}
                className={`p-1.5 rounded-lg bg-black/50 border border-white/10 hover:bg-white/10 active:scale-95 shrink-0 transition-all ${
                  (dateMode === "WEEK" ? selectedWeekMonday >= maxAllowedYMD : selectedDate >= maxAllowedYMD)
                    ? "opacity-40 cursor-not-allowed"
                    : "cursor-pointer"
                }`}
                title="Hari Berikutnya"
              >
                <ChevronRight className="w-4 h-4 text-gray-300" />
              </button>
            </div>

            {/* Baris 3: Teks Tanggal Terpilih Lengkap & Ringkasan Event */}
            <div className="flex items-center justify-between text-[10px] font-mono text-gray-300 flex-wrap gap-1.5 pt-1 border-t border-white/5">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-cyan-300 font-bold">{selectedDateDisplayLabel}</span>
                <span className="text-gray-500">&bull;</span>
                <span className="text-gray-300">
                  {selectedDateSummary.total} Event ({selectedDateSummary.highCount} High, {selectedDateSummary.medCount} Med, {selectedDateSummary.lowCount} Low)
                </span>
                {autoWeekendShiftNotice && (
                  <span className="text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 text-[9px] font-bold">
                    {autoWeekendShiftNotice}
                  </span>
                )}
              </div>

              {(selectedDate !== todayWitaYMD || dateMode !== "SINGLE") && (
                <button
                  onClick={resetToToday}
                  className="text-cyan-400 hover:text-cyan-300 underline font-bold cursor-pointer text-[10px]"
                >
                  Reset Tanggal
                </button>
              )}
            </div>
          </div>

          {/* Baris Status Filter */}
          <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-white/5">
            <span className="text-gray-400 font-bold mr-1">Status:</span>
            <button
              onClick={() => setStatusFilter("ALL")}
              className={`px-2.5 py-1 rounded-md font-bold text-xs transition-all cursor-pointer ${
                statusFilter === "ALL"
                  ? "bg-blue-500/30 text-blue-300 border border-blue-500/50 shadow-sm"
                  : "text-gray-400 hover:text-white bg-black/20"
              }`}
            >
              Semua ({stats.total})
            </button>
            <button
              onClick={() => setStatusFilter("RELEASED")}
              className={`px-2.5 py-1 rounded-md font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                statusFilter === "RELEASED"
                  ? "bg-emerald-500/30 text-emerald-300 border border-emerald-500/60 shadow-sm"
                  : "text-gray-400 hover:text-emerald-400 bg-black/20"
              }`}
            >
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              Telah Dirilis ({stats.releasedCount})
            </button>
            <button
              onClick={() => setStatusFilter("UPCOMING")}
              className={`px-2.5 py-1 rounded-md font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                statusFilter === "UPCOMING"
                  ? "bg-amber-500/30 text-amber-300 border border-amber-500/60 shadow-sm"
                  : "text-gray-400 hover:text-amber-400 bg-black/20"
              }`}
            >
              <Clock className="w-3 h-3 text-amber-400" />
              Menunggu Rilis ({stats.upcomingCount})
            </button>
          </div>

          {/* Baris Filter Hasil Prediksi AI */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-gray-400 font-bold mr-1 flex items-center gap-1">
              <Target className="w-3 h-3 text-emerald-400" />
              Hasil Prediksi:
            </span>
            <button
              onClick={() => setAccuracyFilter("ALL")}
              className={`px-2.5 py-1 rounded-md font-bold text-xs transition-all cursor-pointer ${
                accuracyFilter === "ALL"
                  ? "bg-cyan-500/30 text-cyan-300 border border-cyan-500/50 shadow-sm"
                  : "text-gray-400 hover:text-white bg-black/20"
              }`}
            >
              Semua
            </button>
            <button
              onClick={() => setAccuracyFilter("TEPAT")}
              className={`px-2.5 py-1 rounded-md font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                accuracyFilter === "TEPAT"
                  ? "bg-emerald-500/30 text-emerald-300 border border-emerald-500/70 shadow-sm"
                  : "text-gray-400 hover:text-emerald-400 bg-black/20"
              }`}
            >
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              Tepat Sasaran ({stats.accurateCount})
            </button>
            <button
              onClick={() => setAccuracyFilter("MELESET")}
              className={`px-2.5 py-1 rounded-md font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                accuracyFilter === "MELESET"
                  ? "bg-rose-500/30 text-rose-300 border border-rose-500/70 shadow-sm"
                  : "text-gray-400 hover:text-rose-400 bg-black/20"
              }`}
            >
              <XCircle className="w-3 h-3 text-rose-400" />
              Tidak Tepat ({stats.missedCount})
            </button>
          </div>

          {/* Baris Tingkat Impact */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-gray-400 font-bold mr-1">Tingkat Impact:</span>
            <button
              onClick={() => setImpactFilter("ALL")}
              className={`px-2.5 py-1 rounded-md font-bold text-xs transition-all cursor-pointer ${
                impactFilter === "ALL"
                  ? "bg-purple-500/30 text-purple-300 border border-purple-500/50 shadow-sm"
                  : "text-gray-400 hover:text-white bg-black/20"
              }`}
            >
              Semua Impact
            </button>
            <button
              onClick={() => setImpactFilter("HIGH")}
              className={`px-2.5 py-1 rounded-md font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                impactFilter === "HIGH"
                  ? "bg-rose-500/30 text-rose-300 border border-rose-500/60 shadow-sm"
                  : "text-gray-400 hover:text-rose-400 bg-black/20"
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-rose-500 inline-block animate-ping" />
              High Impact ({stats.highImpactCount})
            </button>
            <button
              onClick={() => setImpactFilter("MEDIUM")}
              className={`px-2.5 py-1 rounded-md font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                impactFilter === "MEDIUM"
                  ? "bg-amber-500/30 text-amber-300 border border-amber-500/60 shadow-sm"
                  : "text-gray-400 hover:text-amber-400 bg-black/20"
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
              Medium
            </button>
            <button
              onClick={() => setImpactFilter("LOW")}
              className={`px-2.5 py-1 rounded-md font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                impactFilter === "LOW"
                  ? "bg-gray-500/30 text-gray-300 border border-gray-500/60 shadow-sm"
                  : "text-gray-400 hover:text-gray-200 bg-black/20"
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-gray-500 inline-block" />
              Low
            </button>
          </div>

          {/* Baris Filter Spike & Search & Currency */}
          <div className="flex items-center justify-between gap-2 flex-wrap pt-1 border-t border-white/5">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-gray-400 font-bold mr-1 flex items-center gap-1">
                <Flame className="w-3 h-3 text-orange-400" />
                Filter Spike:
              </span>
              <button
                onClick={() => setSpikeFilter("ALL")}
                className={`px-2.5 py-1 rounded-md font-bold text-xs transition-all cursor-pointer ${
                  spikeFilter === "ALL"
                    ? "bg-orange-500/30 text-orange-300 border border-orange-500/50 shadow-sm"
                    : "text-gray-400 hover:text-white bg-black/20"
                }`}
              >
                Semua
              </button>
              <button
                onClick={() => setSpikeFilter("HIGH_SPIKE")}
                className={`px-2.5 py-1 rounded-md font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                  spikeFilter === "HIGH_SPIKE"
                    ? "bg-rose-600/30 text-rose-300 border border-rose-500/70 shadow-sm"
                    : "text-gray-400 hover:text-rose-400 bg-black/20"
                }`}
              >
                <CheckCircle2 className="w-3 h-3 text-rose-400" />
                Spike Tinggi
              </button>
              <button
                onClick={() => setSpikeFilter("LOW_SPIKE")}
                className={`px-2.5 py-1 rounded-md font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                  spikeFilter === "LOW_SPIKE"
                    ? "bg-emerald-500/30 text-emerald-300 border border-emerald-500/60 shadow-sm"
                    : "text-gray-400 hover:text-emerald-400 bg-black/20"
                }`}
              >
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                Spike Rendah
              </button>

              <span className="mx-1 text-gray-600 hidden sm:inline">|</span>

              <span className="text-[10px] font-black font-mono px-2.5 py-1 rounded-lg border bg-blue-500/25 text-blue-300 border-blue-500/40 flex items-center gap-1 shadow-sm">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-ping" />
                USD ONLY
              </span>
            </div>

            {/* Input Pencarian Rapat */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari indikator... (CPI, NFP, Fed)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#1A1D24] border border-gray-800 rounded-lg pl-8 pr-7 py-1 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* RINGKASAN DI ATAS DAFTAR EVENT */}
        {/* ========================================================================= */}
        <section className="p-3 rounded-xl bg-black/40 border border-cyan-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 font-mono text-xs">
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="font-bold text-white flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              <span>{selectedDateDisplayLabel}</span>
            </span>
            <span className="text-gray-500">&bull;</span>
            <span className="text-gray-300 font-bold">
              Total: <span className="text-white font-black">{selectedDateSummary.total} Event</span>
            </span>
            <div className="flex items-center gap-1.5 text-[10px]">
              <span className="px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold">
                {selectedDateSummary.highCount} High
              </span>
              <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                {selectedDateSummary.medCount} Med
              </span>
              <span className="px-1.5 py-0.5 rounded bg-gray-500/20 text-gray-300 border border-gray-500/40 font-bold">
                {selectedDateSummary.lowCount} Low
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-[11px] text-amber-300">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>
              High Impact Terdekat: <strong className="text-white font-bold">{selectedDateSummary.nearestHighTime}</strong>
            </span>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* 6. DAFTAR KARTU EVENT */}
        {/* ========================================================================= */}
        <main className="flex flex-col gap-3">
          {isLoading ? (
            <div className="p-12 text-center flex flex-col items-center justify-center gap-3 bg-[#0f131c] border border-gray-800 rounded-2xl">
              <RefreshCw className="w-7 h-7 text-emerald-400 animate-spin" />
              <span className="text-xs font-mono text-gray-400">
                Memuat data kalender ekonomi real-time...
              </span>
            </div>
          ) : sortedEvents.length === 0 ? (
            <div className="bg-black/50 border border-white/10 rounded-xl text-center p-8 flex flex-col items-center justify-center gap-2 font-mono">
              <Calendar className="w-8 h-8 text-gray-500 mb-1" />
              <p className="text-xs text-gray-300 font-bold">
                Tidak ada news pada tanggal ini. Coba ubah filter atau pilih tanggal lain.
              </p>
              <span className="text-[10px] text-gray-500">
                Data belum dirilis oleh sumber kalender.
              </span>
              <button
                onClick={resetToToday}
                className="mt-2 px-3 py-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-bold cursor-pointer hover:bg-cyan-500/30 transition-all"
              >
                Kembali ke Hari Ini
              </button>
            </div>
          ) : dateMode === "WEEK" ? (
            // WEEK VIEW: GROUPED BY DAY MONDAY TO FRIDAY
            weekDays.map((dayYmd) => {
              const dayEvents = sortedEvents.filter((e) => getWitaYMD(e.date) === dayYmd);
              const dayLabel = formatWitaDateFull(dayYmd);

              return (
                <div key={`group_${dayYmd}`} className="flex flex-col gap-2.5">
                  <div className="flex items-center justify-between border-b border-white/10 pb-1.5 pt-2 text-xs font-black text-white">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{dayLabel}</span>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[9px] border border-cyan-500/30">
                      {dayEvents.length} Event
                    </span>
                  </div>

                  {dayEvents.length === 0 ? (
                    <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 text-[11px] text-gray-500 font-mono text-center">
                      Tidak ada news pada tanggal ini.
                    </div>
                  ) : (
                    dayEvents.map((ev, idx) => renderEventCard(ev, idx))
                  )}
                </div>
              );
            })
          ) : (
            // SINGLE DAY VIEW
            sortedEvents.map((ev, idx) => renderEventCard(ev, idx))
          )}
        </main>

        {/* ========================================================================= */}
        {/* 7. ELEMEN MENGAMBANG DI LUAR ALUR: TOAST & MODAL */}
        {/* ========================================================================= */}

        {/* Toast Alert In-App Spike Tinggi (Floating Bottom-Right) */}
        {activeSpikeAlert && (
          <div className="fixed bottom-6 right-6 rounded-2xl bg-gradient-to-r from-amber-950/90 via-[#181106] to-black border-2 border-amber-500/60 shadow-[0_10px_40px_rgba(245,158,11,0.3)] font-mono text-xs font-bold z-50 p-3.5 max-w-sm flex items-start gap-3 animate-bounce">
            <div className="p-2 rounded-xl bg-amber-500 text-black font-black shrink-0">
              <Flame className="w-5 h-5 animate-pulse" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="text-amber-300 uppercase tracking-wide text-[11px]">
                  SPIKE ALERT ({activeSpikeAlert.minutesLeft} MENIT LAGI)
                </span>
                <button
                  onClick={() => setActiveSpikeAlert(null)}
                  className="text-gray-400 hover:text-white cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-gray-200 text-[10px] mt-1 font-sans">
                [{activeSpikeAlert.currency}] <strong>{activeSpikeAlert.title}</strong>
              </p>
              <span className="text-[10px] text-amber-400 block mt-0.5">
                Estimasi Volatilitas: {activeSpikeAlert.estimatedPips}
              </span>
            </div>
          </div>
        )}

        {/* Modal Pop-Up 4-Pilar Pegangan Kuat */}
        {selectedEventModal && selectedEventModal.prediction?.peganganKuat && (
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 p-4 flex items-center justify-center"
            onClick={() => setSelectedEventModal(null)}
          >
            <div
              className="bg-[#0b0f19] border-2 border-indigo-500/50 rounded-2xl p-5 sm:p-6 shadow-[0_0_50px_rgba(99,102,241,0.25)] font-mono max-w-2xl w-full max-h-[88vh] overflow-y-auto flex flex-col gap-3.5"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                    <Sparkles className="w-4 h-4 text-indigo-400" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-white">
                      DETAIL 4-PILAR PEGANGAN KUAT
                    </h3>
                    <span className="text-[10px] text-gray-400">
                      [{selectedEventModal.currency}] {selectedEventModal.title}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedEventModal(null)}
                  className="p-1 rounded-lg bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Status & Bias Header */}
              <div className="p-3 rounded-xl bg-black/50 border border-white/10 flex items-center justify-between flex-wrap gap-2 text-xs">
                <div>
                  <span className="text-[9px] text-gray-400 uppercase font-bold block">Pegangan Konsensus:</span>
                  <span className="text-amber-300 font-bold">
                    {selectedEventModal.prediction.peganganKuat.anchorGrade}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[9px] text-gray-400 uppercase font-bold block">Arah &amp; Target:</span>
                  <span className="text-emerald-300 font-bold">
                    BIAS {selectedEventModal.prediction.direction} ({selectedEventModal.prediction.confidence == null ? "N/A" : `${selectedEventModal.prediction.confidence}%`})
                  </span>
                </div>
              </div>

              {/* Skenario Playbook */}
              {selectedEventModal.prediction.peganganKuat.scenarioPlaybook && (
                <div className="flex flex-col gap-2">
                  <span className="text-[10px] uppercase font-bold text-gray-300">
                    3-WAY SCENARIO PLAYBOOK:
                  </span>
                  <div className="grid grid-cols-1 gap-2 text-[10px]">
                    <div className="p-2.5 rounded-lg bg-rose-950/40 border border-rose-500/30">
                      <span className="text-rose-300 font-black block">Hot (Data Panas Di Atas Estimasi):</span>
                      <p className="text-gray-300 mt-0.5 leading-relaxed">
                        {selectedEventModal.prediction.peganganKuat.scenarioPlaybook.hot.condition} &rarr;{" "}
                        <strong className="text-rose-400">
                          {selectedEventModal.prediction.peganganKuat.scenarioPlaybook.hot.actionBias}
                        </strong>{" "}
                        ({selectedEventModal.prediction.peganganKuat.scenarioPlaybook.hot.expectedPips})
                      </p>
                    </div>

                    <div className="p-2.5 rounded-lg bg-amber-950/40 border border-amber-500/30">
                      <span className="text-amber-300 font-black block">In-Line (Data Sesuai Konsensus):</span>
                      <p className="text-gray-300 mt-0.5 leading-relaxed">
                        {selectedEventModal.prediction.peganganKuat.scenarioPlaybook.inline.condition} &rarr;{" "}
                        <strong className="text-amber-400">
                          {selectedEventModal.prediction.peganganKuat.scenarioPlaybook.inline.actionBias}
                        </strong>{" "}
                        ({selectedEventModal.prediction.peganganKuat.scenarioPlaybook.inline.expectedPips})
                      </p>
                    </div>

                    <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30">
                      <span className="text-emerald-300 font-black block">Soft (Data Mendingin / Turun):</span>
                      <p className="text-gray-300 mt-0.5 leading-relaxed">
                        {selectedEventModal.prediction.peganganKuat.scenarioPlaybook.soft.condition} &rarr;{" "}
                        <strong className="text-emerald-400">
                          {selectedEventModal.prediction.peganganKuat.scenarioPlaybook.soft.actionBias}
                        </strong>{" "}
                        ({selectedEventModal.prediction.peganganKuat.scenarioPlaybook.soft.expectedPips})
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Rincian 4 Pilar */}
              <div className="flex flex-col gap-2 text-[10px]">
                <span className="text-[10px] uppercase font-bold text-gray-300">
                  KETERSEDIAAN DATA ANALISIS:
                </span>
                <div className="p-2.5 rounded-lg bg-black/40 border border-white/10">
                  <span className="text-blue-300 font-bold block">1. Transmisi Makro &amp; DXY:</span>
                  <p className="text-gray-300 mt-0.5 leading-relaxed">
                    {selectedEventModal.prediction.peganganKuat.macroPillar.transmissionSummary}
                  </p>
                </div>
                <div className="p-2.5 rounded-lg bg-black/40 border border-white/10">
                  <span className="text-purple-300 font-bold block">2. Smart Money Concepts (SMC) &amp; Likuiditas:</span>
                  <p className="text-gray-300 mt-0.5 leading-relaxed">
                    Target: {selectedEventModal.prediction.peganganKuat.smcPillar.orderFlowTarget} &bull; Taktik:{" "}
                    {selectedEventModal.prediction.peganganKuat.smcPillar.recommendedEntryTactic}
                  </p>
                </div>
                <div className="p-2.5 rounded-lg bg-black/40 border border-white/10">
                  <span className="text-amber-300 font-bold block">3. Preseden Empiris:</span>
                  <p className="text-gray-300 mt-0.5 leading-relaxed">
                    {selectedEventModal.prediction.peganganKuat.historicalPillar.empiricalPrecedent}
                  </p>
                </div>
                <div className="p-2.5 rounded-lg bg-black/40 border border-white/10">
                  <span className="text-rose-300 font-bold block">4. Batas Proteksi Risiko (SL &amp; TP):</span>
                  <div className="flex items-center gap-3 text-gray-300 mt-1">
                    <span>SL: <strong className="text-rose-400">{selectedEventModal.prediction.peganganKuat.riskGuardPillar.recommendedSl}</strong></span>
                    <span>TP1: <strong className="text-emerald-400">{selectedEventModal.prediction.peganganKuat.riskGuardPillar.recommendedTp1}</strong></span>
                    <span>RR: <strong className="text-cyan-400">{selectedEventModal.prediction.peganganKuat.riskGuardPillar.riskRewardRatio}</strong></span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-2 border-t border-white/10">
                <button
                  onClick={() => setSelectedEventModal(null)}
                  className="px-4 py-2 rounded-xl bg-gray-800 hover:bg-gray-700 text-white text-xs font-bold font-mono cursor-pointer transition-all"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Spacer di akhir halaman agar konten tidak tertutup toast */}
        <div className="h-20" />
      </div>
    </div>
  );

  // Helper renderer for event card
  function renderEventCard(ev: UpgradedEconomicEvent, idx: number) {
    const evTime = new Date(ev.date).getTime();
    const isNowReleased = ev.actual !== null && ev.actual !== "---" && ev.actual !== "N/A";
    const isPastWithoutActual = !isNowReleased && Number.isFinite(evTime) && evTime <= nowTicker;

    const displayImpact = ev.importance === 1 ? "HIGH" : ev.importance === 0 ? "MEDIUM" : "LOW";
    const direction = ev.prediction?.direction || "WAIT";
    const confidence = ev.prediction?.confidence ?? ev.marketOutcome?.accuracyScore ?? 0;

    const isPredictionCorrect = ev.isPredictionCorrect === true && ev.accuracyStatus === "TEPAT_SASARAN";
    const isPredictionIncorrect = ev.isPredictionCorrect === false && ev.accuracyStatus === "TIDAK_TEPAT";
    const isPredictionEvaluated = isPredictionCorrect || isPredictionIncorrect;
    const pipsGain = ev.pipsGain || "N/A";
    const verdictSummary = ev.verdictSummary || "";

    const isHighSpike =
      ev.spikePrediction?.spikeType === "HIGH_SPIKE" ||
      ev.importance === 1 ||
      /cpi|consumer price|nfp|non-farm|fomc|interest rate|fed rate|unemployment rate|gdp|pce|powell/i.test(
        ev.title || ""
      );

    const relDay = getRelativeDayLabel(ev.date, nowTicker);
    const isExpanded = !!expandedCardIds[ev.id || String(idx)];

    return (
      <article
        key={`eco_ev_${ev.id || 'no_id'}_${idx}`}
        className={`p-4 flex flex-col gap-3 rounded-2xl border transition-all ${
          isNowReleased
            ? !isPredictionEvaluated ? "bg-[#111827]/95 border-slate-600/50" : isPredictionCorrect
              ? "bg-[#091713]/95 border-emerald-500/50 shadow-[0_0_25px_rgba(16,185,129,0.15)]"
              : "bg-[#180e12]/95 border-rose-500/50 shadow-[0_0_25px_rgba(244,63,94,0.15)]"
            : "bg-[#0f172a]/90 border-blue-500/30 hover:border-blue-500/60 shadow-lg"
        }`}
      >
        {/* 1. Bar Atas: Waktu WITA • Tanggal relatif • USD • Status • Impact • Bias */}
        <div className="flex flex-wrap justify-between items-center gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Chip waktu WITA */}
            <span className="text-xs font-mono font-bold bg-black/50 px-2.5 py-1 rounded-lg border border-white/10 shadow-inner flex items-center gap-1.5 text-gray-200">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              {new Date(ev.date).toLocaleTimeString("id-ID", {
                timeZone: "Asia/Makassar",
                hour: "2-digit",
                minute: "2-digit",
              })}{" "}
              WITA
            </span>

            {/* Badge Tanggal Relatif */}
            <span className={`text-[9px] font-black font-mono px-2 py-0.5 rounded-lg border ${relDay.badgeClass}`}>
              {relDay.label}
            </span>

            {/* Badge Mata Uang */}
            <span className="text-[10px] font-black font-mono px-2.5 py-0.5 rounded-lg border bg-blue-500/25 text-blue-300 border-blue-500/40">
              {ev.currency}
            </span>

            {/* Status Badge */}
            {isNowReleased ? (
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="px-2.5 py-1 rounded-lg bg-gray-800/80 border border-gray-700 text-gray-300 text-[9px] font-black tracking-wider flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  TELAH DIRILIS
                </span>
                {!isPredictionEvaluated ? (
                  <span className="px-3 py-1 rounded-lg bg-slate-700/40 border border-slate-500/50 text-slate-300 text-[10px] font-black tracking-wider">HASIL BELUM DIEVALUASI — TIDAK ADA MODEL TERKALIBRASI</span>
                ) : isPredictionCorrect ? (
                  <span className="px-3 py-1 rounded-lg bg-emerald-500/25 border border-emerald-500/60 text-emerald-300 text-[10px] font-black tracking-wider">HASIL PREDIKSI TERVERIFIKASI</span>
                ) : (
                  <span className="px-3 py-1 rounded-lg bg-rose-500/25 border border-rose-500/60 text-rose-300 text-[10px] font-black tracking-wider">HASIL PREDIKSI TIDAK SESUAI</span>
                )}
              </div>
            ) : isPastWithoutActual ? (
              <span className="px-3 py-1 rounded-lg bg-slate-700/40 border border-slate-500/50 text-slate-300 text-[10px] font-black tracking-wider">WAKTU RILIS LEWAT — ACTUAL TIDAK TERSEDIA</span>
            ) : (
              <span className="px-3 py-1 rounded-lg bg-amber-500/20 border border-amber-500/50 text-amber-300 text-[10px] font-black tracking-wider flex items-center gap-1.5 animate-pulse">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                MENUNGGU RILIS
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Indikator impact */}
            <span
              className={`text-[8px] font-black uppercase px-2 py-0.5 rounded border flex items-center gap-1.5 ${
                displayImpact === "HIGH"
                  ? "bg-rose-500/20 text-rose-300 border-rose-500/40"
                  : displayImpact === "MEDIUM"
                    ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
                    : "bg-gray-500/20 text-gray-300 border-gray-500/40"
              }`}
            >
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  displayImpact === "HIGH"
                    ? "bg-rose-400 animate-ping"
                    : displayImpact === "MEDIUM"
                      ? "bg-amber-400"
                      : "bg-gray-400"
                }`}
              />
              {displayImpact} IMPACT
            </span>

            {/* Bias pill */}
            <span
              className={`text-[10px] font-black px-2.5 py-1 rounded-lg flex items-center gap-1.5 shadow-md uppercase tracking-wider ${
                direction === "BUY"
                  ? "bg-emerald-500/30 text-emerald-300 border border-emerald-500/60 ring-1 ring-emerald-500/20"
                  : "bg-rose-500/30 text-rose-300 border border-rose-500/60 ring-1 ring-rose-500/20"
              }`}
            >
              <Zap className="w-3.5 h-3.5 fill-current" />
              BIAS XAUUSD: {direction} ({confidence}%)
            </span>

            {/* Potensi Spike */}
            {isHighSpike ? (
              <span className="text-[10px] font-black px-2.5 py-1 rounded-lg flex items-center gap-1.5 shadow-md uppercase tracking-wider bg-rose-500/25 text-rose-300 border border-rose-500/60 ring-1 ring-rose-500/20">
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                Potensi Spike: Tinggi
              </span>
            ) : (
              <span className="text-[10px] font-black px-2.5 py-1 rounded-lg flex items-center gap-1.5 shadow-md uppercase tracking-wider bg-emerald-500/25 text-emerald-300 border border-emerald-500/60 ring-1 ring-emerald-500/20">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Potensi Spike: Rendah
              </span>
            )}
          </div>
        </div>

        {/* 2. Judul Event & Sumber */}
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
          <h2 className="text-sm font-bold text-white leading-snug">
            {ev.title || "Economic Event"}
          </h2>
          <span className="text-[9px] text-gray-400 font-mono font-bold flex items-center gap-1 shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            {ev.source || "TradingView Economic Calendar"}
          </span>
        </div>

        {/* 3. Countdown Ticker Digital (jika belum dirilis) */}
        {!isNowReleased && (
          <div className="flex items-center justify-between p-2 rounded-xl bg-black/40 border border-white/5">
            <span className="text-[9px] font-mono font-bold text-gray-400 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin" style={{ animationDuration: "12s" }} />
              HITUNG MUNDUR WAKTU RILIS RESMI:
            </span>
            <CountdownTicker targetMs={evTime} nowMs={nowTicker} />
          </div>
        )}

        {/* 4. Grid Data 4-Kolom */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 py-2 px-3 rounded-xl bg-black/60 border border-white/10 text-[10px] font-mono">
          <div className="p-1.5 rounded-lg bg-cyan-950/40 border border-cyan-500/40">
            <span className="text-[8px] uppercase font-bold text-cyan-300 block">Perkiraan AI (A1):</span>
            <span className="text-xs font-black text-cyan-300 block">
              {ev.estimatedActual || "---"}
            </span>
            <span className="text-[8px] text-cyan-400 font-bold block mt-0.5">
              {ev.predictedDeviation || "In-Line"}
            </span>
          </div>

          <div className="p-1.5 rounded-lg bg-black/40 border border-white/5">
            <span className="text-[8px] uppercase font-bold text-gray-400 block">Estimasi (Forecast):</span>
            <span className="text-xs font-bold text-gray-200 block">
              {ev.forecast ? `${ev.forecast}${ev.unit || ""}` : "---"}
            </span>
            <span className="text-[8px] text-gray-500 block mt-0.5">Konsensus Pasar</span>
          </div>

          <div className="p-1.5 rounded-lg bg-black/40 border border-white/5">
            <span className="text-[8px] uppercase font-bold text-gray-400 block">Sebelumnya (Previous):</span>
            <span className="text-xs font-semibold text-gray-400 block">
              {ev.previous ? `${ev.previous}${ev.unit || ""}` : "---"}
            </span>
            <span className="text-[8px] text-gray-500 block mt-0.5">Rilis Lalu</span>
          </div>

          <div className="p-1.5 rounded-lg bg-black/40 border border-white/5">
            <span className="text-[8px] uppercase font-bold text-gray-400 block">Aktual Resmi:</span>
            <span
              className={`text-xs font-black block ${
                isNowReleased && ev.actual
                  ? !isPredictionEvaluated ? "text-slate-300" : isPredictionCorrect ? "text-emerald-400" : "text-rose-400"
                  : "text-amber-400 font-bold"
              }`}
            >
              {isNowReleased && ev.actual ? `${ev.actual}${ev.unit || ""}` : isPastWithoutActual ? "Actual tidak tersedia dari feed" : "Menunggu Rilis"}
            </span>
            <span className="text-[8px] text-gray-500 block mt-0.5">
              {isPastWithoutActual ? "Provider belum memberi nilai actual" : !isNowReleased ? "Menunggu aktual" : !isPredictionEvaluated ? "Belum dievaluasi" : isPredictionCorrect ? "Tepat sasaran" : "Tidak sesuai"}
            </span>
          </div>
        </div>

        {/* 5. Kotak Verifikasi AI Bergradien & Intelijen A1 */}
        <div
          className={`p-3.5 rounded-xl border flex flex-col gap-2 font-mono text-[11px] transition-all relative overflow-hidden ${
            !isNowReleased
              ? "bg-gradient-to-r from-[#0a1526]/95 via-[#0b1b30]/90 to-[#0e1628]/95 border-cyan-500/40 text-cyan-200 shadow-md"
              : !isPredictionEvaluated
              ? "bg-gradient-to-r from-[#111827]/95 via-[#172033]/90 to-[#111827]/95 border-slate-600/60 text-slate-200"
              : isPredictionCorrect
                ? "bg-gradient-to-r from-[#061d15]/95 via-[#08261c]/90 to-[#071d17]/95 border-emerald-500/60 text-emerald-200 shadow-[0_0_25px_rgba(16,185,129,0.25)]"
                : "bg-gradient-to-r from-[#210912]/95 via-[#290d17]/90 to-[#1e0710]/95 border-rose-500/60 text-rose-200 shadow-[0_0_25px_rgba(244,63,94,0.25)]"
          }`}
        >
          <div className="flex items-center justify-between flex-wrap gap-2 border-b border-white/10 pb-2">
            <div className="flex items-center gap-2 font-black tracking-wide text-xs">
              {!isNowReleased ? (
                <div className="flex items-center gap-2">
                  <span className="flex items-center gap-1.5 text-cyan-300">
                    <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
                    DATA KONSENSUS &amp; RILIS EKONOMI
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 text-[8px] border border-cyan-500/30 uppercase">
                    DATA FEED
                  </span>
                </div>
              ) : !isPredictionEvaluated ? (
                <span className="text-slate-300">HASIL BELUM DIEVALUASI</span>
              ) : isPredictionCorrect ? (
                <div className="flex items-center gap-2">
                  <span className="flex items-center gap-1.5 text-emerald-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    HASIL MODEL TERVERIFIKASI
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-emerald-500/30 text-emerald-200 text-[8px] font-black border border-emerald-400/40 uppercase">
                    VERIFIED WIN
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="flex items-center gap-1.5 text-rose-300">
                    <XCircle className="w-4 h-4 text-rose-400" />
HASIL MODEL TIDAK SESUAI
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-rose-500/30 text-rose-200 text-[8px] font-black border border-rose-400/40 uppercase">
                    SL SHIELDED
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[9px] text-gray-400 uppercase font-mono hidden sm:inline-block">
                {!isNowReleased ? "Potensi:" : !isPredictionEvaluated ? "Evaluasi:" : isPredictionCorrect ? "Hasil:" : "Hasil:"}
              </span>
              <span
                className={`px-3 py-1 rounded-lg font-black font-mono text-xs shadow-md ${
                  !isNowReleased
                    ? "bg-blue-500/20 text-cyan-300 border border-cyan-500/40"
                    : !isPredictionEvaluated ? "bg-slate-700/40 text-slate-300 border border-slate-500"
                      : isPredictionCorrect
                        ? "bg-emerald-500/30 text-emerald-200 border border-emerald-400 text-xs shadow-[0_0_12px_rgba(16,185,129,0.3)]"
                        : "bg-rose-500/30 text-rose-200 border border-rose-400 text-xs shadow-[0_0_12px_rgba(244,63,94,0.3)]"
                }`}
              >
                {pipsGain}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between flex-wrap gap-2 text-[10px] text-gray-300 pt-0.5">
            <div className="flex items-center gap-3">
              <span>
                Bias Eksekusi:{" "}
                <strong className={direction === "BUY" ? "text-emerald-400" : "text-rose-400"}>
                  {direction} ({confidence > 0 ? `${confidence}%` : "N/A"})
                </strong>
              </span>
              <span>
                Perkiraan AI (A1):{" "}
                <strong className="text-cyan-300 font-bold">
                  {ev.estimatedActual || "---"}
                </strong>{" "}
                ({ev.predictedDeviation || "In-Line"})
              </span>
            </div>
            <span className="text-[9px] text-gray-400 flex items-center gap-1 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              A1 Institutional Engine &bull; Auto Sync
            </span>
          </div>

          <p className="text-[10px] text-gray-200 leading-relaxed font-sans bg-black/40 p-2.5 rounded-lg border border-white/5">
            {isNowReleased && verdictSummary
              ? verdictSummary
              : ev.a1LeakIntelligence || ev.prediction?.reasoning || ev.marketOutcome?.summary}
          </p>

          {/* Penguat Diskusi AS */}
          <div className="p-2 rounded-lg bg-cyan-950/40 border border-cyan-500/30 flex items-start gap-2 text-[9px] text-cyan-200">
            <Target className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-cyan-300 uppercase tracking-wide">
                Penguat Prediksi dari Pantauan Diskusi AS:
              </span>{" "}
              <span>
                {direction === "BUY"
                  ? "Pernyataan pejabat The Fed & konsensus Wall Street memproyeksikan suku bunga melandai (Dovish) yang menekan DXY dan menguatkan dorongan BUY Emas (XAUUSD)."
                  : "Retorika pejabat The Fed mempertahankan suku bunga tinggi (Hawkish) dan yield Treasury menguatkan DXY serta membatasi kenaikan Gold."}
              </span>
            </div>
          </div>
        </div>

        {/* 6. Tombol Aksi */}
        <div className="flex items-center justify-between gap-2 pt-1 border-t border-white/5">
          <button
            onClick={() => toggleCardExpand(ev.id || String(idx))}
            className="flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isExpanded ? "Sembunyikan 4-Pilar & Skenario" : "Buka 4-Pilar Pegangan Kuat & Skenario"}</span>
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={() => setSelectedEventModal(ev)}
            className="px-2.5 py-1 rounded-md text-[10px] font-mono font-bold text-cyan-300 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 cursor-pointer transition-all active:scale-95 flex items-center gap-1"
          >
            <span>Modal Pop-Up</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>

        {/* Akordion 4-Pilar */}
        {isExpanded && ev.prediction?.peganganKuat && (
          <div className="p-3.5 rounded-xl bg-[#151a25] border border-gray-800/80 flex flex-col gap-3 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="font-bold text-amber-300 text-[11px]">
                {ev.prediction.peganganKuat.anchorGrade}
              </span>
              <span className="text-[10px] font-black text-emerald-400 bg-black/40 px-2 py-0.5 rounded border border-white/10">
                Skor Pegangan: {ev.prediction.peganganKuat.anchorScore == null ? "N/A" : `${ev.prediction.peganganKuat.anchorScore}%`}
              </span>
            </div>

            {/* 3-Way Scenario */}
            {ev.prediction.peganganKuat.scenarioPlaybook && (
              <div className="flex flex-col gap-1.5">
                <span className="text-[9px] uppercase font-bold text-gray-400">
                  3-WAY SCENARIO PLAYBOOK (PANDUAN EKSEKUSI):
                </span>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  <div className="p-2.5 rounded-lg bg-rose-950/40 border border-rose-500/30 flex flex-col gap-1">
                    <span className="text-[9px] font-black text-rose-300 uppercase">
                      Hot (Data Panas):
                    </span>
                    <span className="text-gray-300 text-[10px]">
                      {ev.prediction.peganganKuat.scenarioPlaybook.hot.condition}
                    </span>
                    <span className="text-rose-400 font-bold text-[10px] mt-1">
                      {ev.prediction.peganganKuat.scenarioPlaybook.hot.actionBias} (
                      {ev.prediction.peganganKuat.scenarioPlaybook.hot.expectedPips})
                    </span>
                  </div>

                  <div className="p-2.5 rounded-lg bg-amber-950/40 border border-amber-500/30 flex flex-col gap-1">
                    <span className="text-[9px] font-black text-amber-300 uppercase">
                      In-Line (Sesuai):
                    </span>
                    <span className="text-gray-300 text-[10px]">
                      {ev.prediction.peganganKuat.scenarioPlaybook.inline.condition}
                    </span>
                    <span className="text-amber-400 font-bold text-[10px] mt-1">
                      {ev.prediction.peganganKuat.scenarioPlaybook.inline.actionBias} (
                      {ev.prediction.peganganKuat.scenarioPlaybook.inline.expectedPips})
                    </span>
                  </div>

                  <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30 flex flex-col gap-1">
                    <span className="text-[9px] font-black text-emerald-300 uppercase">
                      Soft (Mendingin):
                    </span>
                    <span className="text-gray-300 text-[10px]">
                      {ev.prediction.peganganKuat.scenarioPlaybook.soft.condition}
                    </span>
                    <span className="text-emerald-400 font-bold text-[10px] mt-1">
                      {ev.prediction.peganganKuat.scenarioPlaybook.soft.actionBias} (
                      {ev.prediction.peganganKuat.scenarioPlaybook.soft.expectedPips})
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Rincian 4 Pilar */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px]">
              <div className="p-2 rounded-lg bg-black/40 border border-white/5">
                <span className="text-blue-300 font-bold block mb-1">
                  1. Transmisi Makro &amp; DXY:
                </span>
                <p className="text-gray-300 leading-relaxed">
                  {ev.prediction.peganganKuat.macroPillar.transmissionSummary}
                </p>
              </div>

              <div className="p-2 rounded-lg bg-black/40 border border-white/5">
                <span className="text-purple-300 font-bold block mb-1">
                  2. Likuiditas SMC &amp; FVG:
                </span>
                <p className="text-gray-300 leading-relaxed">
                  {ev.prediction.peganganKuat.smcPillar.orderFlowTarget}
                </p>
              </div>

              <div className="p-2 rounded-lg bg-black/40 border border-white/5">
                <span className="text-amber-300 font-bold block mb-1">
                  3. Preseden Empiris Historis:
                </span>
                <p className="text-gray-300 leading-relaxed">
                  {ev.prediction.peganganKuat.historicalPillar.empiricalPrecedent}
                </p>
              </div>

              <div className="p-2 rounded-lg bg-black/40 border border-white/5">
                <span className="text-rose-300 font-bold block mb-1">
                  4. Batas Risiko &amp; Invalidation:
                </span>
                <p className="text-gray-300 leading-relaxed">
                  {ev.prediction.peganganKuat.riskGuardPillar.invalidationRule}
                </p>
              </div>
            </div>
          </div>
        )}
      </article>
    );
  }
}
