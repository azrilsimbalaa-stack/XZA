export type NewsClassification = "PENGGERAK_PASAR" | "GANGGUAN";
export type NewsSentiment = "BULLISH" | "BEARISH" | "NEUTRAL";
export type ImpactStrength = "KRITIKAL" | "TINGGI" | "SEDANG" | "RENDAH";

export interface PersonalizedNewsArticle {
  id: string;
  title: string;
  source: string;
  url: string;
  publishedAt: number;
  body: string;
  category: "FOREX" | "CRYPTO" | "MACRO" | "COMMODITY";
  targetAsset: "XAUUSD" | "BTCUSD" | "ALL" | string;
  classification: NewsClassification;
  classificationRationale: string;
  sentiment: NewsSentiment;
  sentimentScore: number; // -100 to +100
  assetImpactScore: number; // 0 to 100
  impactStrength: ImpactStrength;
  marketDriverTags: string[];
  noiseReason?: string;
  actionableAdvice: string;
  institutionalCorrelation?: string;
  expectedPipsImpact?: string;
}

export interface AssetNewsIntelligence {
  symbolId: string;
  dominantBias: "BULLISH" | "BEARISH" | "NEUTRAL";
  sentimentScore: number; // -100 to +100
  marketMoversCount: number;
  noiseCount: number;
  totalArticles: number;
  signalToNoiseRatio: number; // percentage (0 - 100%)
  
  // Dynamic Volatility Adaptation Parameters
  volatilityShockMultiplier: number; // 1.0x to 1.8x
  dynamicAtrBufferPips: number; // Additional safety buffer
  volatilityRegime: "KOMPRESI (SQUEEZE)" | "EKSPANSI MODERAT" | "VOLATILITAS TINGGI (EXPANSION)" | "LONJAKAN EKSTRIM (SHOCK SPIKE)" | "UNAVAILABLE";
  volatilityActionAdvice: string;
  
  // Signal Strengthening Metrics
  confluenceConfidenceBoost: number; // e.g. +3% to +5%
  isMoverAlignedWithSignal: (direction: "BUY" | "SELL") => boolean;
  topCatalysts: string[];
  actionableSignalVerdict: string;
  institutionalSynthesis: string;
  latestMover?: PersonalizedNewsArticle;
  articles: PersonalizedNewsArticle[];
}

// Master Institutional Knowledgebase for Asset-Filtered News
export const MASTER_ASSET_NEWS_ARTICLES: PersonalizedNewsArticle[] = [];

export function getAssetPersonalizedNews(symbolId: string, sourceArticles = MASTER_ASSET_NEWS_ARTICLES): PersonalizedNewsArticle[] {
  const isGold = symbolId.toUpperCase().includes("XAU") || symbolId.toUpperCase().includes("GOLD");
  const isBtc = symbolId.toUpperCase().includes("BTC") || symbolId.toUpperCase().includes("BITCOIN");

  return sourceArticles.filter((art) => {
    if (art.targetAsset === "ALL") return true;
    if (isGold && art.targetAsset === "XAUUSD") return true;
    if (isBtc && art.targetAsset === "BTCUSD") return true;
    return art.targetAsset === symbolId;
  });
}

/**
 * Computes deep institutional sentiment and dynamic volatility parameters
 * for signal engine integration.
 */
export function computeAssetNewsIntelligence(
  symbolId: string,
  sourceArticles = MASTER_ASSET_NEWS_ARTICLES
): AssetNewsIntelligence {
  const articles = getAssetPersonalizedNews(symbolId, sourceArticles);
  const isGold = symbolId.toUpperCase().includes("XAU") || symbolId.toUpperCase().includes("GOLD");
  const isBtc = symbolId.toUpperCase().includes("BTC") || symbolId.toUpperCase().includes("BITCOIN");

  const movers = articles.filter((a) => a.classification === "PENGGERAK_PASAR");
  const noise = articles.filter((a) => a.classification === "GANGGUAN");
  const total = articles.length;

  const moverCount = movers.length;
  const noiseCount = noise.length;
  const signalToNoiseRatio = total > 0 ? Math.round((moverCount / total) * 100) : 0;

  // Calculate weighted mover sentiment score
  const avgMoverSentimentScore = moverCount > 0
    ? Math.round(movers.reduce((acc, m) => acc + m.sentimentScore * (m.assetImpactScore / 100), 0) /
        movers.reduce((acc, m) => acc + (m.assetImpactScore / 100), 0))
    : 0;

  const dominantBias: "BULLISH" | "BEARISH" | "NEUTRAL" =
    avgMoverSentimentScore > 25 ? "BULLISH" : avgMoverSentimentScore < -25 ? "BEARISH" : "NEUTRAL";

  // Volatility shock detection: If critical movers are present
  const hasCriticalMover = movers.some((m) => m.impactStrength === "KRITIKAL" || m.assetImpactScore >= 95);
  const maxImpactScore = movers.length > 0 ? Math.max(...movers.map((m) => m.assetImpactScore)) : 50;

  let volatilityShockMultiplier = 1.0;
  let dynamicAtrBufferPips = 0;
  let volatilityRegime: AssetNewsIntelligence["volatilityRegime"] = "EKSPANSI MODERAT";
  let volatilityActionAdvice = "";

  if (hasCriticalMover || maxImpactScore >= 95) {
    volatilityShockMultiplier = 1.55;
    dynamicAtrBufferPips = isBtc ? 450 : 25.0;
    volatilityRegime = "LONJAKAN EKSTRIM (SHOCK SPIKE)";
    volatilityActionAdvice = "KATALIS KRITIKAL TERDETEKSI: Volatilitas melebar. Buffer SL dilebarkan +25 pips untuk mencegah false sweep!";
  } else if (maxImpactScore >= 85) {
    volatilityShockMultiplier = 1.30;
    dynamicAtrBufferPips = isBtc ? 250 : 15.0;
    volatilityRegime = "VOLATILITAS TINGGI (EXPANSION)";
    volatilityActionAdvice = "EKSPANSI TREN: Penggerak pasar institusional mengonfirmasi momentum berkelanjutan.";
  } else if (moverCount > 0) {
    volatilityShockMultiplier = 1.15;
    dynamicAtrBufferPips = isBtc ? 120 : 8.0;
    volatilityRegime = "EKSPANSI MODERAT";
    volatilityActionAdvice = "ARUS NORMAL: Sinyal berjalan sesuai model matematis standar.";
  } else {
    volatilityShockMultiplier = 1.0;
    dynamicAtrBufferPips = 0;
    volatilityRegime = total === 0 ? "UNAVAILABLE" : "KOMPRESI (SQUEEZE)";
    volatilityActionAdvice = total === 0
      ? "DATA BERITA TIDAK TERSEDIA — VOLATILITAS TIDAK DISIMPULKAN DARI KETIADAAN DATA."
      : "Tidak ada market mover pada artikel yang diberikan; tidak ada inferensi tambahan.";
  }

  const confluenceConfidenceBoost = total > 0 ? Math.min(6, Math.round((signalToNoiseRatio / 100) * 5)) : 0;

  const latestMover = movers.length > 0 ? movers[0] : undefined;

  const topCatalysts = Array.from(new Set(movers.flatMap((m) => m.marketDriverTags))).slice(0, 5);

  let actionableSignalVerdict = total === 0 ? "NEWS INTELLIGENCE UNAVAILABLE — no verified articles supplied." : "";
  if (dominantBias === "BULLISH") {
    actionableSignalVerdict = `⚡ Umpan Berita ${symbolId}: Katalis Penggerak Pasar (${signalToNoiseRatio}% SNR) memvalidasi bias BULLISH. Inflow institusi & sentimen makro memperkuat sinyal BUY dengan buffer volatilitas +${dynamicAtrBufferPips} pips.`;
  } else if (dominantBias === "BEARISH") {
    actionableSignalVerdict = `⚡ Umpan Berita ${symbolId}: Sentimen Pasar Bearish mendominasi. Tekanan supply institusional mengonfirmasi sinyal SELL dengan buffer proteksi risiko optimal.`;
  } else {
    actionableSignalVerdict = `⚡ Umpan Berita ${symbolId}: Sentimen netral terkonsolidasi. Menjaga disiplin Risk-Reward 1:2.5+ pada area OTE.`;
  }

  const institutionalSynthesis = total === 0 ? "No verified news feed connected; no institutional flow inference is made." : `${symbolId}: ${moverCount} market-moving articles and ${noiseCount} noise articles from the supplied feed.`;

  return {
    symbolId,
    dominantBias,
    sentimentScore: avgMoverSentimentScore,
    marketMoversCount: moverCount,
    noiseCount,
    totalArticles: total,
    signalToNoiseRatio,
    volatilityShockMultiplier,
    dynamicAtrBufferPips,
    volatilityRegime,
    volatilityActionAdvice,
    confluenceConfidenceBoost,
    isMoverAlignedWithSignal: (direction: "BUY" | "SELL") => {
      if (dominantBias === "BULLISH" && direction === "BUY") return true;
      if (dominantBias === "BEARISH" && direction === "SELL") return true;
      return false;
    },
    topCatalysts,
    actionableSignalVerdict,
    institutionalSynthesis,
    latestMover,
    articles
  };
}
