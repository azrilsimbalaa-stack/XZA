/**
 * ZRILL Quantitative Core v2
 * Deterministic OHLCV-only model. No synthetic quotes, macro values, or probability claims.
 * Confidence is a rule-evidence score, NOT a calibrated win probability.
 */
export type QuantSide = "BUY" | "SELL" | "WAIT";
export interface QuantCandle { time: number; open: number; high: number; low: number; close: number; volume: number; }
export interface QuantInput {
  symbol: string; timeframe: string;
  bid: number; ask: number; quoteTime: number;
  candles: QuantCandle[];
  now?: number;
}
export interface QuantResult {
  status: "READY" | "WAIT";
  side: QuantSide;
  evidenceScore: number;
  entry: number; stop: number; targets: [number, number, number];
  rr: [number, number, number];
  atr: number; emaFast: number; emaSlow: number; rsi: number;
  realizedVolatility: number; spread: number;
  data: { bars: number; lastBarTime: number; ageMs: number; quoteAgeMs: number; stale: boolean };
  reasons: string[];
  limitations: string[];
}
const finite = (n: unknown): n is number => typeof n === "number" && Number.isFinite(n);
const mean = (xs: number[]) => xs.reduce((a,b)=>a+b,0)/xs.length;
function ema(xs:number[], period:number):number {
  const k=2/(period+1); let v=mean(xs.slice(0,period));
  for(let i=period;i<xs.length;i++) v=xs[i]*k+v*(1-k);
  return v;
}
function rsi(xs:number[], period=14):number {
  let up=0,down=0;
  for(let i=xs.length-period;i<xs.length;i++){const d=xs[i]-xs[i-1]; if(d>0)up+=d; else down-=d;}
  if(down===0)return 100;
  const rs=(up/period)/(down/period); return 100-100/(1+rs);
}
export function analyzeQuantitativeMarket(input: QuantInput): QuantResult {
  const empty=(reason:string):QuantResult=>({
    status:"WAIT",side:"WAIT",evidenceScore:0,entry:0,stop:0,targets:[0,0,0],rr:[0,0,0],
    atr:0,emaFast:0,emaSlow:0,rsi:0,realizedVolatility:0,spread:0,
    data:{bars:input.candles?.length||0,lastBarTime:0,ageMs:0,quoteAgeMs:0,stale:true},
    reasons:[reason],limitations:["Data tidak cukup/valid; tidak ada sinyal yang diterbitkan."]
  });
  const c=input.candles;
  if(!Array.isArray(c)||c.length<100)return empty("Diperlukan minimal 100 candle OHLCV aktual untuk analisis kuantitatif.");
  if(!finite(input.bid)||!finite(input.ask)||input.bid<=0||input.ask<input.bid)return empty("Bid/ask tidak valid; harga tidak boleh diganti dengan fallback.");
  if(!finite(input.quoteTime)||input.quoteTime<=0)return empty("Timestamp quote tidak tersedia; freshness bid/ask tidak dapat diverifikasi.");
  for(let i=0;i<c.length;i++){
    const x=c[i];
    if(!x||![x.time,x.open,x.high,x.low,x.close,x.volume].every(finite)||
      x.time<=0||x.open<=0||x.close<=0||x.low<=0||x.high<x.low||
      x.high<Math.max(x.open,x.close)||x.low>Math.min(x.open,x.close)||x.volume<0)
      return empty(`Candle OHLCV ke-${i} tidak valid.`);
    if(i>0&&(x.time<=c[i-1].time||x.close<=0))return empty("Urutan timestamp candle tidak monoton.");
  }
  const now=input.now??Date.now(), last=c[c.length-1];
  if(last.time>now+5_000||input.quoteTime>now+5_000)return empty("Timestamp candle/quote berada di masa depan; input ditolak.");
  const age=Math.max(0,now-last.time), quoteAge=Math.max(0,now-input.quoteTime);
  if(quoteAge<0||quoteAge>30_000)return {...empty("Quote bid/ask kedaluwarsa atau timestamp tidak valid; menunggu quote baru."),data:{bars:c.length,lastBarTime:last.time,ageMs:Math.max(0,age),quoteAgeMs:Math.max(0,quoteAge),stale:true}};
  const medianStep=(()=>{const d=c.slice(-30).slice(1).map((x,i)=>x.time-c[c.length-30+i].time).sort((a,b)=>a-b);return d[Math.floor(d.length/2)]||0;})();
  const stale=age>Math.max(2*medianStep,120_000);
  if(stale)return {...empty("Candle terakhir kedaluwarsa; menunggu feed aktual."),data:{bars:c.length,lastBarTime:last.time,ageMs:age,quoteAgeMs:quoteAge,stale:true}};
  const closes=c.map(x=>x.close), tr=c.map((x,i)=>i===0?x.high-x.low:Math.max(x.high-x.low,Math.abs(x.high-c[i-1].close),Math.abs(x.low-c[i-1].close)));
  const atr=mean(tr.slice(-14)), fast=ema(closes,20), slow=ema(closes,50), rv=closes.slice(-31).slice(1).map((v,i)=>Math.log(v/closes[c.length-31+i]));
  const vol=Math.sqrt(rv.reduce((sum,x)=>sum+x*x,0)), momentum=rsi(closes,14), spread=input.ask-input.bid, mid=(input.ask+input.bid)/2;
  if(![atr,fast,slow,vol,momentum].every(finite)||atr<=0)return empty("Indikator tidak dapat dihitung dari data yang diberikan.");
  const trend=fast>slow?1:fast<slow?-1:0;
  const recent=c.slice(-20), priorHigh=Math.max(...recent.slice(0,-1).map(x=>x.high)), priorLow=Math.min(...recent.slice(0,-1).map(x=>x.low));
  const breakoutUp=last.close>priorHigh, breakoutDown=last.close<priorLow;
  const buyMomentum=momentum>=52&&momentum<=72, sellMomentum=momentum<=48&&momentum>=28;
  const spreadOk=spread/ mid<=0.0025;
  const side:QuantSide=trend===1&&buyMomentum&&last.close>fast&&spreadOk?"BUY":
    trend===-1&&sellMomentum&&last.close<fast&&spreadOk?"SELL":"WAIT";
  const reasons:string[]=[
    `EMA20 ${fast.toPrecision(7)} dan EMA50 ${slow.toPrecision(7)}: ${trend===1?"tren naik":trend===-1?"tren turun":"netral"}.`,
    `RSI14 ${momentum.toFixed(1)}; ATR14 ${atr.toPrecision(6)}.`,
    `Volatilitas terealisasi 30-bar ${vol.toFixed(6)} (akumulasi return log; bukan prediksi atau annualisasi).`,
    `Spread ${(spread/mid*100).toFixed(4)}% dari mid-price.`,
    breakoutUp?"Breakout high 19 candle sebelumnya terdeteksi.":breakoutDown?"Breakdown low 19 candle sebelumnya terdeteksi.":"Belum ada breakout 19 candle yang terkonfirmasi."
  ];
  if(!spreadOk)reasons.push("Spread relatif terlalu lebar; sinyal diblokir.");
  if(side==="WAIT")reasons.push("Konfirmasi tren, momentum, dan spread belum searah; status WAIT.");
  const entry=side==="BUY"?input.ask:side==="SELL"?input.bid:mid, dir=side==="BUY"?1:side==="SELL"?-1:0;
  const swingLow=Math.min(...c.slice(-10).map(x=>x.low)), swingHigh=Math.max(...c.slice(-10).map(x=>x.high));
  const stop=dir===1?Math.min(swingLow,entry-1.5*atr):dir===-1?Math.max(swingHigh,entry+1.5*atr):0;
  const risk=dir?Math.abs(entry-stop):0;
  const targets:[number,number,number]=dir?[entry+dir*risk*1.5,entry+dir*risk*2,entry+dir*risk*3]:[0,0,0];
  const rr:[number,number,number]=dir?[1.5,2,3]:[0,0,0];
  const evidenceScore=side==="WAIT"?Math.min(49,Math.round((trend!==0?15:0)+(buyMomentum||sellMomentum?15:0)+(spreadOk?10:0)+(breakoutUp||breakoutDown?9:0))):Math.min(85,Math.round(55+(breakoutUp||breakoutDown?15:0)+(Math.abs(momentum-50)>10?10:0)+(spreadOk?5:0)));
  return {status:side==="WAIT"?"WAIT":"READY",side,evidenceScore,entry,stop,targets,rr,atr,emaFast:fast,emaSlow:slow,rsi:momentum,realizedVolatility:vol,spread,
    data:{bars:c.length,lastBarTime:last.time,ageMs:age,quoteAgeMs:quoteAge,stale:false},reasons,
    limitations:["Evidence score bukan probabilitas menang dan belum dikalibrasi melalui walk-forward/backtest.","Validasi OHLCV hanya memeriksa struktur, urutan, dan freshness; asal-usul data tidak diverifikasi independen.","Target berbasis ATR dan swing lokal; bukan jaminan harga akan tercapai.","Belum memasukkan order book, makro, berita, biaya komisi, slippage, maupun korelasi lintas aset."]};
}
