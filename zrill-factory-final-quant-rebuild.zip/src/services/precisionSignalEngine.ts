// Precision Quantitative & Smart Money Concepts (SMC + ICT + DRL) Signal Engine
// Designed for Institutional High-Probability Accuracy, Unified Multi-Timeframe Alignment & Zero Contradiction

import { analyzeQuantitativeMarket } from "./quantitativeCoreV2";

import {
  computeAssetNewsIntelligence,
  AssetNewsIntelligence,
  getAssetPersonalizedNews,
  PersonalizedNewsArticle,
} from "./assetNewsIntelligenceService";

import {
  computeRealtimeMacroSMCFusion,
  computeRealtimeMacroPulse,
  RealtimeMacroSMCFusion,
  RealtimeMacroPulse,
  InstitutionalOrderBlock,
  FairValueGapImbalance,
} from "./realtimeFundamentalStreamEngine";

export {
  computeAssetNewsIntelligence,
  getAssetPersonalizedNews,
  computeRealtimeMacroSMCFusion,
  computeRealtimeMacroPulse,
};
export type {
  AssetNewsIntelligence,
  PersonalizedNewsArticle,
  RealtimeMacroSMCFusion,
  RealtimeMacroPulse,
  InstitutionalOrderBlock,
  FairValueGapImbalance,
};

export interface ConfluenceCheck {
  id: string;
  name: string;
  category: "STRUCTURE" | "LIQUIDITY" | "IMBALANCE" | "MOMENTUM" | "RISK" | "TIMING" | "MACRO";
  passed: boolean;
  score: number; // 0 to 15 points
  details: string;
}

export type TradingRegime = "SCALP" | "INTRADAY" | "SWING";

export interface TrendPillars {
  macroStructureD1_H4: string;
  intermediateFlowH1_M30: string;
  triggerPrecisionM15: string;
  emaRibbonAlignment: string;
  orderFlowDelta: string;
}

export interface TrendIntelligence {
  masterTrend: "STRONG_BULLISH" | "HEALTHY_BULLISH" | "STRONG_BEARISH" | "HEALTHY_BEARISH" | "NEUTRAL_ACCUMULATION";
  trendStrengthPct: number;
  trendPhase: "EXPANSION_IMPULSE" | "PULLBACK_DISCOUNT_OTE" | "PULLBACK_PREMIUM_OTE" | "BREAKOUT_BOS";
  trendDirection: "BUY" | "SELL";
  trendPillars: TrendPillars;
  tradeRecommendation: "STRONG_BUY_ON_DIPS" | "STRONG_SELL_ON_RALLIES";
  safetyFilter: string;
}

export interface WitaCalendarSync {
  currentWitaTime: string;
  currentWitaDate: string;
  activeSession: string;
  isKillzone: boolean;
  killzoneBadge: string;
  nearestHighImpactEvent: {
    title: string;
    currency: string;
    witaReleaseTime: string;
    countdownStr: string;
    forecast: string;
    previous: string;
    impactDirection: "BUY" | "SELL";
    confidence: number;
    isReleased: boolean;
    spikePrediction?: {
      spikeProbability: number;
      spikeLevel: string;
      spikeType: string;
      estimatedPipsGold: string;
      spikeDirectionBias: string;
      trapRiskLevel: string;
      preReleaseStrategy: string;
    };
  };
  newsSafetyStatus: "🟢 SAFE TRADING WINDOW (No High Impact News in next 2 hours)" | "🟡 HIGH IMPACT NEWS IMMINENT (Volatility Guard Active)" | "🔴 NEWS RELEASE EXPANSION IN PROGRESS";
  volatilityMultiplier: string;
  nextSessionName: string;
  timeToNextSession: string;
  sessionProgressPct: number;
}

export interface LiquidityEngineRadar {
  buySideLiquidity: {
    price: number;
    pipsDistance: string;
    status: "UNSWEPT POOL (MAGNET TARGET)" | "SWEPT & REJECTED";
    confidence: number;
  };
  sellSideLiquidity: {
    price: number;
    pipsDistance: string;
    status: "DISCOUNT POOL (PROTECTED)" | "SWEPT & REVERSED";
    confidence: number;
  };
  oteFibonacci: {
    fib618: number;
    fib705: number;
    fib786: number;
    sweetSpotLabel: string;
  };
  orderBlockStatus: string;
  fvgImbalanceStatus: string;
}

export interface QuantumOrderFlow {
  buyerAggressionPct: number;
  sellerAggressionPct: number;
  institutionalDeltaVolume: string;
  smartMoneyAbsorption: string;
  orderFlowBias: "INSTITUTIONAL ACCUMULATION (HEAVY BUYERS)" | "INSTITUTIONAL DISTRIBUTION (HEAVY SELLERS)";
  accumulationScore: number;
  institutionalDominancePct: number;
  retailPressurePct: number;
  dominanceStatus: "INSTITUSI BELI DOMINAN (HIGH PRESSURE BUY)" | "INSTITUSI JUAL DOMINAN (HIGH PRESSURE SELL)";
  dominanceLevel: "ULTRA HIGH DOMINANCE" | "STRONG INSTITUTIONAL ACCUMULATION" | "EXTREME SMART MONEY PUSH";
  retailTrapDiagnosis: string;
  whaleCapitalDelta: string;
  orderBookImbalanceRatio: string;
  smartMoneyFootprint: string;
  volumeAggressionLevel: string;
}

export interface KeyAreaTarget {
  name: string; // e.g. "TP 1 (Likuiditas Sesi)", "TP 2 (Ekspansi Struktur)", "TP 3 (Runner Makro)", "SL (Invalidasi)"
  price: number;
  pips: number;
  pipsStr: string;
  rrRatio: string; // e.g. "1:2.4"
  hitProbability: number | null; // null until empirically calibrated
  reachabilityCondition: "SANGAT MUDAH DICAPAI" | "TARGET OPTIMAL STRUKTUR" | "RUNNER KATALIS MAKRO" | "BATAS PROTEKSI RISIKO";
  areaPentingReason: string; // Detailed reason for placing at this important area
  structuralAnchor: string; // Structural level e.g. "Order Block H1 / Asian Low / Equal Highs / BSL Pool"
}

export interface GuaranteedRREngine {
  guaranteedMinRR: string; // e.g. "1:2.0"
  effectiveRR: string; // e.g. "1:2.0", "1:3.0", "1:5.0"
  macroRunnerRR?: string; // e.g. "1:5.0" or "1:7.2"
  tp1RR: string; // e.g. "1:1.5 (+1.5R)"
  tp2RR: string; // e.g. "1:3.0 (+3.0R)"
  tp3RR: string; // e.g. "1:5.0 (+5.0R)"
  riskPipDistance: number; // e.g. 24
  tp1PipDistance: number; // e.g. 48
  tp2PipDistance: number; // e.g. 72
  tp3PipDistance: number; // e.g. 120
  invalidationPrice: number;
  invalidationArmorReason: string;
  distanceToInvalidationStr: string;
  mathematicalAlphaScore: string;
  winProbabilityPct: number;
  trajectoryProbabilities: {
    tp1HitProb: number;
    tp2HitProb: number;
    tp3HitProb: number;
  };
  expectedValueAlphaR: string;
  invalidationBufferPips: string;
  liquiditySweepTargetPips: string;
  slArea?: KeyAreaTarget;
  tp1Area?: KeyAreaTarget;
  tp2Area?: KeyAreaTarget;
  tp3Area?: KeyAreaTarget;
  marketConditionSummary?: string;
  // Dynamic R:R flexibility metrics
  rrFlexibilityNotice?: string;
  structuralRoomAvailable?: string;
  isCustomTailoredRR?: boolean;
  tailoredRRRatio?: string;
  scalpMaxCapEnforced?: boolean;
  isScalpCappedAt3R?: boolean;
  isExpandedBeyond3R?: boolean;
  opposingHurdlePrice?: number;
}

export interface DynamicPositionCalculator {
  riskPerTradePct: string;
  slPipsNumber: number;
  tp1PipsNumber: number;
  tp3PipsNumber: number;
  lotSize500: string;
  lotSize1000: string;
  lotSize5000: string;
  lotSize10000: string;
  lotSize50000: string;
  expectedDollarGain1Lot: string;
  maxRiskDollar1Lot: string;
  expectedValueMultiplier: string;
}

export interface RegimeAnalysis {
  recommendedRegime: TradingRegime;
  regimeLabel: string;
  regimeConfidence: number;
  regimeReason: string;
  estimatedHolding: string;
  bestTimeframe: string;
  targetExpectancy: string;
  recommendedPlaybook: string;
  isAdaptiveFallback?: boolean;
  fallbackFromRegime?: TradingRegime;
  fallbackReason?: string;
  adaptiveFallbackBadge?: string;
  rrFlexibilityMode?: string;
}

export interface ReversalWarningIntelligence {
  hasReversalThreat: boolean;
  reversalSeverity: "NONE" | "MODERATE_WARNING" | "HIGH_DANGER" | "IMMINENT_REVERSAL";
  reversalType: "BULLISH_REVERSAL" | "BEARISH_REVERSAL" | "NO_REVERSAL";
  reversalReason: string;
  structureSignal: {
    chochDetected: boolean;
    liquiditySweepTrap: boolean;
    bosFailed: boolean;
    structureDetails: string;
  };
  candlestickPattern: {
    patternName: string;
    patternDescription: string;
    exhaustionWickRatio: number;
    isExhaustionConfirmed: boolean;
  };
  mathematicalConfirmation: {
    gaussianZScore: number;
    rsiDivergenceType: string;
    bayesReversalProbability: number;
    mathematicalProof: string;
  };
  fundamentalConfirmation: {
    isOpposingMacroPressure: boolean;
    dxyCatalystSummary: string;
    yieldCatalystSummary: string;
  };
  recommendedTraderAction: string;
}

export interface FundamentalIntelligence {
  macroScore: number; // 0 - 100% (e.g. 96%)
  macroBias: "STRONG_BULLISH_CATALYST" | "HEALTHY_BULLISH_FLOW" | "STRONG_BEARISH_CATALYST" | "HEALTHY_BEARISH_FLOW" | "NEUTRAL_EXPANSION";
  fundamentalStrengtheningMultiplier: string; // e.g. "1.38x Fundamental Confluence Booster"
  isFundamentalAligned: boolean;
  alignmentLabel: string;
  keyCatalysts: {
    dxyCorrelation: {
      dxyValue: number;
      dxyTrend: "BEARISH_PRESSURE" | "BULLISH_SURGE" | "CONSOLIDATING";
      impactOnAsset: string;
      correlationWeight: number;
    };
    treasuryYields: {
      yield10Y: number;
      yieldTrend: "FALLING_YIELDS" | "RISING_YIELDS" | "SIDEWAYS";
      realInterestRateImpact: string;
    };
    fedMonetaryStance: {
      stance: string;
      nextMeetingSentiment: string;
      policyRateRange: string;
    };
    inflationAndLabor: {
      cpiTrend: string;
      nfpOutlook: string;
      summary: string;
    };
    geopoliticalSafeHaven: {
      safeHavenDemand: string;
      description: string;
    };
  };
  assetNewsFeedIntegration?: {
    dominantBias: "BULLISH" | "BEARISH" | "NEUTRAL";
    signalToNoiseRatio: number;
    marketMoversCount: number;
    noiseCount: number;
    volatilityRegime: string;
    dynamicAtrBufferPips: number;
    catalysts: string[];
    actionableVerdict: string;
    latestMoverTitle?: string;
    volatilityActionAdvice?: string;
  };
  fundamentalConfluencePillars: {
    name: string;
    score: number;
    status: string;
    description: string;
  }[];
  fundamentalVerdict: string;
}

export interface LimitOrderDetails {
  isLimitOrder: boolean;
  limitType: "BUY LIMIT" | "SELL LIMIT";
  limitEntryPrice: number;
  keyAreaName: string;
  keyAreaType: "UNMITIGATED_DEMAND_OB" | "UNMITIGATED_SUPPLY_OB" | "DISCOUNT_FVG" | "PREMIUM_FVG" | "GOLDEN_POCKET_0618" | "LIQUIDITY_SWEEP_POOL" | "FIB_2618_EXT_REVERSAL";
  triggerCondition: string;
  distanceToLimitPips: number;
  distanceToLimitPrice: number;
  mathematicalZoneReason: string;
  limitFibLevel: string;
  orderValidityTime: string;
  threePillarsEvaluation?: {
    marketStructure: {
      type: "BULLISH_STRUCTURE" | "BEARISH_STRUCTURE" | "SIDEWAYS_RANGE";
      details: string;
      swingHigh: number;
      swingLow: number;
    };
    selectedEntryStrategy: "2.618_EXTENSION_REVERSAL" | "0.618_GOLDEN_RETRACEMENT";
    selectedFibLevel: string;
    fibonacciReason: string;
    fundamentalStatus: "ALIGNED" | "NEUTRAL" | "OPPOSING" | "HIGH_IMPACT_ACTIVE";
    fundamentalReason: string;
    sentimentStatus: "STRONG_SUPPORTIVE" | "WEAK_MIXED" | "CONTRARIAN";
    sentimentReason: string;
    trendExhaustionStatus: "EXHAUSTION_CONFIRMED" | "STRONG_TREND_CONTINUATION";
    trendExhaustionReason: string;
    confidenceGrade: "TINGGI" | "SEDANG" | "RENDAH";
    confidenceScorePct: number;
    invalidationRule: string;
    atrVolatilityBufferPips: number;
  };
}

export interface MarketSentimentRadar {
  buyerPercentage: number;
  sellerPercentage: number;
  sentimentBias: "DOMINAN_BUYER" | "DOMINAN_SELLER" | "NEUTRAL_BALANCED";
  orderFlowDeltaRatio: string;
  institutionalAbsorptionScore: string;
  retailTrapWarning: string;
  limitOrderOptimalReason: string;
  drawdownReductionPct: string;
}

export interface MathematicalAreaModel {
  entryFormula: string;
  slFormula: string;
  tp1Formula: string;
  tp2Formula: string;
  tp3Formula: string;
  calculatedExactRR: {
    tp1RR: string; // e.g. "1:2.15"
    tp2RR: string; // e.g. "1:3.82"
    tp3RR: string; // e.g. "1:6.18"
    compositeRR: string; // e.g. "1:3.8"
  };
  swingRange: {
    swingHigh: number;
    swingLow: number;
    swingDelta: number;
    atrVolBuffer: number;
  };
  fibonacciMatrix: {
    fib0_EquilibriumHigh: number;
    fib382: number;
    fib500_Equilibrium: number;
    fib618_GoldenPocket: number;
    fib705_OptimalEntry: number;
    fib786_DeepExtreme: number;
    fib100_SwingAnchor: number;
    fib1272_LiquidityTarget: number;
    fib1618_GoldenExpansion: number;
    fib2618_MacroExpansion: number;
  };
  mathematicalProof: string;
}

export interface RuleValidationShield {
  noCounterTrendTrade: {
    passed: boolean;
    trendType: "BULLISH" | "BEARISH" | "SIDEWAYS";
    allowedDirection: "BUY_ONLY" | "SELL_ONLY" | "SAFE_0618_OR_WAIT";
    ruleDetails: string;
  };
  orderTypeDecision: {
    passed: boolean;
    orderType: "BUY NOW" | "SELL NOW" | "BUY LIMIT" | "SELL LIMIT";
    executionCategory: "MARKET_ORDER_CONTINUATION" | "LIMIT_ORDER_PULLBACK";
    conditionMatched: "KONDISI_1_LANJUTAN_KUAT" | "KONDISI_2_SEDANG_PULLBACK";
    ruleDetails: string;
  };
  pricePlacementIntegrity: {
    passed: boolean;
    entryPrice: number;
    currentPrice: number;
    ruleDetails: string;
  };
  fibonacciStrategyApplied: {
    passed: boolean;
    selectedLevel: "0.618" | "2.618" | "MARKET_NOW";
    zoneClassification: "ZONA_AMAN_0618" | "ZONA_EKSTREM_2618" | "MOMENTUM_BREAKOUT";
    ruleDetails: string;
  };
  slStructureSafety: {
    passed: boolean;
    slPrice: number;
    swingReference: "SWING_LOW" | "SWING_HIGH";
    ruleDetails: string;
  };
  tpMultiTargetRREnforced: {
    passed: boolean;
    tp1: { price: number; rr: string; rule: string };
    tp2: { price: number; rr: string; rule: string };
    tp3: { price: number; rr: string; rule: string };
    ruleDetails: string;
  };
  allRulesCompliant: boolean;
  complianceScorePct: number;
  prohibitionsPassed: {
    antiCounterTrend: boolean;
    antiInvertedLimitPlacement: boolean;
    antiForcedFib2618InSideways: boolean;
    antiSlInsideStructure: boolean;
    antiNonStandardRRMappings: boolean;
  };
}

export interface OptimalRetestAdvisory {
  status: "RETEST_ZONE_ACTIVE" | "WAIT_RETEST_RECOMMENDED" | "MOMENTUM_BREAKOUT_NO_RETEST";
  advisoryTitle: string;
  advisoryMessage: string;
  optimalRetestPrice: number;
  optimalRetestAreaName: string;
  optimalFibLevel: string;
  distanceToRetestPips: number;
  drawdownSavingPips: number;
  drawdownSavingDollarEstimate: string;
  improvedRiskReward: string;
  retestConfirmationChecklist: {
    checkName: string;
    passed: boolean;
    instruction: string;
  }[];
  traderTacticalChoice: {
    instantMarketAction: {
      actionLabel: "BUY NOW" | "SELL NOW";
      price: number;
      pros: string;
      riskNote: string;
    };
    limitRetestAction: {
      actionLabel: "PENDING LIMIT ORDER (HARGA TERBAIK)";
      price: number;
      pros: string;
      riskNote: string;
    };
  };
}

export interface GoldenZone0618Quality {
  zoneQualityStatus: "MURNI_VALID" | "TERSENTUH_SEKALI" | "ZONA_RUSAK_REANCHOR";
  badgeLabel: string;
  badgeColor: "emerald" | "amber" | "rose";
  touchCount: number;
  touchHistoryDescription: string;
  price0618: number;
  swingHighAnchor: number;
  swingLowAnchor: number;
  fiboDirection: "BUY_LOW_TO_HIGH" | "SELL_HIGH_TO_LOW";
  isReanchoredNewFibo: boolean;
  reanchorReason?: string;
  trendSmoothness: {
    isClearTrend: boolean;
    hasNoObstacles: boolean;
    isFresh0618: boolean;
    hasNoOpposingKeyLevel: boolean;
    momentumAndVolumeAligned: boolean;
    verdict: "BUY_NOW_ALLOWED" | "SELL_NOW_ALLOWED" | "WAIT_RETEST_REQUIRED";
    reasoning: string;
  };
  statusSignalText: "BUY NOW" | "SELL NOW" | "WAIT RETEST BUY 0.618" | "WAIT RETEST SELL 0.618" | "TUNGGU KONFIRMASI";
  executionInstruction: string;
  slOutsideStructure: number;
  slPipsDistanceStr: string;
  tpNextZone: number;
  tpRRatioStr: string;
  formattedOutputSignalText: string;
  candleVolSignal?: "VOLUME_CONTINUATION" | "VOLUME_REVERSAL" | "VOLUME_NORMAL" | "VOLUME_DRY";
  candleVolLabel?: string;
  candleVolDetail?: string;
  candleVolume?: {
    volumeSignal: string;
    volumeLabel: string;
    volumeDetail: string;
    rvol: number;
    lastCandleVol: number;
    avgCandleVol: number;
  };
}

export interface EntryThinkingStep {
  stepNumber: number;
  stageName: string;
  title: string;
  category: "MACRO_BIAS" | "LIQUIDITY_ENGINEERING" | "MARKET_STRUCTURE" | "VALUE_DISCOUNT" | "ORDER_FLOW" | "INVALIDATION_RISK";
  statusBadge: string;
  passed: boolean;
  coreQuestion: string;
  institutionalObservation: string;
  verdict: string;
  keyMetric: string;
}

export interface BestEntryZoneArchitecture {
  zoneRangeMin: number;
  zoneRangeMax: number;
  sweetSpotSniperPrice: number;
  zoneType: string;
  valuationStatus: "DEEP_DISCOUNT" | "OPTIMAL_DISCOUNT" | "EQUILIBRIUM" | "PREMIUM_EXPENSIVE" | "DEEP_PREMIUM";
  valuationLabel: string;
  discountOrPremiumPercentage: number;
  distanceFromCurrentPricePoints: number;
  distanceFromCurrentPricePipsStr: string;
  isPriceCurrentlyInZone: boolean;
  recommendedEntryStyle: "MARKET_EXECUTION_NOW" | "PENDING_LIMIT_SNIPER" | "CONFIRMATION_CANDLE_CLOSE";
  recommendedExecutionBadge: string;
  zoneQualityScore: number;
  zoneQualityGrade: string;
  expectedDrawdownAtr: string;
  invalidationLevel: number;
  whyThisIsTheBestArea: string;
  limitOrderSetupText: string;
}

export interface SupremeConfluencePillar {
  id: string;
  pillarNumber: number;
  name: string;
  category: "STRUCTURE" | "ORDER_FLOW" | "FIBONACCI" | "RISK_REWARD" | "TIMING" | "MACRO" | "LIQUIDITY";
  statusBadge: string;
  passed: boolean;
  score: number;
  maxScore: number;
  weightPct: number;
  institutionalAnalysis: string;
}

export interface TimeframeVolatilityNode {
  timeframe: "M1" | "M5" | "M15" | "M30" | "H1" | "H4" | "D1" | string;
  atrPips: number;
  atrPrice: number;
  bollingerBandwidthPercent: number;
  expansionRatio: number;
  status: "KOMPRESI (SQUEEZE)" | "NORMAL" | "EKSPANSI TINGGI" | "LONJAKAN EKSTRIM";
  regimeColor: string;
}

export interface PrecisionVolatilityTracker {
  atrPips: number;
  atrPrice: number;
  atrPercent: number;
  volatilityRegime: "KOMPRESI RENDAH (SQUEEZE)" | "EKSPANSI MODERAT" | "VOLATILITAS TINGGI (EXPANSION)" | "LONJAKAN EKSTRIM (SHOCK SPIKE)";
  volatilityIndexScore: number;
  bollingerPhase: "SQUEEZE (POTENSI BREAKOUT)" | "EXPANSION RIDING" | "EXTREME OVERSTRETCHED (MEAN REVERSION)";
  bollingerBandwidthPercent: number;
  historicalVolatilityPercentile: number;
  sigmaBands: {
    sigma1Range: { lower: number; upper: number; pips: number };
    sigma2Range: { lower: number; upper: number; pips: number };
    sigma26GoldenRange: { lower: number; upper: number; pips: number };
    sigma3ExtremeRange: { lower: number; upper: number; pips: number };
  };
  sessionProjectedRange: {
    expectedHigh: number;
    expectedLow: number;
    dailyAtrLimit: number;
    pipSpanTotal: number;
    remainingRoomPips: number;
  };
  timeframeVolatilityMap: TimeframeVolatilityNode[];
  slSafetyBufferPips: number;
  volatilityActionAdvice: string;
}

export interface FootprintImbalanceNode {
  priceLevel: number;
  bidAggressorVolume: number;
  askAggressorVolume: number;
  delta: number;
  dominantSide: "BUY" | "SELL";
  imbalanceRatio: number;
  isAbsorptionZone: boolean;
}

export interface InstitutionalMoneyFlowTracker {
  netFundFlowUsd: number;
  netFundFlowFormatted: string;
  flowDirection: "NET_INFLOW_BULLISH" | "NET_OUTFLOW_BEARISH" | "NEUTRAL_CHOP";
  cumulativeVolumeDelta: number;
  cvdTrend: "BULLISH DIVERGENCE (SMART MONEY ACCUMULATION)" | "BEARISH DIVERGENCE (DISTRIBUTION)" | "STRONG POSITIVE FLOW" | "STRONG NEGATIVE FLOW";
  buyAggressionPercent: number;
  sellAggressionPercent: number;
  whaleBlockOrdersCount: number;
  whaleBlockVolumeUsd: string;
  darkPoolState: "ACTIVE LIQUIDITY SWEEP" | "STEALTH ACCUMULATION" | "QUIET ABSORPTION";
  smartMoneyAbsorption: {
    isAbsorbing: boolean;
    absorbedPriceLevel: number;
    absorptionType: "BID ABSORPTION (WHALE BUYING DIPS)" | "ASK ABSORPTION (WHALE CAPPING HIGHS)" | "NO_ABSORPTION";
    absorptionPowerPercent: number;
  };
  footprintLevels: FootprintImbalanceNode[];
  smartMoneyBehaviorVerdict: string;
}

export interface SupremeSignalMetrics {
  omnipotenceScore: number;
  powerGrade: "SUPREME APEX AAA+" | "INSTITUTIONAL AAA+" | "HIGH ALPHA AA+";
  powerTierBadge: string;
  marketRegimePhase: "IMPULSIVE EXPANSION" | "ACCUMULATION DISCOUNT OTE" | "DISTRIBUTION PREMIUM OTE" | "SWEEP LIQUIDITY INVERSION";
  confluencePillarsCount: { passed: number; total: number };
  twelvePillars?: SupremeConfluencePillar[];
  precisionVolatilityTracker: PrecisionVolatilityTracker;
  institutionalMoneyFlowTracker: InstitutionalMoneyFlowTracker;
  bestEntryZone: BestEntryZoneArchitecture;
  entryThinkingChain: EntryThinkingStep[];
  orderFlowQuantum: {
    buyerAggression: number;
    sellerAggression: number;
    whaleDeltaVolume: string;
    whaleAbsorptionWall: string;
    dominanceVerdict: string;
    retailTrapAlert: string;
  };
  liquidityArchitecture: {
    buySideLiquidityPrice: number;
    buySidePips: string;
    sellSideLiquidityPrice: number;
    sellSidePips: string;
    magnetTarget: string;
    sweepTrapRisk: string;
  };
  smcOrderBlockMatrix: {
    type: string;
    priceRange: string;
    fvgStatus: string;
    bosStatus: string;
    chochStatus: string;
    oteSweetSpot: string;
  };
  tacticalBlueprint: {
    phase1Entry: string;
    phase2Breakeven: string;
    phase3PartialTakeProfit: string;
    phase4Runner: string;
    executionProtocol: string;
    invalidationArmor: string;
  };
  accountSizingTable: Array<{
    balance: string;
    recommendedLot: string;
    riskAmount: string;
    tp1Gain: string;
    tp2Gain: string;
    tp3Gain: string;
  }>;
  quickMtCopyText: string;
  aiSupremeVerdict: string;
  omnipresentMtfCertainty?: OmnipresentMtfCertaintySynthesis;
}

export interface TimeframeCertaintyItem {
  timeframe: "M1" | "M5" | "M15" | "M30" | "H1" | "H4" | "D1" | string;
  name: string;
  role: string;
  trend: "BULLISH" | "BEARISH" | "SIDEWAYS";
  certaintyPercent: number | null;
  status: string; // descriptive state only; no fixed confidence labels
  keyFactor: string;
  weightPercent: number;
  alignmentWithSignal: boolean;
  entrySuggestion: string;
}

export interface OmnipresentMtfCertaintySynthesis {
  totalTimeframesAnalyzed: number;
  alignedTimeframesCount: number;
  overallCertaintyScore: number;
  consensusRating: string;
  macroAnchorD1Bias: "BULLISH" | "BEARISH";
  executionTriggerM1Status: string;
  structuralConfirmationM5Status: string;
  intradayEngineM15Status: string;
  timeframeCertaintyList: TimeframeCertaintyItem[];
  institutionalSynthesisVerdict: string;
}

export interface TimeframeSignalProfile {
  timeframe: string;
  category: TradingRegime;
  type: "BUY NOW" | "SELL NOW" | "BUY" | "SELL" | "BUY LIMIT" | "SELL LIMIT" | "WAIT RETEST" | string;
  orderExecutionType?: "BUY NOW" | "SELL NOW" | "MARKET_EXECUTION" | "BUY LIMIT" | "SELL LIMIT" | "WAIT RETEST" | string;
  goldenZone0618Quality?: GoldenZone0618Quality;
  limitOrderDetails?: LimitOrderDetails;
  optimalRetestAdvisory?: OptimalRetestAdvisory;
  marketSentimentRadar?: MarketSentimentRadar;
  mathematicalAreas?: MathematicalAreaModel;
  ruleValidationShield?: RuleValidationShield;
  entry: number;
  entryZoneMin: number;
  entryZoneMax: number;
  sl: number;
  tp: number;
  tp1: number;
  tp2: number;
  tp3: number;
  rr: string;
  breakevenPrice: number;
  invalidationPrice: number;
  confidence: number;
  targetPips: string;
  slPips: string;
  isRecommendedRegime?: boolean;
  slArea?: KeyAreaTarget;
  tp1Area?: KeyAreaTarget;
  tp2Area?: KeyAreaTarget;
  tp3Area?: KeyAreaTarget;
  reachabilitySummary?: string;
  supremeSignalMetrics?: SupremeSignalMetrics;
  bestEntryZone?: BestEntryZoneArchitecture;
  entryThinkingChain?: EntryThinkingStep[];
  omnipresentMtfCertainty?: OmnipresentMtfCertaintySynthesis;
  realtimeMacroSMCFusion?: RealtimeMacroSMCFusion;
  entryZoneType?: string;
  actionStatusText?: string;
  snrBounceCount?: number;
  snrStrengthLabel?: string;
  breakoutIndication?: string;
}

export type AmdPhaseType = "AKUMULASI" | "MANIPULASI" | "DISTRIBUSI";

export interface AmdExecutionStrategy {
  strategyName: string;
  phaseMode: AmdPhaseType;
  adjustedSlPrice: number;
  adjustedTpPrice: number;
  slAdjustmentReason: string;
  tpAdjustmentReason: string;
  riskRewardRatio: string;
  stopType: "STANDARD_BUFFER_STOP" | "SNIPER_SWEEP_STOP" | "TIGHT_DISTRIBUTION_LOCK_STOP";
  tpType: "BALANCED_RANGE_TARGET" | "SWEEP_EXTENDED_TARGET" | "MAX_EXPANSION_TARGET";
  tightStopsPrioritized: boolean;
}

export interface AmdPhaseAnalysis {
  currentPhase: AmdPhaseType;
  phaseBadge: string;
  phaseColor: "amber" | "rose" | "emerald";
  accuracyBonusPercent: number;
  confidenceScore: number;
  summaryExplanation: string;
  accumulationZone: {
    rangeMin: number;
    rangeMax: number;
    rangePips: number;
    statusLabel: string;
    description: string;
  };
  manipulationZone: {
    sweepPrice: number;
    sweepDirection: "BSL_SWEEP_BUY_TRAP" | "SSL_SWEEP_SELL_TRAP" | "JUDAS_SWEEP_ACTIVE";
    judasDistancePips: number;
    statusLabel: string;
    description: string;
  };
  distributionZone: {
    targetExpansionPrice: number;
    expansionPips: number;
    statusLabel: string;
    description: string;
  };
  executionStrategy: AmdExecutionStrategy;
  po3ConfluenceScore: number;
  institutionalTacticalAdvice: string;
}

export interface PrecisionSignalResult {
  status: "ACTIVE" | "WAITING";
  type: "BUY NOW" | "SELL NOW" | "BUY" | "SELL" | "BUY LIMIT" | "SELL LIMIT" | "WAIT RETEST" | string;
  orderExecutionType?: "BUY NOW" | "SELL NOW" | "MARKET_EXECUTION" | "BUY LIMIT" | "SELL LIMIT" | "WAIT RETEST" | string;
  goldenZone0618Quality?: GoldenZone0618Quality;
  limitOrderDetails?: LimitOrderDetails;
  optimalRetestAdvisory?: OptimalRetestAdvisory;
  marketSentimentRadar?: MarketSentimentRadar;
  mathematicalAreas?: MathematicalAreaModel;
  ruleValidationShield?: RuleValidationShield;
  qualityGrade: "AAA+ INSTITUTIONAL" | "AA+ HIGH PROBABILITY" | "A+ CONFIRMED" | string;
  confidence: number; // reserved for empirically calibrated probability; 0 until calibrated
  evidenceScore?: number; // rule-evidence score, not a win probability
  entry: number;
  entryZoneMin: number;
  entryZoneMax: number;
  safeZoneName: string;
  profitExpectancy: string;
  sl: number;
  tp: number;
  tp1: number;
  tp2: number;
  tp3: number;
  rr: string;
  rrType: "INSTITUTIONAL_RUNNER" | "BALANCED" | "AGGRESSIVE";
  invalidationPrice: number;
  breakevenPrice: number;
  method: string;
  analysis: string;
  formattedOutputSignalText?: string;
  actionStatusText?: string;
  candleVolSignal?: "VOLUME_CONTINUATION" | "VOLUME_REVERSAL" | "VOLUME_NORMAL" | "VOLUME_DRY";
  candleVolLabel?: string;
  candleVolDetail?: string;
  candleVolume?: {
    volumeSignal: string;
    volumeLabel: string;
    volumeDetail: string;
    rvol: number;
    lastCandleVol: number;
    avgCandleVol: number;
  };
  category: TradingRegime;
  regimeAnalysis: RegimeAnalysis;
  trendIntelligence: TrendIntelligence;
  witaCalendarSync: WitaCalendarSync;
  liquidityEngineRadar: LiquidityEngineRadar;
  quantumOrderFlow: QuantumOrderFlow;
  guaranteedRREngine: GuaranteedRREngine;
  dynamicPositionCalculator: DynamicPositionCalculator;
  mathematicalModelEngine: MathematicalModelEngine;
  fundamentalIntelligence: FundamentalIntelligence;
  reversalWarningIntelligence?: ReversalWarningIntelligence;
  reversalIntelligence?: ReversalWarningIntelligence;
  unifiedNeuralSynapseBus: UnifiedNeuralSynapseBus;
  confluenceChecks: ConfluenceCheck[];
  executionLogic: {
    htfBias: string;
    liquidityTrap: string;
    ltfTrigger: string;
    riskManagement: string;
  };
  reasoning: string[];
  timestamp: number;
  symbol: string;
  timeframe: string;
  autonomousTriggered: boolean;
  
  // Multi-Timeframe Alignment & Harmonization Data
  mtfHarmonized: boolean;
  mtfConcordance: {
    bias: "BULLISH" | "BEARISH" | "WAIT";
    scalpAlignment: string;
    intradayAlignment: string;
    swingAlignment: string;
    concordanceRate: string; // e.g. "100% (Zero Contradiction)"
  };
  timeframeMatrix: Record<string, TimeframeSignalProfile>;
  supremeSignalMetrics?: SupremeSignalMetrics;
  bestEntryZone?: BestEntryZoneArchitecture;
  entryThinkingChain?: EntryThinkingStep[];
  omnipresentMtfCertainty?: OmnipresentMtfCertaintySynthesis;
  realtimeMacroSMCFusion?: RealtimeMacroSMCFusion;
  amdPhaseAnalysis?: AmdPhaseAnalysis;
  zrillV5Core?: ZrillV5CoreAnalysis;
  entryZoneType?: string;
  snrBounceCount?: number;
  snrStrengthLabel?: string;
  breakoutIndication?: string;
}

export interface ZrillV5ConfluencePillar {
  id: number;
  title: string;
  category: "EMA_TREND" | "STRUCTURE" | "FIBONACCI" | "IMBALANCE" | "SNR_TOUCH" | "RSI" | "MACD" | "MTF" | "NEWS" | "RISK" | "VOLUME" | "PATTERN";
  passed: boolean;
  valueDescription: string;
  weightBonus: string;
}

export interface ZrillV5CoreAnalysis {
  version: string;
  confluenceScore: number; // 0 - 10
  confluenceRating: "SUPER KUAT" | "KUAT" | "MODERAT" | "TUNGGU";
  ratingBadgeColor: "emerald" | "amber" | "rose";
  ratingLabel: string; // e.g. "🟢 SUPER KUAT"
  winRateEstimatePct: number | null; // null until calibrated out-of-sample
  signalType: "BUY NOW" | "SELL NOW" | "BUY LIMIT" | "SELL LIMIT" | "WAITING";
  trendDirection: "UPTREND" | "DOWNTREND" | "RAGU";
  trendLabel: string; // e.g. "🟢 UPTREND"
  newsLabel: string; // e.g. "✅ Aman" | "⏳ Menunggu" | "🔴 Hindari"
  fibLevelSelected: string; // e.g. "0.618" or "2.618"

  fibonacci: {
    zone2618_Sniper: number;
    zone0618_Retest: number;
    zone0786_Deep: number;
    zone1618_Extension: number;
    isUntouchedArea: boolean;
    untouchedMultiplierActive: boolean; // Win rate 2x
    statusDescription: string;
  };

  emaFilter: {
    ema50: number;
    ema200: number;
    currentPrice: number;
    trendState: "UPTREND_KUAT" | "DOWNTREND_KUAT" | "RAGU_SIDEWAY";
    allowedDirection: "BUY_ONLY" | "SELL_ONLY" | "WAIT";
    crossStatus: "GOLDEN_CROSS" | "DEATH_CROSS" | "PARALLEL_EXPANSION" | "NEUTRAL";
    isPriceTouchingEma50InFibZone: boolean;
    snrStackedZone: boolean;
  };

  marketStructure: {
    mssShift: "BULLISH_SHIFT" | "BEARISH_SHIFT" | "NO_SHIFT";
    fvgPriceMagnet: string;
    orderBlockOrigin: string;
    keyLevelConfluence: string;
    isStructureAligned: boolean;
  };

  momentum: {
    adxValue: number;
    adxRegime: "STRONG_TREND" | "WEAK_TREND" | "SIDEWAY"; // >25 strong, 15-25 weak, <15 sideway
    adxActionGuidance: "BUY_NOW_SELL_NOW" | "LIMIT_ORDER_WAIT_RETEST" | "NO_SIGNAL";
    rsi14: number;
    rsiStatus: "HEALTHY_BUY" | "HEALTHY_SELL" | "OVERBOUGHT" | "OVERSOLD" | "NEUTRAL";
    rsiDivergenceDetected: boolean;
    macdLine: number;
    macdSignal: number;
    macdHistogram: number;
    macdDirectionAligned: boolean;
    momentumOverallPassed: boolean;
  };

  volatilityRisk: {
    atr14: number;
    dynamicSlPips: number;
    bollingerBandwidth: number;
    bollingerTouch: "UPPER_TOUCH" | "LOWER_TOUCH" | "MID_RIDING" | "SQUEEZE";
    riskRewardRatio: string;
    rrRatioValue: number;
    isMinRRMet: boolean; // >= 1:2
  };

  usdNewsFilter: {
    source: "TradingView Economic Calendar";
    nearestUsdEventTitle: string;
    impactLevel: "HIGH" | "MEDIUM" | "LOW" | "NONE";
    minutesToEvent: number;
    newsStatusBadge: "Aman" | "Menunggu" | "Hindari";
    actionRule: string;
    lotReductionRecommended: boolean;
  };

  multiTimeframe: {
    h4Trend: "UPTREND" | "DOWNTREND" | "SIDEWAY";
    h1Trend: "UPTREND" | "DOWNTREND" | "SIDEWAY";
    m15Trigger: "UPTREND" | "DOWNTREND" | "SIDEWAY";
    allAligned: boolean;
    alignmentPct: number;
  };

  pillars: ZrillV5ConfluencePillar[];
  entryPrice: number;
  slPrice: number;
  tpPrice: number;
  tp1Price: number;
  tp2Price: number;
  tp3Price: number;
  slPipsDistance: number;
  recommendedLot: number;
  accountBalanceReference: number;
  riskPctReference: number;
  formattedOutputSignalText: string;
  reasonSummary: string;
  entryZoneType?: string;
  actionStatusText?: string;
  snrBounceCount?: number;
  snrStrengthLabel?: string;
  breakoutIndication?: string;
  candleVolSignal?: "VOLUME_CONTINUATION" | "VOLUME_REVERSAL" | "VOLUME_NORMAL" | "VOLUME_DRY";
  candleVolLabel?: string;
  candleVolDetail?: string;
  candleVolume?: {
    volumeSignal: string;
    volumeLabel: string;
    volumeDetail: string;
    rvol: number;
    lastCandleVol: number;
    avgCandleVol: number;
  };
}

export interface MathematicalModelEngine {
  fibGoldenPocket: {
    goldenRatioPhi: number;
    subGoldenRatio: number;
    oteEquilibriumLevel: number;
    deepDiscountLevel: number;
    extensionTarget1: number;
    extensionTarget2: number;
    extensionTarget3?: number;
    fib618Price: number;
    fib705Price: number;
    fib786Price: number;
    tp1FibExtPrice: number;
    tp2FibExtPrice: number;
    tp3FibExtPrice?: number;
  };
  expectedValueFormula: string;
  expectedValueResult: string;
  bayesProbabilityFormula?: string;
  bayesPosteriorProbability?: string;
  kellyCriterionFraction: string;
  gaussianZScore: number;
  volatilityAtrSigma: number;
  invalidationFormula: string;
  targetMathFormula: string;
  rrMathematicalScalingFormula?: string;
  shannonEntropyScore: number;
  institutionalDominanceIndex: string;
  mathematicalProof: string;
  quantitativeCalculations?: {
    meanPrice: number;
    standardDeviation: number;
    zScoreInterpretation: string;
    expectedGainLossRatio: string;
    probabilisticSharpeRatio: number;
    monteCarloSimulatedWinRate: string;
    volatilityRegime: string;
  };
}

export interface NeuralSynapseCable {
  id: string;
  name: string;
  sourceModule: string;
  targetModule: string;
  status: "SYNCHRONIZED_ACTIVE" | "SUB_MS_STREAMING";
  throughputLatency: string;
  dataPayloadSummary: string;
  concordanceScore: number;
  cableColor: string;
}

export interface UnifiedNeuralSynapseBus {
  busStatus: "100% HARDWIRED_SYNCHRONIZED" | "REALTIME_FIBER_MESH";
  totalCablesCount: number;
  globalLatencyMs: number;
  cables: NeuralSynapseCable[];
  systemEntropy: string;
  concordanceIndex: string;
  neuralHeartbeatHz: number;
}

export interface EngineInput {
  symbol: { id: string; name?: string };
  timeframe: { id: string; label?: string };
  tradingStyle: { id: string; label?: string };
  currentPrice: { bid: number; ask: number; updatedAt?: number };
  indicators: {
    ema20?: number;
    sma50?: number;
    sma200?: number;
    ema50?: number;
    ema200?: number;
    macd?: number;
    macdSignal?: number;
    macdHistogram?: number;
    adx?: number | { adx?: number; pdi?: number; mdi?: number; value?: number };
    plusDI?: number;
    minusDI?: number;
    bollingerBands?: {
      middle: number;
      upper: number;
      lower: number;
      bandwidth: number;
      isSqueeze?: boolean;
    };
    rsi?: number;
    atr?: number;
    stochK?: number;
    stochD?: number;
    smc?: {
      trend?: string;
      lastStruct?: string;
      fvg?: string;
      ob?: string;
      sweep?: string;
      bos?: string;
      choch?: string;
      sentiment?: { buy: number; sell: number };
    };
    smcDrawings?: any;
    supportResistance?: {
      support?: any;
      resistance?: any;
    };
    pattern?: string;
    rsiDivergence?: string;
  };
  htfData?: { 
    m15?: any;
    m30?: any;
    h1?: any; 
    h4?: any; 
    overall?: string;
    condition?: string;
  };
  ltfData?: { 
    m1?: any;
    m5?: any;
    overall?: string;
  };
  realtimeWitaClock?: {
    witaTimeStr?: string;
    witaDateStr?: string;
    activeSession?: string;
    isKillzone?: boolean;
    killzoneBadge?: string;
    marketStatus?: string;
    hours?: number;
    minutes?: number;
    seconds?: number;
  };
  economicEvents?: any[];
  isAutonomous?: boolean;
  recentCandles?: any[];
  activePositions?: any[];
  assetNewsIntelligence?: AssetNewsIntelligence;
}

export interface SignalConfluenceValidationRecord {
  id: string;
  symbol: string;
  timeframe: string;
  timestamp: number;
  passed: boolean;
  score: number;
  minRequired: number;
  winRate: number;
  signalType: string;
  status: "ACTIVE" | "WAITING";
  reasons: string[];
}

/**
 * Public signal API. The legacy presentation model is retained only as a compatibility
 * adapter for existing UI contracts; actionable fields are overwritten by the validated
 * OHLCV quantitative core. Evidence score is not a win-rate probability.
 */
export function generatePrecisionSignal(input: EngineInput): PrecisionSignalResult {
  const candles = (input.recentCandles || []).map((c: any) => ({
    time: Number(c.time ?? c.timestamp ?? c.t) < 1e12 ? Number(c.time ?? c.timestamp ?? c.t) * 1000 : Number(c.time ?? c.timestamp ?? c.t),
    open: Number(c.open ?? c.o), high: Number(c.high ?? c.h), low: Number(c.low ?? c.l),
    close: Number(c.close ?? c.c), volume: Number(c.volume ?? c.v),
  }));
  const quant = analyzeQuantitativeMarket({
    symbol: input.symbol.id, timeframe: input.timeframe.id,
    bid: input.currentPrice?.bid, ask: input.currentPrice?.ask, quoteTime: input.currentPrice?.updatedAt ?? 0, candles,
  });
  // Keep the existing component contract stable while making the actual decision
  // fail-closed and sourcing executable levels exclusively from validated OHLCV.
  const active = quant.status === "READY" && quant.side !== "WAIT";
  // Legacy engine contains hard-coded institutional/order-flow assumptions; do not execute it.
  const direction = quant.side === "BUY" ? 1 : quant.side === "SELL" ? -1 : 0;
  const entry = active ? quant.entry : 0;
  const stop = active ? quant.stop : 0;
  const [tp1, tp2, tp3] = active ? quant.targets : [0, 0, 0];
  const reasons = [...quant.reasons, ...quant.limitations];
  return {
    status: active ? "ACTIVE" : "WAITING",
    type: active ? (direction > 0 ? "BUY" : "SELL") : "WAIT RETEST",
    orderExecutionType: active ? (direction > 0 ? "BUY NOW" : "SELL NOW") : "WAIT RETEST",
    qualityGrade: active ? "QUANTITATIVE SETUP — UNCALIBRATED" : "WAIT — DATA/CONFIRMATION INSUFFICIENT",
    confidence: 0,
    evidenceScore: quant.evidenceScore,
    entry, entryZoneMin: active ? entry - quant.atr * 0.15 : 0, entryZoneMax: active ? entry + quant.atr * 0.15 : 0,
    safeZoneName: active ? "ATR + SWING VALIDATED ZONE" : "NO VALIDATED ENTRY",
    profitExpectancy: "Belum dikalibrasi; bukan estimasi profit atau win rate.",
    sl: stop, tp: tp3, tp1, tp2, tp3, rr: active ? "1:1.5 / 1:2 / 1:3 (matematis, bukan probabilitas tercapai)" : "N/A",
    rrType: "BALANCED", invalidationPrice: stop, breakevenPrice: active ? entry : 0,
    method: "ZRILL Quantitative Core v2 — OHLCV deterministic; no synthetic inputs",
    analysis: reasons.join(" "), formattedOutputSignalText: active
      ? `ZRILL QUANT ${quant.side}\n${input.symbol.id} ${input.timeframe.id}\nEntry: ${entry}\nSL: ${stop}\nTP1: ${tp1}\nTP2: ${tp2}\nTP3: ${tp3}\nEvidence score: ${quant.evidenceScore}/100 (bukan win probability)`
      : `ZRILL STATUS: WAIT\n${input.symbol.id} ${input.timeframe.id}\n${quant.reasons.join(" ")}\nTidak ada harga/target prediksi yang diterbitkan.`,
    actionStatusText: active ? "RULE CHECKS MET — INPUT PROVENANCE UNVERIFIED; NOT A GUARANTEE" : "WAIT — NO ACTIONABLE SIGNAL",
    category: "INTRADAY" as TradingRegime,
    supremeSignalMetrics: undefined,
    omnipresentMtfCertainty: undefined,
    liquidityEngineRadar: undefined,
    quantumOrderFlow: undefined,
    guaranteedRREngine: undefined,
    dynamicPositionCalculator: undefined,
    mathematicalModelEngine: undefined,
    unifiedNeuralSynapseBus: undefined,
    regimeAnalysis: undefined,
    trendIntelligence: undefined,
    reversalWarningIntelligence: undefined,
    reversalIntelligence: undefined,
    marketSentimentRadar: undefined,
    optimalRetestAdvisory: undefined,
    witaCalendarSync: undefined,
    mathematicalAreas: undefined,
    ruleValidationShield: undefined,
    entryThinkingChain: [],
    bestEntryZone: undefined,
    bestEntryZoneArchitecture: undefined,
    timeframeMatrix: {},
    realtimeMacroSMCFusion: undefined,
    confluenceChecks: [],
    reasoning: reasons, timestamp: Date.now(), symbol: input.symbol.id, timeframe: input.timeframe.id,
    autonomousTriggered: false,
    fundamentalIntelligence: {
      macroScore: 0, macroBias: "NEUTRAL_EXPANSION",
      fundamentalStrengtheningMultiplier: "DISABLED — NO VERIFIED MACRO FEED", isFundamentalAligned: false,
      alignmentLabel: "MACRO DATA UNAVAILABLE", fundamentalVerdict: "Tidak ada data makro terverifikasi pada input; tidak digunakan dalam keputusan.",
      keyCatalysts: {
        dxyCorrelation: { dxyValue: 0, dxyTrend: "CONSOLIDATING", impactOnAsset: "Unavailable", correlationWeight: 0 },
        treasuryYields: { yield10Y: 0, yieldTrend: "SIDEWAYS", realInterestRateImpact: "Unavailable" },
        fedMonetaryStance: { stance: "Unavailable", nextMeetingSentiment: "Unavailable", policyRateRange: "Unavailable" },
        inflationAndLabor: { cpiTrend: "Unavailable", nfpOutlook: "Unavailable", summary: "No verified macro feed supplied." },
        geopoliticalSafeHaven: { safeHavenDemand: "Unavailable", description: "No verified feed supplied." },
      }, fundamentalConfluencePillars: [],
    },
    executionLogic: { htfBias: "UNAVAILABLE", liquidityTrap: "UNAVAILABLE", ltfTrigger: "UNAVAILABLE", riskManagement: "UNAVAILABLE" },
    mtfHarmonized: false,
    mtfConcordance: { bias: "WAIT", scalpAlignment: "UNAVAILABLE", intradayAlignment: "UNAVAILABLE", swingAlignment: "UNAVAILABLE", concordanceRate: "UNAVAILABLE" },
  } as PrecisionSignalResult;
}

export const zrillConfluenceAuditLogs: SignalConfluenceValidationRecord[] = [];

export function getZrillConfluenceAuditLogs(): SignalConfluenceValidationRecord[] {
  return [...zrillConfluenceAuditLogs];
}

// Generate the complete suite of synchronized signals for all timeframes on a symbol
export function generateSynchronizedSignalSuite(input: EngineInput): Record<string, any> {
  // Only the timeframe whose actual OHLCV was supplied can be analyzed.
  // No other timeframe is synthesized or inferred from the same candle series.
  const result = generatePrecisionSignal(input);
  return { [input.timeframe.id]: result };
}
