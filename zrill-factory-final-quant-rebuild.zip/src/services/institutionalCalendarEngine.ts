/**
 * Economic calendar normalization and factual event classification.
 * No price forecast, spike probability, or empirical hit-rate is generated here.
 */

export type MacroCategory =
  | "INFLATION_CPI_PCE"
  | "LABOR_PAYROLLS_NFP"
  | "LABOR_UNEMPLOYMENT"
  | "LABOR_WAGES"
  | "CENTRAL_BANK_RATES"
  | "GROWTH_GDP_RETAIL"
  | "BUSINESS_PMI"
  | "SENTIMENT_HOUSING"
  | "GLOBAL_MACRO";

export interface MacroPillar {
  title: string;
  transmissionSummary: string;
  dxyMechanism: string;
  yield10yImpact: string;
  goldCorrelation: string;
  btcImpact: string;
}

export interface HistoricalPillar {
  winRateStat: string;
  sampleSize: string;
  avgVolatilityPips: number | null;
  empiricalPrecedent: string;
}

export interface SmcPillar {
  orderFlowTarget: string;
  liquiditySweepZone: string;
  fvgImbalanceArea: string;
  recommendedEntryTactic: string;
}

export interface RiskGuardPillar {
  invalidationLevelPips: number | null;
  invalidationRule: string;
  recommendedSl: string;
  recommendedTp1: string;
  recommendedTp2: string;
  riskRewardRatio: string;
}

export interface ScenarioPlaybook {
  hot: {
    condition: string;
    marketReaction: string;
    actionBias: "STRONG SELL" | "STRONG BUY" | "WAIT";
    expectedPips: string;
  };
  inline: {
    condition: string;
    marketReaction: string;
    actionBias: "BUY" | "SELL" | "NEUTRAL / WHIPSAW" | "WAIT";
    expectedPips: string;
  };
  soft: {
    condition: string;
    marketReaction: string;
    actionBias: "STRONG BUY" | "STRONG SELL" | "WAIT";
    expectedPips: string;
  };
}

export interface PeganganKuat {
  anchorGrade: string;
  anchorScore: number | null;
  macroPillar: MacroPillar;
  historicalPillar: HistoricalPillar;
  smcPillar: SmcPillar;
  riskGuardPillar: RiskGuardPillar;
  scenarioPlaybook: ScenarioPlaybook;
  institutionalConsensus: string;
}

export interface SpikePredictionData {
  spikeProbability: number | null;
  spikeLevel: string;
  spikeType: "HIGH_SPIKE" | "MEDIUM_SPIKE" | "LOW_SPIKE" | "UNAVAILABLE";
  estimatedPipsGold: string;
  estimatedPipsFx: string;
  estimatedPipsBtc: string;
  spikeDirectionBias: string;
  trapRiskLevel: string;
  liquiditySpreadRisk: string;
  peakVolatilityWindow: string;
  preReleaseStrategy: string;
  historicalAvgSpikePips: number | null;
  spikeVolatilityRank: string;
}

export interface UpgradedEconomicEvent {
  id: string;
  title: string;
  currency: string;
  country: string;
  date: string;
  importance: number; // 1 = High, 0 = Medium, -1 = Low
  forecast: string;
  previous: string;
  actual: string | null;
  estimatedActual: string;
  estimatedActualNum: number | null;
  predictedDeviation: string;
  a1LeakIntelligence: string;
  unit: string;
  source: string;
  status: "RELEASED" | "UPCOMING";
  isReleased: boolean;
  releasedLabel: string;
  deviation: number | null;
  macroCategory: MacroCategory;
  spikePrediction: SpikePredictionData;
  isPredictionCorrect: boolean | null;
  pipsGain: string;
  accuracyStatus: "TEPAT_SASARAN" | "TIDAK_TEPAT" | "MENUNGGU";
  verdictSummary: string;
  marketOutcome: {
    dxyEffect: "BEARISH_USD" | "BULLISH_USD" | "NEUTRAL_CHOP";
    goldImpact: "BUY" | "SELL" | "WAIT";
    recommendation: "STRONG BUY" | "BUY" | "STRONG SELL" | "SELL" | "WAIT";
    accuracyScore: number | null;
    summary: string;
  };
  prediction: {
    direction: "BUY" | "SELL" | "WAIT";
    biasStrength: "STRONG BUY (BREAKOUT)" | "BUY ON RETEST (DISCOUNT)" | "STRONG SELL (BREAKOUT)" | "SELL ON RALLY (PREMIUM)" | "WAIT";
    targetSymbol: string;
    confidence: number | null;
    peganganKuat: PeganganKuat;
    reasoning: string;
    fundamentalAspect: string;
    technicalConfluence: string;
    macroSentiment: string;
    statusLabel: string;
  };
}

/**
 * 1. Klasifikasi Mendalam Kategori Makro Ekonomi
 */
export function classifyIndicator(title: string, indicator: string = ""): {
  category: MacroCategory;
  higherIsBullishUSD: boolean;
  weightTier: 1 | 2 | 3;
} {
  const text = (title + " " + indicator).toLowerCase();

  // A. Inflasi & Indeks Harga (CPI, PPI, PCE) -> Nilai Tinggi = Inflasi Panas = The Fed Hawkish = USD Menguat / Gold Turun
  if (/cpi|consumer price|inflation|pce|core pce|personal consumption expenditures/i.test(text)) {
    return { category: "INFLATION_CPI_PCE", higherIsBullishUSD: true, weightTier: 1 };
  }
  if (/ppi|producer price|import price|export price/i.test(text)) {
    return { category: "INFLATION_CPI_PCE", higherIsBullishUSD: true, weightTier: 2 };
  }

  // B. Suku Bunga & Kebijakan Bank Sentral (FOMC, Fed Rate, Powell, ECB, BOE, BOJ)
  if (/fomc|federal funds|fed rate|interest rate|ecb rate|boe rate|boj rate|monetary policy|powell|lagarde/i.test(text)) {
    return { category: "CENTRAL_BANK_RATES", higherIsBullishUSD: true, weightTier: 1 };
  }

  // C. Ketenagakerjaan - Payrolls (NFP, ADP, JOLTS) -> Nilai Tinggi = Pekerjaan Bertambah = USD Menguat / Gold Turun
  if (/non-farm|nonfarm|nfp|payrolls|adp employment|jolts|job openings/i.test(text)) {
    return { category: "LABOR_PAYROLLS_NFP", higherIsBullishUSD: true, weightTier: 1 };
  }

  // D. Ketenagakerjaan - Tingkat Pengangguran & Klaim Pengangguran -> Nilai Tinggi = Tenaga Kerja Melemah = USD Melemah / Gold Naik
  if (/unemployment rate|jobless claim|initial claim|continuing claim|unemployed/i.test(text)) {
    return { category: "LABOR_UNEMPLOYMENT", higherIsBullishUSD: false, weightTier: 1 };
  }

  // E. Upah Tenaga Kerja (Average Hourly Earnings) -> Nilai Tinggi = Inflasi Upah = USD Menguat / Gold Turun
  if (/hourly earnings|wage growth|employment cost|unit labor/i.test(text)) {
    return { category: "LABOR_WAGES", higherIsBullishUSD: true, weightTier: 1 };
  }

  // F. Pertumbuhan Ekonomi & Konsumsi (GDP, Retail Sales, Durable Goods)
  if (/gdp|gross domestic product|retail sales|core retail/i.test(text)) {
    return { category: "GROWTH_GDP_RETAIL", higherIsBullishUSD: true, weightTier: 1 };
  }
  if (/durable goods|factory orders|wholesale trade/i.test(text)) {
    return { category: "GROWTH_GDP_RETAIL", higherIsBullishUSD: true, weightTier: 2 };
  }

  // G. Indeks Manufaktur & Jasa (ISM, PMI, S&P Global)
  if (/ism services|services pmi/i.test(text)) {
    return { category: "BUSINESS_PMI", higherIsBullishUSD: true, weightTier: 1 };
  }
  if (/ism manufacturing|manufacturing pmi|s&p global|chicago pmi|philly fed|empire state/i.test(text)) {
    return { category: "BUSINESS_PMI", higherIsBullishUSD: true, weightTier: 2 };
  }

  // H. Sentimen Konsumen & Pasar Perumahan (Michigan, Building Permits, Home Sales)
  if (/michigan|consumer sentiment|consumer confidence|inflation expectation/i.test(text)) {
    return { category: "SENTIMENT_HOUSING", higherIsBullishUSD: true, weightTier: 2 };
  }
  if (/building permits|housing starts|existing home|new home/i.test(text)) {
    return { category: "SENTIMENT_HOUSING", higherIsBullishUSD: true, weightTier: 3 };
  }

  // I. Default Global Macro
  return { category: "GLOBAL_MACRO", higherIsBullishUSD: true, weightTier: 2 };
}

/**
 * Normalize factual event fields; prediction fields remain unavailable until independently validated.
 */
export function buildComprehensiveEconomicEvent(item: any, nowMs: number = Date.now()): UpgradedEconomicEvent {
  const eventDate = new Date(item?.date);
  const validDate = Number.isFinite(eventDate.getTime());
  const hasActual = item?.actual !== null && item?.actual !== undefined && item?.actual !== "" && item?.actual !== "---";
  const hasForecast = item?.forecast !== null && item?.forecast !== undefined && item?.forecast !== "" && item?.forecast !== "---";
  const hasPrevious = item?.previous !== null && item?.previous !== undefined && item?.previous !== "" && item?.previous !== "---";
  const actual = hasActual && Number.isFinite(Number(String(item.actual).replace(/[^0-9.-]/g, ""))) ? String(item.actual) : null;
  const currency = String(item?.currency || (item?.country === "US" ? "USD" : "UNKNOWN"));
  const title = String(item?.title || item?.indicator || item?.event || "Economic Event");
  const id = String(item?.id || `${currency}_${title.replace(/[^a-z0-9]+/gi, "_")}_${validDate ? eventDate.getTime() : "unknown"}`);
  const isReleased = Boolean(actual !== null || (validDate && eventDate.getTime() <= nowMs));
  const category = classifyIndicator(title, item?.indicator || "").category;
  const unavailable = "UNAVAILABLE — NO CALIBRATED MODEL / VERIFIED FEED";
  const spikePrediction: SpikePredictionData = {
    spikeProbability: null, spikeLevel: "NOT CALIBRATED", spikeType: "UNAVAILABLE",
    estimatedPipsGold: "N/A", estimatedPipsFx: "N/A", estimatedPipsBtc: "N/A",
    spikeDirectionBias: "NO PREDICTION", trapRiskLevel: "MINIMAL", liquiditySpreadRisk: unavailable,
    peakVolatilityWindow: "N/A", preReleaseStrategy: unavailable, historicalAvgSpikePips: null, spikeVolatilityRank: "NOT CALIBRATED",
  };
  const peganganKuat = {
    anchorGrade: "UNAVAILABLE", anchorScore: null,
    macroPillar: { title: unavailable, transmissionSummary: unavailable, dxyMechanism: unavailable, yield10yImpact: unavailable, goldCorrelation: unavailable, btcImpact: unavailable },
    historicalPillar: { winRateStat: "N/A", sampleSize: "0", avgVolatilityPips: null, empiricalPrecedent: unavailable },
    smcPillar: { orderFlowTarget: unavailable, liquiditySweepZone: unavailable, fvgImbalanceArea: unavailable, recommendedEntryTactic: unavailable },
    riskGuardPillar: { invalidationLevelPips: null, invalidationRule: unavailable, recommendedSl: "N/A", recommendedTp1: "N/A", recommendedTp2: "N/A", riskRewardRatio: "N/A" },
    scenarioPlaybook: {
      hot: { condition: unavailable, marketReaction: unavailable, actionBias: "WAIT", expectedPips: "N/A" },
      inline: { condition: unavailable, marketReaction: unavailable, actionBias: "WAIT", expectedPips: "N/A" },
      soft: { condition: unavailable, marketReaction: unavailable, actionBias: "WAIT", expectedPips: "N/A" },
    }, institutionalConsensus: unavailable,
  } as unknown as PeganganKuat;
  return {
    id, title, currency, country: String(item?.country || currency), date: validDate ? eventDate.toISOString() : "",
    importance: item?.importance === 1 ? 1 : item?.importance === 0 ? 0 : -1,
    forecast: hasForecast ? String(item.forecast) : "N/A", previous: hasPrevious ? String(item.previous) : "N/A", actual,
    estimatedActual: "N/A", estimatedActualNum: null, predictedDeviation: "N/A",
    a1LeakIntelligence: unavailable, unit: String(item?.unit || ""), source: String(item?.source || "TradingView Economic Calendar"),
    status: isReleased ? "RELEASED" : "UPCOMING", isReleased, releasedLabel: actual !== null ? "ACTUAL TERSEDIA" : isReleased ? "ACTUAL TIDAK TERSEDIA" : "MENUNGGU RILIS",
    deviation: null, macroCategory: category, spikePrediction, isPredictionCorrect: null,
    pipsGain: "N/A", accuracyStatus: "MENUNGGU", verdictSummary: unavailable,
    marketOutcome: { dxyEffect: "NEUTRAL_CHOP", goldImpact: "WAIT", recommendation: "WAIT", accuracyScore: null, summary: unavailable },
    prediction: { direction: "WAIT", biasStrength: "WAIT", targetSymbol: "XAUUSD", confidence: null, peganganKuat,
      reasoning: unavailable, fundamentalAspect: unavailable, technicalConfluence: unavailable, macroSentiment: unavailable,
      statusLabel: "NO PREDICTION — WAIT FOR VERIFIED MODEL" },
  } as UpgradedEconomicEvent;
}
