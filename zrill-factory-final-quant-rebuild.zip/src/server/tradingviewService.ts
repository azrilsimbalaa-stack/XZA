import WebSocket from "ws";
import { randomBytes } from "node:crypto";

export interface TradingViewPrice {
  symbol: string;
  tradingviewSymbol: string;
  price: number;
  bid: number;
  ask: number;
  ch: number;
  chp: number;
  volume: number;
  high: number;
  low: number;
  open: number;
  updatedAt: number;
}

const SYMBOL_MAP: Record<string, string> = {
  "XAUUSD": "OANDA:XAUUSD",
  "BTCUSD": "COINBASE:BTCUSD",
  "BTCUSDT": "BINANCE:BTCUSDT",
  "EURUSD": "OANDA:EURUSD",
  "GBPUSD": "OANDA:GBPUSD",
  "USDJPY": "OANDA:USDJPY",
  "AUDUSD": "OANDA:AUDUSD",
  "ETHUSD": "BINANCE:ETHUSDT",
};

const ADDITIONAL_SYMBOLS: string[] = [];

const REVERSE_SYMBOL_MAP: Record<string, string> = {
  "OANDA:XAUUSD": "XAUUSD",
  "BINANCE:BTCUSDT": "BTCUSDT",
  "COINBASE:BTCUSD": "BTCUSD",
  "OANDA:EURUSD": "EURUSD",
  "OANDA:GBPUSD": "GBPUSD",
  "OANDA:USDJPY": "USDJPY",
  "OANDA:AUDUSD": "AUDUSD",
  "BINANCE:ETHUSDT": "ETHUSD",
};

const priceMap: Record<string, TradingViewPrice> = {};


function generateSession() {
  return "qs_" + randomBytes(12).toString("hex");
}

function constructMsg(func: string, params: any[]) {
  const jsonStr = JSON.stringify({ m: func, p: params });
  return `~m~${jsonStr.length}~m~${jsonStr}`;
}

let ws: WebSocket | null = null;
let session = "";
let heartbeatTimeout: NodeJS.Timeout | null = null;

export function initTradingViewEngine() {
  connect();
}

function connect() {
  try {
    session = generateSession();
    ws = new WebSocket("wss://data.tradingview.com/socket.io/websocket", {
      headers: { Origin: "https://data.tradingview.com" },
    });

    const resetHeartbeat = () => {
      if (heartbeatTimeout) clearTimeout(heartbeatTimeout);
      heartbeatTimeout = setTimeout(() => {
        console.warn("[TradingView Engine] Silent connection detected (30s timeout). Terminating to reconnect...");
        if (ws) {
          try {
            ws.terminate();
          } catch (e) {}
        }
      }, 30000);
    };

    resetHeartbeat();

    ws.on("open", () => {
      console.log("[TradingView Engine] Connected with session:", session);
      if (!ws) return;
      resetHeartbeat();
      ws.send(constructMsg("quote_create_session", [session]));
      ws.send(
        constructMsg("quote_set_fields", [
          session,
          "lp",
          "volume",
          "ch",
          "chp",
          "bid",
          "ask",
          "high_price",
          "low_price",
          "open_price",
        ])
      );

      const allSymbolsToSubscribe = Array.from(new Set([...Object.values(SYMBOL_MAP), ...ADDITIONAL_SYMBOLS]));
      for (const tvSym of allSymbolsToSubscribe) {
        ws.send(constructMsg("quote_add_symbols", [session, tvSym]));
      }
    });

    ws.on("message", (data: WebSocket.Data) => {
      const str = data.toString();
      resetHeartbeat();
      
      // Handle Pings
      const pingMatch = str.match(/~m~\d+~m~~h~(\d+)/);
      if (pingMatch) {
        const pingId = pingMatch[1];
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(`~m~${pingId.length}~m~~h~${pingId}`);
        }
        return;
      }

      // Handle Data Payload
      if (str.includes("qsd")) {
        // TradingView protocol uses ~m~LEN~m~MSG format. We split by this pattern to handle bundled messages
        const payloads = str.split(/~m~\d+~m~/);
        for (const rawPayload of payloads) {
          const payload = rawPayload.trim();
          if (!payload || !payload.startsWith("{") || !payload.endsWith("}")) {
            continue;
          }
          try {
            const parsed = JSON.parse(payload);
            if (parsed.m === "qsd" && parsed.p && parsed.p[1]) {
              const tvSymData = parsed.p[1];
              const tvSymbolName = tvSymData.n; // e.g. "OANDA:XAUUSD"
              const val = tvSymData.v || {};
              const internalSymbol = REVERSE_SYMBOL_MAP[tvSymbolName] || tvSymbolName;

              const existing = priceMap[internalSymbol] || {
                symbol: internalSymbol,
                tradingviewSymbol: tvSymbolName,
                price: 0,
                bid: 0,
                ask: 0,
                ch: 0,
                chp: 0,
                volume: 0,
                high: 0,
                low: 0,
                open: 0,
                updatedAt: Date.now(),
              };

              if (val.lp != null) existing.price = val.lp;
              if (val.bid != null) existing.bid = val.bid;
              if (val.ask != null) existing.ask = val.ask;
              if (val.ch != null) existing.ch = val.ch;
              if (val.chp != null) existing.chp = val.chp;
              if (val.volume != null) existing.volume = val.volume;
              if (val.high_price != null) existing.high = val.high_price;
              if (val.low_price != null) existing.low = val.low_price;
              if (val.open_price != null) existing.open = val.open_price;
              
              if (existing.price === 0 && existing.bid > 0) existing.price = existing.bid;

              existing.updatedAt = Date.now();
              priceMap[internalSymbol] = existing;
            }
          } catch (e) {
            // Ignore parse errors for individual malformed sub-frames
          }
        }
      }
    });

    ws.on("error", (err) => {
      console.error("[TradingView Engine] WS Error:", err.message);
    });

    ws.on("close", () => {
      console.warn("[TradingView Engine] WS Closed. Reconnecting in 3s...");
      setTimeout(connect, 3000);
    });
  } catch (err) {
    console.error("[TradingView Engine] Connection error:", err);
    setTimeout(connect, 5000);
  }
}

export function getTradingViewPrice(symbol: string): TradingViewPrice | null {
  const cleanSym = symbol.toUpperCase().replace("=X", "").replace("-USD", "");
  const cached = priceMap[cleanSym];
  if (!cached || !Number.isFinite(cached.price) || cached.price <= 0) return null;
  // Do not present stale websocket ticks as live market data.
  const maxAgeMs = 30_000;
  if (!Number.isFinite(cached.updatedAt) || Date.now() - cached.updatedAt > maxAgeMs) return null;
  return cached;
}

export function getAllTradingViewPrices(): Record<string, TradingViewPrice> {
  const now = Date.now();
  return Object.fromEntries(Object.entries(priceMap).filter(([, quote]) =>
    Number.isFinite(quote.updatedAt) && now - quote.updatedAt <= 30_000 && Number.isFinite(quote.price) && quote.price > 0
  ));
}
