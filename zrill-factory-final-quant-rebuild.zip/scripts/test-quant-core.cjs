const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');

const sourcePath = path.join(__dirname, '../src/services/quantitativeCoreV2.ts');
const source = fs.readFileSync(sourcePath, 'utf8');
const compiled = ts.transpile(source, { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS });
const mod = new Module(sourcePath, module);
mod.filename = sourcePath;
mod.paths = module.paths;
mod._compile(compiled, sourcePath);
const { analyzeQuantitativeMarket } = mod.exports;
const now = Date.now();

function makeCandles({ trend = 0.08, amplitude = 0.8, stale = false } = {}) {
  const rows = [];
  for (let i = 0; i < 150; i++) {
    const close = 100 + i * trend + amplitude * Math.sin(i * Math.PI / 4);
    const open = i === 0 ? close - trend : rows[i - 1].close;
    const high = Math.max(open, close) + 0.15;
    const low = Math.min(open, close) - 0.15;
    rows.push({ time: now - (149 - i) * 60_000 - (stale ? 3_600_000 : 0), open, high, low, close, volume: 100 + i });
  }
  return rows;
}
const candles = makeCandles();
const input = { symbol: 'TEST', timeframe: '1m', quoteTime: now, bid: candles.at(-1).close - 0.01, ask: candles.at(-1).close + 0.01, candles, now };
const ready = analyzeQuantitativeMarket(input);
assert.equal(ready.status, 'READY', `Expected valid trending sample; got ${ready.reasons.join('; ')}`);
assert.ok(['BUY', 'SELL'].includes(ready.side));
assert.ok(ready.stop > 0 && ready.targets.every(Number.isFinite));
assert.equal(ready.evidenceScore > 100, false);

const stale = analyzeQuantitativeMarket({ ...input, candles: makeCandles({ stale: true }) });
assert.equal(stale.status, 'WAIT');
assert.equal(stale.data.stale, true);

const malformed = candles.map((c) => ({ ...c }));
malformed[149].high = 1;
assert.equal(analyzeQuantitativeMarket({ ...input, candles: malformed }).status, 'WAIT');

assert.equal(analyzeQuantitativeMarket({ ...input, candles: candles.slice(0, 40) }).status, 'WAIT');
assert.equal(analyzeQuantitativeMarket({ ...input, ask: input.bid - 1 }).status, 'WAIT');
assert.equal(analyzeQuantitativeMarket({ ...input, quoteTime: now - 60_000 }).status, 'WAIT');
assert.equal(analyzeQuantitativeMarket({ ...input, quoteTime: undefined }).status, 'WAIT');
assert.equal(analyzeQuantitativeMarket({ ...input, quoteTime: now + 60_000 }).status, 'WAIT');
const futureBars = candles.map((c) => ({ ...c })); futureBars[149].time = now + 60_000;
assert.equal(analyzeQuantitativeMarket({ ...input, candles: futureBars }).status, 'WAIT');

console.log('Quantitative core tests passed: valid OHLCV, stale feed, malformed candle, insufficient history, invalid quote.');

function loadTsModule(relativePath) {
  const filePath = path.join(__dirname, '..', relativePath);
  const code = ts.transpile(fs.readFileSync(filePath, 'utf8'), { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS });
  const loaded = new Module(filePath, module);
  loaded.filename = filePath;
  loaded.paths = module.paths;
  loaded._compile(code, filePath);
  return loaded.exports;
}
const calendar = loadTsModule('src/services/institutionalCalendarEngine.ts');
const event = calendar.buildComprehensiveEconomicEvent({
  id: 'test-event', title: 'Consumer Price Index', currency: 'USD', country: 'US',
  date: new Date(now + 86_400_000).toISOString(), importance: 1,
  forecast: '2.5', previous: '2.6', actual: null, source: 'TEST_FIXTURE',
}, now);
assert.equal(event.prediction.direction, 'WAIT');
assert.equal(event.prediction.confidence, null);
assert.equal(event.spikePrediction.spikeProbability, null);
assert.equal(event.estimatedActual, 'N/A');
assert.equal(event.pipsGain, 'N/A');
const releasedEvent = calendar.buildComprehensiveEconomicEvent({ ...{ id: 'released-test', title: 'Employment Change', currency: 'USD', country: 'US', date: new Date(now - 60_000).toISOString(), importance: 1, forecast: '10', previous: '8', actual: '12', source: 'TEST_FIXTURE' } }, now);
assert.equal(releasedEvent.isReleased, true);
assert.equal(releasedEvent.isPredictionCorrect, null);
assert.equal(releasedEvent.accuracyStatus, 'MENUNGGU');
assert.equal(releasedEvent.prediction.direction, 'WAIT');
const pastNoActual = calendar.buildComprehensiveEconomicEvent({ id: 'past-no-actual', title: 'CPI', currency: 'USD', country: 'US', date: new Date(now - 60_000).toISOString(), importance: 1, forecast: '2', previous: '2', actual: null }, now);
assert.equal(pastNoActual.isReleased, true);
assert.equal(pastNoActual.actual, null);
assert.equal(pastNoActual.releasedLabel, 'ACTUAL TIDAK TERSEDIA');

const news = loadTsModule('src/services/assetNewsIntelligenceService.ts');
const newsResult = news.computeAssetNewsIntelligence('XAUUSD', []);
assert.equal(newsResult.totalArticles, 0);
assert.equal(newsResult.sentimentScore, 0);
assert.equal(newsResult.confluenceConfidenceBoost, 0);
assert.equal(newsResult.dominantBias, 'NEUTRAL');
assert.equal(newsResult.volatilityRegime, 'UNAVAILABLE');

const macro = loadTsModule('src/services/realtimeFundamentalStreamEngine.ts');
const pulse = macro.computeRealtimeMacroPulse('XAUUSD');
assert.equal(pulse.isLiveStreaming, false);
assert.equal(pulse.fundamentalBiasScore, 0);
assert.equal(macro.computeRealtimeMacroSMCFusion({ symbol: { id: 'XAUUSD' }, currentPrice: 0 }), null);

console.log('No-fabrication tests passed: calendar predictions disabled, empty news neutral, macro feed unavailable, fusion disabled.');
