# ZRILL Quantitative Core v2 — Catatan Rebuild

## Arsitektur

`quantitativeCoreV2.ts` adalah core deterministik OHLCV. Mesin tidak mengambil keputusan dari data statis. Ia menerima OHLCV + bid/ask, memvalidasi integritas struktural dan freshness, lalu menghitung indikator.

## Aturan keputusan

- Minimal 100 candle valid.
- Bid/ask wajib disertai `quoteTime`; quote lebih tua dari 30 detik atau timestamp yang terlalu jauh di masa depan ditolak.
- Kalkulator risiko tidak mengasumsikan ukuran kontrak universal atau kurs USD/IDR statis. Lot memerlukan contract value dari broker; akun IDR memerlukan kurs aktual bertimestamp.
- EMA20/EMA50 menentukan arah tren.
- RSI14 membatasi momentum (BUY 52–72; SELL 28–48).
- Harga harus berada di sisi EMA20 sesuai arah.
- Spread relatif harus <= 0.25% dari mid-price.
- Jika salah satu syarat gagal, output `WAIT`.

## Level dan skor

- BUY entry menggunakan ask; SELL entry menggunakan bid.
- ATR14 + swing 10-bar digunakan untuk stop.
- Target skenario: 1.5R, 2R, 3R.
- Evidence score adalah penjumlahan aturan berbobot sederhana; bukan probabilitas menang dan belum dikalibrasi.

## API

`POST /api/quant/analyze` menerima `symbol`, `timeframe`, `bid`, `ask`, `quoteTime`, `candles`. Candle dapat berbentuk array `[time, open, high, low, close, volume]` atau objek OHLCV. Endpoint memberi label `CLIENT_SUPPLIED_OHLCV_UNVERIFIED` karena server tidak dapat membuktikan asal data yang dikirim klien.

## Batasan

Model ini belum memasukkan order book, macro/news, korelasi aset, biaya transaksi, slippage, atau model prediksi yang dilatih. Output WAIT/BUY/SELL adalah hasil aturan teknikal, bukan jaminan hasil. Validasi historis dan forward test masih diperlukan. Halaman utama saat ini adalah kalender ekonomi; endpoint kuantitatif belum terhubung ke pemilih chart/quote pada UI karena UI diminta tetap.

Candle sintetis pada `scripts/test-quant-core.cjs` adalah fixture pengujian saja dan tidak digunakan di runtime produksi.
