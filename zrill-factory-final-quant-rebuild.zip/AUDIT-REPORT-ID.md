# Laporan Audit Final ZRILL Factory

Tanggal: 11 November 2026

## Ringkasan

Rebuild berfokus pada menghilangkan data statis yang tampil seperti data live, menonaktifkan prediksi yang tidak punya dasar statistik, membatasi feed ke instrumen yang benar-benar cocok, dan membuat mesin analisis gagal-aman.

UI tidak didesain ulang dan stylesheet tidak diganti. Perubahan visual hanya berupa state/konten jujur seperti `N/A`, `WAIT`, dan pemberitahuan feed belum tersedia.

## Perbaikan utama

### 1. Market data
- Menghapus fallback harga/candle sintetis dan pengisian volume kosong dengan angka `100` atau `0`.
- Tidak lagi menimpa candle Binance/Coinbase/Yahoo dengan tick TradingView dari venue berbeda.
- Tidak menganggap PAXGUSDT atau GC futures sebagai XAUUSD spot.
- BTCUSD menggunakan Coinbase BTC-USD; BTCUSDT menggunakan Binance BTCUSDT. Tidak ada substitusi diam-diam di antara keduanya.
- Quote TradingView yang stale lebih dari 30 detik tidak dikirim sebagai quote live.
- Bid/ask tidak lagi disalin dari last price jika feed bid/ask kosong.
- Endpoint OHLCV mengembalikan error jika provider tidak memberi bar valid yang cukup.

### 2. Quantitative Core v2
File: `src/services/quantitativeCoreV2.ts`
- Menghitung EMA20/EMA50, RSI14, ATR14, realized volatility 30-bar, spread, dan breakout 19 bar dari candle yang diterima.
- Memvalidasi minimal 100 candle, OHLC, volume, timestamp, urutan candle, bid/ask, freshness candle, dan timestamp quote.
- Quote wajib memiliki timestamp dan harus berumur <= 30 detik; quote stale/missing/future menghasilkan WAIT.
- BUY/SELL hanya jika tren, momentum, dan spread memenuhi aturan; selain itu `WAIT`.
- Entry menggunakan ask untuk BUY dan bid untuk SELL.
- Stop berbasis ATR dan swing lokal; target skenario 1.5R/2R/3R.
- Skor bukti tidak diklaim sebagai win probability.
- Timestamp quote wajib ada dan quote berumur lebih dari 30 detik ditolak.
- Kalkulator risiko tidak lagi memakai konversi USD/IDR statis atau asumsi kontrak lot XAU/BTC/Forex universal. Lot hanya dihitung bila contract value broker diberikan; akun IDR memerlukan kurs USD/IDR bertimestamp yang masih fresh.
- Data yang dikirim klien tetap ditandai asal-usulnya belum diverifikasi independen.

### 3. Kalender ekonomi
- Menghapus proyeksi actual AI dari angka forecast/previous.
- Menghapus angka probabilitas spike 38/74/95/98%, estimasi pips, klaim 100% bullseye, dan default +180 pips.
- Arah prediksi menjadi `WAIT`, confidence 0, dan spike probability null sampai ada model terkalibrasi.
- Statistik hit-rate tidak dihitung dari kejutan angka makro. Kalender ekonomi bukan hasil transaksi.
- Event tanpa nilai actual tidak dianggap sebagai prediksi yang menang/kalah.

### 4. News, macro, SMC, DRL
- Knowledgebase berita hard-coded dikosongkan; tidak ada headline lama yang ditampilkan sebagai berita terbaru.
- Macro stream sintetis, tick berbasis waktu, latency acak, ETF flow, DXY, yield, dan confidence palsu dinonaktifkan.
- Fusion macro/SMC mengembalikan unavailable sampai sumber data nyata tersedia.
- DRL overlay menampilkan unavailable ketika tidak ada keluaran model tervalidasi.
- Radar AS/bank tidak lagi memiliki default posisi bank, kutipan pejabat, atau angka makro buatan.

### 5. Panel analisis lama
- Probability score pola chart diset `null` sampai ada kalibrasi historis.
- Timeline AMD/PO3 sintetis dinonaktifkan.
- Supreme dashboard tidak menampilkan matriks MTF, order-flow, atau confidence palsu saat metrik terverifikasi tidak ada.
- Risk calculator menolak membuat level entry/SL/TP jika tidak ada sinyal aktif yang valid; expected value/win probability tidak diklaim.
- Synchronized signal suite tidak lagi menyintesis timeframe lain dari satu seri candle.

### 6. Server & keamanan
- Endpoint TradingView MCP tidak lagi mengaku `ACTIVE` atau menyatakan tool berhasil dieksekusi ketika connector/CDP tidak ada.
- Membership/admin override tetap ditolak sampai autentikasi tepercaya dikonfigurasi.
- Firestore rules menjadi default-deny karena aplikasi ini belum mengimplementasikan identitas dan ownership per pengguna.
- Parameter simbol/rate divalidasi dan di-encode sebelum dipakai dalam URL provider.

## Pengujian yang berhasil

- `npm run test:quant`: lulus.
  - OHLCV valid dan setup terdeteksi.
  - Data stale menghasilkan WAIT.
  - Candle rusak menghasilkan WAIT.
  - Riwayat kurang dari 100 bar menghasilkan WAIT.
  - Quote invalid menghasilkan WAIT.
  - Kalender tidak mengarang actual/prediksi/spike/pips.
  - News kosong menghasilkan neutral/unavailable, bukan bullish default.
  - Macro feed dan fusion tidak mengklaim live saat provider tidak ada.
- TypeScript syntax transpilation pada file yang diubah: 0 syntax errors.
- Type-check semantik tidak melaporkan error kode internal pada audit terbatas setelah mengabaikan missing-module diagnostics.

## Yang belum dapat dinyatakan lulus

**Production build belum berhasil diverifikasi.** Lingkungan audit tidak memiliki instalasi dependency lengkap: `npm ci` timeout, lalu `npm run build` gagal karena `vite: not found`. Karena itu tidak ada klaim bahwa build produksi atau runtime sudah lulus.

**Akurasi prediksi belum terbukti.** Belum ada:
- data historis bersih dengan sumber/venue/timestamp yang dapat diaudit;
- walk-forward validation dan out-of-sample test;
- backtest yang memasukkan spread, komisi, slippage, swap/funding, dan latency;
- kalibrasi probabilitas, reliability diagram, Brier score, atau confidence interval;
- paper-trading forward test.

Feed berita, DXY, US10Y, ETF/central-bank flows, order book institusional, serta DRL tidak diklaim aktif karena provider/pipeline-nya belum dikonfigurasi.

Halaman utama `src/App.tsx` adalah kalender ekonomi, bukan chart trading. Endpoint kuantitatif sudah tersedia, tetapi tidak disambungkan ke UI karena tidak ada input chart/quote yang dapat dipakai tanpa mengubah UI. Data OHLCV yang dikirim ke endpoint tetap ditandai belum diverifikasi asal-usulnya. Candle sintetis hanya dipakai sebagai fixture tes dan tidak digunakan di runtime.

## Langkah verifikasi di mesin pengguna

```bash
npm ci
npm run test:quant
npm run build
npm run dev
```

Jika `npm ci` dan `npm run build` berhasil, uji endpoint `/api/klines`, `/api/yahoo/klines`, `/api/tradingview/price`, `/api/calendar`, dan `/api/quant/analyze` dengan sumber data aktual. Jangan gunakan output sebagai bukti edge sampai seluruh rangkaian validasi out-of-sample selesai.
