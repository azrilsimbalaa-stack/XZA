import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import cors from "cors";
import {
  initTradingViewEngine,
  getTradingViewPrice,
  getAllTradingViewPrices,
} from "./src/server/tradingviewService.js";
import {
  buildComprehensiveEconomicEvent,
} from "./src/services/institutionalCalendarEngine.js";
import { analyzeQuantitativeMarket } from "./src/services/quantitativeCoreV2.js";

async function startServer() {
  const app = express();
  const PORT = 3000;
  
  app.use(cors({ origin: process.env.ALLOWED_ORIGIN ? process.env.ALLOWED_ORIGIN.split(",") : false }));
  app.use(express.json({ limit: "256kb" }));

  // Initialize Real-Time TradingView WebSocket Engine (from cloned repository module)
  initTradingViewEngine();

  // Real-Time TradingView Prices Endpoint
  app.get("/api/binance-time", async (req, res) => {
    try {
      const response = await fetch("https://api.binance.com/api/v3/time");
      const data = await response.json();
      res.json(data);
    } catch (e) {
      console.error(e);
      res.status(500).json({ error: "Failed to fetch Binance time" });
    }
  });

  app.get("/api/tradingview/prices", (req, res) => {
    const prices = getAllTradingViewPrices();
    res.json({
      prices,
      connected: Object.keys(prices).length > 0,
      source: Object.keys(prices).length > 0 ? "TRADINGVIEW_WEBSOCKET" : null,
      timestamp: Date.now(),
    });
  });

  // MCP is not connected to a browser/CDP session in this deployment. Report that honestly.
  app.get("/api/mcp/status", (_req, res) => {
    res.status(503).json({ status: "NOT_CONFIGURED", connected: false, availableToolGroups: [], timestamp: Date.now() });
  });
  app.get("/api/mcp/tools", (_req, res) => res.status(503).json({ tools: [], status: "NOT_CONFIGURED" }));
  app.post("/api/mcp/execute", (_req, res) => res.status(501).json({
    success: false, status: "NOT_IMPLEMENTED", error: "TradingView MCP browser/CDP connector is not configured. No tool was executed."
  }));

  // Real-Time TradingView Price Single Symbol Endpoint
  app.get("/api/tradingview/price", (req, res) => {
    const rawSymbol = (req.query.symbol as string) || "XAUUSD";
    const tvPrice = getTradingViewPrice(rawSymbol);
    if (tvPrice && tvPrice.price > 0) {
      return res.json({
        symbol: rawSymbol,
        price: tvPrice.price,
        bid: tvPrice.bid,
        ask: tvPrice.ask,
        ch: tvPrice.ch,
        chp: tvPrice.chp,
        volume: tvPrice.volume,
        high: tvPrice.high,
        low: tvPrice.low,
        open: tvPrice.open,
        source: "TRADINGVIEW_WEBSOCKET",
        updatedAt: tvPrice.updatedAt,
      });
    }
    res.status(404).json({ error: "TradingView symbol price connecting...", symbol: rawSymbol });
  });

  // Strict OHLCV provider: never blend venues, never invent volume, never alias spot gold to futures/tokenized gold.
  app.get("/api/klines", async (req, res) => {
    const symbol = String(req.query.symbol || "").trim().toUpperCase();
    const interval = String(req.query.interval || "1m");
    const allowedIntervals = new Set(["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w", "1M"]);
    const parsedLimit = Number(req.query.limit ?? 150);
    const limit = Number.isInteger(parsedLimit) ? Math.max(100, Math.min(1000, parsedLimit)) : 150;
    if (!symbol || !/^[A-Z0-9._-]{2,24}$/.test(symbol) || !allowedIntervals.has(interval)) {
      return res.status(400).json({ error: "Invalid symbol or interval", source: null, simulated: false });
    }
    // XAUUSD spot is not equivalent to PAXGUSDT or GC futures. Do not silently substitute.
    if (["XAUUSD", "GOLD", "XAUUSD=X"].includes(symbol)) {
      return res.status(503).json({ error: "No verified XAUUSD spot OHLCV provider configured. Futures/tokenized gold are not substituted.", symbol, source: null, simulated: false });
    }
    try {
      const isBtcUsd = symbol === "BTCUSD";
      // BTCUSD and BTCUSDT are distinct instruments; never silently substitute USDT for USD.
      const binanceResponse = isBtcUsd ? null : await fetch(
        `https://api.binance.com/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}&limit=${limit}`,
        { signal: AbortSignal.timeout(5000) }
      );
      if (binanceResponse?.ok) {
        const rows: any = await binanceResponse.json();
        if (Array.isArray(rows) && rows.length >= 2 && rows.every((r:any) => Array.isArray(r) && r.length >= 6 && r.slice(0,6).every((v:any)=>Number.isFinite(Number(v))))) {
          res.setHeader("Cache-Control", "no-store");
          res.setHeader("X-Data-Source", "Binance Spot");
          return res.json(rows);
        }
      }
      // Venue fallback only for BTCUSD: return Coinbase's own bars without patching Binance/TradingView ticks.
      if (isBtcUsd && ["1m", "5m", "15m", "1h", "4h", "1d"].includes(interval)) {
        const granularity: Record<string,number> = { "1m":60, "5m":300, "15m":900, "1h":3600, "4h":14400, "1d":86400 };
        const cb = await fetch(`https://api.exchange.coinbase.com/products/BTC-USD/candles?granularity=${granularity[interval]}`, { signal: AbortSignal.timeout(5000) });
        if (cb.ok) {
          const data:any = await cb.json();
          if (Array.isArray(data) && data.length >= 2) {
            const formatted = data.slice().reverse().slice(-limit).map((c:any)=>[Number(c[0])*1000, Number(c[3]), Number(c[2]), Number(c[1]), Number(c[4]), Number(c[5])]);
            if (formatted.every((r:number[])=>r.every(Number.isFinite))) {
              res.setHeader("Cache-Control", "no-store");
              res.setHeader("X-Data-Source", "Coinbase Exchange BTC-USD");
              return res.json(formatted);
            }
          }
        }
      }
      return res.status(503).json({ error: "No verified OHLCV feed available for this instrument", symbol, interval, source: null, simulated: false });
    } catch (error:any) {
      return res.status(503).json({ error: "OHLCV provider unavailable", detail: error?.message || "provider error", symbol, interval, source: null, simulated: false });
    }
  });

  app.get("/api/yahoo/klines", async (req, res) => {
    try {
      const symbol = String(req.query.symbol || "XAUUSD=X");
      let interval = String(req.query.interval || "1m");
      if (!/^[A-Z0-9=^._-]{2,24}$/i.test(symbol)) return res.status(400).json({ error: "Invalid symbol" });
      if (!["1m", "5m", "15m", "30m", "1h", "4h", "1d"].includes(interval)) return res.status(400).json({ error: "Unsupported interval" });
      
      // Map Yahoo intervals & ranges
      let range = "1d";
      let yahooInterval = interval;
      let is4h = false;
      
      switch (interval) {
        case "1m": range = "1d"; yahooInterval = "1m"; break;
        case "5m": range = "5d"; yahooInterval = "5m"; break;
        case "15m": range = "5d"; yahooInterval = "15m"; break;
        case "30m": range = "1mo"; yahooInterval = "30m"; break;
        case "1h": range = "1mo"; yahooInterval = "60m"; break;
        case "4h": range = "3mo"; yahooInterval = "60m"; is4h = true; break;
        case "1d": range = "1y"; yahooInterval = "1d"; break;
        default: range = "1mo"; yahooInterval = "60m";
      }

      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${encodeURIComponent(yahooInterval)}&range=${range}`;
      const yahooRes = await fetch(url, { signal: AbortSignal.timeout(4000) });
      const data = await yahooRes.json();
      
      const timestamps = data.chart?.result?.[0]?.timestamp || [];
      const quote = data.chart?.result?.[0]?.indicators?.quote?.[0] || {};
      
      let formattedData = timestamps.map((t: number, i: number) => {
        const values = [quote.open?.[i], quote.high?.[i], quote.low?.[i], quote.close?.[i], quote.volume?.[i]];
        if (!values.every((value:any) => value !== null && value !== undefined && Number.isFinite(Number(value)))) return null;
        return [t * 1000, ...values.map((value:any) => String(value))];
      }).filter((d: any) => d !== null && d.every((v:any)=>v !== null));

      if (is4h) {
        const h4Map = new Map<number, any>();
        for (const item of formattedData) {
          const tSec = Math.floor(item[0] / 1000);
          const h4Sec = Math.floor(tSec / 14400) * 14400;
          const h4Ms = h4Sec * 1000;

          const open = parseFloat(item[1]);
          const high = parseFloat(item[2]);
          const low = parseFloat(item[3]);
          const close = parseFloat(item[4]);
          const vol = parseFloat(item[5]);

          if (!h4Map.has(h4Ms)) {
            h4Map.set(h4Ms, [h4Ms, item[1], item[2], item[3], item[4], item[5]]);
          } else {
            const existing = h4Map.get(h4Ms);
            existing[2] = Math.max(parseFloat(existing[2]), high).toString();
            existing[3] = Math.min(parseFloat(existing[3]), low).toString();
            existing[4] = item[4];
            existing[5] = (parseFloat(existing[5]) + vol).toString();
          }
        }
        formattedData = Array.from(h4Map.values());
      }
      
      const rawLimit = Number(req.query.limit || 1000);
      const limit = Number.isInteger(rawLimit) ? Math.max(2, Math.min(1000, rawLimit)) : 1000;
      const limitedData = formattedData.slice(-limit);
      if (limitedData.length < 2) return res.status(503).json({ error: "Insufficient verified Yahoo OHLCV", source: null, simulated: false });
      res.setHeader("Cache-Control", "no-store");
      res.json(limitedData);
    } catch (e) {
      console.warn("Yahoo klines fetch error:", e);
      res.status(503).json({ error: "Yahoo OHLCV unavailable", source: null, simulated: false });
    }
  });

  app.get("/api/yahoo/price", async (req, res) => {
    try {
      const symbol = String(req.query.symbol || "XAUUSD=X");
      if (!/^[A-Z0-9=^._-]{2,24}$/i.test(symbol)) return res.status(400).json({ error: "Invalid symbol" });
      const cleanSym = symbol.replace("=X", "").replace("-USD", "");

      // Check TradingView Live WebSocket cache first
      const tvPrice = getTradingViewPrice(cleanSym);
      if (tvPrice && tvPrice.price > 0) {
        return res.json({
          price: tvPrice.price,
          bid: tvPrice.bid,
          ask: tvPrice.ask,
          symbol,
          source: "TRADINGVIEW_WEBSOCKET",
        });
      }

      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=1m&range=1d`;
      const yahooRes = await fetch(url, { signal: AbortSignal.timeout(3000) });
      const data = await yahooRes.json();
      
      const result = data.chart?.result?.[0];
      const meta = result?.meta;
      const price = meta?.regularMarketPrice;
      
      if (!Number.isFinite(price) || price <= 0) return res.status(503).json({ error: "Yahoo price unavailable", symbol, source: null, simulated: false });
      res.json({ price, symbol, source: "YAHOO" });
    } catch (e) {
      console.warn("Yahoo price fetch error:", e);
      res.status(503).json({ error: "Price provider unavailable", symbol: (req.query.symbol as string) || "XAUUSD=X", source: null, simulated: false });
    }
  });

  app.get("/api/live-rates", async (req, res) => {
    try {
      const rate = String(req.query.rate || "XAUUSD");
      if (!/^[A-Z0-9._-]{2,24}$/i.test(rate)) return res.status(400).json({ error: "Invalid rate symbol" });
      const url = `https://www.live-rates.com/api/price?rate=${encodeURIComponent(rate)}`;
      const apiRes = await fetch(url, { signal: AbortSignal.timeout(3000) });
      const data = await apiRes.json();
      res.json(data);
    } catch (e) {
      console.warn("Live Rates fetch error:", e);
      res.status(503).json({ error: "Rate provider unavailable", rate: req.query.rate || "XAUUSD", source: null, simulated: false });
    }
  });

  // Deterministic quantitative endpoint. It only analyzes caller-supplied, validated market data.
  const quantitativeAnalyzeHandler = (req: express.Request, res: express.Response) => {
    const body = req.body || {};
    const symbol = String(body.symbol || "").trim().toUpperCase();
    const timeframe = String(body.timeframe || "").trim();
    const bid = Number(body.bid);
    const ask = Number(body.ask);
    const quoteTimeRaw = Number(body.quoteTime);
    const quoteTime = quoteTimeRaw < 1e12 ? quoteTimeRaw * 1000 : quoteTimeRaw;
    const rawCandles = body.candles;
    if (!symbol || !timeframe || !Array.isArray(rawCandles) || rawCandles.length < 100 ||
        !Number.isFinite(bid) || !Number.isFinite(ask) || bid <= 0 || ask < bid || !Number.isFinite(quoteTime) || quoteTime <= 0) {
      return res.status(422).json({
        status: "INSUFFICIENT_VERIFIED_DATA", signal: "WAIT", evidenceScore: 0,
        error: "Dibutuhkan symbol, timeframe, bid/ask aktual dengan quoteTime, dan minimal 100 candle OHLCV valid.",
        simulated: false, source: null,
      });
    }
    const candles = rawCandles.map((row: any) => {
      if (Array.isArray(row)) return { time: Number(row[0]), open: Number(row[1]), high: Number(row[2]), low: Number(row[3]), close: Number(row[4]), volume: Number(row[5]) };
      return { time: Number(row.time ?? row.timestamp), open: Number(row.open ?? row.o), high: Number(row.high ?? row.h), low: Number(row.low ?? row.l), close: Number(row.close ?? row.c), volume: Number(row.volume ?? row.v) };
    }).map((c:any) => ({ ...c, time: c.time < 1e12 ? c.time * 1000 : c.time }));
    const result = analyzeQuantitativeMarket({ symbol, timeframe, bid, ask, quoteTime, candles });
    const accepted = result.status === "READY" && result.side !== "WAIT";
    return res.status(accepted ? 200 : 422).json({
      ...result,
      signal: result.side,
      source: "CLIENT_SUPPLIED_OHLCV_UNVERIFIED",
      provenanceVerified: false,
      simulated: "UNKNOWN",
      generatedAt: Date.now(),
      disclaimer: "Evidence score bukan probabilitas menang. Hasil belum terkalibrasi sampai tersedia backtest walk-forward dan out-of-sample.",
    });
  };
  app.post("/api/quant/analyze", quantitativeAnalyzeHandler);
  app.post("/api/ai/analyze", quantitativeAnalyzeHandler);

  // In-memory cache for TradingView economic calendar
  let calendarCache: { data: any[]; timestamp: number } = { data: [], timestamp: 0 };

  app.get("/api/calendar", async (req, res) => {
    try {
      const now = new Date();
      const CACHE_TTL_MS = 8000; // 8 seconds cache for instant real-time updates

      if (calendarCache.data.length > 0 && Date.now() - calendarCache.timestamp < CACHE_TTL_MS) {
        return res.json({
          result: calendarCache.data,
          source: "TradingView Economic Calendar (Live Cache)",
          timestamp: calendarCache.timestamp,
          serverTimeIso: now.toISOString(),
          summary: {
            total: calendarCache.data.length,
            released: calendarCache.data.filter(e => e.isReleased).length,
            upcoming: calendarCache.data.filter(e => !e.isReleased).length,
            highImpact: calendarCache.data.filter(e => e.importance === 1).length,
            accurateCount: null,
            inaccurateCount: null,
            accuracyRate: null
          }
        });
      }

      // Fetch official live economic calendar events strictly for United States (USD only)
      const from = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
      const to = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
      const tvUrl = `https://economic-calendar.tradingview.com/events?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&countries=US`;

      let rawEvents: any[] = [];
      try {
        const tvRes = await fetch(tvUrl, {
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Origin": "https://www.tradingview.com",
            "Referer": "https://www.tradingview.com/"
          },
          signal: AbortSignal.timeout(3000)
        });
        if (tvRes.ok) {
          const tvData = await tvRes.json();
          if (tvData.result && Array.isArray(tvData.result)) {
            // Strictly USD only
            rawEvents = tvData.result.filter((item: any) => {
              const cur = String(item.currency || item.country || "").toUpperCase();
              return cur === "USD" || cur === "US";
            });
          }
        }
      } catch (fetchErr) {
        // No synthetic fallback: return unavailable when the provider fails.
      }

      const events: any[] = [];

      if (rawEvents.length > 0) {
        rawEvents.forEach((item) => {
          events.push(buildComprehensiveEconomicEvent(item, now.getTime()));
        });
      }

      if (events.length === 0) {
        return res.status(503).json({
          result: [],
          status: "LIVE_CALENDAR_UNAVAILABLE",
          source: null,
          simulated: false,
          timestamp: Date.now(),
        });
      }

      // Sort chronological: past released events first, then upcoming by closest date
      events.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

      // Save to cache
      calendarCache = { data: events, timestamp: Date.now() };

      res.json({
        result: events,
        source: "TradingView Economic Calendar (Live)",
        timestamp: Date.now(),
        serverTimeIso: now.toISOString(),
        summary: {
          total: events.length,
          released: events.filter(e => e.isReleased).length,
          upcoming: events.filter(e => !e.isReleased).length,
          highImpact: events.filter(e => e.importance === 1).length,
          accurateCount: null,
          inaccurateCount: null,
          accuracyRate: null
        }
      });
    } catch (err) {
      console.error("Calendar API Error:", err);
      res.status(503).json({ result: [], status: "LIVE_CALENDAR_UNAVAILABLE", source: null, simulated: false, timestamp: Date.now() });
    }
  });

  // Real-time Financial News & Macro Intelligence API
  app.get("/api/news/realtime", async (_req, res) => {
    return res.status(503).json({
      status: "LIVE_NEWS_PROVIDER_NOT_CONFIGURED",
      articles: [],
      macroIndicators: null,
      institutionalFlows: null,
      predictions: null,
      source: null,
      simulated: false,
      message: "Feed berita/makro belum memiliki sumber data yang dapat diverifikasi.",
    });
  });

  app.post("/api/auth/verify-membership", (_req, res) => {
    return res.status(503).json({
      error: "Verifikasi membership belum terhubung ke backend pembayaran/identitas yang tepercaya.",
      status: "AUTH_PROVIDER_NOT_CONFIGURED",
    });
  });

  app.post("/api/override", (_req, res) => {
    return res.status(503).json({
      error: "Override statis dinonaktifkan. Konfigurasikan autentikasi admin berbasis secret server dan role.",
      status: "ADMIN_AUTH_NOT_CONFIGURED",
    });
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
