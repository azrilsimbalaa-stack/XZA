# ZRILL Factory — Quantitative Core Rebuild

UI React dan stylesheet dipertahankan. Rebuild ini berfokus pada integritas data, mesin analisis, API, dan penghilangan klaim yang tidak didukung bukti.

## Menjalankan proyek

Prasyarat: Node.js 20+.

```bash
npm ci
npm run test:quant
npm run build
npm run dev
```

`npm run test:quant` menjalankan pengujian deterministik core kuantitatif dan pemeriksaan agar kalender/news/makro tidak mengarang output.

## Endpoint utama

- `GET /api/klines?symbol=BTCUSD&interval=1m&limit=150` — OHLCV dari Coinbase BTC-USD untuk simbol BTCUSD.
- `GET /api/klines?symbol=BTCUSDT&interval=1m&limit=150` — OHLCV Binance Spot BTCUSDT; tidak disamakan dengan BTCUSD.
- `GET /api/yahoo/klines?symbol=XAUUSD%3DX&interval=5m&limit=150` — mencoba feed Yahoo untuk simbol yang diminta; respons ditolak jika OHLCV/volume tidak lengkap.
- `GET /api/tradingview/price?symbol=XAUUSD` — quote TradingView WebSocket yang masih fresh.
- `POST /api/quant/analyze` — analisis candle OHLCV yang dikirim klien. Asal data input klien dinyatakan **belum diverifikasi independen**. Body wajib memuat `symbol`, `timeframe`, `bid`, `ask`, `quoteTime` (Unix ms atau s), dan `candles` minimal 100 bar.

Format body: `candles` adalah array minimal 100 bar dengan urutan `[time, open, high, low, close, volume]`; `quoteTime` dan waktu candle boleh Unix seconds atau milliseconds. Semua angka harus berasal dari feed yang benar-benar Anda ambil. Endpoint memvalidasi struktur dan freshness, tetapi tidak dapat membuktikan keaslian data yang dikirim browser.
## Prinsip integritas

- Tidak ada harga fallback, volume buatan, candle sintetis, macro tick buatan, berita hard-coded, probabilitas kemenangan rekaan, atau hasil backtest palsu.
- XAUUSD spot tidak otomatis diganti PAXG atau GC futures.
- BTCUSD dan BTCUSDT diperlakukan sebagai instrumen berbeda; feed tidak dicampur.
- Jika feed tidak ada, rusak, kedaluwarsa, atau tidak lengkap, hasilnya `WAIT` / `503`.
- Evidence score adalah skor aturan, bukan probabilitas menang.
- Endpoint kuantitatif tersedia, tetapi halaman `src/App.tsx` saat ini merupakan kalender ekonomi dan belum memiliki chart/quote selector yang mengirim OHLCV ke endpoint tersebut. Integrasi visual sengaja tidak ditambahkan agar layout UI tetap.
- Candle sintetis hanya dipakai sebagai fixture dalam `scripts/test-quant-core.cjs`, tidak dimuat oleh aplikasi produksi.
- Firestore dikunci default-deny sampai model autentikasi dan kepemilikan data per pengguna benar-benar tersedia.

Lihat `AUDIT-REPORT-ID.md` dan `QUANT-REBUILD-NOTES-ID.md` untuk ruang lingkup, batasan, dan hasil verifikasi.
