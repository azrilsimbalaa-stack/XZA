# XZA Kalender — Biquote feed

Kalender ekonomi mengambil data dari `https://biquote.io/api/calendar?limit=500`. Forex Factory tidak digunakan sebagai sumber utama maupun fallback kalender. Data dinormalisasi di server agar tetap kompatibel dengan antarmuka React/TypeScript yang ada.

## Streaming

- `GET /api/calendar/stream`: Server-Sent Events (SSE), mengirim data awal lalu pembaruan kalender dari cache Biquote.
- Server menyegarkan feed Biquote setiap 10 detik.
- `GET /api/calendar?currency=ALL` menampilkan semua mata uang; contoh `?currency=USD` untuk USD saja.
- `POST /api/calendar/scrape-forexfactory` masih dipertahankan sebagai alias kompatibilitas UI lama, tetapi sekarang hanya menyegarkan Biquote.
- Jika Biquote gagal diakses, server mempertahankan cache terakhir yang valid; tidak berpindah ke Forex Factory.

## Catatan migrasi

Antarmuka tetap TypeScript sesuai kebutuhan. Backend utama aplikasi pada arsip ini masih `server.ts`; migrasi seluruh backend dan business engine ke C++ belum dilakukan dalam paket ini.
