import importlib.util
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "backtest_ohlc.py"
spec = importlib.util.spec_from_file_location("backtest_ohlc", SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class OhlcBacktestTests(unittest.TestCase):
    def test_normalizes_and_sorts_candles(self):
        bars = [
            {"time": 2, "open": 11, "high": 13, "low": 10, "close": 12},
            {"time": 1, "open": 10, "high": 12, "low": 9, "close": 11},
        ]
        normalized = module.normalize_bars(bars)
        self.assertEqual([bar["time"] for bar in normalized], [1, 2])

    def test_drops_impossible_candles(self):
        bars = [
            {"time": 1, "open": 10, "high": 9, "low": 8, "close": 9},
            {"time": 2, "open": 10, "high": 12, "low": 9, "close": 11},
        ]
        self.assertEqual(len(module.normalize_bars(bars)), 1)

    def test_backtest_returns_metrics_without_lookahead(self):
        bars = []
        price = 100.0
        for i in range(80):
            price += 1.0 if i < 40 else -0.8
            bars.append({"time": i + 1, "open": price, "high": price + 1,
                         "low": price - 1, "close": price, "volume": 10})
        result = module.backtest(bars, fast_period=5, slow_period=12)
        self.assertIn("trades", result)
        self.assertIn("max_drawdown_pct", result)
        self.assertGreaterEqual(result["trades"], 0)


if __name__ == "__main__":
    unittest.main()
