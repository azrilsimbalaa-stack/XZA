import json
import pathlib
import shutil
import subprocess
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SOURCE = ROOT / "native" / "ohlc_engine.cpp"


@unittest.skipUnless(shutil.which("g++"), "g++ compiler not installed")
class CppOhlcEngineTests(unittest.TestCase):
    def test_analyzes_valid_ohlc_and_rejects_invalid_rows(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            binary = pathlib.Path(temp_dir) / "ohlc_engine"
            compile_result = subprocess.run(
                ["g++", "-std=c++17", "-O2", str(SOURCE), "-o", str(binary)],
                capture_output=True, text=True, check=False,
            )
            self.assertEqual(compile_result.returncode, 0, compile_result.stderr)
            csv_data = (
                "time,open,high,low,close,volume\n"
                "2,101,104,100,103,6\n"
                "1,100,102,99,101,5\n"
                "3,105,104,102,103,7\n"
                "3,103,105,102,104,7\n"
            )
            run = subprocess.run([str(binary)], input=csv_data, text=True,
                                 capture_output=True, check=False)
            self.assertEqual(run.returncode, 0, run.stderr)
            result = json.loads(run.stdout)
            self.assertTrue(result["ok"])
            self.assertEqual(result["validCandles"], 3)
            self.assertEqual(result["lastTime"], 3)
            self.assertIn(result["trend"], {"BULLISH", "BEARISH", "NEUTRAL"})


if __name__ == "__main__":
    unittest.main()
