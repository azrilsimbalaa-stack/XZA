#!/usr/bin/env python3
"""Simple OHLC moving-average backtest with next-bar execution (no same-bar lookahead)."""
import argparse
import csv
import json
import math
from pathlib import Path


def _number(value):
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except (TypeError, ValueError):
        return None


def normalize_bars(bars):
    by_time = {}
    for raw in bars:
        try:
            time = int(float(raw.get("time", raw.get("timestamp", raw.get("openTime")))))
            o, h, low, c = (_number(raw.get(k)) for k in ("open", "high", "low", "close"))
            volume = _number(raw.get("volume", 0)) or 0.0
        except (TypeError, ValueError):
            continue
        if time > 10**12:
            time //= 1000
        if time <= 0 or None in (o, h, low, c) or min(o, h, low, c) <= 0:
            continue
        if h < max(o, c) or low > min(o, c) or h < low:
            continue
        by_time[time] = {"time": time, "open": o, "high": h, "low": low, "close": c, "volume": volume}
    return [by_time[t] for t in sorted(by_time)]


def _sma(values, period, end):
    start = end - period + 1
    if start < 0:
        return None
    return sum(values[start:end + 1]) / period


def backtest(bars, fast_period=10, slow_period=30, fee_bps=5.0, slippage_bps=2.0):
    bars = normalize_bars(bars)
    if fast_period < 1 or slow_period <= fast_period:
        raise ValueError("slow_period harus lebih besar dari fast_period")
    if len(bars) <= slow_period + 1:
        return {"bars": len(bars), "trades": 0, "win_rate_pct": 0.0, "net_return_pct": 0.0,
                "max_drawdown_pct": 0.0, "profit_factor": 0.0, "note": "Data tidak cukup untuk periode MA"}
    closes = [b["close"] for b in bars]
    cost = (fee_bps + slippage_bps) / 10000.0
    position = 0
    entry = 0.0
    equity = 1.0
    peak = 1.0
    max_dd = 0.0
    trade_returns = []
    previous_fast = previous_slow = None

    # At bar i, calculate using data through i-1; enter/exit at bar i open.
    for i in range(slow_period, len(bars)):
        fast = _sma(closes, fast_period, i - 1)
        slow = _sma(closes, slow_period, i - 1)
        if fast is None or slow is None:
            continue
        signal = 1 if fast > slow else -1 if fast < slow else 0
        if position and signal != position:
            exit_price = bars[i]["open"] * (1 - position * cost)
            ret = position * (exit_price / entry - 1.0)
            equity *= max(0.0, 1.0 + ret)
            trade_returns.append(ret)
            position = 0
        if not position and signal:
            position = signal
            entry = bars[i]["open"] * (1 + position * cost)
        previous_fast, previous_slow = fast, slow
        peak = max(peak, equity)
        if peak > 0:
            max_dd = max(max_dd, (peak - equity) / peak)

    if position:
        exit_price = bars[-1]["close"] * (1 - position * cost)
        ret = position * (exit_price / entry - 1.0)
        equity *= max(0.0, 1.0 + ret)
        trade_returns.append(ret)
    wins = sum(1 for r in trade_returns if r > 0)
    gross_profit = sum(r for r in trade_returns if r > 0)
    gross_loss = abs(sum(r for r in trade_returns if r < 0))
    return {
        "bars": len(bars),
        "trades": len(trade_returns),
        "win_rate_pct": round(100.0 * wins / len(trade_returns), 2) if trade_returns else 0.0,
        "net_return_pct": round((equity - 1.0) * 100.0, 4),
        "max_drawdown_pct": round(max_dd * 100.0, 4),
        "profit_factor": round(gross_profit / gross_loss, 4) if gross_loss else (None if gross_profit else 0.0),
        "fast_period": fast_period,
        "slow_period": slow_period,
        "fees_bps_per_side": fee_bps,
        "slippage_bps_per_side": slippage_bps,
        "execution": "next bar open; fees and slippage included",
    }


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    return normalize_bars(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", help="CSV with time,open,high,low,close[,volume]")
    parser.add_argument("--fast", type=int, default=10)
    parser.add_argument("--slow", type=int, default=30)
    parser.add_argument("--fee-bps", type=float, default=5.0)
    parser.add_argument("--slippage-bps", type=float, default=2.0)
    args = parser.parse_args()
    result = backtest(read_csv(args.csv), args.fast, args.slow, args.fee_bps, args.slippage_bps)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
