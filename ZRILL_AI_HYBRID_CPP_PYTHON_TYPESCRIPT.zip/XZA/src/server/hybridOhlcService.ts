import { existsSync } from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";
import { normalizeOHLC, type OHLCBar } from "../services/ohlcIntegrity.js";

export interface HybridOhlcAnalysis {
  ok: boolean;
  validCandles: number;
  lastTime?: number;
  lastClose?: number;
  atr14?: number;
  ema20?: number;
  ema50?: number;
  momentumPct?: number;
  rangeHigh?: number;
  rangeLow?: number;
  trend?: "BULLISH" | "BEARISH" | "NEUTRAL";
  momentum?: "BULLISH" | "BEARISH" | "NEUTRAL";
  engine: "cpp" | "typescript";
  warning?: string;
  error?: string;
}

function ema(values: number[], period: number): number {
  const alpha = 2 / (period + 1);
  let value = values[0];
  for (let i = 1; i < values.length; i++) value = alpha * values[i] + (1 - alpha) * value;
  return value;
}

function analyzeInTypeScript(bars: OHLCBar[]): HybridOhlcAnalysis {
  if (bars.length < 2) return { ok: false, validCandles: bars.length, engine: "typescript", error: "Minimal 2 candle OHLC valid diperlukan" };
  const closes = bars.map((bar) => bar.close);
  const trueRanges = bars.slice(1).map((bar, index) => {
    const previousClose = bars[index].close;
    return Math.max(bar.high - bar.low, Math.abs(bar.high - previousClose), Math.abs(bar.low - previousClose));
  });
  const atrValues = trueRanges.slice(-14);
  const atr14 = atrValues.reduce((sum, value) => sum + value, 0) / atrValues.length;
  const ema20 = ema(closes.slice(-Math.min(closes.length, 60)), 20);
  const ema50 = ema(closes.slice(-Math.min(closes.length, 150)), 50);
  const start = Math.max(0, closes.length - 6);
  const momentumPct = (closes[closes.length - 1] / closes[start] - 1) * 100;
  const structureBars = bars.slice(-20);
  const rangeHigh = Math.max(...structureBars.map((bar) => bar.high));
  const rangeLow = Math.min(...structureBars.map((bar) => bar.low));
  const lastClose = closes[closes.length - 1];
  const trend = lastClose > ema20 && ema20 > ema50 ? "BULLISH" : lastClose < ema20 && ema20 < ema50 ? "BEARISH" : "NEUTRAL";
  const momentum = momentumPct > 0.05 ? "BULLISH" : momentumPct < -0.05 ? "BEARISH" : "NEUTRAL";
  return { ok: true, validCandles: bars.length, lastTime: bars[bars.length - 1].time, lastClose, atr14, ema20, ema50, momentumPct, rangeHigh, rangeLow, trend, momentum, engine: "typescript" };
}

function toCsv(bars: OHLCBar[]): string {
  return ["time,open,high,low,close,volume", ...bars.map((bar) =>
    [bar.time, bar.open, bar.high, bar.low, bar.close, bar.volume ?? 0].join(","),
  )].join("\n") + "\n";
}

async function analyzeWithCpp(binaryPath: string, bars: OHLCBar[]): Promise<HybridOhlcAnalysis> {
  return new Promise((resolve, reject) => {
    const child = spawn(binaryPath, [], { stdio: ["pipe", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    child.stdout.setEncoding("utf8").on("data", (chunk: string) => { stdout += chunk; });
    child.stderr.setEncoding("utf8").on("data", (chunk: string) => { stderr += chunk; });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code !== 0) return reject(new Error(stderr || `C++ engine exited with code ${code}`));
      try {
        const parsed = JSON.parse(stdout) as Omit<HybridOhlcAnalysis, "engine">;
        resolve({ ...parsed, engine: "cpp" });
      } catch {
        reject(new Error("C++ engine returned invalid JSON"));
      }
    });
    child.stdin.end(toCsv(bars));
  });
}

export async function analyzeOhlcHybrid(input: readonly unknown[]): Promise<HybridOhlcAnalysis> {
  const bars = normalizeOHLC(input);
  const fallback = () => analyzeInTypeScript(bars);
  const binaryPath = path.resolve(process.cwd(), "native", process.platform === "win32" ? "ohlc_engine.exe" : "ohlc_engine");
  if (!existsSync(binaryPath)) {
    return { ...fallback(), warning: "C++ binary belum dikompilasi; memakai fallback TypeScript." };
  }
  try {
    return await analyzeWithCpp(binaryPath, bars);
  } catch (error) {
    return { ...fallback(), warning: `C++ engine gagal; fallback TypeScript digunakan (${error instanceof Error ? error.message : "unknown error"}).` };
  }
}
