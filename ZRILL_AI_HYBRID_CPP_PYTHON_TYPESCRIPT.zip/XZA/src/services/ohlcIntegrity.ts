/**
 * Shared OHLC integrity gate.
 * Keeps only real, internally consistent bars; normalizes numeric API payloads,
 * sorts by candle time, and removes duplicate timestamps before analysis.
 */
export interface OHLCBar {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export function normalizeOHLC(
  input: readonly unknown[] | null | undefined,
): OHLCBar[] {
  if (!Array.isArray(input) || input.length === 0) return [];

  const byTime = new Map<number, OHLCBar>();
  for (const raw of input) {
    if (!raw || typeof raw !== "object") continue;
    // Binance REST klines are positional arrays: [openTime, open, high, low, close, volume, ...].
    const item: Record<string, unknown> = Array.isArray(raw)
      ? { openTime: raw[0], open: raw[1], high: raw[2], low: raw[3], close: raw[4], volume: raw[5] }
      : raw as Record<string, unknown>;
    const timeRaw = item.time ?? item.timestamp ?? item.openTime;
    const timeValue = typeof timeRaw === "string" ? Number(timeRaw) : timeRaw;
    const time = typeof timeValue === "number" && Number.isFinite(timeValue)
      ? (timeValue > 1e12 ? Math.floor(timeValue / 1000) : Math.floor(timeValue))
      : NaN;
    const numeric = (value: unknown) => typeof value === "number" ? value
      : typeof value === "string" && value.trim() !== "" ? Number(value) : NaN;
    const open = numeric(item.open);
    const high = numeric(item.high);
    const low = numeric(item.low);
    const close = numeric(item.close);
    const volumeRaw = numeric(item.volume);
    if (![time, open, high, low, close].every(Number.isFinite)) continue;
    if (time <= 0 || open <= 0 || high <= 0 || low <= 0 || close <= 0) continue;
    if (high < low || high < Math.max(open, close) || low > Math.min(open, close)) continue;

    const bar: OHLCBar = {
      ...item,
      time,
      open,
      high,
      low,
      close,
      ...(Number.isFinite(volumeRaw) && volumeRaw >= 0 ? { volume: volumeRaw } : {}),
    };
    byTime.set(time, bar);
  }

  return [...byTime.values()].sort((a, b) => a.time - b.time);
}
