#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

struct Candle {
  long long time{};
  double open{}, high{}, low{}, close{}, volume{};
};

static bool parseLine(const std::string& line, Candle& c) {
  std::stringstream ss(line);
  std::string cell;
  std::vector<std::string> fields;
  while (std::getline(ss, cell, ',')) fields.push_back(cell);
  if (fields.size() < 5) return false;
  try {
    c.time = std::stoll(fields[0]);
    c.open = std::stod(fields[1]);
    c.high = std::stod(fields[2]);
    c.low = std::stod(fields[3]);
    c.close = std::stod(fields[4]);
    c.volume = fields.size() > 5 ? std::stod(fields[5]) : 0.0;
  } catch (...) { return false; }
  return c.time > 0 && c.open > 0 && c.high >= std::max(c.open, c.close) &&
         c.low <= std::min(c.open, c.close) && c.low > 0 && c.high >= c.low &&
         std::isfinite(c.open) && std::isfinite(c.high) &&
         std::isfinite(c.low) && std::isfinite(c.close);
}

static double ema(const std::vector<Candle>& bars, std::size_t period, std::size_t end) {
  if (end >= bars.size() || period == 0) return 0.0;
  const std::size_t start = end + 1 > period * 3 ? end + 1 - period * 3 : 0;
  const double alpha = 2.0 / (static_cast<double>(period) + 1.0);
  double value = bars[start].close;
  for (std::size_t i = start + 1; i <= end; ++i)
    value = alpha * bars[i].close + (1.0 - alpha) * value;
  return value;
}

int main() {
  std::vector<Candle> bars;
  std::string line;
  while (std::getline(std::cin, line)) {
    if (line.empty() || line.rfind("time,", 0) == 0 || line.rfind("timestamp,", 0) == 0) continue;
    Candle c;
    if (parseLine(line, c)) bars.push_back(c);
  }
  std::stable_sort(bars.begin(), bars.end(), [](const Candle& a, const Candle& b) { return a.time < b.time; });
  bars.erase(std::unique(bars.begin(), bars.end(), [](const Candle& a, const Candle& b) { return a.time == b.time; }), bars.end());

  if (bars.size() < 2) {
    std::cout << "{\"ok\":false,\"error\":\"Minimal 2 candle OHLC valid diperlukan\",\"validCandles\":" << bars.size() << "}\n";
    return 0;
  }

  double trSum = 0.0;
  const std::size_t atrN = std::min<std::size_t>(14, bars.size() - 1);
  for (std::size_t i = bars.size() - atrN; i < bars.size(); ++i) {
    const double prevClose = bars[i - 1].close;
    const double tr = std::max({bars[i].high - bars[i].low,
      std::abs(bars[i].high - prevClose), std::abs(bars[i].low - prevClose)});
    trSum += tr;
  }
  const double atr = trSum / static_cast<double>(atrN);
  const double ema20 = ema(bars, 20, bars.size() - 1);
  const double ema50 = ema(bars, 50, bars.size() - 1);
  const std::size_t momentumStart = bars.size() > 6 ? bars.size() - 6 : 0;
  const double momentumPct = bars[momentumStart].close != 0.0
      ? (bars.back().close / bars[momentumStart].close - 1.0) * 100.0 : 0.0;
  const std::size_t structureStart = bars.size() > 20 ? bars.size() - 20 : 0;
  double rangeHigh = bars[structureStart].high, rangeLow = bars[structureStart].low;
  for (std::size_t i = structureStart; i < bars.size(); ++i) {
    rangeHigh = std::max(rangeHigh, bars[i].high);
    rangeLow = std::min(rangeLow, bars[i].low);
  }
  std::string trend = "NEUTRAL";
  if (bars.back().close > ema20 && ema20 > ema50) trend = "BULLISH";
  else if (bars.back().close < ema20 && ema20 < ema50) trend = "BEARISH";
  std::string momentum = momentumPct > 0.05 ? "BULLISH" : momentumPct < -0.05 ? "BEARISH" : "NEUTRAL";

  std::cout << std::fixed << std::setprecision(8)
    << "{\"ok\":true,\"validCandles\":" << bars.size()
    << ",\"lastTime\":" << bars.back().time
    << ",\"lastClose\":" << bars.back().close
    << ",\"atr14\":" << atr
    << ",\"ema20\":" << ema20
    << ",\"ema50\":" << ema50
    << ",\"momentumPct\":" << momentumPct
    << ",\"rangeHigh\":" << rangeHigh
    << ",\"rangeLow\":" << rangeLow
    << ",\"trend\":\"" << trend << "\",\"momentum\":\"" << momentum << "\"}\n";
  return 0;
}
