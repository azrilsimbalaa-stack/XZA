# XZA patch notes

## What changed
- Added `src/services/ohlcIntegrity.ts` as a shared OHLC validation layer.
- Normalizes numeric-string OHLC values and Binance positional kline arrays.
- Rejects malformed candles (non-finite/non-positive prices, impossible high/low ranges), sorts candles chronologically, and de-duplicates timestamps.
- Applied OHLC validation before SMC liquidity/sweep/displacement/MSS/OB/FVG analysis, classic chart-pattern detection, and precision-signal analysis.
- Softened interaction transitions and added reduced-motion support in `src/index.css`.

## Calendar protection
`src/services/institutionalCalendarEngine.ts` was not modified. Calendar-related code in `src/App.tsx` was not modified.

## Validation note
A full TypeScript build could not be completed in this environment because project dependencies (React, Express, Vite, etc.) are not installed. The TypeScript command reports missing dependency modules; this is an environment limitation, not a verified successful build.

## Multi-language OHLC analysis foundation (TypeScript + C++ + Python)

- TypeScript remains the application and API layer.
- `POST /api/analysis/ohlc` accepts `{ "candles": [...] }` and returns validated OHLC metrics.
- `native/ohlc_engine.cpp` computes ATR, EMA20/EMA50, short momentum, and recent range. Compile it with `npm run build:cpp`. The compiled executable is optional and intentionally not shipped; when absent or failing, the server falls back to the TypeScript implementation.
- `scripts/backtest_ohlc.py` runs a simple moving-average historical backtest from CSV with next-bar-open execution, fees, and slippage. Example: `python3 scripts/backtest_ohlc.py candles.csv --fast 10 --slow 30`.
- Tests: `npm run test:python` (requires Python 3; the C++ test is skipped if `g++` is unavailable).
- The current production signal generator remains in TypeScript; this adds a separate OHLC analysis endpoint and research backtester rather than silently replacing existing signal behavior.
- The economic calendar engine was not modified.
