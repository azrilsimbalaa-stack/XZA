<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/43896f8d-b146-4f35-9d68-411f88312662

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Catatan Analisa OHLC (update)
- Candle OHLC nyata per timeframe (M1–D1) dimuat server lewat `/api/ohlc` (Binance → mirror → Coinbase/Kraken/Yahoo/TradingView). Tidak ada candle acak.
- Harga live: BTC dari Binance WebSocket langsung, XAUUSD lewat push server `/ws/ticks`; cadangan polling 1 detik.
- Indikator (RSI Wilder, EMA, MACD, ATR, ADX, Bollinger, Stochastic) + SMC dihitung di `src/services/smcAnalysis.ts` dari candle tersebut.
- Sinyal hanya dihitung bila candle ≥50 bar dan harga live tersedia; gerbang konfluensi 7/10 + bias HTF aktif (tidak lagi dipaksa lolos).
- Modul kalender tidak diubah.
