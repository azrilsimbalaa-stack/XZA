# XZA Kalender News — Biquote + Forex Factory enrichment

Kalender ekonomi USD/US dengan frontend React + TypeScript, backend C++20, SQLite, dan Server-Sent Events (SSE).

## Cara kerja sumber data

- **Biquote adalah sumber utama.**
- **Forex Factory adalah sumber pelengkap.** Backend memeriksa feed JSON kalender mingguan yang dikonfigurasi, maksimal sekali setiap 5 menit secara default.
- Jika event ditemukan di kedua sumber, sistem mencocokkan mata uang, kemiripan nama, dan waktu rilis. Nilai Biquote yang valid dipertahankan; field kosong dapat dilengkapi dari Forex Factory.
- Event USD yang tidak ditemukan di Biquote dapat ditambahkan dari Forex Factory, dengan label sumber.
- Jika Biquote gagal dan snapshot Forex Factory yang valid tersedia, snapshot tersebut digunakan sebagai fallback. Cache SQLite tetap tersedia jika keduanya gagal.
- Pembaruan dari sumber upstream tidak dijamin sebagai push real-time. SSE mengirim perubahan ke browser tanpa reload setelah backend mendeteksinya.

Gunakan feed dan metode akses yang memang diizinkan untuk proyek Anda. Jangan gunakan feed ini untuk redistribusi jika lisensinya tidak mengizinkan. Tidak ada data contoh yang diperlakukan sebagai data live.

## Konfigurasi

Salin `.env.example` menjadi `.env`.

- `XZA_BIQUOTE_URL`: optional override untuk endpoint kalender Biquote.
- `XZA_REFRESH_SECONDS`: interval pemeriksaan Biquote, 30–300 detik.
- `XZA_FOREX_FACTORY_URL`: URL feed JSON kalender mingguan yang diizinkan untuk digunakan.
- `XZA_FOREX_FACTORY_REFRESH_SECONDS`: interval pemeriksaan feed pelengkap, 60–1800 detik; default 300.
- `XZA_DB_PATH`: lokasi database SQLite.
- `PORT`: port server produksi.

## Database

Default path: `data/xza_calendar.db`. SQLite menyimpan event gabungan, riwayat sinkronisasi, dan tabel `event_field_sources` yang mencatat sumber aktual/forecast/previous/impact per field. Gunakan persistent volume saat deployment. Untuk multi-instance, pertimbangkan migrasi ke PostgreSQL.

## Prasyarat

- Node.js 20+ dan npm
- CMake 3.16+
- Kompiler C++20
- Boost headers (Asio, Beast, Property Tree)
- OpenSSL development libraries
- SQLite3 development libraries
- `curl` CLI

## Development

```bash
npm install
npm run dev
```

## Production

```bash
npm install
npm run build
npm start
```

## Endpoint

- `GET /api/health` — status service
- `GET /api/status` — status sinkronisasi dan sumber
- `GET /api/calendar` — event USD dengan filter impact/status/window/search
- `GET /api/calendar/stream` — SSE stream untuk browser
- `POST /api/sync` — antrekan sinkronisasi manual

Jam UI menggunakan zona waktu Asia/Makassar (WITA). Waktu event ISO diproses sesuai zona waktu yang diberikan sumber.
