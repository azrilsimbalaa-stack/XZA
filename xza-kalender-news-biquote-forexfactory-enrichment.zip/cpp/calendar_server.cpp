#define BOOST_ERROR_CODE_HEADER_ONLY
#define BOOST_SYSTEM_NO_DEPRECATED
#include <boost/asio.hpp>
#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/property_tree/ptree.hpp>
#include <sqlite3.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cctype>
#include <limits>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <mutex>
#include <regex>
#include <set>
#include <sstream>
#include <string>
#include <thread>
#include <tuple>
#include <vector>

namespace asio = boost::asio;
namespace beast = boost::beast;
namespace http = beast::http;
namespace pt = boost::property_tree;
using tcp = asio::ip::tcp;
using namespace std::chrono;

namespace {
constexpr int kDefaultRefreshSeconds = 30; // REST source checked on a controlled interval; UI receives changes via SSE
constexpr int kExportFallbackCooldownSeconds = 300; // Refresh supplemental Forex Factory feed at most every 5 minutes
constexpr int kStaleAfterSeconds = 900; // mark feed stale after 15 minutes without a successful sync
const std::string kCalendarUrl = "https://biquote.io/api/calendar?countries=US&limit=500";
const std::string kCalendarSource = "Biquote Economic Calendar (USD / US only)";
const std::string kDefaultForexFactoryUrl = "https://nfs.faireconomy.media/ff_calendar_thisweek.json";

struct Event {
  std::string id, title, currency, country, date, impact, folder, label;
  std::string forecast = "---", previous = "---", actual = "";
  std::string source, rawDate, rawTime, category;
  std::string forecastSource, previousSource, actualSource, impactSource;
  int importance = -1;
  bool isReleased = false, hasActual = false, hasDeviation = false, hasImpact = false;
  double deviation = 0.0;
};

std::mutex g_db_mutex;
sqlite3* g_db = nullptr;
std::atomic<int> g_refresh_interval_seconds{kDefaultRefreshSeconds};

std::string database_path() {
  const char* env = std::getenv("XZA_DB_PATH");
  return env && *env ? std::string(env) : "data/xza_calendar.db";
}

bool db_exec(const char* sql) {
  char* error = nullptr;
  const int rc = sqlite3_exec(g_db, sql, nullptr, nullptr, &error);
  if (rc != SQLITE_OK) {
    std::cerr << "[Database] " << (error ? error : sqlite3_errmsg(g_db)) << "\n";
    sqlite3_free(error);
    return false;
  }
  return true;
}

bool initialize_database() {
  std::lock_guard<std::mutex> lock(g_db_mutex);
  if (g_db) return true;
  const std::string path = database_path();
  const auto parent = std::filesystem::path(path).parent_path();
  std::error_code fsError;
  if (!parent.empty()) std::filesystem::create_directories(parent, fsError);
  if (fsError) {
    std::cerr << "[Database] Cannot create database directory: " << fsError.message() << "\n";
    return false;
  }
  if (sqlite3_open_v2(path.c_str(), &g_db, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX, nullptr) != SQLITE_OK) {
    std::cerr << "[Database] Cannot open " << path << ": " << (g_db ? sqlite3_errmsg(g_db) : "unknown error") << "\n";
    if (g_db) sqlite3_close(g_db);
    g_db = nullptr;
    return false;
  }
  sqlite3_busy_timeout(g_db, 5000);
  const char* schema = R"SQL(
    PRAGMA journal_mode=WAL;
    PRAGMA synchronous=NORMAL;
    CREATE TABLE IF NOT EXISTS calendar_events (
      id TEXT PRIMARY KEY, title TEXT NOT NULL, currency TEXT NOT NULL, country TEXT NOT NULL,
      event_date TEXT NOT NULL, impact TEXT NOT NULL, folder TEXT NOT NULL, label TEXT NOT NULL,
      forecast TEXT NOT NULL, previous_value TEXT NOT NULL, actual TEXT NOT NULL, source TEXT NOT NULL,
      raw_date TEXT NOT NULL, raw_time TEXT NOT NULL, category TEXT NOT NULL, importance INTEGER NOT NULL,
      is_released INTEGER NOT NULL, has_actual INTEGER NOT NULL, has_deviation INTEGER NOT NULL,
      deviation REAL NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_calendar_events_date ON calendar_events(event_date);
    CREATE INDEX IF NOT EXISTS idx_calendar_events_currency_date ON calendar_events(currency, event_date);
    CREATE TABLE IF NOT EXISTS sync_runs (
      id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL, status TEXT NOT NULL,
      event_count INTEGER NOT NULL, started_at TEXT NOT NULL, finished_at TEXT NOT NULL, message TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS event_field_sources (
      event_id TEXT NOT NULL, field_name TEXT NOT NULL, field_value TEXT NOT NULL,
      source_name TEXT NOT NULL, updated_at TEXT NOT NULL,
      PRIMARY KEY(event_id, field_name)
    );
    CREATE INDEX IF NOT EXISTS idx_event_field_sources_source ON event_field_sources(source_name);
  )SQL";
  if (!db_exec(schema)) return false;
  std::cerr << "[Database] SQLite ready at " << path << "\n";
  return true;
}

std::string column_text(sqlite3_stmt* stmt, int col) {
  const unsigned char* value = sqlite3_column_text(stmt, col);
  return value ? reinterpret_cast<const char*>(value) : "";
}

std::vector<Event> load_database_events() {
  std::vector<Event> events;
  std::lock_guard<std::mutex> lock(g_db_mutex);
  if (!g_db) return events;
  const char* sql = "SELECT id,title,currency,country,event_date,impact,folder,label,forecast,previous_value,actual,source,raw_date,raw_time,category,importance,is_released,has_actual,has_deviation,deviation FROM calendar_events ORDER BY event_date";
  sqlite3_stmt* stmt = nullptr;
  if (sqlite3_prepare_v2(g_db, sql, -1, &stmt, nullptr) != SQLITE_OK) return events;
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    Event e;
    e.id = column_text(stmt, 0); e.title = column_text(stmt, 1); e.currency = column_text(stmt, 2);
    e.country = column_text(stmt, 3); e.date = column_text(stmt, 4); e.impact = column_text(stmt, 5);
    e.folder = column_text(stmt, 6); e.label = column_text(stmt, 7); e.forecast = column_text(stmt, 8);
    e.previous = column_text(stmt, 9); e.actual = column_text(stmt, 10); e.source = column_text(stmt, 11);
    e.rawDate = column_text(stmt, 12); e.rawTime = column_text(stmt, 13); e.category = column_text(stmt, 14);
    e.importance = sqlite3_column_int(stmt, 15); e.isReleased = sqlite3_column_int(stmt, 16) != 0;
    e.hasActual = sqlite3_column_int(stmt, 17) != 0; e.hasDeviation = sqlite3_column_int(stmt, 18) != 0;
    e.deviation = sqlite3_column_double(stmt, 19);
    events.push_back(std::move(e));
  }
  sqlite3_finalize(stmt);
  return events;
}

bool persist_database_events(const std::vector<Event>& events, const std::string& startedAt,
                             const std::string& finishedAt, const std::string& status,
                             const std::string& sourceName, const std::string& message) {
  std::lock_guard<std::mutex> lock(g_db_mutex);
  if (!g_db) return false;
  if (!db_exec("BEGIN IMMEDIATE;")) return false;
  const char* sql = "INSERT INTO calendar_events(id,title,currency,country,event_date,impact,folder,label,forecast,previous_value,actual,source,raw_date,raw_time,category,importance,is_released,has_actual,has_deviation,deviation,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,currency=excluded.currency,country=excluded.country,event_date=excluded.event_date,impact=excluded.impact,folder=excluded.folder,label=excluded.label,forecast=excluded.forecast,previous_value=excluded.previous_value,actual=excluded.actual,source=excluded.source,raw_date=excluded.raw_date,raw_time=excluded.raw_time,category=excluded.category,importance=excluded.importance,is_released=excluded.is_released,has_actual=excluded.has_actual,has_deviation=excluded.has_deviation,deviation=excluded.deviation,updated_at=excluded.updated_at";
  sqlite3_stmt* stmt = nullptr;
  if (sqlite3_prepare_v2(g_db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
    db_exec("ROLLBACK;"); return false;
  }
  bool ok = true;
  for (const auto& e : events) {
    int i = 1;
    auto bind = [&](const std::string& v) { sqlite3_bind_text(stmt, i++, v.c_str(), -1, SQLITE_TRANSIENT); };
    bind(e.id); bind(e.title); bind(e.currency); bind(e.country); bind(e.date); bind(e.impact);
    bind(e.folder); bind(e.label); bind(e.forecast); bind(e.previous); bind(e.actual); bind(e.source);
    bind(e.rawDate); bind(e.rawTime); bind(e.category);
    sqlite3_bind_int(stmt, i++, e.importance); sqlite3_bind_int(stmt, i++, e.isReleased ? 1 : 0);
    sqlite3_bind_int(stmt, i++, e.hasActual ? 1 : 0); sqlite3_bind_int(stmt, i++, e.hasDeviation ? 1 : 0);
    sqlite3_bind_double(stmt, i++, e.deviation); bind(finishedAt);
    if (sqlite3_step(stmt) != SQLITE_DONE) ok = false;
    sqlite3_reset(stmt); sqlite3_clear_bindings(stmt);
    if (!ok) break;

    const std::vector<std::tuple<std::string, std::string, std::string>> provenance = {
      {"forecast", e.forecast, e.forecastSource},
      {"previous", e.previous, e.previousSource},
      {"actual", e.actual, e.actualSource},
      {"impact", e.impact, e.impactSource}
    };
    sqlite3_stmt* sourceStmt = nullptr;
    const char* sourceSql = "INSERT INTO event_field_sources(event_id,field_name,field_value,source_name,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(event_id,field_name) DO UPDATE SET field_value=excluded.field_value,source_name=excluded.source_name,updated_at=excluded.updated_at";
    if (sqlite3_prepare_v2(g_db, sourceSql, -1, &sourceStmt, nullptr) != SQLITE_OK) { ok = false; break; }
    for (const auto& item : provenance) {
      const std::string fieldValue = std::get<1>(item);
      if (fieldValue.empty() || fieldValue == "---" || std::get<2>(item).empty()) continue;
      sqlite3_bind_text(sourceStmt, 1, e.id.c_str(), -1, SQLITE_TRANSIENT);
      sqlite3_bind_text(sourceStmt, 2, std::get<0>(item).c_str(), -1, SQLITE_TRANSIENT);
      sqlite3_bind_text(sourceStmt, 3, std::get<1>(item).c_str(), -1, SQLITE_TRANSIENT);
      sqlite3_bind_text(sourceStmt, 4, std::get<2>(item).c_str(), -1, SQLITE_TRANSIENT);
      sqlite3_bind_text(sourceStmt, 5, finishedAt.c_str(), -1, SQLITE_TRANSIENT);
      if (sqlite3_step(sourceStmt) != SQLITE_DONE) ok = false;
      sqlite3_reset(sourceStmt); sqlite3_clear_bindings(sourceStmt);
      if (!ok) break;
    }
    sqlite3_finalize(sourceStmt);
    if (!ok) break;
  }
  sqlite3_finalize(stmt);
  if (ok) {
    sqlite3_stmt* pruneStmt = nullptr;
    if (sqlite3_prepare_v2(g_db, "DELETE FROM calendar_events WHERE updated_at != ?", -1, &pruneStmt, nullptr) == SQLITE_OK) {
      sqlite3_bind_text(pruneStmt, 1, finishedAt.c_str(), -1, SQLITE_TRANSIENT);
      if (sqlite3_step(pruneStmt) != SQLITE_DONE) ok = false;
      sqlite3_finalize(pruneStmt);
    } else ok = false;
  }
  if (ok) {
    sqlite3_stmt* sourcePrune = nullptr;
    if (sqlite3_prepare_v2(g_db, "DELETE FROM event_field_sources WHERE updated_at != ?", -1, &sourcePrune, nullptr) == SQLITE_OK) {
      sqlite3_bind_text(sourcePrune, 1, finishedAt.c_str(), -1, SQLITE_TRANSIENT);
      if (sqlite3_step(sourcePrune) != SQLITE_DONE) ok = false;
      sqlite3_finalize(sourcePrune);
    } else ok = false;
  }
  if (ok) {
    sqlite3_stmt* logStmt = nullptr;
    if (sqlite3_prepare_v2(g_db, "INSERT INTO sync_runs(source,status,event_count,started_at,finished_at,message) VALUES(?,?,?,?,?,?)", -1, &logStmt, nullptr) == SQLITE_OK) {
      sqlite3_bind_text(logStmt, 1, sourceName.c_str(), -1, SQLITE_TRANSIENT);
      sqlite3_bind_text(logStmt, 2, status.c_str(), -1, SQLITE_TRANSIENT);
      sqlite3_bind_int(logStmt, 3, static_cast<int>(events.size()));
      sqlite3_bind_text(logStmt, 4, startedAt.c_str(), -1, SQLITE_TRANSIENT);
      sqlite3_bind_text(logStmt, 5, finishedAt.c_str(), -1, SQLITE_TRANSIENT);
      sqlite3_bind_text(logStmt, 6, message.c_str(), -1, SQLITE_TRANSIENT);
      if (sqlite3_step(logStmt) != SQLITE_DONE) ok = false;
      sqlite3_finalize(logStmt);
    } else ok = false;
  }
  if (ok) ok = db_exec("COMMIT;"); else db_exec("ROLLBACK;");
  return ok;
}

struct State {
  std::vector<Event> events;
  std::uint64_t revision = 0;
  std::string source = "Belum terhubung";
  std::string sourceState = "CONNECTING";
  std::string lastSuccess = "";
  std::string lastFetch = "";
  std::string lastError = "";
  bool refreshing = false;
};

std::mutex g_mutex;
std::condition_variable g_cv;
State g_state;
bool g_stop = false;
bool g_manual_sync_requested = false;
steady_clock::time_point g_lastExportAttempt = steady_clock::time_point::min();
bool g_forexfactory_attempted = false;
std::vector<Event> g_forexfactory_events; // Last successful supplemental feed snapshot; used between FF refreshes.
std::atomic<unsigned long long> g_requestCount{0};
std::string lower(std::string s) {
  std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
  return s;
}
std::string trim(const std::string& s) {
  const auto first = s.find_first_not_of(" \t\r\n\f\v");
  if (first == std::string::npos) return "";
  const auto last = s.find_last_not_of(" \t\r\n\f\v");
  return s.substr(first, last - first + 1);
}
bool contains(const std::string& text, const std::string& needle) { return lower(text).find(lower(needle)) != std::string::npos; }
bool has_any(const std::string& text, const std::vector<std::string>& needles) {
  for (const auto& needle : needles) if (contains(text, needle)) return true;
  return false;
}
std::string json_escape(const std::string& in) {
  std::ostringstream out;
  for (unsigned char c : in) {
    switch (c) {
      case '"': out << "\\\""; break;
      case '\\': out << "\\\\"; break;
      case '\b': out << "\\b"; break;
      case '\f': out << "\\f"; break;
      case '\n': out << "\\n"; break;
      case '\r': out << "\\r"; break;
      case '\t': out << "\\t"; break;
      default:
        if (c < 0x20) out << "\\u" << std::hex << std::setw(4) << std::setfill('0') << static_cast<int>(c) << std::dec;
        else out << static_cast<char>(c);
    }
  }
  return out.str();
}
std::string q(const std::string& s) { return "\"" + json_escape(s) + "\""; }
std::string bool_json(bool value) { return value ? "true" : "false"; }
std::string iso_now() {
  auto t = system_clock::to_time_t(system_clock::now());
  std::tm tm{};
#if defined(_WIN32)
  gmtime_s(&tm, &t);
#else
  gmtime_r(&t, &tm);
#endif
  std::ostringstream s;
  s << std::put_time(&tm, "%Y-%m-%dT%H:%M:%SZ");
  return s.str();
}
std::string slug(const std::string& s) {
  std::string result;
  bool dash = false;
  for (unsigned char c : lower(s)) {
    if (std::isalnum(c)) { result.push_back(static_cast<char>(c)); dash = false; }
    else if (!dash && !result.empty()) { result.push_back('-'); dash = true; }
  }
  while (!result.empty() && result.back() == '-') result.pop_back();
  return result.empty() ? "event" : result;
}
std::string upper(std::string s);
std::string upper(std::string s) {
  std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
  return s;
}
std::string norm_value(std::string s) {
  s = trim(s);
  const std::string folded = lower(s);
  if (s.empty() || s == "-" || s == "---" || folded == "n/a" || folded == "null" || folded == "none") return "---";
  return s;
}

// Normalize the provider's calendar fields in C++; no trading signal is generated here.
std::int64_t parse_iso_epoch(const std::string& iso);
void calculate_event(Event& e) {
  const std::string title = lower(e.title);
  const bool highKeyword = has_any(title, {"non-farm employment change", "nonfarm payroll", "non-farm payroll", "nfp", "unemployment rate", "cpi m/m", "core cpi m/m", "cpi y/y", "core cpi y/y", "consumer price index", "federal funds rate", "fomc statement", "fomc press conference", "fomc economic projections", "core pce price index", "pce price index", "advance gdp", "gross domestic product", "gdp q/q", "retail sales m/m", "core retail sales m/m", "ism manufacturing pmi", "ism services pmi", "powell speaks", "fed chair powell"});
  const bool mediumKeyword = has_any(title, {"ppi m/m", "core ppi m/m", "ppi y/y", "core ppi y/y", "producer price index", "initial jobless claims", "jobless claims", "continuing claims", "jolts job openings", "jolts", "adp non-farm employment change", "adp employment", "average hourly earnings", "cb consumer confidence", "consumer confidence", "uom consumer sentiment", "michigan consumer sentiment", "uom inflation expectations", "philly fed manufacturing", "empire state manufacturing", "building permits", "housing starts", "existing home sales", "new home sales", "durable goods orders", "core durable goods", "chicago pmi", "fomc meeting minutes", "trade balance", "fed governors speaks"});

  // Prefer the provider's stated impact. Use a conservative title mapping only if missing.
  const std::string rawImpact = lower(trim(e.impact));
  if (rawImpact == "high") {
    e.impact = "HIGH"; e.importance = 1; e.folder = "RED_FOLDER"; e.label = "FOREX FACTORY HIGH IMPACT (RED FOLDER)";
  } else if (rawImpact == "medium" || rawImpact == "med") {
    e.impact = "MEDIUM"; e.importance = 0; e.folder = "ORANGE_FOLDER"; e.label = "FOREX FACTORY MEDIUM IMPACT (ORANGE FOLDER)";
  } else if (rawImpact == "low") {
    e.impact = "LOW"; e.importance = -1; e.folder = "YELLOW_FOLDER"; e.label = "FOREX FACTORY LOW IMPACT (YELLOW FOLDER)";
  } else if (rawImpact == "holiday") {
    e.impact = "HOLIDAY"; e.importance = -1; e.folder = "GRAY_FOLDER"; e.label = "FOREX FACTORY HOLIDAY (GRAY FOLDER)";
  } else if (highKeyword) {
    e.impact = "HIGH"; e.importance = 1; e.folder = "RED_FOLDER"; e.label = "FOREX FACTORY HIGH IMPACT (RED FOLDER)";
  } else if (mediumKeyword) {
    e.impact = "MEDIUM"; e.importance = 0; e.folder = "ORANGE_FOLDER"; e.label = "FOREX FACTORY MEDIUM IMPACT (ORANGE FOLDER)";
  } else {
    e.impact = "LOW"; e.importance = -1; e.folder = "YELLOW_FOLDER"; e.label = "FOREX FACTORY LOW IMPACT (YELLOW FOLDER)";
  }

  // Informational macro grouping retained for calendar filtering and display.
  if (has_any(title, {"cpi", "consumer price", "inflation", "pce", "personal consumption expenditures", "ppi", "producer price"})) e.category = "INFLATION";
  else if (has_any(title, {"fomc", "federal funds", "fed rate", "interest rate", "ecb rate", "boe rate", "boj rate", "monetary policy", "powell", "lagarde", "rate decision"})) e.category = "CENTRAL_BANK_RATES";
  else if (has_any(title, {"unemployment", "jobless claims", "initial claims", "continuing claims", "claimant count", "non-farm", "nonfarm", "nfp", "payroll", "adp employment", "jolts", "job openings", "hourly earnings", "wage growth"})) e.category = "LABOR_MARKET";
  else if (has_any(title, {"gdp", "retail sales", "industrial production", "durable goods", "trade balance"})) e.category = "GROWTH";
  else if (has_any(title, {"pmi", "ism manufacturing", "ism services", "philly fed", "empire state"})) e.category = "BUSINESS_ACTIVITY";
  else if (has_any(title, {"consumer confidence", "consumer sentiment", "housing", "home sales", "building permits"})) e.category = "SENTIMENT_HOUSING";
  else e.category = "GLOBAL_MACRO";

  auto parse_number = [](const std::string& value, double& out) {
    static const std::regex numberRe(R"([-+]?[0-9]+(?:[,.][0-9]+)?)");
    std::smatch match;
    if (!std::regex_search(value, match, numberRe)) return false;
    std::string normalized = match[0].str();
    // Provider values use comma as a thousands separator (e.g. 1,234.5).
    normalized.erase(std::remove(normalized.begin(), normalized.end(), ','), normalized.end());
    try { out = std::stod(normalized); return true; } catch (...) { return false; }
  };
  double actualNum = 0, forecastNum = 0, previousNum = 0;
  e.hasActual = !e.actual.empty() && e.actual != "---";
  const bool hasActualNum = e.hasActual && parse_number(e.actual, actualNum);
  const bool hasForecast = parse_number(e.forecast, forecastNum);
  const bool hasPrevious = parse_number(e.previous, previousNum);
  const auto eventMs = parse_iso_epoch(e.date);
  const auto nowMs = duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
  e.isReleased = e.hasActual || (eventMs > 0 && eventMs <= nowMs);
  e.hasDeviation = false;
  if (hasActualNum && (hasForecast || hasPrevious)) {
    e.deviation = actualNum - (hasForecast ? forecastNum : previousNum);
    e.hasDeviation = true;
  }
}

std::string run_curl(const std::string& url, int timeoutSeconds) {
  // Only permit HTTP(S) URLs without shell quoting characters; the URL is passed to curl via a shell command.
  if (!(url.rfind("https://", 0) == 0 || url.rfind("http://", 0) == 0) ||
      url.find('\'') != std::string::npos || url.find('"') != std::string::npos ||
      url.find('\n') != std::string::npos || url.find('\r') != std::string::npos) return "";
  const std::string command = "curl --fail --location --silent --show-error --compressed --max-time " +
    std::to_string(timeoutSeconds) + " --header 'Cache-Control: no-cache' --header 'Pragma: no-cache' --user-agent 'XZA-Calendar-News/1.0' '" + url + "' 2>/dev/null";
#if defined(_WIN32)
  FILE* pipe = _popen(command.c_str(), "rb");
#else
  FILE* pipe = popen(command.c_str(), "r");
#endif
  if (!pipe) return "";
  std::string result;
  std::array<char, 8192> buffer{};
  while (true) {
    const size_t n = fread(buffer.data(), 1, buffer.size(), pipe);
    if (n) result.append(buffer.data(), n);
    if (n < buffer.size()) break;
    if (result.size() > 20 * 1024 * 1024) break;
  }
#if defined(_WIN32)
  int rc = _pclose(pipe);
#else
  int rc = pclose(pipe);
#endif
  if (rc != 0 || result.empty()) return "";
  return result;
}

std::int64_t parse_iso_epoch(const std::string& iso) {
  std::smatch m;
  static const std::regex re(R"((\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?(Z|[+-]\d{2}:?\d{2})?)");
  if (!std::regex_search(iso, m, re)) return 0;
  try {
    int y = std::stoi(m[1]), mo = std::stoi(m[2]), d = std::stoi(m[3]);
    int h = std::stoi(m[4]), mi = std::stoi(m[5]), sec = m[6].matched ? std::stoi(m[6]) : 0;
    using namespace std::chrono;
    sys_seconds p = sys_days{std::chrono::year{y}/std::chrono::month{static_cast<unsigned>(mo)}/std::chrono::day{static_cast<unsigned>(d)}} + hours{h} + minutes{mi} + seconds{sec};
    if (m[7].matched && m[7].str() != "Z") {
      const std::string z = m[7].str();
      const int zh = std::stoi(z.substr(1,2));
      const int zm = std::stoi(z.substr(z.find(':') != std::string::npos ? 4 : 3, 2));
      const int offset = (zh * 60 + zm) * (z[0] == '+' ? 1 : -1);
      p -= minutes{offset};
    }
    return duration_cast<milliseconds>(p.time_since_epoch()).count();
  } catch (...) { return 0; }
}
std::string event_json(const Event& e) {
  std::ostringstream o;
  o << "{" << "\"id\":" << q(e.id) << ",\"title\":" << q(e.title)
    << ",\"currency\":" << q(e.currency) << ",\"country\":" << q(e.country)
    << ",\"date\":" << q(e.date) << ",\"impact\":" << q(e.impact)
    << ",\"importance\":" << e.importance << ",\"forexFactoryFolder\":" << q(e.folder)
    << ",\"forexFactoryLabel\":" << q(e.label) << ",\"forecast\":" << q(e.forecast)
    << ",\"previous\":" << q(e.previous) << ",\"actual\":" << (e.actual.empty() ? "null" : q(e.actual))
    << ",\"rawDate\":" << q(e.rawDate) << ",\"rawTime\":" << q(e.rawTime)
    << ",\"source\":" << q(e.source) << ",\"isReleased\":" << bool_json(e.isReleased)
    << ",\"status\":" << q(e.isReleased ? "RELEASED" : "UPCOMING")
    << ",\"hasActual\":" << bool_json(e.hasActual)
    << ",\"deviation\":" << (e.hasDeviation ? std::to_string(e.deviation) : "null")
    << ",\"macroCategory\":" << q(e.category) << "}";
  return o.str();
}

std::string snapshot_json(const std::vector<Event>& events, const State& s) {
  auto nowMs = duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
  int released = 0, high = 0, medium = 0, low = 0, upcoming = 0;
  std::ostringstream rows;
  rows << '[';
  bool first = true;
  for (auto e : events) {
    // Event status is recalculated when a client snapshot is serialized.
    const auto evMs = parse_iso_epoch(e.date);
    e.isReleased = e.hasActual || (evMs > 0 && evMs <= nowMs);
    if (e.isReleased) ++released; else ++upcoming;
    if (e.importance == 1) ++high; else if (e.importance == 0) ++medium; else ++low;
    if (!first) rows << ',';
    first = false;
    rows << event_json(e);
  }
  rows << ']';
  const bool stale = s.lastSuccess.empty() || parse_iso_epoch(s.lastSuccess) == 0 || (nowMs - parse_iso_epoch(s.lastSuccess) > kStaleAfterSeconds * 1000LL);
  std::ostringstream o;
  o << "{\"events\":" << rows.str() << ",\"result\":" << rows.str()
    << ",\"revision\":" << s.revision << ",\"serverTime\":" << q(iso_now())
    << ",\"source\":" << q(s.source) << ",\"sourceState\":" << q(s.sourceState)
    << ",\"lastSuccess\":" << (s.lastSuccess.empty() ? "null" : q(s.lastSuccess))
    << ",\"lastFetch\":" << (s.lastFetch.empty() ? "null" : q(s.lastFetch))
    << ",\"lastError\":" << (s.lastError.empty() ? "null" : q(s.lastError))
    << ",\"refreshing\":" << bool_json(s.refreshing) << ",\"stale\":" << bool_json(stale)
    << ",\"refreshIntervalSeconds\":" << g_refresh_interval_seconds.load()
    << ",\"summary\":{" << "\"total\":" << events.size() << ",\"released\":" << released
    << ",\"upcoming\":" << upcoming << ",\"highImpact\":" << high
    << ",\"mediumImpact\":" << medium << ",\"lowImpact\":" << low << "}}";
  return o.str();
}

std::map<std::string, std::string> parse_query(const std::string& target) {
  std::map<std::string, std::string> result;
  auto qpos = target.find('?');
  if (qpos == std::string::npos) return result;
  std::string query = target.substr(qpos + 1);
  std::size_t start = 0;
  auto decode = [](std::string s) {
    std::string out;
    for (std::size_t i = 0; i < s.size(); ++i) {
      if (s[i] == '+') out.push_back(' ');
      else if (s[i] == '%' && i + 2 < s.size()) {
        try { out.push_back(static_cast<char>(std::stoi(s.substr(i+1,2), nullptr, 16))); i += 2; } catch (...) { out.push_back(s[i]); }
      } else out.push_back(s[i]);
    }
    return out;
  };
  while (start <= query.size()) {
    auto end = query.find('&', start);
    auto piece = query.substr(start, end == std::string::npos ? std::string::npos : end - start);
    auto eq = piece.find('=');
    result[decode(piece.substr(0, eq))] = eq == std::string::npos ? "" : decode(piece.substr(eq+1));
    if (end == std::string::npos) break;
    start = end + 1;
  }
  return result;
}
std::vector<Event> filtered_events(const std::vector<Event>& all, const std::map<std::string, std::string>& p) {
  auto val = [&](const std::string& k, const std::string& d) { auto i=p.find(k); return i==p.end() || i->second.empty()?d:i->second; };
  const std::string currency = "USD"; // XZA Calendar is intentionally USD-only.
  const std::string impact = upper(val("impact", "ALL"));
  const std::string status = upper(val("status", "ALL"));
  const std::string window = upper(val("window", "ALL"));
  const std::string search = lower(trim(val("search", "")));
  const auto nowMs = duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
  const auto witaNow = system_clock::time_point{milliseconds{nowMs + 8LL * 3600 * 1000}};
  const auto today = floor<days>(witaNow).time_since_epoch().count();
  std::vector<Event> result;
  for (auto e : all) {
    const auto epoch = parse_iso_epoch(e.date);
    e.isReleased = e.hasActual || (epoch > 0 && epoch <= nowMs);
    if (currency != "ALL" && upper(e.currency) != currency) continue;
    if (impact != "ALL" && upper(e.impact) != impact) continue;
    if (status == "RELEASED" && !e.isReleased) continue;
    if (status == "UPCOMING" && e.isReleased) continue;
    if (!search.empty() && lower(e.title + " " + e.currency + " " + e.country).find(search) == std::string::npos) continue;
    const auto localEventDay = floor<days>(system_clock::time_point{milliseconds{epoch + 8LL * 3600 * 1000}}).time_since_epoch().count();
    if (window == "TODAY" && localEventDay != today) continue;
    if (window == "YESTERDAY" && localEventDay != today - 1) continue;
    if (window == "TOMORROW" && localEventDay != today + 1) continue;
    if (window == "THIS_WEEK" && (localEventDay < today || localEventDay > today + 6)) continue;
    result.push_back(e);
  }
  std::sort(result.begin(), result.end(), [](const Event& a, const Event& b) { return a.date < b.date; });
  return result;
}

std::vector<Event> parse_biquote_calendar(const std::string& body) {
  std::vector<Event> events;
  std::stringstream stream(body);
  pt::ptree root;
  try { pt::read_json(stream, root); } catch (...) { return events; }
  for (const auto& node : root) {
    if (!node.first.empty()) continue;
    const auto& p = node.second;
    auto get = [&](const std::string& key, const std::string& fallback = "") {
      return p.get<std::string>(key, fallback);
    };
    const std::string currency = upper(get("currency", ""));
    const std::string countryCode = upper(get("countryCode", get("country", "")));
    // Strictly limit this application to US economic releases denominated in USD.
    if (currency != "USD" && !(currency.empty() && countryCode == "US")) continue;
    const std::string title = trim(get("name", get("title", "")));
    const std::string date = trim(get("time", get("date", "")));
    if (title.empty() || date.size() < 16) continue;

    Event e;
    e.id = "biquote-" + get("id", slug(title + date));
    e.title = title;
    e.currency = "USD";
    e.country = "US";
    e.date = date;
    if (e.date.size() == 19 && e.date.back() != 'Z' && e.date.find('+') == std::string::npos) e.date += "Z";
    std::string impact = lower(get("importance", ""));
    if (impact == "3" || impact == "high") { impact = "HIGH"; e.hasImpact = true; }
    else if (impact == "2" || impact == "medium" || impact == "med") { impact = "MEDIUM"; e.hasImpact = true; }
    else if (impact == "1" || impact == "low") { impact = "LOW"; e.hasImpact = true; }
    else if (impact == "holiday") { impact = "HOLIDAY"; e.hasImpact = true; }
    else impact = "UNKNOWN";
    e.impact = impact;
    e.forecast = norm_value(get("forecast", "---"));
    e.previous = norm_value(get("previous", "---"));
    e.actual = norm_value(get("actual", "---"));
    if (!e.forecast.empty() && e.forecast != "---") e.forecastSource = "Biquote";
    if (!e.previous.empty() && e.previous != "---") e.previousSource = "Biquote";
    if (e.actual == "---") e.actual.clear();
    if (!e.actual.empty()) e.actualSource = "Biquote";
    if (e.hasImpact) e.impactSource = "Biquote";
    e.rawDate = date.substr(0, 10);
    e.rawTime = date.size() >= 16 ? date.substr(11, 5) : "";
    e.source = "Biquote Economic Calendar";
    calculate_event(e);
    events.push_back(std::move(e));
  }
  std::sort(events.begin(), events.end(), [](const Event& a, const Event& b) { return a.date < b.date; });
  return events;
}


std::string env_or(const char* key, const std::string& fallback) {
  const char* value = std::getenv(key);
  return value && *value ? std::string(value) : fallback;
}

std::string event_date_to_iso(const std::string& value) {
  const std::string v = trim(value);
  if (v.empty()) return "";
  // Some feeds expose a Unix timestamp instead of an ISO date.
  if (std::regex_match(v, std::regex(R"(\d{9,13})"))) {
    try {
      long long n = std::stoll(v);
      if (v.size() == 10) n *= 1000;
      const std::time_t secondsValue = static_cast<std::time_t>(n / 1000);
      std::tm tm{};
#if defined(_WIN32)
      gmtime_s(&tm, &secondsValue);
#else
      gmtime_r(&secondsValue, &tm);
#endif
      std::ostringstream out;
      out << std::put_time(&tm, "%Y-%m-%dT%H:%M:%SZ");
      return out.str();
    } catch (...) { return ""; }
  }
  if (parse_iso_epoch(v) > 0) {
    // Keep explicit offsets intact; append Z only for timezone-less ISO timestamps.
    if (v.size() >= 19 && v.find('T') != std::string::npos &&
        v.find('Z') == std::string::npos && v.find('+', 10) == std::string::npos &&
        v.find('-', 10) == std::string::npos) return v + "Z";
    if (v.size() == 16 && v.find('T') != std::string::npos) return v + ":00Z";
    return v;
  }
  return "";
}

std::vector<Event> parse_forexfactory_calendar(const std::string& body) {
  std::vector<Event> events;
  if (body.empty()) return events;
  pt::ptree root;
  try {
    std::stringstream stream(body);
    pt::read_json(stream, root);
  } catch (...) {
    std::cerr << "[ForexFactory] Feed response was not valid JSON; skipping enrichment.\n";
    return events;
  }
  const pt::ptree* rows = &root;
  auto rowsIt = root.find("events");
  if (rowsIt != root.not_found()) rows = &rowsIt->second;
  for (const auto& node : *rows) {
    if (!node.first.empty() && rows == &root) continue;
    const auto& p = node.second;
    auto get = [&](std::initializer_list<const char*> keys) {
      for (const char* key : keys) {
        auto value = p.get_optional<std::string>(key);
        if (value && !trim(*value).empty()) return trim(*value);
      }
      return std::string{};
    };
    const std::string currency = upper(get({"currency", "country", "ccy"}));
    if (currency != "USD") continue;
    const std::string title = get({"title", "event", "name"});
    const std::string date = event_date_to_iso(get({"date", "datetime", "time", "timestamp"}));
    if (title.empty() || date.empty()) continue;

    Event e;
    const std::string providerId = get({"id", "event_id", "eventId"});
    e.id = "forexfactory-" + (providerId.empty() ? slug(currency + "-" + title + "-" + date) : slug(providerId));
    e.title = title;
    e.currency = "USD";
    e.country = "US";
    e.date = date;
    std::string impact = lower(get({"impact", "importance", "impactTitle"}));
    if (impact.find("high") != std::string::npos || impact == "3") { e.impact = "HIGH"; e.hasImpact = true; }
    else if (impact.find("med") != std::string::npos || impact == "2") { e.impact = "MEDIUM"; e.hasImpact = true; }
    else if (impact.find("low") != std::string::npos || impact == "1") { e.impact = "LOW"; e.hasImpact = true; }
    else if (impact.find("holiday") != std::string::npos) { e.impact = "HOLIDAY"; e.hasImpact = true; }
    else e.impact = "UNKNOWN";
    e.actual = norm_value(get({"actual"}));
    if (e.actual == "---") e.actual.clear();
    e.forecast = norm_value(get({"forecast"}));
    e.previous = norm_value(get({"previous", "previousValue"}));
    if (!e.actual.empty()) e.actualSource = "Forex Factory";
    if (!e.forecast.empty() && e.forecast != "---") e.forecastSource = "Forex Factory";
    if (!e.previous.empty() && e.previous != "---") e.previousSource = "Forex Factory";
    if (e.hasImpact) e.impactSource = "Forex Factory";
    e.rawDate = date.substr(0, 10);
    e.rawTime = date.size() >= 16 ? date.substr(11, 5) : "";
    e.source = "Forex Factory (supplemental)";
    calculate_event(e);
    events.push_back(std::move(e));
  }
  std::sort(events.begin(), events.end(), [](const Event& a, const Event& b) { return a.date < b.date; });
  return events;
}

std::set<std::string> title_tokens(const std::string& title) {
  std::set<std::string> tokens;
  std::stringstream ss(slug(title));
  std::string token;
  while (std::getline(ss, token, '-')) {
    if (token.size() > 1) tokens.insert(token);
  }
  return tokens;
}

double event_title_similarity(const std::string& a, const std::string& b) {
  const std::string sa = slug(a), sb = slug(b);
  if (sa == sb) return 1.0;
  const auto ta = title_tokens(a), tb = title_tokens(b);
  if (ta.empty() || tb.empty()) return 0.0;
  std::size_t intersection = 0;
  for (const auto& token : ta) if (tb.count(token)) ++intersection;
  const std::size_t uni = ta.size() + tb.size() - intersection;
  return uni ? static_cast<double>(intersection) / static_cast<double>(uni) : 0.0;
}

bool event_match(const Event& a, const Event& b) {
  if (a.currency != b.currency) return false;
  const auto ta = parse_iso_epoch(a.date), tb = parse_iso_epoch(b.date);
  if (ta <= 0 || tb <= 0 || std::llabs(ta - tb) > 18LL * 60 * 60 * 1000) return false;
  const double similarity = event_title_similarity(a.title, b.title);
  return similarity >= 0.60;
}

bool has_provider_value(const std::string& value) {
  return !value.empty() && value != "---" && lower(value) != "n/a" && lower(value) != "null";
}

std::vector<Event> merge_calendar_sources(const std::vector<Event>& biquote,
                                          const std::vector<Event>& forexfactory) {
  std::vector<Event> merged = biquote;
  for (const auto& ff : forexfactory) {
    std::size_t matchIndex = merged.size();
    double bestScore = 0.0;
    for (std::size_t i = 0; i < merged.size(); ++i) {
      if (!event_match(merged[i], ff)) continue;
      const double score = event_title_similarity(merged[i].title, ff.title);
      if (score > bestScore) { bestScore = score; matchIndex = i; }
    }
    if (matchIndex == merged.size()) {
      Event added = ff;
      added.source = "Forex Factory (supplemental event)";
      calculate_event(added);
      merged.push_back(std::move(added));
      continue;
    }

    Event& base = merged[matchIndex];
    bool changed = false;
    if (!has_provider_value(base.forecast) && has_provider_value(ff.forecast)) { base.forecast = ff.forecast; base.forecastSource = "Forex Factory"; changed = true; }
    if (!has_provider_value(base.previous) && has_provider_value(ff.previous)) { base.previous = ff.previous; base.previousSource = "Forex Factory"; changed = true; }
    if (!has_provider_value(base.actual) && has_provider_value(ff.actual)) { base.actual = ff.actual; base.actualSource = "Forex Factory"; changed = true; }
    if (!base.hasImpact && ff.hasImpact) { base.impact = ff.impact; base.impactSource = "Forex Factory"; base.hasImpact = true; changed = true; }
    if (base.title.empty()) { base.title = ff.title; changed = true; }
    if (changed) base.source = "Biquote + Forex Factory (field enrichment)";
    calculate_event(base);
  }
  std::sort(merged.begin(), merged.end(), [](const Event& a, const Event& b) { return a.date < b.date; });
  return merged;
}

int forexfactory_refresh_seconds() {
  int interval = kExportFallbackCooldownSeconds;
  const char* env = std::getenv("XZA_FOREX_FACTORY_REFRESH_SECONDS");
  if (env && *env) {
    try { interval = std::clamp(std::stoi(env), 60, 1800); } catch (...) {}
  }
  return interval;
}

std::vector<Event> fetch_forexfactory_if_due() {
  const auto now = steady_clock::now();
  if (g_forexfactory_attempted && g_lastExportAttempt != steady_clock::time_point::min() &&
      now - g_lastExportAttempt < seconds{forexfactory_refresh_seconds()}) {
    return g_forexfactory_events;
  }
  g_forexfactory_attempted = true;
  g_lastExportAttempt = now;
  const std::string url = env_or("XZA_FOREX_FACTORY_URL", kDefaultForexFactoryUrl);
  std::cerr << "[ForexFactory] Checking supplemental USD calendar feed...\n";
  const std::string body = run_curl(url, 15);
  auto parsed = parse_forexfactory_calendar(body);
  if (!parsed.empty()) {
    g_forexfactory_events = std::move(parsed);
    std::cerr << "[ForexFactory] Loaded " << g_forexfactory_events.size() << " USD events for enrichment.\n";
  } else {
    std::cerr << "[ForexFactory] No valid USD events received; retaining the last successful FF snapshot.\n";
  }
  return g_forexfactory_events;
}

void refresh_calendar() {
  const std::string startedAt = iso_now();
  {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_state.refreshing = true;
    g_state.lastFetch = startedAt;
  }
  std::cerr << "[Calendar] Fetching Biquote USD calendar snapshot...\n";
  const std::string biquoteBody = run_curl(env_or("XZA_BIQUOTE_URL", kCalendarUrl), 15);
  auto biquoteEvents = biquoteBody.empty() ? std::vector<Event>{} : parse_biquote_calendar(biquoteBody);
  auto ffEvents = fetch_forexfactory_if_due();
  auto events = merge_calendar_sources(biquoteEvents, ffEvents);
  std::string error;
  std::string sourceName = "Biquote + Forex Factory enrichment";
  std::string sourceLabel = "Biquote + Forex Factory field enrichment + SQLite";
  std::string syncStatus = "SUCCESS";
  std::string syncMessage = "Biquote events normalized and supplemented with matching Forex Factory fields/events.";

  if (biquoteEvents.empty() && ffEvents.empty()) {
    error = biquoteBody.empty()
      ? "Biquote tidak dapat diakses dan feed pelengkap Forex Factory belum menghasilkan data; cache dipertahankan."
      : "Biquote tidak menghasilkan event USD yang valid dan feed pelengkap Forex Factory belum menghasilkan data; cache dipertahankan.";
  } else if (biquoteEvents.empty() && !ffEvents.empty()) {
    sourceName = "Forex Factory fallback";
    sourceLabel = "Forex Factory fallback + SQLite";
    syncStatus = "FALLBACK";
    syncMessage = "Biquote unavailable/invalid; using the last valid Forex Factory USD snapshot.";
  } else if (ffEvents.empty()) {
    sourceName = "Biquote";
    sourceLabel = "Biquote + SQLite (Forex Factory enrichment unavailable)";
    syncStatus = "PARTIAL";
    syncMessage = "Biquote synced; Forex Factory enrichment unavailable, so Biquote data was retained.";
  }

  const std::string finishedAt = iso_now();
  if (!events.empty()) {
    if (!persist_database_events(events, startedAt, finishedAt, syncStatus, sourceName, syncMessage)) {
      std::cerr << "[Database] Gagal menyimpan snapshot kalender gabungan. Data tetap tersedia di memori.\n";
    }
  }

  std::lock_guard<std::mutex> lock(g_mutex);
  g_state.refreshing = false;
  if (!events.empty()) {
    g_state.events = std::move(events);
    g_state.source = sourceLabel;
    g_state.sourceState = biquoteEvents.empty() ? "FALLBACK" : "SYNCED";
    g_state.lastSuccess = finishedAt;
    g_state.lastError.clear();
    ++g_state.revision;
    std::cerr << "[Calendar] Synced " << g_state.events.size()
              << " merged USD events; source mode=" << g_state.sourceState
              << "; SSE revision " << g_state.revision << ".\n";
  } else {
    g_state.lastError = error;
    g_state.sourceState = g_state.events.empty() ? "ERROR" : "STALE";
    ++g_state.revision;
    std::cerr << "[Calendar] Sync failed: " << error << "\n";
  }
  g_cv.notify_all();
}
void initial_calendar_load() {
  if (initialize_database()) {
    auto cached = load_database_events();
    if (!cached.empty()) {
      std::lock_guard<std::mutex> lock(g_mutex);
      g_state.events = std::move(cached);
      g_state.source = "SQLite cache (Biquote + Forex Factory enrichment)";
      g_state.sourceState = "STALE";
      g_state.lastError = "Memuat cache lokal; sedang memeriksa Biquote dan data pelengkap Forex Factory.";
      ++g_state.revision;
      g_cv.notify_all();
      std::cerr << "[Database] Restored " << g_state.events.size() << " cached USD events.\n";
    }
  }
  refresh_calendar();
  const char* env = std::getenv("XZA_REFRESH_SECONDS");
  int refreshSeconds = kDefaultRefreshSeconds;
  if (env && *env) {
    try { refreshSeconds = std::clamp(std::stoi(env), 30, 300); } catch (...) {}
  }
  g_refresh_interval_seconds.store(refreshSeconds);
  std::cerr << "[Calendar] Biquote sync interval: " << refreshSeconds
            << " seconds; Forex Factory enrichment interval: "
            << forexfactory_refresh_seconds() << " seconds.\n";
  while (true) {
    std::unique_lock<std::mutex> lock(g_mutex);
    const bool signaled = g_cv.wait_for(lock, seconds{refreshSeconds}, [] { return g_stop || g_manual_sync_requested; });
    if (g_stop) break;
    if (signaled && g_manual_sync_requested) g_manual_sync_requested = false;
    lock.unlock();
    refresh_calendar();
  }
}

std::string status_json() {
  std::lock_guard<std::mutex> lock(g_mutex);
  return snapshot_json(g_state.events, g_state);
}
std::string mime_type(const std::string& path) {
  if (path.ends_with(".html")) return "text/html; charset=utf-8";
  if (path.ends_with(".js")) return "text/javascript; charset=utf-8";
  if (path.ends_with(".css")) return "text/css; charset=utf-8";
  if (path.ends_with(".svg")) return "image/svg+xml";
  if (path.ends_with(".png")) return "image/png";
  if (path.ends_with(".jpg") || path.ends_with(".jpeg")) return "image/jpeg";
  if (path.ends_with(".webp")) return "image/webp";
  if (path.ends_with(".ico")) return "image/x-icon";
  if (path.ends_with(".json")) return "application/json; charset=utf-8";
  return "application/octet-stream";
}
std::string read_file(const std::filesystem::path& p) {
  std::ifstream f(p, std::ios::binary);
  if (!f) return "";
  std::ostringstream s; s << f.rdbuf(); return s.str();
}
void send_http(tcp::socket& socket, const http::request<http::string_body>& req, http::status status, const std::string& body, const std::string& type = "application/json; charset=utf-8") {
  http::response<http::string_body> res{status, req.version()};
  res.set(http::field::server, "XZA-Calendar-Cpp");
  res.set(http::field::content_type, type);
  res.set(http::field::access_control_allow_origin, "*");
  res.set(http::field::access_control_allow_methods, "GET, POST, OPTIONS");
  res.set(http::field::access_control_allow_headers, "Content-Type");
  res.keep_alive(false);
  res.body() = body;
  res.prepare_payload();
  beast::error_code ec;
  http::write(socket, res, ec);
}

void handle_client(tcp::socket socket) {
  beast::flat_buffer buffer;
  http::request<http::string_body> req;
  beast::error_code ec;
  http::read(socket, buffer, req, ec);
  if (ec) return;
  const std::string target(req.target());
  const std::string method(req.method_string());
  const std::string path = target.substr(0, target.find('?'));
  const auto params = parse_query(target);
  ++g_requestCount;

  if (method == "OPTIONS") { send_http(socket, req, http::status::no_content, ""); return; }
  if (method == "GET" && path == "/api/health") {
    send_http(socket, req, http::status::ok, "{\"ok\":true,\"service\":\"xza-calendar-cpp\",\"time\":" + q(iso_now()) + "}"); return;
  }
  if (method == "GET" && path == "/api/status") { send_http(socket, req, http::status::ok, status_json()); return; }
  if (method == "POST" && path == "/api/sync") {
    {
      std::lock_guard<std::mutex> lock(g_mutex);
      g_manual_sync_requested = true;
    }
    g_cv.notify_all();
    send_http(socket, req, http::status::accepted, "{\"queued\":true,\"message\":\"Sinkronisasi manual masuk antrean.\"}"); return;
  }
  if (method == "GET" && path == "/api/calendar") {
    std::lock_guard<std::mutex> lock(g_mutex);
    auto filtered = filtered_events(g_state.events, params);
    send_http(socket, req, http::status::ok, snapshot_json(filtered, g_state)); return;
  }
  if (method == "GET" && path == "/api/calendar/stream") {
    const std::string headers = "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nCache-Control: no-cache, no-transform\r\nConnection: keep-alive\r\nAccess-Control-Allow-Origin: *\r\nX-Accel-Buffering: no\r\n\r\n";
    asio::write(socket, asio::buffer(headers), ec);
    if (ec) return;
    std::uint64_t lastRevision = std::numeric_limits<std::uint64_t>::max();
    auto lastHeartbeat = steady_clock::now();
    socket.non_blocking(false, ec);
    while (!ec) {
      std::string body;
      std::uint64_t rev;
      {
        std::lock_guard<std::mutex> lock(g_mutex);
        rev = g_state.revision;
        if (rev != lastRevision) {
          body = snapshot_json(filtered_events(g_state.events, params), g_state);
          lastRevision = rev;
        }
      }
      if (!body.empty()) {
        const std::string message = "data: " + body + "\n\n";
        asio::write(socket, asio::buffer(message), ec);
        if (ec) break;
      }
      if (steady_clock::now() - lastHeartbeat >= seconds{15}) {
        const std::string heartbeat = ": keep-alive\n\n";
        asio::write(socket, asio::buffer(heartbeat), ec);
        if (ec) break;
        lastHeartbeat = steady_clock::now();
      }
      if (!ec) {
        std::unique_lock<std::mutex> lock(g_mutex);
        g_cv.wait_for(lock, seconds{15}, [&] { return g_stop || g_state.revision != lastRevision; });
      }
    }
    return;
  }

  if (method == "GET") {
    std::string requested = path == "/" ? "/index.html" : path;
    if (requested.find("..") != std::string::npos || requested.find('\\') != std::string::npos) {
      send_http(socket, req, http::status::bad_request, "{\"error\":\"Invalid path\"}"); return;
    }
    const auto filePath = std::filesystem::path("dist") / requested.substr(1);
    const std::string body = read_file(filePath);
    if (!body.empty()) { send_http(socket, req, http::status::ok, body, mime_type(filePath.string())); return; }
    if (requested.find("/assets/") == 0) { send_http(socket, req, http::status::not_found, "Not found", "text/plain; charset=utf-8"); return; }
    const std::string index = read_file("dist/index.html");
    if (!index.empty()) { send_http(socket, req, http::status::ok, index, "text/html; charset=utf-8"); return; }
  }
  send_http(socket, req, http::status::not_found, "{\"error\":\"Not found\"}");
}
}

int main() {
  const char* envPort = std::getenv("XZA_PORT");
  if (!envPort) envPort = std::getenv("PORT");
  unsigned short port = 3000;
  if (envPort) { try { port = static_cast<unsigned short>(std::stoi(envPort)); } catch (...) {} }
  try {
    asio::io_context io{1};
    tcp::acceptor acceptor{io, tcp::endpoint{tcp::v4(), port}};
    std::thread initialLoad(initial_calendar_load);
    std::cerr << "[XZA Calendar] C++ server listening on 0.0.0.0:" << port << "\n";
    for (;;) {
      tcp::socket socket{io};
      acceptor.accept(socket);
      std::thread(handle_client, std::move(socket)).detach();
    }
    {
      std::lock_guard<std::mutex> lock(g_mutex); g_stop = true;
    }
    g_cv.notify_all();
    initialLoad.join();
  } catch (const std::exception& e) {
    std::cerr << "[Fatal] " << e.what() << "\n";
    return 1;
  }
  return 0;
}
