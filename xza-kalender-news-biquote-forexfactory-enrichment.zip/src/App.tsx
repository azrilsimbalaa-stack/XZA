import { useCallback, useEffect, useMemo, useState } from 'react';

type EconomicEvent = {
  id: string;
  title: string;
  currency: string;
  country: string;
  date: string;
  impact: 'HIGH' | 'MEDIUM' | 'LOW' | 'HOLIDAY' | string;
  importance: number;
  forecast: string;
  previous: string;
  actual: string | null;
  source: string;
  rawDate?: string;
  rawTime?: string;
  isReleased: boolean;
  status: 'RELEASED' | 'UPCOMING' | string;
  hasActual: boolean;
  deviation: number | null;
  macroCategory: string;
};

type Snapshot = {
  events: EconomicEvent[];
  result?: EconomicEvent[];
  revision: number;
  serverTime: string;
  source: string;
  sourceState: 'LIVE' | 'FALLBACK' | 'STALE' | 'ERROR' | 'CONNECTING' | string;
  lastSuccess: string | null;
  lastFetch: string | null;
  lastError: string | null;
  refreshing: boolean;
  stale: boolean;
  refreshIntervalSeconds: number;
  summary: {
    total: number;
    released: number;
    upcoming: number;
    highImpact: number;
    mediumImpact: number;
    lowImpact: number;
  };
};

type Filters = { currency: string; impact: string; status: string; window: string };
const EMPTY_SNAPSHOT: Snapshot = {
  events: [], revision: 0, serverTime: '', source: 'Belum terhubung', sourceState: 'CONNECTING',
  lastSuccess: null, lastFetch: null, lastError: null, refreshing: false, stale: true,
  refreshIntervalSeconds: 0,
  summary: { total: 0, released: 0, upcoming: 0, highImpact: 0, mediumImpact: 0, lowImpact: 0 },
};

function formatWitaDate(iso: string, withTime = true): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return 'Waktu tidak tersedia';
  return new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Makassar', weekday: 'short', day: '2-digit', month: 'short', year: 'numeric',
    ...(withTime ? { hour: '2-digit', minute: '2-digit', hour12: false } : {}),
  }).format(date).replace(' pukul ', ' · ');
}
function formatWitaTime(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '--:--';
  return new Intl.DateTimeFormat('id-ID', { timeZone: 'Asia/Makassar', hour: '2-digit', minute: '2-digit', hour12: false }).format(date);
}
function formatClock(date: Date): string {
  return new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Makassar', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  }).format(date);
}
function formatLastUpdate(iso: string | null): string {
  if (!iso) return 'Belum ada pembaruan sukses';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return 'Waktu tidak tersedia';
  return `${formatWitaDate(d.toISOString())} WITA`;
}
function impactClass(impact: string): string {
  if (impact === 'HIGH') return 'impact-high';
  if (impact === 'MEDIUM') return 'impact-medium';
  if (impact === 'HOLIDAY') return 'impact-holiday';
  return 'impact-low';
}
function stateLabel(state: string, stale: boolean): string {
  if (state === 'CONNECTING') return 'MENYAMBUNG';
  if (state === 'ERROR') return 'SUMBER ERROR';
  if (stale || state === 'STALE') return 'DATA LAMA';
  if (state === 'LIVE') return 'LIVE';
  if (state === 'SYNCED') return 'SYNC AKTIF';
  if (state === 'FALLBACK') return 'FALLBACK';
  if (state === 'SNAPSHOT') return 'BIQUOTE SNAPSHOT';
  return 'MENYAMBUNG';
}

export default function App() {
  const [snapshot, setSnapshot] = useState<Snapshot>(EMPTY_SNAPSHOT);
  const [filters, setFilters] = useState<Filters>({ currency: 'USD', impact: 'ALL', status: 'ALL', window: 'THIS_WEEK' });
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [clock, setClock] = useState(() => new Date());
  const [connectionError, setConnectionError] = useState('');

  useEffect(() => {
    const id = window.setTimeout(() => setSearch(searchInput.trim()), 220);
    return () => window.clearTimeout(id);
  }, [searchInput]);
  useEffect(() => {
    const id = window.setInterval(() => setClock(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const queryString = useMemo(() => {
    const p = new URLSearchParams();
    p.set('currency', filters.currency);
    p.set('impact', filters.impact);
    p.set('status', filters.status);
    p.set('window', filters.window);
    if (search) p.set('search', search);
    return p.toString();
  }, [filters, search]);

  useEffect(() => {
    let alive = true;
    let stream: EventSource | null = null;
    const applySnapshot = (incoming: Snapshot) => {
      if (!alive) return;
      setSnapshot(incoming);
      setConnectionError('');
    };
    const load = async () => {
      try {
        const response = await fetch(`/api/calendar?${queryString}`, { headers: { Accept: 'application/json' } });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        applySnapshot(await response.json() as Snapshot);
      } catch (error) {
        if (alive) setConnectionError(error instanceof Error ? error.message : 'Gagal memuat kalender');
      }
    };
    void load();
    stream = new EventSource(`/api/calendar/stream?${queryString}`);
    stream.onmessage = (event) => {
      try { applySnapshot(JSON.parse(event.data) as Snapshot); }
      catch { setConnectionError('Respons stream tidak valid'); }
    };
    stream.onerror = () => {
      if (alive) setConnectionError((old) => old || 'Stream terputus; mencoba menyambung kembali.');
    };
    return () => {
      alive = false;
      stream?.close();
    };
  }, [queryString]);

  const updateFilter = useCallback((key: keyof Filters, value: string) => {
    setFilters((old) => ({ ...old, [key]: value }));
  }, []);



  const stateText = stateLabel(snapshot.sourceState, snapshot.stale);
  const isConnected = (snapshot.sourceState === 'LIVE' || snapshot.sourceState === 'SYNCED') && !snapshot.stale;

  return (
    <main className="app-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <header className="topbar">
        <a className="brand" href="#top" aria-label="XZA Kalender News">
          <span className="brand-mark">X<span>ZA</span></span>
          <span className="brand-copy"><strong>ZRILL AI</strong><small>ECONOMIC NEWS TERMINAL</small></span>
        </a>
        <div className="topbar-right">
          <div className="source-links">
            <a className="source-link" href="https://biquote.io/docs/" target="_blank" rel="noreferrer">BIQUOTE DOCS <span aria-hidden="true">↗</span></a>
            <a className="source-link" href="https://www.forexfactory.com/calendar" target="_blank" rel="noreferrer">FOREX FACTORY <span aria-hidden="true">↗</span></a>
          </div>
          <div className="clock-box"><span className="clock-dot" /> <strong>{formatClock(clock)}</strong><span>WITA</span></div>
        </div>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-line" /> KALENDER EKONOMI USD</div>
          <h1>News <span>Terminal</span></h1>
          <p>Data rilis ekonomi, forecast, previous, dan actual dalam satu tampilan. Biquote menjadi sumber utama; Forex Factory melengkapi field atau event USD yang tidak tersedia. Data gabungan disimpan di SQLite dan perubahan dikirim ke UI melalui SSE tanpa reload.</p>
          <div className="source-meta">
            <span className={`state-pill ${isConnected ? 'state-live' : snapshot.stale ? 'state-stale' : 'state-muted'}`}><i />{stateText}</span>
            <span className="meta-divider" />
            <span className="source-name">{snapshot.source}</span>
            <span className="meta-divider" />
            <span>SQLITE + SSE · SINKRONISASI {snapshot.refreshIntervalSeconds} DETIK</span>
          </div>
        </div>
        <div className="hero-stamp" aria-hidden="true">
          <div className="stamp-orbit orbit-a" /><div className="stamp-orbit orbit-b" />
          <div className="stamp-core"><span>XZ</span><small>MACRO</small></div>
          <span className="stamp-label stamp-label-top">DATA STREAM</span><span className="stamp-label stamp-label-bottom">WITA · UTC+8</span>
        </div>
      </section>

      {connectionError && <div className="connection-banner"><span>!</span><div><strong>Koneksi data perlu diperiksa</strong><small>{connectionError}</small></div></div>}
      {snapshot.lastError && <div className="connection-banner warning-banner"><span>!</span><div><strong>Sumber utama gagal diperbarui</strong><small>{snapshot.lastError}</small></div></div>}

      <section className="stat-grid" aria-label="Ringkasan kalender">
        <article className="stat-card stat-total"><div className="stat-label">EVENT TERFILTER <span>01</span></div><strong>{snapshot.summary.total}</strong><small>Jumlah berita di tampilan ini</small><div className="stat-spark spark-a" /></article>
        <article className="stat-card"><div className="stat-label">HIGH IMPACT <span className="stat-bullet red" /></div><strong>{snapshot.summary.highImpact}</strong><small>Red folder · dampak tinggi</small><div className="stat-spark spark-b" /></article>
        <article className="stat-card"><div className="stat-label">MEDIUM IMPACT <span className="stat-bullet amber" /></div><strong>{snapshot.summary.mediumImpact}</strong><small>Orange folder · dampak menengah</small><div className="stat-spark spark-c" /></article>
        <article className="stat-card"><div className="stat-label">LOW IMPACT <span className="stat-bullet blue" /></div><strong>{snapshot.summary.lowImpact}</strong><small>Yellow folder · dampak rendah</small><div className="stat-spark spark-d" /></article>
      </section>

      <section className="calendar-panel">
        <div className="panel-heading">
          <div><div className="eyebrow"><span className="eyebrow-line" /> EVENT FEED</div><h2>Kalender <span>News</span></h2><p>Actual, forecast, dan previous ditampilkan apa adanya dari sumber; nilai yang tidak tersedia tidak dibuat-buat.</p></div>
          <div className={`sync-button ${isConnected ? '' : 'syncing'}`} aria-live="polite">
            <span className="sync-icon">{isConnected ? '●' : '↻'}</span>{snapshot.sourceState === 'SNAPSHOT' ? 'BIQUOTE SNAPSHOT' : isConnected ? 'STREAM TERHUBUNG' : 'MENUNGGU SUMBER'}
          </div>
        </div>

        <div className="filters-bar">
          <label className="search-field"><span className="search-icon">⌕</span><input value={searchInput} onChange={(e) => setSearchInput(e.target.value)} placeholder="Cari event atau mata uang…" aria-label="Cari event" /></label>
          <label className="filter-control"><span>MATA UANG</span><select value={filters.currency} onChange={(e) => updateFilter('currency', e.target.value)}><option>USD</option></select></label>
          <label className="filter-control"><span>DAMPAK</span><select value={filters.impact} onChange={(e) => updateFilter('impact', e.target.value)}><option value="ALL">Semua</option><option value="HIGH">High</option><option value="MEDIUM">Medium</option><option value="LOW">Low</option><option value="HOLIDAY">Holiday</option></select></label>
          <label className="filter-control"><span>STATUS</span><select value={filters.status} onChange={(e) => updateFilter('status', e.target.value)}><option value="ALL">Semua</option><option value="UPCOMING">Akan datang</option><option value="RELEASED">Waktu lewat / rilis</option></select></label>
          <label className="filter-control"><span>PERIODE WITA</span><select value={filters.window} onChange={(e) => updateFilter('window', e.target.value)}><option value="ALL">Semua waktu</option><option value="YESTERDAY">Kemarin</option><option value="TODAY">Hari ini</option><option value="TOMORROW">Besok</option><option value="THIS_WEEK">7 hari</option></select></label>
        </div>

        <div className="table-wrap">
          <table className="news-table">
            <thead><tr><th>TANGGAL / WITA</th><th>CCY</th><th>DAMPAK</th><th>EVENT EKONOMI</th><th>ACTUAL</th><th>FORECAST</th><th>PREVIOUS</th><th>STATUS DATA</th></tr></thead>
            <tbody>
              {snapshot.events.map((event) => (
                <tr key={event.id}>
                  <td className="date-cell"><strong>{formatWitaDate(event.date, false)}</strong><small>{formatWitaTime(event.date)} WITA</small></td>
                  <td><span className="currency-chip">{event.currency || '—'}</span></td>
                  <td><span className={`impact-tag ${impactClass(event.impact)}`}><i />{event.impact}</span></td>
                  <td className="event-cell"><strong>{event.title}</strong><small>{event.macroCategory.replaceAll('_', ' ')}</small></td>
                  <td><span className={`value-cell ${event.actual ? 'value-live' : ''}`}>{event.actual || '—'}</span></td>
                  <td className="number-cell">{event.forecast || '—'}</td>
                  <td className="number-cell">{event.previous || '—'}</td>
                  <td><span className={`event-status ${event.hasActual ? 'status-released' : event.isReleased ? 'status-late' : 'status-upcoming'}`}>{event.hasActual ? 'ACTUAL ADA' : event.isReleased ? 'WAKTU LEWAT' : 'UPCOMING'}</span><small className="source-note">{event.source}</small></td>
                </tr>
              ))}
              {snapshot.events.length === 0 && <tr><td colSpan={8} className="empty-cell"><div className="empty-symbol">⌁</div><strong>{snapshot.sourceState === 'CONNECTING' ? 'Menghubungkan sumber berita…' : 'Tidak ada event yang cocok'}</strong><span>{snapshot.sourceState === 'ERROR' ? 'Belum ada data di database lokal. Periksa koneksi sumber Biquote dan log backend.' : 'Ubah filter periode, mata uang, atau dampak untuk melihat event lain.'}</span></td></tr>}
            </tbody>
          </table>
        </div>
        <div className="table-footer"><span><i className="footer-live-dot" /> STREAM KALENDER AKTIF</span><span>{snapshot.events.length} event · terakhir sukses {formatLastUpdate(snapshot.lastSuccess)}</span></div>
      </section>

      <section className="bottom-grid">
        <article className="info-card"><div className="info-icon">↻</div><div><h3>Sinkronisasi berkelanjutan</h3><p>Backend C++ memeriksa Biquote setiap 30 detik secara default, menyimpan event ke SQLite, lalu mengirim snapshot terbaru lewat Server-Sent Events. UI diperbarui tanpa reload halaman; interval bisa diatur melalui XZA_REFRESH_SECONDS (30–300 detik).</p></div></article>
        <article className="info-card"><div className="info-icon info-icon-muted">i</div><div><h3>Transparansi sumber</h3><p>Jika sumber gagal, sistem mempertahankan cache SQLite terakhir dan menandai data sebagai lama. Data lama ditandai; nilai actual, forecast, atau previous yang tidak tersedia tidak direkayasa.</p></div></article>
      </section>
      <footer className="footer"><span>ZRILL AI <b>·</b> XZA CALENDAR</span><span>FEED: {snapshot.sourceState} <b>·</b> WITA UTC+8</span></footer>
    </main>
  );
}
