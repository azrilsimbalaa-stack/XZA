#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ -f .env ]]; then set -a; source .env; set +a; fi
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build -j2
XZA_PORT=8787 ./build/xza_calendar_server &
BACKEND_PID=$!
cleanup() {
  kill "$BACKEND_PID" 2>/dev/null || true
  wait "$BACKEND_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM
npx vite --host 0.0.0.0
