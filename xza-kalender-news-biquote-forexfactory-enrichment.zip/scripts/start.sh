#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ -f .env ]]; then set -a; source .env; set +a; fi
export XZA_PORT="${XZA_PORT:-${PORT:-3000}}"
exec ./build/xza_calendar_server
