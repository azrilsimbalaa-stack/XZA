#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ZRILL_CPP_PORT=3001 ./native/zrill_backend & BACKEND_PID=$!
cleanup() { kill "$BACKEND_PID" 2>/dev/null || true; wait "$BACKEND_PID" 2>/dev/null || true; }
trap cleanup EXIT INT TERM
npx vite --host 0.0.0.0
