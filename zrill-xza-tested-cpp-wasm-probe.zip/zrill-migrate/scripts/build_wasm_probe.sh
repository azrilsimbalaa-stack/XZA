#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
CXX_WASM="${CXX_WASM:-clang++}"
command -v "$CXX_WASM" >/dev/null 2>&1 || { echo "clang++ not found; install a Clang build with wasm32 target support." >&2; exit 1; }
mkdir -p native/wasm
"$CXX_WASM" --target=wasm32-unknown-unknown -std=c++20 -O2 -nostdlib \
  native/wasm/toolchain_probe.cpp \
  -Wl,--no-entry -Wl,--export=zrill_wasm_probe -Wl,--export-memory -Wl,--allow-undefined \
  -o native/wasm/toolchain_probe.wasm
node - <<'NODE'
const fs = require('fs');
const bytes = fs.readFileSync('native/wasm/toolchain_probe.wasm');
const module = new WebAssembly.Module(bytes);
const instance = new WebAssembly.Instance(module);
if (instance.exports.zrill_wasm_probe() !== 20261016) throw new Error('Unexpected WASM probe result');
console.log('PASS: C++ WASM toolchain compiles and Node loads the probe. This is not application logic.');
NODE
