#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p native
CXX="${CXX:-g++}"
PKG_CFLAGS="$(pkg-config --cflags libcurl sqlite3)"
PKG_LIBS="$(pkg-config --libs libcurl sqlite3)"
"$CXX" -std=c++20 -O2 -DNDEBUG native/forexfactory_scraper.cpp -o native/ff_scraper $PKG_CFLAGS $PKG_LIBS -pthread
"$CXX" -std=c++20 -O2 -DNDEBUG native/zrill_backend.cpp -o native/zrill_backend $PKG_CFLAGS $PKG_LIBS -pthread
printf 'Built C++ binaries: native/ff_scraper and native/zrill_backend\n'
