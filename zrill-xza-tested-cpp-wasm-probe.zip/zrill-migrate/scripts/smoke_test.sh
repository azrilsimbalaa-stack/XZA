#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PORT_TEST=3187
ZRILL_CPP_PORT="$PORT_TEST" ./native/zrill_backend >/tmp/zrill-xza-smoke.log 2>&1 & PID=$!
cleanup(){ kill "$PID" 2>/dev/null || true; wait "$PID" 2>/dev/null || true; }
trap cleanup EXIT
for _ in $(seq 1 30); do
  if curl -fsS --max-time 1 "http://127.0.0.1:$PORT_TEST/api/health" >/tmp/zrill-health.json 2>/dev/null; then break; fi
  sleep 0.2
done
grep -q '"runtime":"C++20"' /tmp/zrill-health.json
curl -fsS --max-time 2 "http://127.0.0.1:$PORT_TEST/api/calendar" >/tmp/zrill-calendar.json
grep -q '"result"' /tmp/zrill-calendar.json
curl -fsS --max-time 2 "http://127.0.0.1:$PORT_TEST/api/calendar/tier1-sniper" >/tmp/zrill-tier1.json
grep -q '"primaryTier1"' /tmp/zrill-tier1.json
printf 'PASS: C++ health, calendar contract, and tier-1 contract. Live upstream data is environment-dependent.\n'
