#!/usr/bin/env bash
# Broad regression smoke suite. It separates local contract tests from live-provider checks.
set -euo pipefail
cd "$(dirname "$0")/.."
PORT_TEST="${ZRILL_TEST_PORT:-3197}"
LOG="${TMPDIR:-/tmp}/zrill-xza-test-all.log"
BASE="http://127.0.0.1:${PORT_TEST}"
ZRILL_CPP_PORT="$PORT_TEST" ./native/zrill_backend >"$LOG" 2>&1 & PID=$!
cleanup(){ kill "$PID" 2>/dev/null || true; wait "$PID" 2>/dev/null || true; }
trap cleanup EXIT
for _ in $(seq 1 50); do
  if curl -fsS --max-time 1 "$BASE/api/health" >/tmp/zrill-test-health.json 2>/dev/null; then break; fi
  sleep 0.2
done
python3 - <<'PY'
import json
p='/tmp/zrill-test-health.json'
d=json.load(open(p))
assert d.get('status') == 'ok', d
assert d.get('runtime') == 'C++20', d
print('PASS health endpoint + runtime contract')
PY
curl -fsS --max-time 3 "$BASE/api/calendar" >/tmp/zrill-test-calendar.json
python3 - <<'PY'
import json
x=json.load(open('/tmp/zrill-test-calendar.json'))
assert isinstance(x.get('result'), list), x
assert 'source' in x and 'timestamp' in x, x
print('PASS calendar response contract (events=%d, source=%s)'%(len(x['result']),x['source']))
PY
curl -fsS --max-time 3 "$BASE/api/calendar/tier1-sniper" >/tmp/zrill-test-tier1.json
python3 - <<'PY'
import json
x=json.load(open('/tmp/zrill-test-tier1.json'))
assert isinstance(x.get('result'),list) and 'primaryTier1' in x, x
print('PASS Tier-1 calendar response contract (events=%d)'%len(x['result']))
PY
curl -fsS --max-time 3 "$BASE/api/tradingview/prices" >/tmp/zrill-test-prices.json
python3 - <<'PY'
import json
x=json.load(open('/tmp/zrill-test-prices.json'))
assert isinstance(x.get('prices'),dict) and 'source' in x, x
print('PASS price-adapter response contract (adapter only; no live socket)')
PY
for path in '/api/mcp/status' '/api/mcp/tools'; do curl -fsS --max-time 3 "$BASE$path" >/dev/null; echo "PASS local route responds: $path"; done
curl -fsS --max-time 3 -X POST -H 'Content-Type: application/json' -d '{"symbol":"BTCUSD","smcStructure":"BULLISH","currentPrice":"100"}' "$BASE/api/ai/analyze" >/tmp/zrill-test-analyze.json
python3 - <<'PY'
import json
x=json.load(open('/tmp/zrill-test-analyze.json'))
assert x.get('status')=='limited' and x.get('bias')=='BUY' and x.get('symbol')=='BTCUSD', x
print('PASS /api/ai/analyze contract only (LIMITED deterministic fallback, not original signal engine)')
PY
code=$(curl -sS --max-time 3 -o /tmp/zrill-test-auth.json -w '%{http_code}' "$BASE/api/auth/verify-membership" || true)
[[ "$code" == 501 ]] && echo 'KNOWN GAP: membership endpoint returns 501 (not migrated)' || { echo "FAIL unexpected membership status $code"; exit 1; }
code=$(curl -sS --max-time 3 -o /tmp/zrill-test-override.json -w '%{http_code}' "$BASE/api/override" || true)
[[ "$code" == 501 ]] && echo 'KNOWN GAP: override endpoint returns 501 (not migrated)' || { echo "FAIL unexpected override status $code"; exit 1; }
python3 - <<'PY'
import sqlite3, os
p='data/zrill_news.sqlite3'
assert os.path.exists(p), 'SQLite file was not created'
c=sqlite3.connect(p)
row=c.execute("select name from sqlite_master where type='table' and name='calendar_events'").fetchone()
assert row, 'calendar_events table missing'
print('PASS SQLite database initialization + calendar_events schema')
c.close()
PY
# A valid module must be loadable by the JS WebAssembly runtime; this is a toolchain probe only.
if [[ -f native/wasm/toolchain_probe.wasm ]]; then
  node - <<'NODE'
const fs=require('fs'); const b=fs.readFileSync('native/wasm/toolchain_probe.wasm');
const m=new WebAssembly.Module(b); const i=new WebAssembly.Instance(m);
if (i.exports.zrill_wasm_probe() !== 20261016) process.exit(1);
console.log('PASS WASM toolchain probe (not application logic)');
NODE
else
  echo 'SKIP WASM toolchain probe: module not built'
fi
printf '\nLOCAL CONTRACT TESTS PASSED. Live provider connectivity, UI build, and full feature parity are separate checks.\n'
