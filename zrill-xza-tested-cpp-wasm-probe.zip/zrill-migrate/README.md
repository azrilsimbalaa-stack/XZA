# Zrill XZA Calendar & News

## Native C++ Forex Factory scraper

- `native/forexfactory_scraper.cpp` is the native scraper implementation. It fetches the current and following Forex Factory calendar weeks, parses event rows, normalizes Eastern Time to UTC with EST/EDT rules, and emits the same event-field contract consumed by the existing server.
- The scraper persists snapshots to `data/zrill_news.sqlite3` (or `ZRILL_NEWS_DB` when set). SQLite WAL mode and upserts preserve `first_seen` while refreshing event values and `last_seen`.
- The Node/TypeScript server invokes `native/ff_scraper`; it no longer invokes Python. Biquote's public economic-calendar REST endpoint is now queried as an independent backup/supplement. Forex Factory remains the primary source; when its native scrape fails, the server tries the Fair Economy CDN and merges Biquote events without exact duplicates. Biquote events are tagged separately so they are not mislabeled as official Forex Factory records.
- The internal `/api/calendar/stream` endpoint delivers calendar snapshots and `news` events to the UI through Server-Sent Events. Calendar data is still fetched from upstream sources on the server refresh cadence; this does not turn the economic calendar REST endpoints into a true upstream push/WebSocket feed.

## Build and run

Requirements: Node.js/npm, a C++20 compiler (`g++` or compatible), `pkg-config`, libcurl development headers, and SQLite3 development headers.

- `npm install`
- `npm run native:build` (compile scraper manually; `predev` and `prebuild` also run it)
- `npm run dev`

## Migration status

The React/TypeScript UI remains unchanged as requested. The Forex Factory scraper is now C++, but this archive is **not yet a full C++ conversion**: the Express compatibility server, signal-analysis engines, calendar enrichment logic, and several client-side calculations remain TypeScript. Those components require separate behavior-parity ports and tests before they can be removed safely. C++ cannot directly replace React browser components; keeping the presentation layer in TypeScript is intentional.


## C++ backend migration (in progress)

The archive now includes `native/zrill_backend.cpp`, a C++20 HTTP backend using Boost.Beast/Boost.JSON, libcurl and SQLite. It exposes the health check, calendar endpoint, SSE calendar stream, Biquote + Forex Factory/CDN collection, calendar deduplication and SQLite persistence, plus adapters for several market-data endpoints. The Vite dev server proxies `/api` to port 3001; run `npm run dev`. For production, run `npm run build` then `npm start`. Build requirements: g++, Boost headers including Boost.JSON headers, pkg-config, libcurl and SQLite development headers.

**Migration status is not yet complete.** The React/TypeScript presentation remains, as requested, but `src/services/*`, parts of `src/App.tsx`, several component calculations, Firebase client operations and some legacy server routes still contain TypeScript business logic. The current C++ backend does not yet reproduce the full precision-signal engine, complete economic-event enrichment, Firebase membership/authentication, MCP chart-control integration or the original TradingView WebSocket feed. The C++ `/api/ai/analyze` route is explicitly a limited deterministic fallback, not equivalent to the original signal engine. Do not use this archive as proof of full behavior parity or for live trading until those components are ported and tested.

## Verification and WebAssembly

Run `bash scripts/test_all.sh` for broad local contract checks. See `TEST_REPORT.md` for the observed pass/fail/blocked status. The C++ WebAssembly files under `native/wasm/` are a **toolchain probe only**, not application logic. WebAssembly can be used later for portable, CPU-bound analytics after those algorithms have been ported from TypeScript to C++ and checked for output parity. The native HTTP server and its libcurl/SQLite/network dependencies should remain a server-side C++ binary.
