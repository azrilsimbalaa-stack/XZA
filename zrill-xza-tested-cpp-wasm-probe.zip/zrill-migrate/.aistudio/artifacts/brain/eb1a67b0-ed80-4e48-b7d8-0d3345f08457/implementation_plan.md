# Implementation Plan - Clean Up Unused Logic in App.tsx

## Goal
Remove unused state variables, helper functions, and effect hooks related to trading charts, technical indicators (RSI, EMA, SMA, Stochastic, ATR, Bollinger Bands, SMC chart analysis), and signal generation, while strictly preserving 100% of the economic calendar logic, Forex Factory API scrapers, WITA time sync, and calendar event filters.

## Proposed Changes

### `src/App.tsx`
- Remove unused technical indicator helper functions (`calculateSMA`, `calculateEMA`, `calculateRSI`, `calculateATR`, `calculateBollingerBands`, `calculateADX`, `detectRSIDivergence`, `detectCandlePattern`, `analyzeSMC`).
- Remove unused chart and trading state variables (activeSymbol, activeTimeframe, tradingStyle, signalMethod, indicators, currentPrice, htfData, ltfData, sessionTrades, etc.).
- Remove unused effect hooks and API fetch loops for TradingView price klines.
- Preserve 100% of economic calendar state variables (`economicEvents`, `calendarStats`, `calendarHorizonLists`, `filteredCalendarEvents`, `fetchCalendar`, `handleSyncForexFactoryNow`, `spikeNotificationEnabled`, `tier1Alert`, etc.).
- Verify build and compilation with `compile_applet` and `lint_applet`.

## Verification Plan
- Run `compile_applet` and `lint_applet` to ensure zero compilation or TypeScript errors.
- Confirm calendar functionality, Forex Factory scraping, and Tier-1 news radar operate perfectly.
