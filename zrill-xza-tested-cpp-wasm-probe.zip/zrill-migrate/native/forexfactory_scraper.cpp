#include <curl/curl.h>
#include <sqlite3.h>
#include <algorithm>
#include <chrono>
#include <cctype>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <iostream>
#include <map>
#include <regex>
#include <set>
#include <sstream>
#include <string>
#include <vector>

struct Event { std::map<std::string,std::string> fields; int importance = -1; bool actual_null = true; };
static std::string esc(const std::string& s) { std::string o; for(unsigned char c:s){switch(c){case '\\':o+="\\\\";break;case '\"':o+="\\\"";break;case '\n':o+="\\n";break;case '\r':o+="\\r";break;case '\t':o+="\\t";break;default:if(c>=32)o+=(char)c;}}return o;}
static std::string serialize(const Event& e) { std::ostringstream o;o<<"{";bool first=true;for(auto&kv:e.fields){if(!first)o<<",";first=false;o<<"\""<<esc(kv.first)<<"\":";if(kv.first=="actual"&&e.actual_null)o<<"null";else if(kv.first=="importance")o<<e.importance;else if((kv.first=="isForexFactoryOfficial"||kv.first=="isForexFactoryCalibrated")&&kv.second=="true")o<<"true";else o<<"\""<<esc(kv.second)<<"\"";}o<<"}";return o.str(); }
static size_t write_cb(char* ptr, size_t size, size_t nmemb, void* userdata) {
  auto* out = static_cast<std::string*>(userdata); out->append(ptr, size * nmemb); return size * nmemb;
}
static std::string fetch_html(const std::string& week) {
  CURL* c = curl_easy_init(); if (!c) return {};
  std::string body; std::string url = "https://www.forexfactory.com/calendar?week=" + week;
  curl_easy_setopt(c, CURLOPT_URL, url.c_str());
  curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, 1L); curl_easy_setopt(c, CURLOPT_TIMEOUT, 18L);
  curl_easy_setopt(c, CURLOPT_CONNECTTIMEOUT, 8L); curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, write_cb); curl_easy_setopt(c, CURLOPT_WRITEDATA, &body);
  curl_easy_setopt(c, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/129.0 Safari/537.36");
  curl_easy_setopt(c, CURLOPT_ACCEPT_ENCODING, "");
  CURLcode rc = curl_easy_perform(c); long status = 0; curl_easy_getinfo(c, CURLINFO_RESPONSE_CODE, &status); curl_easy_cleanup(c);
  return (rc == CURLE_OK && status >= 200 && status < 300) ? body : std::string{};
}
static std::string lower(std::string s) { std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return std::tolower(c);}); return s; }
static std::string trim(std::string s) { auto a=s.find_first_not_of(" \t\r\n"); if(a==std::string::npos)return {}; auto b=s.find_last_not_of(" \t\r\n"); return s.substr(a,b-a+1); }
static std::string html_text(std::string s) {
  s = std::regex_replace(s, std::regex("<script[^>]*>[\\s\\S]*?</script>", std::regex::icase), " ");
  s = std::regex_replace(s, std::regex("<style[^>]*>[\\s\\S]*?</style>", std::regex::icase), " ");
  s = std::regex_replace(s, std::regex("<[^>]+>"), " ");
  const std::vector<std::pair<std::string,std::string>> entities={{"&nbsp;"," "},{"&amp;","&"},{"&quot;","\""},{"&#39;","'"},{"&lt;","<"},{"&gt;",">"}};
  for (auto& e:entities) { size_t p=0; while((p=s.find(e.first,p))!=std::string::npos){s.replace(p,e.first.size(),e.second);p+=e.second.size();} }
  return trim(std::regex_replace(s,std::regex("\\s+")," "));
}
static int nth_sunday(int year, int month, int nth) {
  std::tm t{}; t.tm_year=year-1900; t.tm_mon=month-1; t.tm_mday=1; std::mktime(&t);
  int first_sunday = 1 + ((7 - t.tm_wday) % 7); return first_sunday + 7*(nth-1);
}
static bool is_dst_eastern(int y,int m,int d,int h) {
  if(m<3||m>11)return false; if(m>3&&m<11)return true;
  if(m==3){int start=nth_sunday(y,3,2);return d>start||(d==start&&h>=2);} 
  int end=nth_sunday(y,11,1);return d<end||(d==end&&h<2);
}
static std::string iso_date(const std::string& date, const std::string& time) {
  static const std::map<std::string,int> months={{"jan",1},{"feb",2},{"mar",3},{"apr",4},{"may",5},{"jun",6},{"jul",7},{"aug",8},{"sep",9},{"oct",10},{"nov",11},{"dec",12}};
  std::smatch dm, tm; std::regex dr("(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\\s*(\\d+)",std::regex::icase), tr("(\\d+)(?::(\\d+))?\\s*(am|pm)",std::regex::icase);
  if(!std::regex_search(date,dm,dr)) return "";
  int mo=months.at(lower(dm[1].str())), day=std::stoi(dm[2].str()), hour=12, minute=0;
  if(std::regex_search(time,tm,tr)){hour=std::stoi(tm[1].str());minute=tm[2].matched?std::stoi(tm[2].str()):0;std::string ap=lower(tm[3].str());if(ap=="pm"&&hour<12)hour+=12;if(ap=="am"&&hour==12)hour=0;}
  std::time_t now=std::time(nullptr); std::tm et{}; gmtime_r(&now,&et); int y=et.tm_year+1900;
  // Estimate current Eastern date/year; choosing among adjacent years handles calendar weeks crossing New Year.
  int best_year=y; long long best=LLONG_MAX;
  for(int cy=y-1;cy<=y+1;++cy){std::tm x{};x.tm_year=cy-1900;x.tm_mon=mo-1;x.tm_mday=day;x.tm_hour=hour;x.tm_min=minute;std::time_t local_as_utc=timegm(&x);int offset=is_dst_eastern(cy,mo,day,hour)?-4:-5;std::time_t utc=local_as_utc-offset*3600;long long delta=std::llabs((long long)(utc-now));if(delta<best){best=delta;best_year=cy;}}
  std::tm x{};x.tm_year=best_year-1900;x.tm_mon=mo-1;x.tm_mday=day;x.tm_hour=hour;x.tm_min=minute;std::time_t local_as_utc=timegm(&x);int offset=is_dst_eastern(best_year,mo,day,hour)?-4:-5;std::time_t utc=local_as_utc-offset*3600;std::tm out{};gmtime_r(&utc,&out);char buf[32];std::strftime(buf,sizeof(buf),"%Y-%m-%dT%H:%M:%S.000Z",&out);return buf;
}
static std::vector<Event> parse_week(const std::string& week) {
  std::string html=fetch_html(week); if(html.empty()) return {};
  std::regex row_re("<tr\\b(?=[^>]*\\bdata-event-id=[\\\"'](\\d+)[\\\"'])[^>]*>([\\s\\S]*?)</tr>",std::regex::icase);
  std::regex cell_re("<td\\b(?=[^>]*\\bclass=[\\\"']([^\\\"']*)[\\\"'])[^>]*>([\\s\\S]*?)</td>",std::regex::icase);
  std::vector<Event> out; std::string curr_date,curr_time; auto ri=std::sregex_iterator(html.begin(),html.end(),row_re), end=std::sregex_iterator();
  const std::map<std::string,std::string> countries={{"USD","US"},{"EUR","EU"},{"GBP","GB"},{"JPY","JP"},{"AUD","AU"},{"CAD","CA"},{"CHF","CH"},{"NZD","NZ"},{"CNY","CN"}};
  for(;ri!=end;++ri){std::string id=(*ri)[1].str(), content=(*ri)[2].str();std::map<std::string,std::string> fields;std::string impact_code="yel";
    auto ci=std::sregex_iterator(content.begin(),content.end(),cell_re);for(;ci!=end;++ci){std::string cls=(*ci)[1].str(), val=(*ci)[2].str(), lc=lower(cls);for(const auto& k:{"date","time","currency","impact","event","actual","forecast","previous"}) if(lc.find(std::string("calendar__")+k)!=std::string::npos){fields[k]=html_text(val);if(std::string(k)=="impact"){std::smatch im;if(std::regex_search(val,im,std::regex("icon--ff-impact-([a-z]+)",std::regex::icase)))impact_code=lower(im[1].str());}}}
    if(fields.count("date")&&!fields["date"].empty())curr_date=fields["date"];else fields["date"]=curr_date;
    if(fields.count("time")&&!fields["time"].empty())curr_time=fields["time"];else fields["time"]=curr_time;
    if(fields["date"].empty())continue;
    std::string curr=fields.count("currency")?fields["currency"]:"USD";curr=curr.empty()?"USD":curr;std::transform(curr.begin(),curr.end(),curr.begin(),::toupper);
    std::string impact="LOW",folder="YELLOW_FOLDER",label="FOREX FACTORY LOW IMPACT (YELLOW FOLDER)";int importance=-1;
    if(impact_code=="red"){impact="HIGH";folder="RED_FOLDER";label="FOREX FACTORY HIGH IMPACT (RED FOLDER)";importance=1;}else if(impact_code=="ora"){impact="MEDIUM";folder="ORANGE_FOLDER";label="FOREX FACTORY MEDIUM IMPACT (ORANGE FOLDER)";importance=0;}else if(impact_code=="gra"){impact="HOLIDAY";folder="GRAY_FOLDER";label="FOREX FACTORY HOLIDAY (GRAY FOLDER)";importance=-1;}
    Event ev;ev.importance=importance;ev.actual_null=!(fields.count("actual")&&!fields["actual"].empty());ev.fields={{"id","ff-"+id},{"eventId",id},{"title",(fields.count("event")&&!fields["event"].empty())?fields["event"]:"Economic Event"},{"currency",curr},{"country",countries.count(curr)?countries.at(curr):"US"},{"date",iso_date(fields["date"],fields["time"])},{"rawDate",fields["date"]},{"rawTime",fields["time"]},{"impact",impact},{"importance",std::to_string(importance)},{"forexFactoryImpact",impact},{"forexFactoryFolder",folder},{"forexFactoryLabel",label},{"forecast",(fields.count("forecast")&&!fields["forecast"].empty())?fields["forecast"]:"---"},{"previous",(fields.count("previous")&&!fields["previous"].empty())?fields["previous"]:"---"},{"actual",ev.actual_null?"":fields["actual"]},{"source","Forex Factory Official (https://www.forexfactory.com/calendar)"},{"isForexFactoryOfficial","true"},{"isForexFactoryCalibrated","true"}};out.push_back(std::move(ev));
  }
  return out;
}
static bool persist(const std::vector<Event>& events) {
  const char* env=std::getenv("ZRILL_NEWS_DB");std::string dbpath=env?env:"data/zrill_news.sqlite3";std::filesystem::path p(dbpath);if(p.has_parent_path())std::filesystem::create_directories(p.parent_path());
  sqlite3* db=nullptr;if(sqlite3_open_v2(dbpath.c_str(),&db,SQLITE_OPEN_READWRITE|SQLITE_OPEN_CREATE|SQLITE_OPEN_FULLMUTEX,nullptr)!=SQLITE_OK){if(db)sqlite3_close(db);return false;}
  char* err=nullptr;const char* schema="PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS calendar_events(id TEXT PRIMARY KEY,event_id TEXT,title TEXT NOT NULL,currency TEXT,country TEXT,event_date TEXT,raw_date TEXT,raw_time TEXT,impact TEXT,importance INTEGER,forecast TEXT,previous_value TEXT,actual TEXT,source TEXT,payload_json TEXT NOT NULL,first_seen TEXT NOT NULL,last_seen TEXT NOT NULL);";
  if(sqlite3_exec(db,schema,nullptr,nullptr,&err)!=SQLITE_OK){sqlite3_free(err);sqlite3_close(db);return false;}
  sqlite3_stmt* st=nullptr;const char* sql="INSERT INTO calendar_events(id,event_id,title,currency,country,event_date,raw_date,raw_time,impact,importance,forecast,previous_value,actual,source,payload_json,first_seen,last_seen) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET event_id=excluded.event_id,title=excluded.title,currency=excluded.currency,country=excluded.country,event_date=excluded.event_date,raw_date=excluded.raw_date,raw_time=excluded.raw_time,impact=excluded.impact,importance=excluded.importance,forecast=excluded.forecast,previous_value=excluded.previous_value,actual=excluded.actual,source=excluded.source,payload_json=excluded.payload_json,last_seen=excluded.last_seen;";
  if(sqlite3_prepare_v2(db,sql,-1,&st,nullptr)!=SQLITE_OK){sqlite3_close(db);return false;}std::time_t now=std::time(nullptr);char tbuf[32];std::strftime(tbuf,sizeof(tbuf),"%Y-%m-%dT%H:%M:%SZ",std::gmtime(&now));
  for(const auto&e:events){std::string payload=serialize(e);auto get=[&](const char*k)->std::string{auto it=e.fields.find(k);return it!=e.fields.end()?it->second:std::string();};
    std::vector<std::string> vals={get("id"),get("eventId"),get("title"),get("currency"),get("country"),get("date"),get("rawDate"),get("rawTime"),get("impact"),"",get("forecast"),get("previous"),get("actual"),get("source"),payload,tbuf,tbuf};
    for(int i=0;i<17;++i){if(i==9)sqlite3_bind_int(st,i+1,e.importance);else sqlite3_bind_text(st,i+1,vals[i].c_str(),-1,SQLITE_TRANSIENT);}sqlite3_step(st);sqlite3_reset(st);sqlite3_clear_bindings(st);
  }
  sqlite3_finalize(st);sqlite3_close(db);return true;
}
int main(int argc,char**argv){curl_global_init(CURL_GLOBAL_DEFAULT);bool next=false;for(int i=1;i<argc;++i)if(std::string(argv[i])=="--include-next")next=true;std::vector<Event> events;std::set<std::string> seen;for(const auto&w:(next?std::vector<std::string>{"this","next"}:std::vector<std::string>{"this"})){auto part=parse_week(w);for(auto&e:part){std::string id=e.fields.at("id");if(seen.insert(id).second)events.push_back(std::move(e));}}
  if(!events.empty()&&!persist(events))std::cerr<<"SQLite persistence failed\n";std::cout<<"[";for(size_t i=0;i<events.size();++i){if(i)std::cout<<",";std::cout<<serialize(events[i]);}std::cout<<"]"<<std::endl;curl_global_cleanup();return events.empty()?2:0;}
