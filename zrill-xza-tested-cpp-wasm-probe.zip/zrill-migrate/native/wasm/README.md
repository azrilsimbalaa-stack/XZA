# C++ WebAssembly status

`toolchain_probe.cpp` and `toolchain_probe.wasm` only verify that this environment can compile and load a minimal C++ WebAssembly module with Clang + wasm-ld. The probe is not connected to the React UI and does not contain Zrill business logic.

The current backend (`native/zrill_backend.cpp`) cannot be compiled directly into a browser `.wasm` module: it is a native HTTP server and depends on Boost.Asio/Beast, libcurl, and SQLite. Those server/network/database responsibilities should remain native C++ on the server. WebAssembly is suitable for pure, CPU-bound calculations that run in the browser, after the existing TypeScript business algorithms have been ported to a portable C++ core and regression-tested against the original outputs.

Emscripten (`emcc`) is not installed in this environment. The probe was compiled with `clang++ --target=wasm32-unknown-unknown -nostdlib` and validated with Node's `WebAssembly` runtime. Do not treat it as a production engine or performance optimization.
