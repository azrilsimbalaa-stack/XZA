// Toolchain-only probe. This is NOT application logic and is not used by the UI.
extern "C" __attribute__((visibility("default"))) int zrill_wasm_probe() {
  return 20261016;
}
