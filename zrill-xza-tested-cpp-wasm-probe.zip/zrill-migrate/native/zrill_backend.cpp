#include <boost/asio.hpp>
#include <boost/beast.hpp>
#include <boost/json.hpp>
#include <boost/json/src.hpp>
#include <curl/curl.h>
#include <sqlite3.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <mutex>
#include <regex>
#include <set>
#include <cctype>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

namespace asio = boost::asio;
namespace beast = boost::beast;
namespace http = beast::http;
namespace json = boost::json;
using tcp = asio::ip::tcp;
using namespace std::chrono_literals;

static std::mutex g_mutex;
static std::mutex g_refresh_mutex;
static json::array g_calendar;
static std::string g_calendar_source = "cache";
static std::atomic<long long> g_calendar_updated{0};
static std::atomic<bool> g_running{true};
static sqlite3* g_db = nullptr;

static size_t curl_write(char* p, size_t s, size_t n, void* out) {
  static_cast<std::string*>(out)->append(p, s*n); return s*n;
}
static std::string http_get(const std::string& url, long timeout_ms=6500, const std::string& accept="application/json") {
  CURL* c = curl_easy_init(); if (!c) return {};
  std::string body;
  struct curl_slist* headers=nullptr;
  headers=curl_slist_append(headers, ("Accept: "+accept).c_str());
  headers=curl_slist_append(headers, "User-Agent: Zrill-XZA/2.0 (calendar-backend)");
  curl_easy_setopt(c,CURLOPT_URL,url.c_str()); curl_easy_setopt(c,CURLOPT_HTTPHEADER,headers);
  curl_easy_setopt(c,CURLOPT_WRITEFUNCTION,curl_write); curl_easy_setopt(c,CURLOPT_WRITEDATA,&body);
  curl_easy_setopt(c,CURLOPT_FOLLOWLOCATION,1L); curl_easy_setopt(c,CURLOPT_TIMEOUT_MS,timeout_ms);
  curl_easy_setopt(c,CURLOPT_CONNECTTIMEOUT_MS,3500L); curl_easy_setopt(c,CURLOPT_NOSIGNAL,1L);
  long status=0; CURLcode rc=curl_easy_perform(c); curl_easy_getinfo(c,CURLINFO_RESPONSE_CODE,&status);
  curl_slist_free_all(headers); curl_easy_cleanup(c);
  return (rc==CURLE_OK && status>=200 && status<300) ? body : std::string{};
}
static std::string str(const json::value& v, const std::string& fallback="") {
  if (v.is_string()) return std::string(v.as_string());
  if (v.is_int64()) return std::to_string(v.as_int64());
  if (v.is_uint64()) return std::to_string(v.as_uint64());
  if (v.is_double()) return std::to_string(v.as_double());
  if (v.is_bool()) return v.as_bool()?"true":"false";
  return fallback;
}
static std::string getstr(const json::object& o, const char* key, const std::string& fallback="") {
  auto it=o.find(key); return it==o.end()?fallback:str(it->value(),fallback);
}
static json::value parse_json(const std::string& s) {
  if(s.empty()) return nullptr;
  try { return json::parse(s); } catch(...) { return nullptr; }
}
static void db_exec(const char* sql) { if(g_db) sqlite3_exec(g_db,sql,nullptr,nullptr,nullptr); }
static void persist_calendar(const json::array& arr) {
  if(!g_db) return;
  std::lock_guard<std::mutex> lock(g_mutex);
  sqlite3_exec(g_db,"BEGIN IMMEDIATE",nullptr,nullptr,nullptr);
  sqlite3_stmt* st=nullptr;
  const char* sql="INSERT INTO calendar_events(id,event_id,title,currency,country,event_date,raw_date,raw_time,impact,importance,forecast,previous_value,actual,source,payload_json,first_seen,last_seen) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET event_id=excluded.event_id,title=excluded.title,currency=excluded.currency,country=excluded.country,event_date=excluded.event_date,raw_date=excluded.raw_date,raw_time=excluded.raw_time,impact=excluded.impact,importance=excluded.importance,forecast=excluded.forecast,previous_value=excluded.previous_value,actual=excluded.actual,source=excluded.source,payload_json=excluded.payload_json,last_seen=excluded.last_seen";
  if(sqlite3_prepare_v2(g_db,sql,-1,&st,nullptr)==SQLITE_OK){
    for(const auto& v:arr){ if(!v.is_object()) continue; const auto& o=v.as_object();
      std::string payload=json::serialize(v), id=getstr(o,"id"), event_id=getstr(o,"eventId",id), title=getstr(o,"title"), currency=getstr(o,"currency"), country=getstr(o,"country"), date=getstr(o,"date"), raw_date=getstr(o,"rawDate"), raw_time=getstr(o,"rawTime"), imp=getstr(o,"forexFactoryImpact",getstr(o,"impact")), importance=getstr(o,"importance","0"), forecast=getstr(o,"forecast"), previous=getstr(o,"previous"), actual=getstr(o,"actual"), source=getstr(o,"source");
      std::string nowstr=std::to_string(std::chrono::system_clock::to_time_t(std::chrono::system_clock::now()));
      sqlite3_reset(st); sqlite3_clear_bindings(st);
      const std::string vals[]={id,event_id,title,currency,country,date,raw_date,raw_time,imp,importance,forecast,previous,actual,source,payload,nowstr,nowstr};
      for(int i=0;i<17;i++) sqlite3_bind_text(st,i+1,vals[i].c_str(),-1,SQLITE_TRANSIENT);
      sqlite3_step(st);
    }
    sqlite3_finalize(st);
  }
  sqlite3_exec(g_db,"COMMIT",nullptr,nullptr,nullptr);
}
static json::array normalize_biquote(const json::value& raw) {
  json::array out; if(!raw.is_array()) return out;
  for(const auto& v:raw.as_array()) {
    if(!v.is_object()) continue; const auto& o=v.as_object();
    std::string title=getstr(o,"name",getstr(o,"title","Economic event"));
    std::string currency=getstr(o,"currency",getstr(o,"countryCode","USD"));
    std::transform(currency.begin(),currency.end(),currency.begin(),::toupper);
    std::string date=getstr(o,"time",getstr(o,"date",getstr(o,"datetime")));
    if(date.empty()) continue;
    std::string rawimp=getstr(o,"importance","low"); std::transform(rawimp.begin(),rawimp.end(),rawimp.begin(),::tolower);
    int imp=rawimp=="high"?1:rawimp=="medium"?0:-1;
    std::string id="biquote-"+getstr(o,"id",currency+"-"+title+"-"+date);
    for(char& c:id) if(!(std::isalnum((unsigned char)c)||c=='_'||c=='-')) c='-';
    json::object e{{"id",id},{"title",title},{"currency",currency},{"country",getstr(o,"countryCode",currency)},{"date",date},{"impact",std::string(rawimp.size()?rawimp:"low")},{"forexFactoryImpact",imp==1?"HIGH":imp==0?"MEDIUM":"LOW"},{"forexFactoryFolder",imp==1?"RED_FOLDER":imp==0?"ORANGE_FOLDER":"YELLOW_FOLDER"},{"forexFactoryLabel","["+rawimp+"] BIQUOTE ECONOMIC CALENDAR"},{"importance",imp},{"forecast",getstr(o,"forecast","---")},{"previous",getstr(o,"previous","---")},{"actual",o.contains("actual")?o.at("actual"):json::value(nullptr)},{"source","Biquote Economic Calendar (https://biquote.io/docs/)"},{"isBiquote",true},{"isForexFactoryOfficial",false},{"isForexFactoryCalibrated",false},{"timeMode",getstr(o,"timeMode","exact")}};
    out.push_back(e);
  } return out;
}
static std::string key_for(const json::value& v) {
  if(!v.is_object()) return {};
  auto& o=v.as_object(); std::string title=getstr(o,"title",getstr(o,"name"));
  std::transform(title.begin(),title.end(),title.begin(),[](unsigned char c){return std::isalnum(c)?std::tolower(c):' ';});
  std::string currency=getstr(o,"currency",getstr(o,"country"));
  std::string date=getstr(o,"date",getstr(o,"time"));
  return currency+"|"+title+"|"+date;
}
static json::array merge_arrays(const json::array& a, const json::array& b) {
  json::array out=a; std::set<std::string> keys;
  for(const auto& v:out) keys.insert(key_for(v));
  for(const auto& v:b) if(keys.insert(key_for(v)).second) out.push_back(v);
  return out;
}
static json::array scrape_ff_native() {
  std::string cmd="./native/ff_scraper --include-next 2>/dev/null";
  FILE* p=popen(cmd.c_str(),"r"); if(!p) return {};
  std::string out; char buf[4096]; while(fgets(buf,sizeof(buf),p)) out+=buf; int rc=pclose(p);
  if(rc!=0) return {}; auto parsed=parse_json(out); if(!parsed.is_array()) return {}; return parsed.as_array();
}
static void refresh_calendar(bool force=false) {
  std::unique_lock<std::mutex> refresh_lock(g_refresh_mutex, std::try_to_lock);
  if (!refresh_lock.owns_lock()) return;
  long long now=std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count();
  if(!force && now-g_calendar_updated.load()<45) return;
  json::array ff=scrape_ff_native();
  if(ff.empty()) { auto cdn=parse_json(http_get("https://nfs.faireconomy.media/ff_calendar_thisweek.json",4000)); if(cdn.is_array()) ff=cdn.as_array(); }
  auto tnow=std::chrono::system_clock::now(); auto from=std::chrono::system_clock::to_time_t(tnow-24h); auto to=std::chrono::system_clock::to_time_t(tnow+14*24h);
  auto iso=[](std::time_t t){ char b[40]; std::tm tm{}; gmtime_r(&t,&tm); std::strftime(b,sizeof(b),"%Y-%m-%dT%H:%M:%SZ",&tm); return std::string(b); };
  std::string url="https://biquote.io/api/calendar?from="+iso(from)+"&to="+iso(to)+"&limit=500";
  auto braw=parse_json(http_get(url)); auto biquote=normalize_biquote(braw);
  auto combined=merge_arrays(ff,biquote);
  if(!combined.empty()) { {std::lock_guard<std::mutex> lock(g_mutex); g_calendar=combined; g_calendar_source=ff.empty()?"Biquote Economic Calendar":"Forex Factory + Biquote backup";} persist_calendar(combined); }
  g_calendar_updated=now;
}
static json::value calendar_value() { std::lock_guard<std::mutex> lock(g_mutex); return json::object{{"events",g_calendar},{"source",g_calendar_source},{"timestamp",std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count()}}; }
static json::value fetch_news_payload() {
  json::array cryptoNews, forexNews; int bull=0, bear=0;
  auto crypto=parse_json(http_get("https://min-api.cryptocompare.com/data/v2/news/?lang=EN",1800));
  if(crypto.is_object() && crypto.as_object().contains("Data") && crypto.as_object().at("Data").is_array()) {
    for(const auto& item:crypto.as_object().at("Data").as_array()) {
      if(!item.is_object() || cryptoNews.size()>=10) continue; const auto& o=item.as_object();
      std::string title=getstr(o,"title"), body=getstr(o,"body",title), text=title+" "+body, low=text;
      std::transform(low.begin(),low.end(),low.begin(),[](unsigned char c){return std::tolower(c);});
      bool up=low.find("bull")!=std::string::npos||low.find("soar")!=std::string::npos||low.find("gain")!=std::string::npos||low.find("surge")!=std::string::npos||low.find("rally")!=std::string::npos||low.find("approval")!=std::string::npos;
      bool dn=low.find("bear")!=std::string::npos||low.find("drop")!=std::string::npos||low.find("fall")!=std::string::npos||low.find("crash")!=std::string::npos||low.find("plunge")!=std::string::npos||low.find("ban")!=std::string::npos;
      bull+=up; bear+=dn; std::string source="CryptoCompare";
      if(o.contains("source_info")&&o.at("source_info").is_object())source=getstr(o.at("source_info").as_object(),"name",source);
      json::object e{{"id",getstr(o,"id",std::to_string(cryptoNews.size()))},{"title",title},{"source",source},{"url",getstr(o,"url")},{"publishedAt",std::stoll(getstr(o,"published_on","0"))*1000LL},{"body",body},{"category","CRYPTO"},{"sentiment",up?"BULLISH":dn?"BEARISH":"NEUTRAL"}};
      cryptoNews.push_back(e);
    }
  }
  auto rss=parse_json(http_get("https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fwww.investing.com%2Frss%2Fnews_25.rss",1800));
  if(rss.is_object()&&rss.as_object().contains("items")&&rss.as_object().at("items").is_array()) for(const auto& item:rss.as_object().at("items").as_array()) {
    if(!item.is_object()||forexNews.size()>=10)continue;const auto&o=item.as_object();std::string title=getstr(o,"title"),low=title;std::transform(low.begin(),low.end(),low.begin(),[](unsigned char c){return std::tolower(c);});
    bool up=low.find("gain")!=std::string::npos||low.find("rise")!=std::string::npos||low.find("surge")!=std::string::npos||low.find("rally")!=std::string::npos;
    bool dn=low.find("fall")!=std::string::npos||low.find("drop")!=std::string::npos||low.find("crash")!=std::string::npos||low.find("plunge")!=std::string::npos;
    bull+=up;bear+=dn;forexNews.push_back(json::object{{"id",getstr(o,"guid",std::to_string(forexNews.size()))},{"title",title},{"source",getstr(o,"author","Investing.com RSS")},{"url",getstr(o,"link")},{"publishedAt",getstr(o,"pubDate")},{"body",getstr(o,"description",title)},{"category","FOREX"},{"sentiment",up?"BULLISH":dn?"BEARISH":"NEUTRAL"}});
  }
  std::string sentiment=bull>bear?"BULLISH":bear>bull?"BEARISH":"NEUTRAL";
  json::object sentiment_obj{{"overall",sentiment},{"bullishCount",bull},{"bearishCount",bear},{"xauImpact",sentiment},{"btcImpact",sentiment},{"updatedAt",std::chrono::system_clock::to_time_t(std::chrono::system_clock::now())}};
  json::object result{{"cryptoNews",cryptoNews},{"forexNews",forexNews},{"sentiment",sentiment_obj},{"source","CryptoCompare + Investing.com RSS via C++"},{"timestamp",std::chrono::system_clock::to_time_t(std::chrono::system_clock::now())}};
  return result;
}
static std::string url_decode(std::string s) { std::string o; for(size_t i=0;i<s.size();++i){ if(s[i]=='+')o+=' '; else if(s[i]=='%'&&i+2<s.size()){try{o+=char(std::stoi(s.substr(i+1,2),nullptr,16));i+=2;}catch(...){o+=s[i];}} else o+=s[i];} return o; }
static std::string query_param(const std::string& target,const std::string& key) { auto q=target.find('?'); if(q==std::string::npos)return {}; std::stringstream ss(target.substr(q+1)); std::string p; while(std::getline(ss,p,'&')){auto e=p.find('=');if(url_decode(p.substr(0,e))==key)return e==std::string::npos?"":url_decode(p.substr(e+1));}return {}; }
static std::string mime_for(const std::string& p) { if(p.ends_with(".js"))return "application/javascript";if(p.ends_with(".css"))return "text/css";if(p.ends_with(".png"))return "image/png";if(p.ends_with(".svg"))return "image/svg+xml";if(p.ends_with(".json"))return "application/json";if(p.ends_with(".woff2"))return "font/woff2";return "text/html; charset=utf-8"; }
static http::response<http::string_body> response(http::status status, std::string body, unsigned version, std::string type="application/json") { http::response<http::string_body> r{status,version}; r.set(http::field::server,"ZrillXZA-Cpp/1.0");r.set(http::field::content_type,type);r.set(http::field::access_control_allow_origin,"*");r.set(http::field::access_control_allow_headers,"Content-Type, Authorization");r.set(http::field::access_control_allow_methods,"GET, POST, OPTIONS");r.keep_alive(false);r.body()=std::move(body);r.prepare_payload();return r; }
static http::response<http::string_body> handle(http::request<http::string_body>& req) {
  auto target=std::string(req.target()); auto path=target.substr(0,target.find('?')); unsigned ver=req.version();
  if(req.method()==http::verb::options) return response(http::status::no_content,"",ver);
  if(path=="/api/health"||path=="/health") return response(http::status::ok,json::serialize(json::object{{"status","ok"},{"runtime","C++20"},{"calendarSource",g_calendar_source},{"timestamp",std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count()}}),ver);
  if(path=="/api/calendar"||path=="/api/calendar/scrape-forexfactory") { refresh_calendar(req.method()==http::verb::post||query_param(target,"refresh")=="1"); auto cv=calendar_value().as_object(); return response(http::status::ok,json::serialize(json::object{{"result",cv.at("events")},{"source",cv.at("source")},{"timestamp",cv.at("timestamp")}}),ver); }
  if(path=="/api/calendar/tier1-sniper") { refresh_calendar(); json::array out; auto c=calendar_value().as_object().at("events"); if(c.is_array()) for(auto& v:c.as_array()) if(v.is_object() && (getstr(v.as_object(),"forexFactoryImpact")=="HIGH"||getstr(v.as_object(),"impact")=="HIGH")) out.push_back(v); return response(http::status::ok,json::serialize(json::object{{"result",out},{"primaryTier1",out.empty()?json::value(nullptr):out.front()}}),ver); }
  if(path=="/api/news/realtime") { return response(http::status::ok,json::serialize(fetch_news_payload()),ver); }
  if(path=="/api/binance-time") { auto s=http_get("https://api.binance.com/api/v3/time",4000); return response(s.empty()?http::status::bad_gateway:http::status::ok,s.empty()?"{\"error\":\"Binance time unavailable\"}":s,ver); }
  if(path=="/api/tradingview/price") { std::string symbol=query_param(target,"symbol"); std::string pair=symbol; if(pair=="BTCUSD")pair="BTCUSDT";if(pair=="XAUUSD"||pair=="XAUS")return response(http::status::bad_gateway,"{\"error\":\"No configured licensed gold quote provider\",\"symbol\":\""+symbol+"\"}",ver); auto raw=parse_json(http_get("https://api.binance.com/api/v3/ticker/price?symbol="+pair,4500)); if(raw.is_object())return response(http::status::ok,json::serialize(json::object{{"symbol",symbol},{"price",getstr(raw.as_object(),"price")},{"source","Binance REST fallback"},{"timestamp",std::chrono::system_clock::to_time_t(std::chrono::system_clock::now())}}),ver); return response(http::status::bad_gateway,"{\"error\":\"Price provider unavailable\"}",ver); }
  if(path=="/api/klines") { std::string symbol=query_param(target,"symbol");if(symbol.empty())symbol="BTCUSDT";std::string interval=query_param(target,"interval");if(interval.empty())interval="1m";std::string limit=query_param(target,"limit");if(limit.empty())limit="100";auto raw=http_get("https://api.binance.com/api/v3/klines?symbol="+symbol+"&interval="+interval+"&limit="+limit,6000);return response(raw.empty()?http::status::bad_gateway:http::status::ok,raw.empty()?"[]":raw,ver); }
  if(path=="/api/live-rates") { auto raw=http_get("https://api.frankfurter.app/latest?from=USD",5000); return response(raw.empty()?http::status::bad_gateway:http::status::ok,raw.empty()?"{\"error\":\"FX rates unavailable\"}":raw,ver); }
  if(path=="/api/tradingview/prices") return response(http::status::ok,"{\"prices\":{},\"source\":\"C++ provider adapter; no live TradingView socket configured\",\"timestamp\":"+std::to_string(std::chrono::system_clock::to_time_t(std::chrono::system_clock::now()))+"}",ver);
  if(path=="/api/mcp/status") return response(http::status::ok,"{\"mcpVersion\":\"2.0.0\",\"status\":\"adapter-only\",\"description\":\"MCP chart control is not connected in the C++ runtime\"}",ver);
  if(path=="/api/mcp/tools") return response(http::status::ok,"{\"tools\":[{\"name\":\"quote_get\"},{\"name\":\"data_get_ohlcv\"}]}",ver);
  if(path=="/api/ai/analyze" && req.method()==http::verb::post) { auto body=parse_json(req.body()); std::string sym="XAUUSD", trend="NEUTRAL"; double price=0; if(body.is_object()){auto& o=body.as_object();sym=getstr(o,"symbol",getstr(o,"asset","XAUUSD"));trend=getstr(o,"smcStructure",getstr(o,"htfTrend","NEUTRAL"));try{price=std::stod(getstr(o,"currentPrice","0"));}catch(...){}} json::object out{{"status","limited"},{"symbol",sym},{"currentPrice",price},{"bias",trend=="BEARISH"?"SELL":trend=="BULLISH"?"BUY":"NEUTRAL"},{"source","C++ deterministic fallback"},{"warning","This endpoint is a deterministic fallback, not an AI-generated or validated trading signal."}}; return response(http::status::ok,json::serialize(out),ver); }
  if(path=="/api/auth/verify-membership"||path=="/api/override") return response(http::status::not_implemented,"{\"error\":\"Endpoint migration pending; configure identity provider before enabling\"}",ver);
  // Static UI in production build. Vite serves it separately during development.
  std::filesystem::path root="dist"; std::filesystem::path file=root/(path=="/"?"index.html":path.substr(1));
  if(std::filesystem::exists(file)&&std::filesystem::is_regular_file(file)){std::ifstream f(file,std::ios::binary);std::ostringstream s;s<<f.rdbuf();return response(http::status::ok,s.str(),ver,mime_for(file.string()));}
  if(std::filesystem::exists(root/"index.html")){std::ifstream f(root/"index.html",std::ios::binary);std::ostringstream s;s<<f.rdbuf();return response(http::status::ok,s.str(),ver,"text/html; charset=utf-8");}
  return response(http::status::not_found,"{\"error\":\"not found\"}",ver);
}
static void session(tcp::socket socket) {
  try { beast::flat_buffer buffer; http::request<http::string_body> req; http::read(socket,buffer,req);
    if(std::string(req.target()).starts_with("/api/calendar/stream")) {
      std::string hdr="HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nCache-Control: no-cache\r\nConnection: close\r\nAccess-Control-Allow-Origin: *\r\n\r\n";
      asio::write(socket,asio::buffer(hdr));
      while(g_running && socket.is_open()) { refresh_calendar(); auto payload=json::serialize(calendar_value()); std::string ev="data: "+payload+"\n\n"; beast::error_code ec; asio::write(socket,asio::buffer(ev),ec); if(ec)break; auto news=json::serialize(fetch_news_payload()); std::string nev="event: news\ndata: "+news+"\n\n"; asio::write(socket,asio::buffer(nev),ec); if(ec)break; std::this_thread::sleep_for(15s); }
    } else { auto res=handle(req); http::write(socket,res); }
    beast::error_code ec; socket.shutdown(tcp::socket::shutdown_send,ec); socket.close(ec);
  } catch(...) {}
}
int main() {
  curl_global_init(CURL_GLOBAL_DEFAULT);
  std::filesystem::create_directories("data");
  std::string dbpath=std::getenv("ZRILL_NEWS_DB")?std::getenv("ZRILL_NEWS_DB"):"data/zrill_news.sqlite3";
  if(sqlite3_open(dbpath.c_str(),&g_db)==SQLITE_OK){sqlite3_busy_timeout(g_db,3000);db_exec("PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS calendar_events(id TEXT PRIMARY KEY,event_id TEXT,title TEXT NOT NULL,currency TEXT,country TEXT,event_date TEXT,raw_date TEXT,raw_time TEXT,impact TEXT,importance INTEGER,forecast TEXT,previous_value TEXT,actual TEXT,source TEXT,payload_json TEXT NOT NULL,first_seen TEXT NOT NULL,last_seen TEXT NOT NULL);");}
  std::thread([]{ refresh_calendar(true); }).detach();
  std::thread([]{ while(g_running){ std::this_thread::sleep_for(60s); if(g_running) refresh_calendar(true); } }).detach();
  unsigned short port=3000; const char* env_port=std::getenv("PORT"); if(!env_port) env_port=std::getenv("ZRILL_CPP_PORT"); if(env_port)try{port=static_cast<unsigned short>(std::stoi(env_port));}catch(...){}
  try { asio::io_context ioc{1}; tcp::acceptor acceptor{ioc,{asio::ip::make_address("0.0.0.0"),port}}; std::cout<<"Zrill XZA C++ backend listening on "<<port<<std::endl;
    while(true){tcp::socket socket{ioc};acceptor.accept(socket);std::thread(session,std::move(socket)).detach();}
  } catch(const std::exception& e){std::cerr<<"backend fatal: "<<e.what()<<std::endl;}
  g_running=false; if(g_db)sqlite3_close(g_db);curl_global_cleanup();return 1;
}
