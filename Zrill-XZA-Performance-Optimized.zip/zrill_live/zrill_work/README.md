# Zrill-XZA

Web application using React + TypeScript for the unchanged UI, a C++17/WebAssembly core for latency-sensitive indicator calculations, and Python for economic-calendar data acquisition.

## Run locally

Prerequisites: Node.js and Python 3.

```sh
npm install
npm run dev
```

The calendar endpoints fetch from Biquote (`https://biquote.io/api/calendar`) through `scripts/fetch_biquote_calendar.py`. The existing calendar prediction/classification logic in `src/services/institutionalCalendarEngine.ts` is retained unchanged.

The browser loads the compiled C++ module from `public/zrill-core.wasm`. The migrated native calculations are SMA, EMA, MACD, Stochastic, RSI, ATR, Bollinger Bands, ADX/DI, candlestick-pattern classification, and RSI-divergence pivot detection. TypeScript keeps the existing interfaces and a compatibility fallback if WebAssembly cannot load.

## Verification

```sh
npm run test:wasm
npm run test:native
```

See [`migration/README.md`](migration/README.md) for rebuild instructions and exact migration boundaries.

**Migration status:** the C++/WASM indicator hot path and Python Calendar fetching are integrated and tested. The larger precision signal, SMC-structure, classic-chart-pattern, intraday engine, real-time macro, and news-intelligence modules have not yet been fully ported from TypeScript; the project does not claim a complete application-wide conversion.

## Event-driven/live update changes (2026-10-14)
- Browser price feed no longer falls back to REST polling. It reconnects the WebSocket with exponential backoff.
- OHLC history loads once at startup; active candles are updated from incoming WebSocket ticks. Periodic `/api/ohlc` refresh was removed from the browser.
- Calendar is loaded at startup and on explicit manual sync; the 3-second browser calendar polling loop was removed.
- UI timer effects used to simulate a live fundamental stream were removed; the card pulse now reacts to incoming price/fusion props.

Limitations: true push freshness depends on upstream providers. The server's current XAU/TradingView bridge still samples its latest quote on a server-side timer; this is not an upstream TradingView tick subscription. Biquote calendar is request/response through the Python adapter, and does not provide verified push streaming in this project, so calendar data changes only on initial load/manual sync. A strict end-to-end zero-poll implementation requires upstream provider-supported streaming/webhooks. The TypeScript check could not run successfully in this environment because project dependencies are not installed (`react`, `express`, and other packages missing); install with `npm ci` before deployment.
