import { nativeSMA, nativeEMA, nativeMACD, nativeStochastic, nativeRSI, nativeATR, nativeBollinger, nativeADX, nativeCandlePattern, nativeRSIDivergence } from "./nativeCore";

// Analisa OHLC murni (tanpa React): indikator, struktur pasar SMC, pola candle.
// Dipindahkan dari App.tsx agar bisa dipakai feed OHLC dan diuji di Node.

export const isValid = (val: any) => val !== null && val !== undefined && !isNaN(val);

export function calculateSMA(prices: number[], period: number) {
  const native = nativeSMA(prices, period);
  if (native !== null) return native;
  if (prices.length < period) return 0;
  let sum = 0;
  for (let i = prices.length - period; i < prices.length; i++) sum += prices[i];
  return sum / period;
}

/** EMA standar (seed = SMA periode pertama), sama dengan TradingView. */
export function calculateEMA(prices: number[], period: number) {
  const native = nativeEMA(prices, period);
  if (native !== null) return native;
  const n = prices.length;
  if (n === 0) return 0;
  if (n < period) return prices.reduce((a, b) => a + b, 0) / n;
  const k = 2 / (period + 1);
  let ema = 0;
  for (let i = 0; i < period; i++) ema += prices[i];
  ema /= period;
  for (let i = period; i < n; i++) ema = (prices[i] - ema) * k + ema;
  return ema;
}

/** Deret EMA penuh (nilai ke-i sejajar dengan prices[i]; sebelum seed = NaN). */
export function emaSeries(prices: number[], period: number): number[] {
  const n = prices.length;
  const out: number[] = new Array(n).fill(NaN);
  if (n < period) return out;
  const k = 2 / (period + 1);
  let ema = 0;
  for (let i = 0; i < period; i++) ema += prices[i];
  ema /= period;
  out[period - 1] = ema;
  for (let i = period; i < n; i++) {
    ema = (prices[i] - ema) * k + ema;
    out[i] = ema;
  }
  return out;
}

/** MACD 12/26/9 dari deret close: satu kali jalan, O(n). */
export function calculateMACD(closes: number[], fast = 12, slow = 26, signalP = 9) {
  const native = nativeMACD(closes, fast, slow, signalP);
  if (native !== null) return native;
  const ef = emaSeries(closes, fast);
  const es = emaSeries(closes, slow);
  const line: number[] = [];
  for (let i = 0; i < closes.length; i++) {
    if (!isNaN(ef[i]) && !isNaN(es[i])) line.push(ef[i] - es[i]);
  }
  if (line.length === 0) return { macd: 0, signal: 0, histogram: 0 };
  const sig = emaSeries(line, signalP);
  const macd = line[line.length - 1];
  const signal = isNaN(sig[sig.length - 1]) ? macd : sig[sig.length - 1];
  return { macd, signal, histogram: macd - signal };
}

export function calculateStochastic(
  highs: number[],
  lows: number[],
  closes: number[],
  periodK = 14,
  periodD = 3,
) {
  const native = nativeStochastic(highs, lows, closes, periodK, periodD);
  if (native !== null) return native;
  const n = closes.length;
  if (n < periodK + periodD - 1) return { k: 50, d: 50 };
  const kValues: number[] = [];
  for (let end = n - periodD + 1; end <= n; end++) {
    let hh = -Infinity;
    let ll = Infinity;
    for (let j = end - periodK; j < end; j++) {
      if (highs[j] > hh) hh = highs[j];
      if (lows[j] < ll) ll = lows[j];
    }
    kValues.push(hh === ll ? 50 : ((closes[end - 1] - ll) / (hh - ll)) * 100);
  }
  return {
    k: kValues[kValues.length - 1],
    d: kValues.reduce((a, b) => a + b, 0) / kValues.length,
  };
}

/** RSI Wilder (smoothing RMA), sama dengan TradingView. */
export function calculateRSI(closes: number[], period = 14) {
  const native = nativeRSI(closes, period);
  if (native !== null) return native;
  if (closes.length <= period) return 50;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d > 0) gain += d;
    else loss -= d;
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    avgGain = (avgGain * (period - 1) + (d > 0 ? d : 0)) / period;
    avgLoss = (avgLoss * (period - 1) + (d < 0 ? -d : 0)) / period;
  }
  if (avgLoss === 0) return avgGain === 0 ? 50 : 100;
  return 100 - 100 / (1 + avgGain / avgLoss);
}

export function calculateATR(highs: number[], lows: number[], closes: number[], period = 14) {
  const native = nativeATR(highs, lows, closes, period);
  if (native !== null) return native;
  if (closes.length < period + 1) return 1.5;
  const trValues: number[] = [];
  for (let i = 1; i < closes.length; i++) {
    const tr = Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1])
    );
    trValues.push(tr);
  }
  if (trValues.length < period) return Number((trValues[trValues.length - 1] || 1.5).toFixed(2));
  let atr = trValues.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < trValues.length; i++) {
    atr = (atr * (period - 1) + trValues[i]) / period;
  }
  return Number(atr.toFixed(2));
}

export function calculateBollingerBands(closes: number[], period = 20, multiplier = 2) {
  const native = nativeBollinger(closes, period, multiplier);
  if (native !== null) return native;
  if (closes.length < period) {
    const last = closes[closes.length - 1] || 0;
    return { upper: last, middle: last, lower: last, bandwidth: 0, percentB: 50 };
  }
  const slice = closes.slice(closes.length - period);
  const mean = slice.reduce((a, b) => a + b, 0) / period;
  const variance = slice.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / period;
  const stdDev = Math.sqrt(variance);
  const upper = mean + multiplier * stdDev;
  const lower = mean - multiplier * stdDev;
  const current = closes[closes.length - 1];
  const bandwidth = mean !== 0 ? ((upper - lower) / mean) * 100 : 0;
  const percentB = upper !== lower ? ((current - lower) / (upper - lower)) * 100 : 50;
  return {
    upper: Number(upper.toFixed(2)),
    middle: Number(mean.toFixed(2)),
    lower: Number(lower.toFixed(2)),
    bandwidth: Number(bandwidth.toFixed(2)),
    percentB: Number(percentB.toFixed(2)),
  };
}

export function calculateADX(highs: number[], lows: number[], closes: number[], period = 14) {
  const native = nativeADX(highs, lows, closes, period);
  if (native !== null) return native;
  if (closes.length < period * 2) {
    return { adx: 25, pdi: 25, mdi: 25 };
  }
  const trs: number[] = [];
  const plusDMs: number[] = [];
  const minusDMs: number[] = [];

  for (let i = 1; i < closes.length; i++) {
    const upMove = highs[i] - highs[i - 1];
    const downMove = lows[i - 1] - lows[i];

    plusDMs.push(upMove > downMove && upMove > 0 ? upMove : 0);
    minusDMs.push(downMove > upMove && downMove > 0 ? downMove : 0);

    const tr = Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1])
    );
    trs.push(tr);
  }

  if (trs.length < period) return { adx: 25, pdi: 25, mdi: 25 };

  let trSmooth = trs.slice(0, period).reduce((a, b) => a + b, 0);
  let plusDMSmooth = plusDMs.slice(0, period).reduce((a, b) => a + b, 0);
  let minusDMSmooth = minusDMs.slice(0, period).reduce((a, b) => a + b, 0);

  const dxValues: number[] = [];

  for (let i = period; i < trs.length; i++) {
    trSmooth = trSmooth - trSmooth / period + trs[i];
    plusDMSmooth = plusDMSmooth - plusDMSmooth / period + plusDMs[i];
    minusDMSmooth = minusDMSmooth - minusDMSmooth / period + minusDMs[i];

    const pdi = trSmooth > 0 ? (plusDMSmooth / trSmooth) * 100 : 0;
    const mdi = trSmooth > 0 ? (minusDMSmooth / trSmooth) * 100 : 0;
    const diSum = pdi + mdi;
    const dx = diSum > 0 ? (Math.abs(pdi - mdi) / diSum) * 100 : 0;
    dxValues.push(dx);
  }

  if (dxValues.length < period) {
    const avgDx = dxValues.reduce((a, b) => a + b, 0) / (dxValues.length || 1);
    return {
      adx: Number(avgDx.toFixed(1)),
      pdi: Number(((plusDMSmooth / (trSmooth || 1)) * 100).toFixed(1)),
      mdi: Number(((minusDMSmooth / (trSmooth || 1)) * 100).toFixed(1)),
    };
  }

  let adx = dxValues.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < dxValues.length; i++) {
    adx = (adx * (period - 1) + dxValues[i]) / period;
  }

  const finalPdi = trSmooth > 0 ? (plusDMSmooth / trSmooth) * 100 : 25;
  const finalMdi = trSmooth > 0 ? (minusDMSmooth / trSmooth) * 100 : 25;

  return {
    adx: Number(adx.toFixed(1)),
    pdi: Number(finalPdi.toFixed(1)),
    mdi: Number(finalMdi.toFixed(1)),
  };
}

export function detectRSIDivergence(candles: any[]) {
  const native = nativeRSIDivergence(candles);
  if (native !== undefined) return native;
  if (!candles || candles.length < 30) return null;
  const closes = candles.map((c) => c.close);
  const highs = candles.map((c) => c.high);
  const lows = candles.map((c) => c.low);

  const rsiValues: number[] = [];
  for (let i = 0; i < candles.length; i++) {
    if (i < 14) {
      rsiValues.push(50);
    } else {
      rsiValues.push(calculateRSI(closes.slice(0, i + 1), 14));
    }
  }

  const startIndex = Math.max(15, candles.length - 45);
  const peaks: { index: number; price: number; rsi: number; time: any }[] = [];
  const troughs: { index: number; price: number; rsi: number; time: any }[] = [];

  for (let i = startIndex; i < candles.length - 1; i++) {
    if (
      highs[i] >= highs[i - 1] &&
      highs[i] >= highs[i - 2] &&
      highs[i] >= highs[i + 1] &&
      rsiValues[i] > 48
    ) {
      peaks.push({
        index: i,
        price: highs[i],
        rsi: rsiValues[i],
        time: candles[i].time,
      });
    }

    if (
      lows[i] <= lows[i - 1] &&
      lows[i] <= lows[i - 2] &&
      lows[i] <= lows[i + 1] &&
      rsiValues[i] < 52
    ) {
      troughs.push({
        index: i,
        price: lows[i],
        rsi: rsiValues[i],
        time: candles[i].time,
      });
    }
  }

  // 1. Bearish Divergence: Price HH, RSI LH
  if (peaks.length >= 2) {
    const p2 = peaks[peaks.length - 1];
    const p1 = peaks[peaks.length - 2];
    if (p2.index - p1.index >= 3 && p2.price > p1.price * 1.00015 && p2.rsi < p1.rsi - 1.0) {
      return {
        type: "BEARISH_DIVERGENCE",
        title: "RSI BEARISH DIVERGENCE (POTENSI REVERSAL SELL)",
        price1: p1.price,
        price2: p2.price,
        rsi1: Number(p1.rsi.toFixed(1)),
        rsi2: Number(p2.rsi.toFixed(1)),
        time1: p1.time,
        time2: p2.time,
        description: `Harga mencetak Higher High ($${p2.price.toFixed(2)} vs $${p1.price.toFixed(2)}) tetapi RSI melemah ke Lower High (${p2.rsi.toFixed(1)} vs ${p1.rsi.toFixed(1)}). Indikasi kuat kelelahan momentum BUY & sinyal pembalikan harga ke arah SELL!`,
      };
    }
  }

  // 2. Bullish Divergence: Price LL, RSI HL
  if (troughs.length >= 2) {
    const t2 = troughs[troughs.length - 1];
    const t1 = troughs[troughs.length - 2];
    if (t2.index - t1.index >= 3 && t2.price < t1.price * 0.99985 && t2.rsi > t1.rsi + 1.0) {
      return {
        type: "BULLISH_DIVERGENCE",
        title: "RSI BULLISH DIVERGENCE (POTENSI REVERSAL BUY)",
        price1: t1.price,
        price2: t2.price,
        rsi1: Number(t1.rsi.toFixed(1)),
        rsi2: Number(t2.rsi.toFixed(1)),
        time1: t1.time,
        time2: t2.time,
        description: `Harga mencetak Lower Low ($${t2.price.toFixed(2)} vs $${t1.price.toFixed(2)}) tetapi RSI menguat ke Higher Low (${t2.rsi.toFixed(1)} vs ${t1.rsi.toFixed(1)}). Indikasi kuat akumulasi momentum BUY & sinyal pembalikan harga ke arah NAIK!`,
      };
    }
  }

  return null;
}

export function detectCandlePattern(
  open: number,
  high: number,
  low: number,
  close: number,
  prevOpen: number,
  prevClose: number,
) {
  const native = nativeCandlePattern(open, high, low, close, prevOpen, prevClose);
  if (native !== null) return native;
  const body = Math.abs(close - open);
  const upperWick = high - Math.max(open, close);
  const lowerWick = Math.min(open, close) - low;

  // Bullish Engulfing
  if (
    prevClose < prevOpen &&
    close > open &&
    close > prevOpen &&
    open < prevClose
  )
    return "BULLISH_ENGULFING";
  // Bearish Engulfing
  if (
    prevClose > prevOpen &&
    close < open &&
    close < prevOpen &&
    open > prevClose
  )
    return "BEARISH_ENGULFING";
  // Bullish Pinbar (Hammer)
  if (lowerWick > body * 2 && upperWick < body) return "BULLISH_PINBAR";
  // Bearish Pinbar (Shooting Star)
  if (upperWick > body * 2 && lowerWick < body) return "BEARISH_PINBAR";

  return "NONE";
}

export function analyzeSMC(data: any[]) {
  const emptyResult = {
    markers: [],
    drawings: {
      bullishFVG: null,
      bearishFVG: null,
      ob: null,
      sd: null,
      support: null,
      resistance: null,
      bos: null,
      choch: null,
      ibos: null,
      sweep: null,
      trendlines: { support: null, resistance: null },
    },
    state: {
      trend: "SIDEWAYS",
      lastStruct: "NONE",
      fvg: "NONE",
      ob: "NONE",
      sweep: "NONE",
      recentStructures: [] as any[],
      bos: "NONE",
      choch: "NONE",
      patterns: [] as any[],
      sentiment: { buy: 50, sell: 50 },
    },
  };
  if (!data || data.length < 50) return emptyResult;

  const markers: any[] = [];
  const totalRange =
    Math.max(...data.map((d) => d.high)) - Math.min(...data.map((d) => d.low));
  const offset = totalRange * 0.005;

  const leftBars = 10;
  const rightBars = 5;

  let swings: any[] = [];
  for (let i = leftBars; i < data.length - rightBars; i++) {
    let isHigh = true;
    let isLow = true;
    for (let j = 1; j <= leftBars; j++) {
      if (data[i - j].high >= data[i].high) isHigh = false;
      if (data[i - j].low <= data[i].low) isLow = false;
    }
    for (let j = 1; j <= rightBars; j++) {
      if (data[i + j].high >= data[i].high) isHigh = false;
      if (data[i + j].low <= data[i].low) isLow = false;
    }
    if (isHigh)
      swings.push({
        type: "High",
        index: i,
        price: data[i].high,
        time: data[i].time,
      });
    if (isLow)
      swings.push({
        type: "Low",
        index: i,
        price: data[i].low,
        time: data[i].time,
      });
  }

  let filteredSwings: any[] = [];
  let lastType = "";
  for (let s of swings) {
    if (s.type !== lastType) {
      filteredSwings.push(s);
      lastType = s.type;
    } else {
      if (
        s.type === "High" &&
        s.price > filteredSwings[filteredSwings.length - 1].price
      ) {
        filteredSwings[filteredSwings.length - 1] = s;
      } else if (
        s.type === "Low" &&
        s.price < filteredSwings[filteredSwings.length - 1].price
      ) {
        filteredSwings[filteredSwings.length - 1] = s;
      }
    }
  }

  let structure = [];
  let lastHigh = null;
  let lastLow = null;
  let trend = "SIDEWAYS";

  for (let i = 0; i < filteredSwings.length; i++) {
    let s = filteredSwings[i];
    if (s.type === "High") {
      if (lastHigh === null) {
        s.label = "High";
      } else if (s.price > lastHigh.price) {
        s.label = "HH";
      } else {
        s.label = "LH";
      }
      lastHigh = s;
    } else {
      if (lastLow === null) {
        s.label = "Low";
      } else if (s.price > lastLow.price) {
        s.label = "HL";
      } else {
        s.label = "LL";
      }
      lastLow = s;
    }
    structure.push(s);
  }

  if (structure.length >= 4) {
    const last4 = structure.slice(-4).map((s) => s.label);
    if (last4.includes("HH") && last4.includes("HL")) trend = "BULLISH";
    else if (last4.includes("LH") && last4.includes("LL")) trend = "BEARISH";
    else trend = "SIDEWAYS";
  }

  const recentStructs = structure.slice(-15);
  for (let s of recentStructs) {
    markers.push({
      time: s.time,
      position: s.type === "High" ? "aboveBar" : "belowBar",
      color: s.type === "High" ? "#ef4444" : "#10b981",
      shape: s.type === "High" ? "arrowDown" : "arrowUp",
      text: "", // Removed HH, HL, LH, LL labels
      size: 1,
    });
  }

  const lastTime = data[data.length - 1].time;
  const extendedTime = lastTime + 3600 * 24; // Extend by 24h roughly for visual

  // Find recent FVG
  let bullishFVG = null;
  let bearishFVG = null;
  for (let i = data.length - 25; i < data.length - 1; i++) {
    if (i < 2) continue;
    const c1 = data[i - 2];
    const c2 = data[i - 1];
    const c3 = data[i];
    const atr = Math.abs(c2.high - c2.low);

    // Celah dianggap terisi bila candle setelahnya sudah menutup seluruh celah.
    let filledBull = false;
    let filledBear = false;
    for (let j = i + 1; j < data.length; j++) {
      if (data[j].low <= c1.high) filledBull = true;
      if (data[j].high >= c1.low) filledBear = true;
    }
    if (
      !filledBull &&
      c1.high < c3.low &&
      c2.close > c2.open &&
      c3.low - c1.high > atr * 0.15
    ) {
      bullishFVG = {
        type: "BULLISH",
        time: c2.time,
        top: c3.low,
        bottom: c1.high,
        endTime: extendedTime,
      };
    }
    if (
      !filledBear &&
      c1.low > c3.high &&
      c2.close < c2.open &&
      c1.low - c3.high > atr * 0.15
    ) {
      bearishFVG = {
        type: "BEARISH",
        time: c2.time,
        top: c1.low,
        bottom: c3.high,
        endTime: extendedTime,
      };
    }
  }

  // Find recent OB (with Mitigation Check)
  let lastOB = null;
  for (let i = data.length - 30; i < data.length - 1; i++) {
    const c1 = data[i - 2];
    const c2 = data[i - 1];
    const c3 = data[i];
    if (!c1 || !c2 || !c3) continue;

    let ob = null;
    if (
      c1.close < c1.open &&
      c2.close > c2.open &&
      c3.close > c3.open &&
      c3.close - c2.open > (c1.open - c1.close) * 2
    ) {
      ob = {
        type: "BULLISH",
        time: c1.time,
        top: c1.open,
        bottom: c1.low,
        endTime: extendedTime,
        mitigated: false,
      };
    }
    if (
      c1.close > c1.open &&
      c2.close < c2.open &&
      c3.close < c3.open &&
      c2.open - c3.close > (c1.close - c1.open) * 2
    ) {
      ob = {
        type: "BEARISH",
        time: c1.time,
        top: c1.high,
        bottom: c1.open,
        endTime: extendedTime,
        mitigated: false,
      };
    }

    if (ob) {
      // Check for mitigation: has any candle after OB creation entered the zone?
      for (let j = i + 1; j < data.length; j++) {
        const testC = data[j];
        if (ob.type === "BULLISH" && testC.low <= ob.top) {
          ob.mitigated = true;
          ob.mitigationTime = testC.time;
          break;
        }
        if (ob.type === "BEARISH" && testC.high >= ob.bottom) {
          ob.mitigated = true;
          ob.mitigationTime = testC.time;
          break;
        }
      }
      lastOB = ob;
    }
  }

  // S&D Zones (Supply & Demand)
  let lastSD = null;
  for (let i = data.length - 30; i < data.length - 5; i++) {
    const range = data.slice(i, i + 5);
    const high = Math.max(...range.map((d) => d.high));
    const low = Math.min(...range.map((d) => d.low));
    const bodySize = Math.abs(high - low);

    // Strong move after consolidation
    const nextCandle = data[i + 5];
    if (nextCandle.close > high + bodySize) {
      lastSD = {
        type: "DEMAND",
        time: data[i].time,
        top: high,
        bottom: low,
        endTime: extendedTime,
      };
    } else if (nextCandle.close < low - bodySize) {
      lastSD = {
        type: "SUPPLY",
        time: data[i].time,
        top: high,
        bottom: low,
        endTime: extendedTime,
      };
    }
  }

  // S&R Zones (Support & Resistance) for each Timeframe
  let lastSupport: any = null;
  let lastResistance: any = null;
  const levels: any[] = [];
  for (let s of filteredSwings.slice(-30)) {
    const existing = levels.find(
      (l) => Math.abs(l.price - s.price) / (s.price || 1) < 0.002,
    );
    if (existing) {
      existing.touches++;
      existing.times.push(s.time);
      existing.types.push(s.type);
      // Update price to weighted average for better precision
      existing.price =
        (existing.price * (existing.touches - 1) + s.price) / existing.touches;
    } else {
      levels.push({
        price: s.price,
        touches: 1,
        times: [s.time],
        types: [s.type],
      });
    }
  }

  // Find strongest Support (Low touches) and Resistance (High touches)
  const sortedLevels = [...levels].sort((a, b) => b.touches - a.touches);

  const lastClosePx = data[data.length - 1].close;
  for (let level of sortedLevels) {
    // Support harus di bawah harga sekarang dan resistance di atasnya; level yang sudah ditembus tidak dipakai.
    const isResistance = level.price > lastClosePx && level.types.includes("High") && !level.types.every((t: string) => t === "Low");
    const isSupport = level.price < lastClosePx && level.types.includes("Low") && !level.types.every((t: string) => t === "High");

    const levelStrength = level.touches >= 3 ? "SANGAT KUAT" : level.touches === 2 ? "KUAT" : "MODERAT";

    if (isSupport && !lastSupport) {
      lastSupport = {
        type: "SUPPORT",
        time: level.times[0],
        price: Number(level.price.toFixed(2)),
        endTime: extendedTime,
        touches: level.touches,
        strength: levelStrength,
        actionAdvice: "WAIT FOR SUPPORT BUY",
      };
    } else if (isResistance && !lastResistance) {
      lastResistance = {
        type: "RESISTANCE",
        time: level.times[0],
        price: Number(level.price.toFixed(2)),
        endTime: extendedTime,
        touches: level.touches,
        strength: levelStrength,
        actionAdvice: "WAIT FOR RESISTANCE SELL",
      };
    }
  }

  // Reliable Fallback: Ensure every Timeframe has active Support and Resistance levels visualized
  const currentClose = data.length > 0 ? data[data.length - 1].close : 0;
  if (!lastSupport) {
    const swingLows = filteredSwings.filter((s) => s.type === "Low" && s.price < currentClose);
    if (swingLows.length > 0) {
      const bestLow = swingLows[swingLows.length - 1];
      lastSupport = {
        type: "SUPPORT",
        time: bestLow.time,
        price: Number(bestLow.price.toFixed(2)),
        endTime: extendedTime,
        touches: 1,
        strength: "MODERAT",
      };
    } else if (data.length > 0) {
      const minLow = Math.min(...data.slice(-30).map((d) => d.low));
      lastSupport = {
        type: "SUPPORT",
        time: data[0].time,
        price: Number(minLow.toFixed(2)),
        endTime: extendedTime,
        touches: 1,
        strength: "MODERAT",
      };
    }
  }

  if (!lastResistance) {
    const swingHighs = filteredSwings.filter((s) => s.type === "High" && s.price > currentClose);
    if (swingHighs.length > 0) {
      const bestHigh = swingHighs[swingHighs.length - 1];
      lastResistance = {
        type: "RESISTANCE",
        time: bestHigh.time,
        price: Number(bestHigh.price.toFixed(2)),
        endTime: extendedTime,
        touches: 1,
        strength: "MODERAT",
      };
    } else if (data.length > 0) {
      const maxHigh = Math.max(...data.slice(-30).map((d) => d.high));
      lastResistance = {
        type: "RESISTANCE",
        time: data[0].time,
        price: Number(maxHigh.toFixed(2)),
        endTime: extendedTime,
        touches: 1,
        strength: "MODERAT",
      };
    }
  }

  // Find last BOS, CHoCH, and iBOS (Anti-Fakeout Logic)
  let lastBOS = null;
  let lastCHoCH = null;
  let lastIBOS = null;

  for (let i = 2; i < structure.length; i++) {
    const curr = structure[i];
    const prev2 = structure[i - 2];

    // Find the candle that caused the breakout
    const breakoutCandle = data.find((d) => d.time === curr.time);
    if (!breakoutCandle) continue;

    // Anti-Fakeout: Check for "Displacement" (Strong Close)
    const isStrongBullish =
      breakoutCandle.close > prev2.price &&
      breakoutCandle.close - breakoutCandle.open >
        (breakoutCandle.high - breakoutCandle.low) * 0.6;
    const isStrongBearish =
      breakoutCandle.close < prev2.price &&
      breakoutCandle.open - breakoutCandle.close >
        (breakoutCandle.high - breakoutCandle.low) * 0.6;

    if (curr.label === "HH" && isStrongBullish) {
      if (prev2.label === "HH" || prev2.label === "High") {
        lastBOS = {
          type: "BULLISH",
          time: prev2.time,
          endTime: curr.time,
          price: prev2.price,
        };
      } else if (prev2.label === "LH") {
        lastCHoCH = {
          type: "BULLISH",
          time: prev2.time,
          endTime: curr.time,
          price: prev2.price,
        };
      } else if (prev2.label === "High") {
        lastIBOS = {
          type: "BULLISH",
          time: prev2.time,
          endTime: curr.time,
          price: prev2.price,
        };
      }
    } else if (curr.label === "LL" && isStrongBearish) {
      if (prev2.label === "LL" || prev2.label === "Low") {
        lastBOS = {
          type: "BEARISH",
          time: prev2.time,
          endTime: curr.time,
          price: prev2.price,
        };
      } else if (prev2.label === "HL") {
        lastCHoCH = {
          type: "BEARISH",
          time: prev2.time,
          endTime: curr.time,
          price: prev2.price,
        };
      } else if (prev2.label === "Low") {
        lastIBOS = {
          type: "BEARISH",
          time: prev2.time,
          endTime: curr.time,
          price: prev2.price,
        };
      }
    }
  }

  if (bullishFVG) {
    markers.push({
      time: bullishFVG.time,
      position: "belowBar",
      color: "#3b82f6",
      shape: "circle",
      text: "",
      tooltip:
        "Bullish Fair Value Gap: A price imbalance where buying pressure was so strong it left a gap. Often acts as a magnet for price to return and rebalance.",
    });
  }

  if (bearishFVG) {
    markers.push({
      time: bearishFVG.time,
      position: "aboveBar",
      color: "#ef4444",
      shape: "circle",
      text: "",
      tooltip:
        "Bearish Fair Value Gap: A price imbalance where selling pressure was so strong it left a gap.",
    });
  }

  if (lastOB) {
    markers.push({
      time: lastOB.time,
      position: lastOB.type === "BULLISH" ? "belowBar" : "aboveBar",
      color: lastOB.type === "BULLISH" ? "#10b981" : "#ef4444",
      shape: "square",
      text: "",
      tooltip:
        lastOB.type === "BULLISH"
          ? `Bullish Order Block (${lastOB.mitigated ? "Mitigated" : "Unmitigated"}): A zone where institutional buying occurred.`
          : `Bearish Order Block (${lastOB.mitigated ? "Mitigated" : "Unmitigated"}): A zone where institutional selling occurred.`,
    });
  }

  if (lastSD) {
    markers.push({
      time: lastSD.time,
      position: lastSD.type === "DEMAND" ? "belowBar" : "aboveBar",
      color: lastSD.type === "DEMAND" ? "#10b981" : "#ef4444",
      shape: "circle",
      text: "",
    });
  }

  if (lastSupport) {
    markers.push({
      time: lastSupport.time,
      position: "belowBar",
      color: "#10b981",
      shape: "arrowUp",
      text: "",
    });
  }

  if (lastResistance) {
    markers.push({
      time: lastResistance.time,
      position: "aboveBar",
      color: "#ef4444",
      shape: "arrowDown",
      text: "",
    });
  }

  if (lastBOS && isValid(lastBOS.price)) {
    markers.push({
      time: lastBOS.endTime,
      position: lastBOS.type === "BULLISH" ? "belowBar" : "aboveBar",
      color: "#f59e0b",
      shape: lastBOS.type === "BULLISH" ? "arrowUp" : "arrowDown",
      text: "",
      tooltip:
        "Break of Structure: Price has broken the previous structure in the direction of the trend, confirming trend continuation.",
    });
  }

  if (lastCHoCH && isValid(lastCHoCH.price)) {
    markers.push({
      time: lastCHoCH.endTime,
      position: lastCHoCH.type === "BULLISH" ? "belowBar" : "aboveBar",
      color: "#8b5cf6",
      shape: lastCHoCH.type === "BULLISH" ? "arrowUp" : "arrowDown",
      text: "",
      tooltip:
        "Change of Character: The first sign of a potential trend reversal. Price has broken the opposite structure.",
    });
  }

  if (lastIBOS && isValid(lastIBOS.price)) {
    markers.push({
      time: lastIBOS.endTime,
      position: "inPrice",
      price: lastIBOS.price,
      color: "#06b6d4",
      shape: "circle",
      text: "",
    });
  }

  let sweep = "NONE";
  let sweepLine = null;
  const currentCandle = data[data.length - 1];

  const lastHighStruct = structure
    .slice()
    .reverse()
    .find((s) => s.type === "High");
  const lastLowStruct = structure
    .slice()
    .reverse()
    .find((s) => s.type === "Low");

  if (structure.length > 0) {
    if (
      lastHighStruct &&
      currentCandle.high > lastHighStruct.price &&
      currentCandle.close < lastHighStruct.price
    ) {
      sweep = "BEARISH";
      sweepLine = {
        time: lastHighStruct.time,
        endTime: currentCandle.time,
        price: lastHighStruct.price,
      };
      markers.push({
        time: currentCandle.time,
        position: "aboveBar",
        color: "#f59e0b",
        shape: "arrowDown",
        text: "",
        tooltip:
          "Buy-Side Liquidity (BSL) Sweep: Price swept above a major high to hunt stop losses before reversing.",
      });
    }
    if (
      lastLowStruct &&
      currentCandle.low < lastLowStruct.price &&
      currentCandle.close > lastLowStruct.price
    ) {
      sweep = "BULLISH";
      sweepLine = {
        time: lastLowStruct.time,
        endTime: currentCandle.time,
        price: lastLowStruct.price,
      };
      markers.push({
        time: currentCandle.time,
        position: "belowBar",
        color: "#f59e0b",
        shape: "arrowUp",
        text: "",
        tooltip:
          "Sell-Side Liquidity (SSL) Sweep: Price swept below a major low to hunt stop losses before reversing.",
      });
    }
  }

  // Candlestick Pattern Detection
  const patterns: any[] = [];
  for (let i = data.length - 20; i < data.length; i++) {
    if (i < 2) continue;
    const curr = data[i];
    const prev = data[i - 1];

    const body = Math.abs(curr.close - curr.open);
    const prevBody = Math.abs(prev.close - prev.open);
    const range = curr.high - curr.low;

    // Engulfing
    if (
      curr.close > curr.open &&
      prev.close < prev.open &&
      curr.close > prev.open &&
      curr.open < prev.close
    ) {
      patterns.push({
        type: "Bullish Engulfing",
        time: curr.time,
        description:
          "Bullish Engulfing: A large green candle completely engulfs the previous red candle, signaling strong buying pressure.",
      });
      markers.push({
        time: curr.time,
        position: "belowBar",
        color: "#10b981",
        shape: "arrowUp",
        text: "",
        tooltip: "Bullish Engulfing: Strong reversal signal.",
      });
    } else if (
      curr.close < curr.open &&
      prev.close > prev.open &&
      curr.close < prev.open &&
      curr.open > prev.close
    ) {
      patterns.push({
        type: "Bearish Engulfing",
        time: curr.time,
        description:
          "Bearish Engulfing: A large red candle completely engulfs the previous green candle, signaling strong selling pressure.",
      });
      markers.push({
        time: curr.time,
        position: "aboveBar",
        color: "#ef4444",
        shape: "arrowDown",
        text: "",
        tooltip: "Bearish Engulfing: Strong reversal signal.",
      });
    }
    
    // Pin Bar / Hammer / Shooting Star
    const upperWick = curr.high - Math.max(curr.open, curr.close);
    const lowerWick = Math.min(curr.open, curr.close) - curr.low;
    if (lowerWick > body * 2 && upperWick < body * 0.5) {
      patterns.push({
        type: "Bullish Pin Bar / Hammer",
        time: curr.time,
        description: "Bullish Pin Bar: Strong rejection of lower prices.",
      });
      markers.push({
        time: curr.time,
        position: "belowBar",
        color: "#10b981",
        shape: "arrowUp",
        text: "",
        tooltip: "Bullish Pin Bar: Price rejection at support.",
      });
    } else if (upperWick > body * 2 && lowerWick < body * 0.5) {
      patterns.push({
        type: "Bearish Shooting Star",
        time: curr.time,
        description: "Shooting Star: Strong rejection of higher prices.",
      });
      markers.push({
        time: curr.time,
        position: "aboveBar",
        color: "#ef4444",
        shape: "arrowDown",
        text: "",
        tooltip: "Bearish Shooting Star: Price rejection at resistance.",
      });
    }
  }

  // Sentiment Calculation (Real-time Buyer vs Seller %)
  const recentSentimentData = data.slice(-15);
  let buyVolume = 0;
  let sellVolume = 0;
  recentSentimentData.forEach((d, idx) => {
    const body = Math.abs(d.close - d.open);
    const weight = (idx + 1) / recentSentimentData.length; // More weight to recent candles
    if (d.close > d.open) buyVolume += body * weight;
    else if (d.close < d.open) sellVolume += body * weight;
    else {
      buyVolume += body * 0.5 * weight;
      sellVolume += body * 0.5 * weight;
    }
  });

  // Add current candle pressure
  const lastBody = Math.abs(currentCandle.close - currentCandle.open);
  if (currentCandle.close > currentCandle.open) buyVolume += lastBody * 2;
  else sellVolume += lastBody * 2;

  const totalVol = buyVolume + sellVolume;
  const buyPercent =
    totalVol > 0 ? Math.round((buyVolume / totalVol) * 100) : 50;
  const sellPercent = 100 - buyPercent;

  // Trendline Detection
  let trendlines = { support: null as any, resistance: null as any };
  const recentHighs = filteredSwings.filter((s) => s.type === "High").slice(-3);
  const recentLows = filteredSwings.filter((s) => s.type === "Low").slice(-3);

  if (recentHighs.length >= 2) {
    const p1 = recentHighs[recentHighs.length - 2];
    const p2 = recentHighs[recentHighs.length - 1];
    trendlines.resistance = { p1, p2 };
  }
  if (recentLows.length >= 2) {
    const p1 = recentLows[recentLows.length - 2];
    const p2 = recentLows[recentLows.length - 1];
    trendlines.support = { p1, p2 };
  }

  const lastStructLabel =
    structure.length > 0 ? structure[structure.length - 1].label : "NONE";
  const recentStructures = structure.slice(-10);

  // High Probability Signal Logic (Very Low Risk)
  const signals: any[] = [];

  // Bullish Low Risk Entry
  const isAtDemand =
    lastSD &&
    lastSD.type === "DEMAND" &&
    currentCandle.low <= lastSD.top &&
    currentCandle.close >= lastSD.bottom;
  const isAtBullishOB =
    lastOB &&
    lastOB.type === "BULLISH" &&
    currentCandle.low <= lastOB.top &&
    currentCandle.close >= lastOB.bottom;
  const hasBullishPattern = patterns.some(
    (p) =>
      p.time === currentCandle.time &&
      (p.type === "Bullish Engulfing" || p.type === "Bullish Pinbar"),
  );
  const hadBullishSweep = sweep === "BULLISH";

  if ((isAtDemand || isAtBullishOB) && hasBullishPattern) {
    let strength = 1;
    if (trend === "BULLISH") strength++;
    if (hadBullishSweep) strength++;

    if (strength >= 2) {
      signals.push({
        type: "BUY",
        strength: strength >= 3 ? "HIGH" : "MEDIUM",
        price: currentCandle.close,
        sl:
          Math.min(
            currentCandle.low,
            isAtDemand ? lastSD.bottom : lastOB.bottom,
          ) -
          totalRange * 0.002,
        tp: lastHighStruct
          ? lastHighStruct.price
          : currentCandle.close + totalRange * 0.05,
        reason: `Bullish confluence at ${isAtDemand ? "Demand" : "Order Block"} with ${patterns.find((p) => p.time === currentCandle.time).type}${hadBullishSweep ? " + Liquidity Sweep" : ""}`,
      });
    }
  }

  // Bearish Low Risk Entry
  const isAtSupply =
    lastSD &&
    lastSD.type === "SUPPLY" &&
    currentCandle.high >= lastSD.bottom &&
    currentCandle.close <= lastSD.top;
  const isAtBearishOB =
    lastOB &&
    lastOB.type === "BEARISH" &&
    currentCandle.high >= lastOB.bottom &&
    currentCandle.close <= lastOB.top;
  const hasBearishPattern = patterns.some(
    (p) =>
      p.time === currentCandle.time &&
      (p.type === "Bearish Engulfing" || p.type === "Bearish Pinbar"),
  );
  const hadBearishSweep = sweep === "BEARISH";

  if ((isAtSupply || isAtBearishOB) && hasBearishPattern) {
    let strength = 1;
    if (trend === "BEARISH") strength++;
    if (hadBearishSweep) strength++;

    if (strength >= 2) {
      signals.push({
        type: "SELL",
        strength: strength >= 3 ? "HIGH" : "MEDIUM",
        price: currentCandle.close,
        sl:
          Math.max(currentCandle.high, isAtSupply ? lastSD.top : lastOB.top) +
          totalRange * 0.002,
        tp: lastLowStruct
          ? lastLowStruct.price
          : currentCandle.close - totalRange * 0.05,
        reason: `Bearish confluence at ${isAtSupply ? "Supply" : "Order Block"} with ${patterns.find((p) => p.time === currentCandle.time)?.type || "Price Action"}${hadBearishSweep ? " + Liquidity Sweep" : ""}`,
      });
    }
  }

  // --- PRIVATE CLASS SETUP: ICT 2022 MENTORSHIP MODEL (Most Profitable) ---
  // 1. Liquidity Sweep (BSL/SSL)
  // 2. Market Structure Shift (MSS) with Displacement
  // 3. Return to FVG

  const hasRecentSweep = sweep !== "NONE";

  if (hasRecentSweep) {
    const isBullishSetup = sweep === "BULLISH"; // SSL Swept
    const isBearishSetup = sweep === "BEARISH"; // BSL Swept

    // Look for MSS (Market Structure Shift)
    if (isBullishSetup && lastCHoCH && lastCHoCH.type === "BULLISH") {
      // Check for FVG in the displacement leg (must be created after or during MSS)
      if (bullishFVG && bullishFVG.time >= lastCHoCH.time - 3600) {
        signals.push({
          type: "BUY",
          strength: "PRIVATE_CLASS",
          price: currentCandle.close,
          sl: lastLowStruct
            ? lastLowStruct.price - totalRange * 0.001
            : currentCandle.low,
          tp: lastHighStruct
            ? lastHighStruct.price
            : currentCandle.close + totalRange * 0.1,
          reason:
            "ICT 2022 MODEL: SSL Sweep + MSS + FVG. High Probability Sniper Entry.",
        });
      }
    } else if (isBearishSetup && lastCHoCH && lastCHoCH.type === "BEARISH") {
      // Check for FVG in the displacement leg
      if (bearishFVG && bearishFVG.time >= lastCHoCH.time - 3600) {
        signals.push({
          type: "SELL",
          strength: "PRIVATE_CLASS",
          price: currentCandle.close,
          sl: lastHighStruct
            ? lastHighStruct.price + totalRange * 0.001
            : currentCandle.high,
          tp: lastLowStruct
            ? lastLowStruct.price
            : currentCandle.close - totalRange * 0.1,
          reason:
            "ICT 2022 MODEL: BSL Sweep + MSS + FVG. High Probability Sniper Entry.",
        });
      }
    }
  }

  // Add markers for signals
  for (let sig of signals) {
    markers.push({
      time: currentCandle.time,
      position: sig.type === "BUY" ? "belowBar" : "aboveBar",
      color: sig.type === "BUY" ? "#10b981" : "#ef4444",
      shape: "arrowUp",
      text: "",
      size: 2,
      tooltip: `LOW RISK ENTRY: ${sig.reason}. SL: ${sig.sl.toFixed(2)}, TP: ${sig.tp.toFixed(2)}`,
    });
  }

  return {
    markers,
    drawings: {
      bullishFVG,
      bearishFVG,
      ob: lastOB,
      sd: lastSD,
      support: lastSupport,
      resistance: lastResistance,
      bos: lastBOS,
      choch: lastCHoCH,
      ibos: lastIBOS,
      sweep: sweepLine,
      trendlines,
    },
    state: {
      trend,
      lastStruct: lastStructLabel,
      support: lastSupport,
      resistance: lastResistance,
      fvg:
        bullishFVG || bearishFVG
          ? bullishFVG
            ? "BULLISH"
            : "BEARISH"
          : "NONE",
      ob: lastOB ? lastOB.type : "NONE",
      sweep,
      recentStructures,
      bos: lastBOS ? lastBOS.type : "NONE",
      choch: lastCHoCH ? lastCHoCH.type : "NONE",
      patterns,
      signals,
      sentiment: { buy: buyPercent, sell: sellPercent },
    },
  };
}
