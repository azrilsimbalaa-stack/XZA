// Feed OHLC untuk mesin analisa: memuat candle ASLI dari server, menyatukan tick live ke candle yang sedang
// terbentuk, lalu menghitung indikator + struktur pasar. Tidak ada data sintetis di sini: bila data tidak ada,
// status "error" dikirim dan analisa berhenti (pemanggil yang memutuskan menampilkan alasan).
import {
  analyzeSMC,
  calculateSMA,
  calculateEMA,
  calculateStochastic,
  calculateRSI,
  calculateATR,
  calculateBollingerBands,
  calculateADX,
  calculateMACD,
  detectRSIDivergence,
  detectCandlePattern,
} from "./smcAnalysis";
import { detectAllClassicPatterns } from "./chartPatternEngine";

export type TfId = "M1" | "M5" | "M15" | "M30" | "H1" | "H4" | "D1";
export const ALL_TF: { id: TfId; sec: number }[] = [
  { id: "M1", sec: 60 },
  { id: "M5", sec: 300 },
  { id: "M15", sec: 900 },
  { id: "M30", sec: 1800 },
  { id: "H1", sec: 3600 },
  { id: "H4", sec: 14400 },
  { id: "D1", sec: 86400 },
];
const SEC: Record<TfId, number> = Object.fromEntries(ALL_TF.map((t) => [t.id, t.sec])) as Record<TfId, number>;
export const MIN_BARS = 50;
const MAX_BARS = 600;

export interface Candle {
  time: number; // detik (UTC)
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}
export type CandlesByTf = Record<TfId, Candle[]>;

export interface FeedStatus {
  state: "loading" | "live" | "stale" | "error";
  source: string;
  sourceLabel: string;
  proxy: boolean;
  basis: number;
  bars: Partial<Record<TfId, number>>;
  lastCandleAgeSec: number | null;
  error?: string;
  updatedAt: number;
}

export interface FeedSnapshot {
  symbolId: string;
  activeTf: TfId;
  price: number;
  indicators: any;
  htfData: any;
  ltfData: any;
  candlesByTf: CandlesByTf;
}

/** Baris klines Binance-style [ms, o, h, l, c, v] -> candle valid, urut naik, tanpa duplikat. */
export function normalizeKlines(raw: any[]): Candle[] {
  const map = new Map<number, Candle>();
  if (!Array.isArray(raw)) return [];
  for (const k of raw) {
    if (!Array.isArray(k) || k.length < 5) continue;
    const time = Math.floor(Number(k[0]) / 1000);
    const open = parseFloat(k[1]);
    let high = parseFloat(k[2]);
    let low = parseFloat(k[3]);
    const close = parseFloat(k[4]);
    const volume = parseFloat(k[5] ?? "0");
    if (![time, open, high, low, close].every((x) => Number.isFinite(x)) || open <= 0 || high <= 0 || low <= 0 || close <= 0) continue;
    high = Math.max(high, open, close, low);
    low = Math.min(low, open, close, high);
    map.set(time, { time, open, high, low, close, volume: Number.isFinite(volume) ? volume : 0 });
  }
  return [...map.values()].sort((a, b) => a.time - b.time);
}

export function emptyStore(): CandlesByTf {
  return { M1: [], M5: [], M15: [], M30: [], H1: [], H4: [], D1: [] };
}

/** Lipat satu tick harga ke candle yang sedang terbentuk di setiap timeframe (grid waktu mengikuti sumber). */
export function foldTick(store: CandlesByTf, price: number, tsMs: number): boolean {
  if (!(price > 0) || !Number.isFinite(price)) return false;
  const ts = Math.floor(tsMs / 1000);
  let changed = false;
  for (const { id, sec } of ALL_TF) {
    const arr = store[id];
    const last = arr[arr.length - 1];
    if (!last) continue;
    if (ts < last.time) continue; // tick basi
    if (ts < last.time + sec) {
      if (price > last.high) last.high = price;
      if (price < last.low) last.low = price;
      if (last.close !== price) { last.close = price; changed = true; }
    } else {
      const k = Math.floor((ts - last.time) / sec);
      const t = last.time + k * sec;
      arr.push({ time: t, open: last.close, high: Math.max(last.close, price), low: Math.min(last.close, price), close: price, volume: 0 });
      if (arr.length > MAX_BARS) arr.splice(0, arr.length - MAX_BARS);
      changed = true;
    }
  }
  return changed;
}

/** Gabungkan candle baru dari server: candle dengan waktu sama diganti, yang lebih baru ditambahkan. */
export function mergeCandles(existing: Candle[], fresh: Candle[]): Candle[] {
  if (fresh.length === 0) return existing;
  const map = new Map<number, Candle>();
  for (const c of existing) map.set(c.time, c);
  for (const c of fresh) map.set(c.time, c);
  const out = [...map.values()].sort((a, b) => a.time - b.time);
  return out.length > MAX_BARS ? out.slice(out.length - MAX_BARS) : out;
}

const tfState = (c: Candle[], ctx?: { adx?: boolean }) => {
  void ctx;
  return analyzeSMC(c).state;
};

/** Hitung indikator + struktur pasar dari OHLC. Murni (tanpa efek samping) sehingga bisa diuji di Node. */
export function buildSnapshot(
  candlesByTf: CandlesByTf,
  activeTf: TfId,
  stateCache?: Map<TfId, { key: string; at: number; state: any }>,
  nowMs = Date.now(),
) {
  const data = candlesByTf[activeTf];
  if (!data || data.length < MIN_BARS) return null;

  const closes = data.map((d) => d.close);
  const highs = data.map((d) => d.high);
  const lows = data.map((d) => d.low);
  const last = data[data.length - 1];

  const ema20 = calculateEMA(closes, 20);
  const sma50 = calculateSMA(closes, 50);
  const ema50 = calculateEMA(closes, 50);
  const sma200 = calculateSMA(closes, 200) || sma50 || last.close;
  const ema200 = data.length >= 200 ? calculateEMA(closes, 200) : ema50 || last.close;
  const macdData = calculateMACD(closes, 12, 26, 9);
  const { k: stochK, d: stochD } = calculateStochastic(highs, lows, closes, 14, 3);
  const rsi = calculateRSI(closes, 14);
  const atr = calculateATR(highs, lows, closes, 14);
  const adxResult = calculateADX(highs, lows, closes, 14);
  const bollingerBands = calculateBollingerBands(closes, 20, 2);
  const rsiDivergence = detectRSIDivergence(data);
  const smc = analyzeSMC(data);

  // Pola candle dibaca dari candle yang SUDAH ditutup (bukan candle yang sedang terbentuk).
  const c1 = data[data.length - 2];
  const c0 = data[data.length - 3];
  const pattern = c1 && c0 ? detectCandlePattern(c1.open, c1.high, c1.low, c1.close, c0.open, c0.close) : "NONE";

  let classicPatterns: any[] = [];
  try { classicPatterns = detectAllClassicPatterns(data as any, last.close, atr) || []; } catch { classicPatterns = []; }

  const indicators = {
    ema20, sma50, sma200, ema50, ema200,
    macd: macdData.macd,
    macdSignal: macdData.signal,
    macdHistogram: macdData.histogram,
    macdData: { macd: macdData.macd, signal: macdData.signal, histogram: macdData.histogram },
    adx: adxResult.adx,
    adxDetails: adxResult,
    plusDI: adxResult.pdi,
    minusDI: adxResult.mdi,
    bollingerBands,
    stochK, stochD,
    prevClose: closes[closes.length - 2] ?? last.close,
    rsi, atr,
    rsiDivergence,
    pattern,
    smc: smc.state,
    smcDrawings: smc.drawings,
    classicPatterns,
    activeClassicPattern: classicPatterns.length > 0 ? classicPatterns[0] : null,
    supportResistance: { support: smc.drawings?.support, resistance: smc.drawings?.resistance },
    // jejak sumber, supaya terlihat bahwa angka berasal dari OHLC asli
    ohlc: { tf: activeTf, bars: data.length, lastTime: last.time, lastClose: last.close },
  };

  // Struktur per timeframe (cache: timeframe non-aktif dihitung ulang hanya saat candle baru / tiap 3 detik).
  const stateOf = (tf: TfId) => {
    const c = candlesByTf[tf];
    if (!c || c.length < MIN_BARS) return {};
    if (tf === activeTf) return smc.state;
    const key = `${c.length}:${c[c.length - 1].time}`;
    const hit = stateCache?.get(tf);
    if (hit && (hit.key === key ? nowMs - hit.at < 3000 : false)) return hit.state;
    const st = tfState(c);
    stateCache?.set(tf, { key, at: nowMs, state: st });
    return st;
  };

  const m1 = stateOf("M1"), m5 = stateOf("M5"), m15 = stateOf("M15"), m30 = stateOf("M30");
  const h1 = stateOf("H1"), h4 = stateOf("H4"), d1 = stateOf("D1");
  const tr = (s: any) => (s && s.trend) || "SIDEWAYS";

  let htfOverall = "NEUTRAL";
  if (tr(h1) === "BULLISH" && tr(h4) === "BULLISH") htfOverall = "BULLISH";
  else if (tr(h1) === "BEARISH" && tr(h4) === "BEARISH") htfOverall = "BEARISH";
  else if (tr(m30) === "BULLISH" && tr(h1) === "BULLISH") htfOverall = "BULLISH";
  else if (tr(m30) === "BEARISH" && tr(h1) === "BEARISH") htfOverall = "BEARISH";
  else htfOverall = tr(h1);

  let ltfOverall = "NEUTRAL";
  if (tr(m1) === "BULLISH" && tr(m5) === "BULLISH") ltfOverall = "BULLISH";
  else if (tr(m1) === "BEARISH" && tr(m5) === "BEARISH") ltfOverall = "BEARISH";
  else ltfOverall = tr(m5);

  // Kondisi pasar: sideways bila EMA20 H1 menempel SMA50 H1 (<0.1%).
  const h1c = candlesByTf.H1.map((c) => c.close);
  let condition = "TRENDING";
  if (h1c.length >= 50) {
    const e = calculateEMA(h1c, 20);
    const s = calculateSMA(h1c, 50);
    if (s > 0 && Math.abs(e - s) / s < 0.001) condition = "SIDEWAYS";
  }

  return {
    indicators,
    htfData: { m15, m30, h1, h4, d1, overall: htfOverall, condition },
    ltfData: { m1, m5, overall: ltfOverall },
    price: last.close,
  };
}

export interface FeedOptions {
  symbolId: string;
  getActiveTf: () => TfId;
  isMarketClosed: () => boolean;
  onSnapshot: (s: FeedSnapshot) => void;
  onStatus: (s: FeedStatus) => void;
}

export function startOhlcFeed(opts: FeedOptions) {
  let stopped = false;
  const store = emptyStore();
  const stateCache = new Map<TfId, { key: string; at: number; state: any }>();
  let source = "";
  let sourceLabel = "";
  let proxy = false;
  let basis = 0;
  let lastTick = 0;
  let loaded = false;
  let loadTimer: any = null;
  let retryMs = 2000;
  let dirty = false;
  let emitTimer: any = null;
  let lastEmitAt = 0;
  let lastStatusJson = "";
  const lastFetchAt: Record<string, number> = {};
  let fetching = false;

  const shift = (arr: Candle[], d: number) => {
    if (!d) return;
    for (const c of arr) { c.open += d; c.high += d; c.low += d; c.close += d; }
  };

  const publishStatus = (state: FeedStatus["state"], error?: string) => {
    const m1 = store.M1[store.M1.length - 1];
    const age = m1 ? Math.max(0, Math.floor(Date.now() / 1000) - m1.time) : null;
    const st: FeedStatus = {
      state: state === "live" && age !== null && age > 180 && !opts.isMarketClosed() ? "stale" : state,
      source, sourceLabel, proxy, basis,
      bars: Object.fromEntries(ALL_TF.map((t) => [t.id, store[t.id].length])) as any,
      lastCandleAgeSec: age,
      error,
      updatedAt: Date.now(),
    };
    const j = JSON.stringify({ ...st, updatedAt: 0, lastCandleAgeSec: age === null ? null : Math.floor(age / 15) });
    if (j !== lastStatusJson) { lastStatusJson = j; opts.onStatus(st); }
  };

  const emit = () => {
    emitTimer = null;
    if (stopped || !loaded) return;
    const tf = opts.getActiveTf();
    const snap = buildSnapshot(store, tf, stateCache);
    lastEmitAt = Date.now();
    dirty = false;
    if (!snap) return;
    opts.onSnapshot({ symbolId: opts.symbolId, activeTf: tf, price: snap.price, indicators: snap.indicators, htfData: snap.htfData, ltfData: snap.ltfData, candlesByTf: store });
  };
  const scheduleEmit = (minGap = 300) => {
    dirty = true;
    if (emitTimer || stopped) return;
    const wait = Math.max(0, minGap - (Date.now() - lastEmitAt));
    emitTimer = setTimeout(emit, wait);
  };

  const url = (tfs: TfId[], limit: number, pin?: string) =>
    `/api/ohlc?symbol=${encodeURIComponent(opts.symbolId)}&tfs=${tfs.join(",")}&limit=${limit}${pin ? `&source=${pin}` : ""}`;

  const applyBasisIfNeeded = () => {
    if (!proxy || !(lastTick > 0)) return;
    const last = store.M1[store.M1.length - 1];
    if (!last) return;
    const next = lastTick - last.close;
    if (Math.abs(next) / lastTick > 0.01) return; // selisih tak masuk akal -> abaikan
    const delta = next - basis;
    if (Math.abs(delta) < 1e-9) return;
    for (const { id } of ALL_TF) shift(store[id], delta);
    basis = next;
  };

  const loadAll = async () => {
    if (stopped) return;
    publishStatus("loading");
    try {
      const res = await fetch(url(ALL_TF.map((t) => t.id), 300), { cache: "no-store" });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(body?.error || `HTTP ${res.status}`);
      for (const { id } of ALL_TF) store[id] = normalizeKlines(body.candles?.[id] || []);
      source = String(body.source || "");
      sourceLabel = String(body.sourceLabel || body.source || "");
      proxy = !!body.proxy;
      basis = 0;
      const ok = store.M15.length >= MIN_BARS && store.H1.length >= MIN_BARS;
      if (!ok) throw new Error("Candle belum cukup untuk analisa (butuh minimal 50 per timeframe)");
      for (const { id } of ALL_TF) lastFetchAt[id] = Date.now();
      applyBasisIfNeeded();
      loaded = true;
      retryMs = 2000;
      publishStatus("live");
      scheduleEmit(0);
    } catch (e: any) {
      loaded = false;
      publishStatus("error", String(e?.message || e));
      retryMs = Math.min(retryMs * 2, 30000);
      if (!stopped) loadTimer = setTimeout(loadAll, retryMs);
    }
  };

  const dueEvery = (tf: TfId) => {
    if (tf === opts.getActiveTf()) return 5000;
    if (tf === "M1") return 8000;
    return Math.min(60000, Math.max(15000, (SEC[tf] * 1000) / 8));
  };

  const refresh = async () => {
    if (stopped || !loaded || fetching) return;
    const hiddenFactor = typeof document !== "undefined" && document.hidden ? 4 : 1;
    const now = Date.now();
    const due = ALL_TF.map((t) => t.id).filter((tf) => now - (lastFetchAt[tf] || 0) >= dueEvery(tf) * hiddenFactor);
    if (due.length === 0) return;
    fetching = true;
    try {
      const res = await fetch(url(due, 6, source), { cache: "no-store" });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(body?.error || `HTTP ${res.status}`);
      if (String(body.source) !== source) { // sumber berganti -> skala bisa beda, muat ulang penuh
        loaded = false;
        fetching = false;
        loadAll();
        return;
      }
      for (const tf of due) {
        const fresh = normalizeKlines(body.candles?.[tf] || []);
        if (basis) for (const c of fresh) { c.open += basis; c.high += basis; c.low += basis; c.close += basis; }
        store[tf] = mergeCandles(store[tf], fresh);
        lastFetchAt[tf] = now;
      }
      // candle terbentuk dari server menimpa tick lokal; tick terakhir dilipat lagi supaya tetap mutakhir
      if (lastTick > 0 && !opts.isMarketClosed()) foldTick(store, lastTick, Date.now());
      publishStatus("live");
      scheduleEmit();
    } catch (e: any) {
      publishStatus("stale", String(e?.message || e));
    } finally {
      fetching = false;
    }
  };

  // Event-driven mode: historical OHLC is loaded once; live candles update from WebSocket ticks.
  // No periodic REST polling. Reconnect/reload is explicit when the source changes or fails.
  loadAll();

  return {
    stop() {
      stopped = true;
      if (loadTimer) clearTimeout(loadTimer);
      if (emitTimer) clearTimeout(emitTimer);
    },
    /** Dipanggil setiap tick harga live. */
    pushTick(price: number, tsMs = Date.now()) {
      if (!(price > 0)) return;
      lastTick = price;
      if (!loaded || opts.isMarketClosed()) return;
      if (foldTick(store, price, tsMs)) scheduleEmit(350);
    },
    /** Timeframe aktif berubah: hitung ulang segera dari data yang sudah ada. */
    setActiveTf() {
      if (loaded) scheduleEmit(0);
    },
    /** Harga referensi terakhir yang dipakai (untuk basis proxy). */
    reconcileBasis() {
      applyBasisIfNeeded();
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Sumber tick harga: WebSocket Binance untuk BTC dan WebSocket server (/ws/ticks) untuk instrumen lain.
// Tidak ada polling fallback; jika koneksi gagal status akan menunggu reconnect.
// ─────────────────────────────────────────────────────────────────────────────
export interface TickInfo {
  price: number;
  bid: number;
  ask: number;
  t: number;
  via: "WS-BINANCE" | "WS-SERVER";
}

export function startTickFeed(symbolId: string, onTick: (t: TickInfo) => void) {
  let stopped = false;
  let sock: WebSocket | null = null;
  let retry: any = null;
  let delay = 800;
  let idx = 0;
  let got = false;
  const isBtc = symbolId.toUpperCase().includes("BTC");
  const urls = isBtc
    ? ["wss://stream.binance.com:9443/ws/btcusdt@bookTicker", "wss://data-stream.binance.vision/ws/btcusdt@bookTicker"]
    : [`${typeof location !== "undefined" && location.protocol === "https:" ? "wss" : "ws"}://${typeof location !== "undefined" ? location.host : "localhost"}/ws/ticks`];

  const stopPoll = () => {};

  const open = () => {
    if (stopped) return;
    let s: WebSocket;
    try { s = new WebSocket(urls[idx % urls.length]); } catch { retry = setTimeout(open, delay); delay = Math.min(delay * 2, 15000); return; }
    sock = s;
    s.onmessage = (ev) => {
      try {
        const m = JSON.parse(ev.data);
        if (isBtc) {
          const b = parseFloat(m.b), a = parseFloat(m.a);
          if (!(b > 0) || !(a > 0)) return;
          got = true; delay = 800; stopPoll();
          onTick({ price: (a + b) / 2, bid: b, ask: a, t: Date.now(), via: "WS-BINANCE" });
        } else {
          if (String(m.symbol) !== symbolId || !(m.price > 0)) return;
          got = true; delay = 800; stopPoll();
          onTick({ price: m.price, bid: m.bid || m.price, ask: m.ask || m.price, t: m.t || Date.now(), via: "WS-SERVER" });
        }
      } catch {}
    };
    s.onclose = () => {
      if (stopped) return;
      idx++;
      retry = setTimeout(open, delay);
      delay = Math.min(delay * 2, 15000);
    };
    s.onerror = () => { try { s.close(); } catch {} };
  };
  open();


  return () => {
    stopped = true;
    if (retry) clearTimeout(retry);
    stopPoll();
    if (sock) { sock.onclose = null; try { sock.close(); } catch {} }
  };
}
