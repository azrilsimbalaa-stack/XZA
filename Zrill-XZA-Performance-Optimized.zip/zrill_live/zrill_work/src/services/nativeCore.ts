/**
 * C++17/WebAssembly bridge for time-critical market calculations.
 * UI and presentation stay in React/TypeScript. Public functions are sync once
 * initialized; callers use the old path until WebAssembly has loaded.
 */
export type NativeCoreExports = Record<string, any> & { memory: WebAssembly.Memory };
let nativeExports: NativeCoreExports | null = null;
let initPromise: Promise<boolean> | null = null;

export function initializeNativeCore(): Promise<boolean> {
  if (nativeExports) return Promise.resolve(true);
  if (initPromise) return initPromise;
  initPromise = (async () => {
    try {
      const url = new URL("/zrill-core.wasm", window.location.origin).toString();
      const response = await fetch(url, { cache: "force-cache" });
      if (!response.ok) throw new Error(`WASM core HTTP ${response.status}`);
      const bytes = await response.arrayBuffer();
      const instance = await WebAssembly.instantiate(bytes, {});
      const exp = instance.instance.exports as unknown as NativeCoreExports;
      if (!exp.memory || typeof exp.zrill_rsi !== "function") throw new Error("C++ WASM exports missing");
      nativeExports = exp;
      return true;
    } catch (error) {
      // Compatibility fallback is deliberate: the current app must keep working
      // on hosts that do not serve WASM assets or disable WebAssembly.
      console.warn("Zrill C++ core unavailable; using compatibility implementation", error);
      return false;
    }
  })();
  return initPromise;
}

export function isNativeCoreReady() { return nativeExports !== null; }

function writeArray(pointerExport: string, values: number[]) {
  if (!nativeExports || values.length > nativeExports.zrill_capacity()) return false;
  const ptr = Number(nativeExports[pointerExport]());
  new Float64Array(nativeExports.memory.buffer, ptr, values.length).set(values);
  return true;
}
function prepare(close: number[], high?: number[], low?: number[], open?: number[], time?: number[]) {
  if (!nativeExports || close.length > nativeExports.zrill_capacity()) return false;
  return writeArray("zrill_close_ptr", close)
    && (!high || writeArray("zrill_high_ptr", high))
    && (!low || writeArray("zrill_low_ptr", low))
    && (!open || writeArray("zrill_open_ptr", open))
    && (!time || writeArray("zrill_time_ptr", time));
}
export function nativeSMA(prices: number[], period: number): number | null {
  if (!nativeExports || !prepare(prices)) return null;
  return Number(nativeExports.zrill_sma(prices.length, period));
}
export function nativeEMA(prices: number[], period: number): number | null {
  if (!nativeExports || !prepare(prices)) return null;
  return Number(nativeExports.zrill_ema(prices.length, period));
}
export function nativeMACD(prices: number[], fast=12, slow=26, signal=9): {macd:number;signal:number;histogram:number} | null {
  if (!nativeExports || !prepare(prices)) return null;
  const ptr = Number(nativeExports.zrill_macd_all(prices.length, fast, slow, signal));
  const out = new Float64Array(nativeExports.memory.buffer, ptr, 3);
  return { macd: out[0], signal: out[1], histogram: out[2] };
}
export function nativeStochastic(highs: number[], lows: number[], closes: number[], periodK=14, periodD=3): {k:number;d:number} | null {
  if (!nativeExports || highs.length !== closes.length || lows.length !== closes.length || !prepare(closes, highs, lows)) return null;
  const ptr = Number(nativeExports.zrill_stochastic_all(closes.length, periodK, periodD));
  const out = new Float64Array(nativeExports.memory.buffer, ptr, 2);
  return { k: out[0], d: out[1] };
}
export function nativeRSI(closes: number[], period=14): number | null {
  if (!nativeExports || !prepare(closes)) return null;
  return Number(nativeExports.zrill_rsi(closes.length, period));
}
export function nativeATR(highs: number[], lows: number[], closes: number[], period=14): number | null {
  if (!nativeExports || highs.length !== closes.length || lows.length !== closes.length || !prepare(closes, highs, lows)) return null;
  return Number(nativeExports.zrill_atr(closes.length, period));
}
export function nativeBollinger(closes: number[], period=20, multiplier=2): {upper:number;middle:number;lower:number;bandwidth:number;percentB:number} | null {
  if (!nativeExports || !prepare(closes)) return null;
  const ptr = Number(nativeExports.zrill_bbands_all(closes.length, period, multiplier));
  const out = new Float64Array(nativeExports.memory.buffer, ptr, 5);
  return { upper:out[0], middle:out[1], lower:out[2], bandwidth:out[3], percentB:out[4] };
}
export function nativeADX(highs: number[], lows: number[], closes: number[], period=14): {adx:number;pdi:number;mdi:number} | null {
  if (!nativeExports || highs.length !== closes.length || lows.length !== closes.length || !prepare(closes, highs, lows)) return null;
  const ptr = Number(nativeExports.zrill_adx_all(closes.length, period));
  const out = new Float64Array(nativeExports.memory.buffer, ptr, 3);
  return { adx:out[0], pdi:out[1], mdi:out[2] };
}

export type NativeDivergence = {
  type: "BEARISH_DIVERGENCE" | "BULLISH_DIVERGENCE";
  title: string; price1: number; price2: number; rsi1: number; rsi2: number;
  time1: any; time2: any; description: string;
};
/** undefined means the WASM core was not available; null means it ran and found no divergence. */
export function nativeRSIDivergence(candles: any[]): NativeDivergence | null | undefined {
  if (!nativeExports || !Array.isArray(candles) || candles.length > nativeExports.zrill_capacity()) return undefined;
  const closes = candles.map(c => Number(c.close));
  const highs = candles.map(c => Number(c.high));
  const lows = candles.map(c => Number(c.low));
  const times = candles.map(c => Number(c.time));
  if (![...closes, ...highs, ...lows].every(Number.isFinite) || !prepare(closes, highs, lows, undefined, times)) return undefined;
  const type = Number(nativeExports.zrill_rsi_divergence(candles.length, 14));
  if (type === 0) return null;
  const ptr = Number(nativeExports.zrill_divergence_ptr());
  const out = new Float64Array(nativeExports.memory.buffer, ptr, 9);
  const idx1 = out[1], idx2 = out[2], price1 = out[3], price2 = out[4];
  const rsi1 = Number(out[5].toFixed(1)), rsi2 = Number(out[6].toFixed(1));
  if (type === 1) return {
    type: "BEARISH_DIVERGENCE", title: "RSI BEARISH DIVERGENCE (POTENSI REVERSAL SELL)", price1, price2, rsi1, rsi2,
    time1: candles[idx1].time, time2: candles[idx2].time,
    description: `Harga mencetak Higher High ($${price2.toFixed(2)} vs $${price1.toFixed(2)}) tetapi RSI melemah ke Lower High (${rsi2.toFixed(1)} vs ${rsi1.toFixed(1)}). Indikasi kuat kelelahan momentum BUY & sinyal pembalikan harga ke arah SELL!`,
  };
  return {
    type: "BULLISH_DIVERGENCE", title: "RSI BULLISH DIVERGENCE (POTENSI REVERSAL BUY)", price1, price2, rsi1, rsi2,
    time1: candles[idx1].time, time2: candles[idx2].time,
    description: `Harga mencetak Lower Low ($${price2.toFixed(2)} vs $${price1.toFixed(2)}) tetapi RSI menguat ke Higher Low (${rsi2.toFixed(1)} vs ${rsi1.toFixed(1)}). Indikasi kuat akumulasi momentum BUY & sinyal pembalikan harga ke arah NAIK!`,
  };
}

export function nativeCandlePattern(open:number, high:number, low:number, close:number, prevOpen:number, prevClose:number): string | null {
  if (!nativeExports) return null;
  const p = Number(nativeExports.zrill_candle_pattern(open, high, low, close, prevOpen, prevClose));
  return ["NONE", "BULLISH_ENGULFING", "BEARISH_ENGULFING", "BULLISH_PINBAR", "BEARISH_PINBAR"][p] ?? "NONE";
}

// Start loading immediately when this module is imported; OHLC acquisition is async,
// so the WASM core is normally ready before the first snapshot is built.
if (typeof window !== "undefined" && typeof WebAssembly !== "undefined") void initializeNativeCore();
