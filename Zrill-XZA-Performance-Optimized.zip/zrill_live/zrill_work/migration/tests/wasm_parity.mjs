import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const bytes = await readFile(new URL('../../public/zrill-core.wasm', import.meta.url));
const { instance } = await WebAssembly.instantiate(bytes, {});
const e = instance.exports;
const closes = Array.from({ length: 420 }, (_, i) => 2300 + i * 0.37 + Math.sin(i / 4) * 4.2 + Math.cos(i / 17) * 8);
const highs = closes.map((v, i) => v + 0.8 + (i % 5) * 0.11);
const lows = closes.map((v, i) => v - 0.7 - (i % 7) * 0.08);
const write = (name, values) => new Float64Array(e.memory.buffer, Number(e[name]()), values.length).set(values);
write('zrill_close_ptr', closes); write('zrill_high_ptr', highs); write('zrill_low_ptr', lows);
const approx = (a, b, eps=1e-8) => assert.ok(Math.abs(a-b) <= eps * Math.max(1, Math.abs(b)), `expected ${a} ≈ ${b}`);
function ema(xs, period) {
  if (!xs.length) return 0;
  if (xs.length < period) return xs.reduce((a,b)=>a+b,0)/xs.length;
  const k=2/(period+1); let x=xs.slice(0,period).reduce((a,b)=>a+b,0)/period;
  for(let i=period;i<xs.length;i++) x=(xs[i]-x)*k+x;
  return x;
}
function emaSeries(xs, period) {
  const out=Array(xs.length).fill(NaN); if(xs.length<period)return out;
  const k=2/(period+1); let x=xs.slice(0,period).reduce((a,b)=>a+b,0)/period; out[period-1]=x;
  for(let i=period;i<xs.length;i++){x=(xs[i]-x)*k+x;out[i]=x;} return out;
}
function rsi(xs,p) {
  if(xs.length<=p)return 50; let g=0,l=0;
  for(let i=1;i<=p;i++){const d=xs[i]-xs[i-1];if(d>0)g+=d;else l-=d;}
  let ag=g/p,al=l/p;
  for(let i=p+1;i<xs.length;i++){const d=xs[i]-xs[i-1];ag=(ag*(p-1)+(d>0?d:0))/p;al=(al*(p-1)+(d<0?-d:0))/p;}
  if(al===0)return ag===0?50:100;return 100-100/(1+ag/al);
}
function atr(h,l,c,p) {
  if(c.length<p+1)return 1.5;const tr=[];
  for(let i=1;i<c.length;i++)tr.push(Math.max(h[i]-l[i],Math.abs(h[i]-c[i-1]),Math.abs(l[i]-c[i-1])));
  if(tr.length<p)return Number((tr.at(-1)||1.5).toFixed(2));let a=tr.slice(0,p).reduce((x,y)=>x+y,0)/p;
  for(let i=p;i<tr.length;i++)a=(a*(p-1)+tr[i])/p;return Number(a.toFixed(2));
}
function stochastic(h,l,c,pk,pd) {
  if(c.length<pk+pd-1)return {k:50,d:50};const vals=[];
  for(let end=c.length-pd+1;end<=c.length;end++){let hh=-Infinity,ll=Infinity;for(let j=end-pk;j<end;j++){hh=Math.max(hh,h[j]);ll=Math.min(ll,l[j]);}vals.push(hh===ll?50:((c[end-1]-ll)/(hh-ll))*100);}
  return {k:vals.at(-1),d:vals.reduce((a,b)=>a+b,0)/vals.length};
}
function adx(h,l,c,p) {
  if(c.length<p*2)return {adx:25,pdi:25,mdi:25};
  const tr=[],plus=[],minus=[];
  for(let i=1;i<c.length;i++){const up=h[i]-h[i-1],down=l[i-1]-l[i];plus.push(up>down&&up>0?up:0);minus.push(down>up&&down>0?down:0);tr.push(Math.max(h[i]-l[i],Math.abs(h[i]-c[i-1]),Math.abs(l[i]-c[i-1])));}
  let ts=tr.slice(0,p).reduce((a,b)=>a+b,0),ps=plus.slice(0,p).reduce((a,b)=>a+b,0),ms=minus.slice(0,p).reduce((a,b)=>a+b,0);const dx=[];
  for(let i=p;i<tr.length;i++){ts=ts-ts/p+tr[i];ps=ps-ps/p+plus[i];ms=ms-ms/p+minus[i];const pdi=ts>0?ps/ts*100:0,mdi=ts>0?ms/ts*100:0,ds=pdi+mdi;dx.push(ds>0?Math.abs(pdi-mdi)/ds*100:0);}
  if(dx.length<p){return {adx:Number((dx.reduce((a,b)=>a+b,0)/(dx.length||1)).toFixed(1)),pdi:Number((ps/(ts||1)*100).toFixed(1)),mdi:Number((ms/(ts||1)*100).toFixed(1))};}
  let a=dx.slice(0,p).reduce((x,y)=>x+y,0)/p;for(let i=p;i<dx.length;i++)a=(a*(p-1)+dx[i])/p;
  return {adx:Number(a.toFixed(1)),pdi:Number((ts>0?ps/ts*100:25).toFixed(1)),mdi:Number((ts>0?ms/ts*100:25).toFixed(1))};
}
const period=14;
const expectedSma=closes.slice(-20).reduce((a,b)=>a+b,0)/20;
approx(e.zrill_sma(closes.length,20),expectedSma);
approx(e.zrill_ema(closes.length,20),ema(closes,20));
approx(e.zrill_rsi(closes.length,period),rsi(closes,period));
approx(e.zrill_atr(closes.length,period),atr(highs,lows,closes,period),1e-6);
const macdLine=[];const ef=emaSeries(closes,12),es=emaSeries(closes,26);
for(let i=0;i<closes.length;i++)if(Number.isFinite(ef[i])&&Number.isFinite(es[i]))macdLine.push(ef[i]-es[i]);
const sigs=emaSeries(macdLine,9);const m=macdLine.at(-1),sig=Number.isFinite(sigs.at(-1))?sigs.at(-1):m;
approx(e.zrill_macd(closes.length,12,26,9,0),m);approx(e.zrill_macd(closes.length,12,26,9,1),sig);approx(e.zrill_macd(closes.length,12,26,9,2),m-sig);
const mo=new Float64Array(e.memory.buffer,Number(e.zrill_macd_all(closes.length,12,26,9)),3);approx(mo[0],m);approx(mo[1],sig);approx(mo[2],m-sig);
const st=stochastic(highs,lows,closes,14,3);approx(e.zrill_stochastic(closes.length,14,3,0),st.k);approx(e.zrill_stochastic(closes.length,14,3,1),st.d);const so=new Float64Array(e.memory.buffer,Number(e.zrill_stochastic_all(closes.length,14,3)),2);approx(so[0],st.k);approx(so[1],st.d);
const ax=adx(highs,lows,closes,14);approx(e.zrill_adx(closes.length,14,0),ax.adx);approx(e.zrill_adx(closes.length,14,1),ax.pdi);approx(e.zrill_adx(closes.length,14,2),ax.mdi);const ao=new Float64Array(e.memory.buffer,Number(e.zrill_adx_all(closes.length,14)),3);approx(ao[0],ax.adx);approx(ao[1],ax.pdi);approx(ao[2],ax.mdi);
const mean=closes.slice(-20).reduce((a,b)=>a+b,0)/20;const variance=closes.slice(-20).reduce((a,b)=>a+(b-mean)**2,0)/20;const sd=Math.sqrt(variance);
approx(e.zrill_bbands(closes.length,20,2,0),Number((mean+2*sd).toFixed(2)),1e-6);
approx(e.zrill_bbands(closes.length,20,2,1),Number(mean.toFixed(2)),1e-6);
approx(e.zrill_bbands(closes.length,20,2,2),Number((mean-2*sd).toFixed(2)),1e-6);const bo=new Float64Array(e.memory.buffer,Number(e.zrill_bbands_all(closes.length,20,2)),5);approx(bo[0],Number((mean+2*sd).toFixed(2)),1e-6);approx(bo[1],Number(mean.toFixed(2)),1e-6);approx(bo[2],Number((mean-2*sd).toFixed(2)),1e-6);approx(bo[3],Number((((mean+2*sd)-(mean-2*sd))/mean*100).toFixed(2)),1e-6);approx(bo[4],Number(((closes.at(-1)-(mean-2*sd))/((mean+2*sd)-(mean-2*sd))*100).toFixed(2)),1e-6);
assert.equal(e.zrill_candle_pattern(7.5,12,7,11,10,8),1);
assert.equal(e.zrill_candle_pattern(11,12,7,8,10,10.5),2);
assert.equal(e.zrill_candle_pattern(10,10.2,5,10.5,10,11),3);
assert.equal(e.zrill_candle_pattern(10,16,10,10.5,10,11),4);
console.log('WASM parity tests passed: SMA, EMA, MACD, Stochastic, RSI, ATR, Bollinger Bands, ADX/DI, candle patterns.');
// Differential test: ported C++ divergence detection must select the same pivots as the old engine.
function refDetect(candles) {
  if (candles.length < 30) return null;
  const cs=candles.map(x=>x.close), hs=candles.map(x=>x.high), ls=candles.map(x=>x.low), rv=[];
  for(let i=0;i<candles.length;i++)rv.push(i<14?50:rsi(cs.slice(0,i+1),14));
  const start=Math.max(15,candles.length-45), peaks=[], troughs=[];
  for(let i=start;i<candles.length-1;i++){
    if(hs[i]>=hs[i-1]&&hs[i]>=hs[i-2]&&hs[i]>=hs[i+1]&&rv[i]>48)peaks.push({index:i,price:hs[i],rsi:rv[i]});
    if(ls[i]<=ls[i-1]&&ls[i]<=ls[i-2]&&ls[i]<=ls[i+1]&&rv[i]<52)troughs.push({index:i,price:ls[i],rsi:rv[i]});
  }
  if(peaks.length>=2){const a=peaks.at(-2),b=peaks.at(-1);if(b.index-a.index>=3&&b.price>a.price*1.00015&&b.rsi<a.rsi-1)return {type:1,a,b};}
  if(troughs.length>=2){const a=troughs.at(-2),b=troughs.at(-1);if(b.index-a.index>=3&&b.price<a.price*0.99985&&b.rsi>a.rsi+1)return {type:2,a,b};}
  return null;
}
let seed=712367;
const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
for(let trial=0;trial<120;trial++){
  const n=30+Math.floor(rnd()*280);let price=100+trial*.1;const cs=[];
  for(let i=0;i<n;i++){price+=((rnd()-.49)*2.2);cs.push(price);}
  const candles=cs.map((close,i)=>({time:1700000000+i,close,open:close+(rnd()-.5)*1.3,high:close+.2+rnd()*.8,low:close-.2-rnd()*.8}));
  // Ensure each high/low encloses both open and close like normalized OHLC bars.
  for(const c of candles){c.high=Math.max(c.high,c.open,c.close);c.low=Math.min(c.low,c.open,c.close);}
  const c=candles.map(x=>x.close),h=candles.map(x=>x.high),l=candles.map(x=>x.low),t=candles.map(x=>x.time);
  write('zrill_close_ptr',c);write('zrill_high_ptr',h);write('zrill_low_ptr',l);write('zrill_time_ptr',t);
  const actualType=e.zrill_rsi_divergence(n,14);const out=new Float64Array(e.memory.buffer,Number(e.zrill_divergence_ptr()),9);const expected=refDetect(candles);
  assert.equal(actualType,expected?.type??0,`divergence type mismatch on trial ${trial}`);
  if(expected){assert.equal(out[1],expected.a.index);assert.equal(out[2],expected.b.index);approx(out[5],expected.a.rsi);approx(out[6],expected.b.rsi);}
}
console.log('Divergence differential tests passed across 120 deterministic OHLC series.');
