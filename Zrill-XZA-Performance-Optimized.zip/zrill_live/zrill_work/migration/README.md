# Zrill-XZA C++ / Python migration

## Runtime routing

- **UI:** React + TypeScript remains unchanged.
- **C++17/WebAssembly (browser runtime):** active for SMA, EMA, MACD, Stochastic, RSI, ATR, Bollinger Bands, ADX/DI, candlestick pattern classification, and RSI divergence pivot detection. The browser loads `public/zrill-core.wasm` through `src/services/nativeCore.ts`; these wrappers preserve the previous call signatures and result shapes.
- **Python (server runtime):** the active economic-calendar fetch helper is `scripts/fetch_biquote_calendar.py`, using `GET https://biquote.io/api/calendar`. The server calls it from `/api/calendar` and `/api/calendar/sync-biquote`.
- **Calendar prediction/classification:** `src/services/institutionalCalendarEngine.ts` remains unchanged, per the requirement to preserve its prediction behavior.

## Tests

```sh
npm run test:wasm
npm run test:native
```

The Wasm tests compare numeric outputs against reference implementations and run 120 deterministic OHLC cases for RSI-divergence pivot parity. The CMake tests compile the native C++ sources and run smoke tests.

## Compile the browser module

The shipped `public/zrill-core.wasm` is already compiled. To rebuild it using Clang with a wasm32 target:

```sh
clang++ --target=wasm32-unknown-unknown -O3 -fno-builtin -nostdlib -fno-exceptions -fno-rtti \
  migration/cpp/wasm_core.cpp \
  -Wl,--no-entry -Wl,--export-memory -Wl,--initial-memory=2097152 -Wl,--max-memory=16777216 \
  -Wl,--strip-all -Wl,--allow-undefined \
  -Wl,--export=zrill_close_ptr -Wl,--export=zrill_high_ptr -Wl,--export=zrill_low_ptr \
  -Wl,--export=zrill_open_ptr -Wl,--export=zrill_time_ptr -Wl,--export=zrill_divergence_ptr \
  -Wl,--export=zrill_capacity -Wl,--export=zrill_sma -Wl,--export=zrill_ema \
  -Wl,--export=zrill_macd -Wl,--export=zrill_macd_all -Wl,--export=zrill_stochastic \
  -Wl,--export=zrill_stochastic_all -Wl,--export=zrill_rsi -Wl,--export=zrill_atr \
  -Wl,--export=zrill_bbands -Wl,--export=zrill_bbands_all -Wl,--export=zrill_adx \
  -Wl,--export=zrill_adx_all -Wl,--export=zrill_rsi_divergence \
  -Wl,--export=zrill_candle_pattern -o public/zrill-core.wasm
```

## Remaining migration boundary

This is an integrated C++/Wasm migration of the indicator/RSI-divergence hot path, not yet a full port of every analytics module. Complex structure, classic-chart-pattern, intraday SMC, real-time macro fusion, news intelligence, and the precision/signal suite are still implemented in their original TypeScript files. They are deliberately retained so this revision does not change trading/prediction behavior without complete output-parity tests. Do not treat the whole application as fully converted until those engines are ported and their parity tests pass.
