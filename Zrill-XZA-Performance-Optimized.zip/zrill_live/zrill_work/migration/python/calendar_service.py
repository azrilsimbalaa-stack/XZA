"""Biquote economic-calendar adapter. Does not implement or alter prediction logic."""
from __future__ import annotations
import json
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode
from urllib.request import Request, urlopen

BASE_URL = "https://biquote.io/api/calendar"
COUNTRY_MAP = {"USD":"US","EUR":"EU","GBP":"GB","JPY":"JP","AUD":"AU","CAD":"CA","CHF":"CH","NZD":"NZ","CNY":"CN","TRY":"TR"}

def fetch_calendar(days_back: int = 1, days_forward: int = 14) -> list[dict]:
    now = datetime.now(timezone.utc)
    params = urlencode({"from":(now-timedelta(days=days_back)).isoformat(),"to":(now+timedelta(days=days_forward)).isoformat(),"limit":500})
    req = Request(f"{BASE_URL}?{params}", headers={"Accept":"application/json","User-Agent":"Zrill-XZA/1.0"})
    with urlopen(req, timeout=15) as response:
        raw = json.loads(response.read().decode("utf-8"))
    if not isinstance(raw, list):
        raise ValueError("Biquote response must be a JSON array")
    events=[]
    for item in raw:
        if not isinstance(item, dict):
            continue
        currency=str(item.get("currency") or item.get("countryCode") or "USD").upper()
        impact_raw=str(item.get("importance") or "low").upper()
        impact=impact_raw if impact_raw in {"HIGH","MEDIUM","HOLIDAY"} else "LOW"
        importance={"HIGH":1,"MEDIUM":0,"HOLIDAY":-1,"LOW":-1}[impact]
        folder={"HIGH":"RED_FOLDER","MEDIUM":"ORANGE_FOLDER","HOLIDAY":"GRAY_FOLDER","LOW":"YELLOW_FOLDER"}[impact]
        event_time=item.get("time") or item.get("date") or item.get("datetime")
        try:
            date=datetime.fromisoformat(str(event_time).replace("Z","+00:00")).astimezone(timezone.utc).isoformat() if event_time else now.isoformat()
        except (ValueError, TypeError):
            date=now.isoformat()
        title=str(item.get("name") or item.get("title") or "Economic Event")
        events.append({
            "id":str(item.get("id") or item.get("eventId") or f"{event_time}-{title}-{currency}"),
            "title":title,"currency":currency,
            "country":str(item.get("countryCode") or COUNTRY_MAP.get(currency,currency)),
            "date":date,"impact":impact,"importance":importance,
            "forexFactoryImpact":impact,"forexFactoryFolder":folder,
            "forexFactoryLabel":f"BIQUOTE {impact} IMPACT ({folder.replace('_FOLDER','')})",
            "forecast":"---" if item.get("forecast") in (None,"") else str(item["forecast"]),
            "previous":"---" if item.get("previous") in (None,"") else str(item["previous"]),
            "actual":None if item.get("actual") in (None,"") else str(item["actual"]),
            "unit":str(item.get("unit") or ""),"source":"Biquote Economic Calendar (https://biquote.io)",
            "isForexFactoryOfficial":False,"isForexFactoryCalibrated":False
        })
    return events

if __name__ == "__main__":
    print(json.dumps(fetch_calendar(), ensure_ascii=False))
