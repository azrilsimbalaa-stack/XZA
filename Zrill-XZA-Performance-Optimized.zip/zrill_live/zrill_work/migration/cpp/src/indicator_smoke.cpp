#include "../indicators.hpp"
#include <cmath>
#include <iostream>
int main() {
  const std::vector<double> p{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
  if (std::abs(zrill::indicators::sma(p, 3)-14.0) > 1e-9) return 1;
  if (!(zrill::indicators::ema(p, 5) > 0)) return 2;
  if (std::abs(zrill::indicators::rsi(p, 14)-100.0) > 1e-9) return 3;
  std::cout << "C++ indicator smoke tests passed\\n";
}
