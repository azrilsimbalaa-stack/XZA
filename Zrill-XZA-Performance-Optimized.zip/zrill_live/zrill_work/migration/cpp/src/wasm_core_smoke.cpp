#include <cmath>
#include <iostream>
#include "../wasm_core.cpp"
int main() {
  constexpr int n = 128;
  auto *c = zrill_close_ptr(); auto *h = zrill_high_ptr(); auto *l = zrill_low_ptr();
  for (int i=0;i<n;++i) { c[i]=100.0+i*0.2+std::sin(i*0.17); h[i]=c[i]+0.6; l[i]=c[i]-0.5; }
  if (std::abs(zrill_sma(n, 20) - [&](){double s=0;for(int i=n-20;i<n;++i)s+=c[i];return s/20;}()) > 1e-9) return 1;
  if (!(zrill_ema(n, 20) > 0)) return 2;
  if (!(zrill_rsi(n, 14) >= 0 && zrill_rsi(n, 14) <= 100)) return 3;
  if (!(zrill_atr(n, 14) > 0)) return 4;
  if (!(zrill_adx(n, 14, 0) >= 0)) return 5;
  if (zrill_candle_pattern(7.5,12,7,11,10,8) != 1) return 6;
  std::cout << "Native C++ core smoke tests passed\n";
  return 0;
}
