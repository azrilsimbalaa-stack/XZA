// Zrill-XZA browser computation core. No Emscripten SDK or libc required.
// API consumes OHLC arrays written into exported WebAssembly memory.
using i32 = int;
using f64 = double;
static constexpr i32 CAP = 8192;
static f64 CLOSES[CAP];
static f64 HIGHS[CAP];
static f64 LOWS[CAP];
static f64 OPENS[CAP];
static f64 TIMES[CAP];
static f64 DIVERGENCE[9];
static f64 MACD_RESULT[3];
static f64 STOCH_RESULT[2];
static f64 BBANDS_RESULT[5];
static f64 ADX_RESULT[3];
static f64 TMP1[CAP];
static f64 TMP2[CAP];
static f64 TMP3[CAP];
static f64 TRS[CAP];
static f64 PLUSDM[CAP];
static f64 MINUSDM[CAP];
static f64 DXS[CAP];

static f64 absd(f64 x) { return x < 0 ? -x : x; }
static f64 maxd(f64 a, f64 b) { return a > b ? a : b; }
static f64 mind(f64 a, f64 b) { return a < b ? a : b; }
static f64 sqrt_approx(f64 x) {
  if (x <= 0) return 0;
  f64 g = x >= 1 ? x : 1;
  for (i32 i=0; i<32; ++i) g = 0.5 * (g + x / g);
  return g;
}
static f64 round_to(f64 x, f64 scale) { return (x >= 0 ? (f64)((long long)(x*scale + 0.5)) : (f64)((long long)(x*scale - 0.5))) / scale; }

extern "C" {
__attribute__((visibility("default"))) f64* zrill_close_ptr() { return CLOSES; }
__attribute__((visibility("default"))) f64* zrill_high_ptr() { return HIGHS; }
__attribute__((visibility("default"))) f64* zrill_low_ptr() { return LOWS; }
__attribute__((visibility("default"))) f64* zrill_open_ptr() { return OPENS; }
__attribute__((visibility("default"))) f64* zrill_time_ptr() { return TIMES; }
__attribute__((visibility("default"))) f64* zrill_divergence_ptr() { return DIVERGENCE; }
__attribute__((visibility("default"))) i32 zrill_capacity() { return CAP; }

__attribute__((visibility("default"))) f64 zrill_sma(i32 n, i32 period) {
  if (period <= 0 || n < period || n > CAP) return 0;
  f64 s=0; for (i32 i=n-period;i<n;++i) s += CLOSES[i]; return s/period;
}
__attribute__((visibility("default"))) f64 zrill_ema(i32 n, i32 period) {
  if (n <= 0 || n > CAP) return 0;
  if (period <= 0) return CLOSES[n-1];
  if (n < period) { f64 s=0; for(i32 i=0;i<n;++i)s+=CLOSES[i]; return s/n; }
  f64 s=0; for(i32 i=0;i<period;++i)s+=CLOSES[i];
  f64 e=s/period, k=2.0/(period+1.0);
  for(i32 i=period;i<n;++i)e=(CLOSES[i]-e)*k+e;
  return e;
}
static i32 ema_series(const f64* x, i32 n, i32 period, f64* out) {
  if (n > CAP || period <= 0) return 0;
  for(i32 i=0;i<n;++i) out[i]=0.0/0.0;
  if(n<period)return 0;
  f64 s=0; for(i32 i=0;i<period;++i)s+=x[i];
  f64 e=s/period,k=2.0/(period+1.0); out[period-1]=e;
  for(i32 i=period;i<n;++i){e=(x[i]-e)*k+e;out[i]=e;}
  return n;
}
__attribute__((visibility("default"))) f64 zrill_macd(i32 n, i32 fast, i32 slow, i32 signalp, i32 which) {
  if(n<0||n>CAP)return 0;
  ema_series(CLOSES,n,fast,TMP1); ema_series(CLOSES,n,slow,TMP2);
  i32 m=0; for(i32 i=0;i<n;++i) if(TMP1[i]==TMP1[i] && TMP2[i]==TMP2[i]) TMP3[m++]=TMP1[i]-TMP2[i];
  if(m==0)return 0;
  ema_series(TMP3,m,signalp,TRS);
  f64 mac=TMP3[m-1], sig=(TRS[m-1]==TRS[m-1])?TRS[m-1]:mac;
  return which==0?mac:(which==1?sig:mac-sig);
}
__attribute__((visibility("default"))) f64* zrill_macd_all(i32 n, i32 fast, i32 slow, i32 signalp) {
  MACD_RESULT[0]=MACD_RESULT[1]=MACD_RESULT[2]=0;
  if(n<0||n>CAP)return MACD_RESULT;
  ema_series(CLOSES,n,fast,TMP1); ema_series(CLOSES,n,slow,TMP2);
  i32 m=0; for(i32 i=0;i<n;++i) if(TMP1[i]==TMP1[i]&&TMP2[i]==TMP2[i])TMP3[m++]=TMP1[i]-TMP2[i];
  if(!m)return MACD_RESULT;
  ema_series(TMP3,m,signalp,TRS); f64 mac=TMP3[m-1], sig=(TRS[m-1]==TRS[m-1])?TRS[m-1]:mac;
  MACD_RESULT[0]=mac;MACD_RESULT[1]=sig;MACD_RESULT[2]=mac-sig;return MACD_RESULT;
}
__attribute__((visibility("default"))) f64 zrill_stochastic(i32 n, i32 pk, i32 pd, i32 which) {
  if(n<0||n>CAP||pk<=0||pd<=0||n<pk+pd-1)return 50;
  i32 count=0; f64 lastk=50, sum=0;
  for(i32 end=n-pd+1;end<=n;++end){
    f64 hh=-1.0e300,ll=1.0e300;
    for(i32 j=end-pk;j<end;++j){hh=maxd(hh,HIGHS[j]);ll=mind(ll,LOWS[j]);}
    lastk=(hh==ll)?50:((CLOSES[end-1]-ll)/(hh-ll))*100;
    sum+=lastk; ++count;
  }
  return which==0?lastk:sum/(count?count:1);
}
__attribute__((visibility("default"))) f64* zrill_stochastic_all(i32 n, i32 pk, i32 pd) {
  STOCH_RESULT[0]=STOCH_RESULT[1]=50;
  if(n<0||n>CAP||pk<=0||pd<=0||n<pk+pd-1)return STOCH_RESULT;
  i32 count=0;f64 lastk=50,sum=0;
  for(i32 end=n-pd+1;end<=n;++end){f64 hh=-1.0e300,ll=1.0e300;for(i32 j=end-pk;j<end;++j){hh=maxd(hh,HIGHS[j]);ll=mind(ll,LOWS[j]);}lastk=hh==ll?50:((CLOSES[end-1]-ll)/(hh-ll))*100;sum+=lastk;++count;}
  STOCH_RESULT[0]=lastk;STOCH_RESULT[1]=sum/(count?count:1);return STOCH_RESULT;
}
__attribute__((visibility("default"))) f64 zrill_rsi(i32 n, i32 period) {
  if(period<=0||n<=period||n>CAP)return 50;
  f64 gain=0,loss=0;
  for(i32 i=1;i<=period;++i){f64 d=CLOSES[i]-CLOSES[i-1]; if(d>0)gain+=d;else loss-=d;}
  f64 ag=gain/period,al=loss/period;
  for(i32 i=period+1;i<n;++i){f64 d=CLOSES[i]-CLOSES[i-1];ag=(ag*(period-1)+(d>0?d:0))/period;al=(al*(period-1)+(d<0?-d:0))/period;}
  if(al==0)return ag==0?50:100;
  return 100-100/(1+ag/al);
}
__attribute__((visibility("default"))) f64 zrill_atr(i32 n, i32 period) {
  if(period<=0||n<period+1||n>CAP)return 1.5;
  i32 m=0; for(i32 i=1;i<n;++i)TRS[m++]=maxd(HIGHS[i]-LOWS[i],maxd(absd(HIGHS[i]-CLOSES[i-1]),absd(LOWS[i]-CLOSES[i-1])));
  if(m<period)return round_to(m?TRS[m-1]:1.5,100);
  f64 a=0;for(i32 i=0;i<period;++i)a+=TRS[i];a/=period;
  for(i32 i=period;i<m;++i)a=(a*(period-1)+TRS[i])/period;
  return round_to(a,100);
}
__attribute__((visibility("default"))) f64 zrill_bbands(i32 n, i32 period, f64 mult, i32 which) {
  if(n<=0||n>CAP)return 0;
  if(n<period){f64 last=CLOSES[n-1];return which==3?0:(which==4?50:last);}
  f64 mean=0;for(i32 i=n-period;i<n;++i)mean+=CLOSES[i];mean/=period;
  f64 var=0;for(i32 i=n-period;i<n;++i){f64 d=CLOSES[i]-mean;var+=d*d;}var/=period;
  f64 sd=sqrt_approx(var),upper=mean+mult*sd,lower=mean-mult*sd,cur=CLOSES[n-1];
  f64 bw=mean!=0?((upper-lower)/mean)*100:0;
  f64 pb=upper!=lower?((cur-lower)/(upper-lower))*100:50;
  if(which==0)return round_to(upper,100); if(which==1)return round_to(mean,100); if(which==2)return round_to(lower,100); if(which==3)return round_to(bw,100); return round_to(pb,100);
}
__attribute__((visibility("default"))) f64* zrill_bbands_all(i32 n, i32 period, f64 mult) {
  if(n<=0||n>CAP){for(i32 j=0;j<5;++j)BBANDS_RESULT[j]=0;return BBANDS_RESULT;}
  if(n<period){f64 last=CLOSES[n-1];BBANDS_RESULT[0]=BBANDS_RESULT[1]=BBANDS_RESULT[2]=last;BBANDS_RESULT[3]=0;BBANDS_RESULT[4]=50;return BBANDS_RESULT;}
  f64 mean=0;for(i32 i=n-period;i<n;++i)mean+=CLOSES[i];mean/=period;f64 var=0;for(i32 i=n-period;i<n;++i){f64 d=CLOSES[i]-mean;var+=d*d;}var/=period;
  f64 sd=sqrt_approx(var),up=mean+mult*sd,lo=mean-mult*sd,cur=CLOSES[n-1];
  BBANDS_RESULT[0]=round_to(up,100);BBANDS_RESULT[1]=round_to(mean,100);BBANDS_RESULT[2]=round_to(lo,100);BBANDS_RESULT[3]=round_to(mean!=0?((up-lo)/mean)*100:0,100);BBANDS_RESULT[4]=round_to(up!=lo?((cur-lo)/(up-lo))*100:50,100);return BBANDS_RESULT;
}
__attribute__((visibility("default"))) f64 zrill_adx(i32 n, i32 period, i32 which) {
  if(period<=0||n<period*2||n>CAP)return 25;
  i32 m=0;
  for(i32 i=1;i<n;++i){f64 up=HIGHS[i]-HIGHS[i-1],down=LOWS[i-1]-LOWS[i];PLUSDM[m]=(up>down&&up>0)?up:0;MINUSDM[m]=(down>up&&down>0)?down:0;TRS[m]=maxd(HIGHS[i]-LOWS[i],maxd(absd(HIGHS[i]-CLOSES[i-1]),absd(LOWS[i]-CLOSES[i-1])));++m;}
  if(m<period)return 25;
  f64 tr=0,p=0,mi=0;for(i32 i=0;i<period;++i){tr+=TRS[i];p+=PLUSDM[i];mi+=MINUSDM[i];}
  i32 dxn=0;
  for(i32 i=period;i<m;++i){tr=tr-tr/period+TRS[i];p=p-p/period+PLUSDM[i];mi=mi-mi/period+MINUSDM[i];f64 pdi=tr>0?(p/tr)*100:0,mdi=tr>0?(mi/tr)*100:0,ds=pdi+mdi;DXS[dxn++]=ds>0?(absd(pdi-mdi)/ds)*100:0;}
  if(dxn<period){f64 sum=0;for(i32 i=0;i<dxn;++i)sum+=DXS[i];f64 av=sum/(dxn?dxn:1);return which==0?round_to(av,10):(which==1?round_to((p/(tr?tr:1))*100,10):round_to((mi/(tr?tr:1))*100,10));}
  f64 adx=0;for(i32 i=0;i<period;++i)adx+=DXS[i];adx/=period;
  for(i32 i=period;i<dxn;++i)adx=(adx*(period-1)+DXS[i])/period;
  f64 pdi=tr>0?(p/tr)*100:25,mdi=tr>0?(mi/tr)*100:25;
  return which==0?round_to(adx,10):(which==1?round_to(pdi,10):round_to(mdi,10));
}
__attribute__((visibility("default"))) f64* zrill_adx_all(i32 n, i32 period) {
  ADX_RESULT[0]=ADX_RESULT[1]=ADX_RESULT[2]=25;
  if(period<=0||n<period*2||n>CAP)return ADX_RESULT;
  i32 m=0;for(i32 i=1;i<n;++i){f64 up=HIGHS[i]-HIGHS[i-1],down=LOWS[i-1]-LOWS[i];PLUSDM[m]=(up>down&&up>0)?up:0;MINUSDM[m]=(down>up&&down>0)?down:0;TRS[m]=maxd(HIGHS[i]-LOWS[i],maxd(absd(HIGHS[i]-CLOSES[i-1]),absd(LOWS[i]-CLOSES[i-1])));++m;}
  if(m<period)return ADX_RESULT;
  f64 tr=0,p=0,mi=0;for(i32 i=0;i<period;++i){tr+=TRS[i];p+=PLUSDM[i];mi+=MINUSDM[i];}i32 dxn=0;
  for(i32 i=period;i<m;++i){tr=tr-tr/period+TRS[i];p=p-p/period+PLUSDM[i];mi=mi-mi/period+MINUSDM[i];f64 pdi=tr>0?p/tr*100:0,mdi=tr>0?mi/tr*100:0,ds=pdi+mdi;DXS[dxn++]=ds>0?absd(pdi-mdi)/ds*100:0;}
  if(dxn<period){f64 sum=0;for(i32 i=0;i<dxn;++i)sum+=DXS[i];ADX_RESULT[0]=round_to(sum/(dxn?dxn:1),10);ADX_RESULT[1]=round_to(p/(tr?tr:1)*100,10);ADX_RESULT[2]=round_to(mi/(tr?tr:1)*100,10);return ADX_RESULT;}
  f64 adx=0;for(i32 i=0;i<period;++i)adx+=DXS[i];adx/=period;for(i32 i=period;i<dxn;++i)adx=(adx*(period-1)+DXS[i])/period;
  ADX_RESULT[0]=round_to(adx,10);ADX_RESULT[1]=round_to(tr>0?p/tr*100:25,10);ADX_RESULT[2]=round_to(tr>0?mi/tr*100:25,10);return ADX_RESULT;
}
__attribute__((visibility("default"))) i32 zrill_rsi_divergence(i32 n, i32 period) {
  for(i32 j=0;j<9;++j)DIVERGENCE[j]=0;
  if(n<30||n>CAP||period<=0||n<=period)return 0;
  // Equivalent to calculateRSI(prefix, period) for each candle, using Wilder's
  // recursive smoothing so the whole RSI series is calculated in O(n).
  for(i32 i=0;i<n;++i)TMP1[i]=50;
  f64 gain=0,loss=0;
  for(i32 i=1;i<=period;++i){f64 d=CLOSES[i]-CLOSES[i-1];if(d>0)gain+=d;else loss-=d;}
  f64 ag=gain/period,al=loss/period;
  TMP1[period]=(al==0?(ag==0?50:100):100-100/(1+ag/al));
  for(i32 i=period+1;i<n;++i){f64 d=CLOSES[i]-CLOSES[i-1];ag=(ag*(period-1)+(d>0?d:0))/period;al=(al*(period-1)+(d<0?-d:0))/period;TMP1[i]=(al==0?(ag==0?50:100):100-100/(1+ag/al));}
  i32 start=n-45; if(start<15)start=15;
  i32 pc=0,tc=0; f64 p1price=0,p2price=0,p1rsi=0,p2rsi=0,p1time=0,p2time=0; i32 p1idx=0,p2idx=0; f64 t1price=0,t2price=0,t1rsi=0,t2rsi=0,t1time=0,t2time=0; i32 t1idx=0,t2idx=0;
  for(i32 i=start;i<n-1;++i){
    if(HIGHS[i]>=HIGHS[i-1]&&HIGHS[i]>=HIGHS[i-2]&&HIGHS[i]>=HIGHS[i+1]&&TMP1[i]>48){if(pc==0){p1idx=i;p1price=HIGHS[i];p1rsi=TMP1[i];p1time=TIMES[i];pc=1;}else if(pc==1){p2idx=i;p2price=HIGHS[i];p2rsi=TMP1[i];p2time=TIMES[i];pc=2;}else{p1idx=p2idx;p1price=p2price;p1rsi=p2rsi;p1time=p2time;p2idx=i;p2price=HIGHS[i];p2rsi=TMP1[i];p2time=TIMES[i];}}
    if(LOWS[i]<=LOWS[i-1]&&LOWS[i]<=LOWS[i-2]&&LOWS[i]<=LOWS[i+1]&&TMP1[i]<52){if(tc==0){t1idx=i;t1price=LOWS[i];t1rsi=TMP1[i];t1time=TIMES[i];tc=1;}else if(tc==1){t2idx=i;t2price=LOWS[i];t2rsi=TMP1[i];t2time=TIMES[i];tc=2;}else{t1idx=t2idx;t1price=t2price;t1rsi=t2rsi;t1time=t2time;t2idx=i;t2price=LOWS[i];t2rsi=TMP1[i];t2time=TIMES[i];}}
  }
  if(pc>=2&&p2idx-p1idx>=3&&p2price>p1price*1.00015&&p2rsi<p1rsi-1.0){DIVERGENCE[0]=1;DIVERGENCE[1]=p1idx;DIVERGENCE[2]=p2idx;DIVERGENCE[3]=p1price;DIVERGENCE[4]=p2price;DIVERGENCE[5]=p1rsi;DIVERGENCE[6]=p2rsi;DIVERGENCE[7]=p1time;DIVERGENCE[8]=p2time;return 1;}
  if(tc>=2&&t2idx-t1idx>=3&&t2price<t1price*0.99985&&t2rsi>t1rsi+1.0){DIVERGENCE[0]=2;DIVERGENCE[1]=t1idx;DIVERGENCE[2]=t2idx;DIVERGENCE[3]=t1price;DIVERGENCE[4]=t2price;DIVERGENCE[5]=t1rsi;DIVERGENCE[6]=t2rsi;DIVERGENCE[7]=t1time;DIVERGENCE[8]=t2time;return 2;}
  return 0;
}
__attribute__((visibility("default"))) i32 zrill_candle_pattern(f64 open,f64 high,f64 low,f64 close,f64 prevopen,f64 prevclose){
  f64 body=absd(close-open),uw=high-maxd(open,close),lw=mind(open,close)-low;
  if(prevclose<prevopen&&close>open&&close>prevopen&&open<prevclose)return 1;
  if(prevclose>prevopen&&close<open&&close<prevopen&&open>prevclose)return 2;
  if(lw>body*2&&uw<body)return 3;
  if(uw>body*2&&lw<body)return 4;
  return 0;
}
}
