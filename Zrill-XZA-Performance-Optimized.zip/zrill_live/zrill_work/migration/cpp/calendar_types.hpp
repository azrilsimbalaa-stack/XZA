#pragma once
#include <string>
#include <vector>

// Native C++ domain types for the Biquote calendar adapter.
// Prediction/classification decisions remain in the existing engine until
// the full engine is ported and parity-tested; this file does not replace them.
namespace zrill {
struct CalendarEvent {
    std::string id, title, currency, country, date, impact;
    int importance = -1;
    std::string forecast = "---", previous = "---", actual, unit;
    std::string source = "Biquote Economic Calendar (https://biquote.io)";
};
struct CalendarSnapshot {
    std::string source_url = "https://biquote.io/api/calendar";
    std::vector<CalendarEvent> events;
};
}
