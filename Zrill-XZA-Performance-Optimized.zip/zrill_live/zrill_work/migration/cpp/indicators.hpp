#pragma once
#include <algorithm>
#include <cmath>
#include <numeric>
#include <limits>
#include <vector>

// C++17 ports of the existing smcAnalysis.ts indicator routines.
// Keep defaults/fallbacks aligned with the TypeScript implementation.
namespace zrill::indicators {
inline double sma(const std::vector<double>& p, int period) {
  if (period <= 0 || static_cast<int>(p.size()) < period) return 0.0;
  return std::accumulate(p.end() - period, p.end(), 0.0) / period;
}
inline double ema(const std::vector<double>& p, int period) {
  if (p.empty()) return 0.0;
  if (period <= 0) return p.back();
  if (static_cast<int>(p.size()) < period) return std::accumulate(p.begin(), p.end(), 0.0) / p.size();
  const double k = 2.0 / (period + 1.0);
  double out = std::accumulate(p.begin(), p.begin() + period, 0.0) / period;
  for (size_t i = period; i < p.size(); ++i) out = (p[i] - out) * k + out;
  return out;
}
inline std::vector<double> ema_series(const std::vector<double>& p, int period) {
  std::vector<double> out(p.size(), std::numeric_limits<double>::quiet_NaN());
  if (period <= 0 || static_cast<int>(p.size()) < period) return out;
  const double k = 2.0 / (period + 1.0);
  double e = std::accumulate(p.begin(), p.begin() + period, 0.0) / period;
  out[period - 1] = e;
  for (size_t i = period; i < p.size(); ++i) { e = (p[i] - e) * k + e; out[i] = e; }
  return out;
}
struct Macd { double macd=0, signal=0, histogram=0; };
inline Macd macd(const std::vector<double>& closes, int fast=12, int slow=26, int signal_period=9) {
  auto f=ema_series(closes, fast), s=ema_series(closes, slow);
  std::vector<double> line;
  for (size_t i=0;i<closes.size();++i) if (std::isfinite(f[i]) && std::isfinite(s[i])) line.push_back(f[i]-s[i]);
  if (line.empty()) return {};
  auto sig=ema_series(line, signal_period);
  const double m=line.back();
  const double signal=std::isfinite(sig.back()) ? sig.back() : m;
  return {m, signal, m-signal};
}
inline double rsi(const std::vector<double>& c, int period=14) {
  if (period <= 0 || static_cast<int>(c.size()) <= period) return 50.0;
  double gain=0, loss=0;
  for (int i=1;i<=period;++i) { double d=c[i]-c[i-1]; if(d>0) gain+=d; else loss-=d; }
  double ag=gain/period, al=loss/period;
  for (size_t i=period+1;i<c.size();++i) { double d=c[i]-c[i-1]; ag=(ag*(period-1)+(d>0?d:0))/period; al=(al*(period-1)+(d<0?-d:0))/period; }
  if(al==0) return ag==0?50:100;
  return 100.0-100.0/(1.0+ag/al);
}
inline double atr(const std::vector<double>& h,const std::vector<double>& l,const std::vector<double>& c,int period=14) {
  if (period <= 0 || static_cast<int>(c.size()) < period+1) return 1.5;
  std::vector<double> tr;
  for(size_t i=1;i<c.size();++i) tr.push_back(std::max({h[i]-l[i],std::abs(h[i]-c[i-1]),std::abs(l[i]-c[i-1])}));
  if(static_cast<int>(tr.size())<period) return std::round((tr.empty()?1.5:tr.back())*100.0)/100.0;
  double a=std::accumulate(tr.begin(),tr.begin()+period,0.0)/period;
  for(size_t i=period;i<tr.size();++i) a=(a*(period-1)+tr[i])/period;
  return std::round(a*100.0)/100.0;
}
}
