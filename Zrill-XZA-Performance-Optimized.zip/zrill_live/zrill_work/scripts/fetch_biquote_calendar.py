#!/usr/bin/env python3
"""Fetch and normalize economic calendar events from Biquote.io."""
import json
import sys
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode
from urllib.request import Request, urlopen

BASE_URL = "https://biquote.io/api/calendar"

def fetch_calendar(days_back=1, days_forward=14):
    now = datetime.now(timezone.utc)
    params = urlencode({
        "from": (now - timedelta(days=days_back)).isoformat(),
        "to": (now + timedelta(days=days_forward)).isoformat(),
        "limit": 500,
    })
    request = Request(BASE_URL + "?" + params, headers={"Accept": "application/json", "User-Agent": "Zrill-XZA/1.0"})
    with urlopen(request, timeout=15) as response:
        data = json.loads(response.read().decode("utf-8"))
    if not isinstance(data, list):
        raise ValueError("Unexpected Biquote calendar response")
    return data

if __name__ == "__main__":
    try:
        print(json.dumps(fetch_calendar(), ensure_ascii=False))
    except Exception as exc:
        print("Biquote calendar error: " + str(exc), file=sys.stderr)
        sys.exit(1)
