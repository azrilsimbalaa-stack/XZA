# Zrill-XZA

Web application using React + TypeScript for the unchanged UI, a C++17/WebAssembly core for latency-sensitive indicator calculations, and Python for economic-calendar data acquisition.

## Run locally

Prerequisites: Node.js and Python 3.

```sh
npm install
npm run dev
```

The calendar endpoints fetch from Biquote (`https://biquote.io/api/calendar`) through `scripts/fetch_biquote_calendar.py`. The existing calendar prediction/classification logic in `src/services/institutionalCalendarEngine.ts` is retained unchanged.

The browser loads the compiled C++ module from `public/zrill-core.wasm`. The migrated native calculations are SMA, EMA, MACD, Stochastic, RSI, ATR, Bollinger Bands, ADX/DI, candlestick-pattern classification, and RSI-divergence pivot detection. TypeScript keeps the existing interfaces and a compatibility fallback if WebAssembly cannot load.

## Verification

```sh
npm run test:wasm
npm run test:native
```

See [`migration/README.md`](migration/README.md) for rebuild instructions and exact migration boundaries.

**Migration status:** the C++/WASM indicator hot path and Python Calendar fetching are integrated and tested. The larger precision signal, SMC-structure, classic-chart-pattern, intraday engine, real-time macro, and news-intelligence modules have not yet been fully ported from TypeScript; the project does not claim a complete application-wide conversion.
