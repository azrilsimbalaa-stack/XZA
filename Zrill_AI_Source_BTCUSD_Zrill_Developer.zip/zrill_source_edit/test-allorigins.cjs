async function test() {
  const proxy = 'https://api.allorigins.win/get?url=';
  const url = 'https://query1.finance.yahoo.com/v8/finance/chart/GC=F?range=1d&interval=1m';
  const res = await fetch(proxy + encodeURIComponent(url));
  const data = await res.json();
  const content = JSON.parse(data.contents);
  console.log(content.chart?.result?.[0]?.meta?.regularMarketPrice);
}
test();
