const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');
code = code.replace(/<\/motion\.div>\n    <\/div>\n  \);\n}/, '</motion.div>\n      </div>\n    </div>\n  );\n}');
fs.writeFileSync('src/App.tsx', code);
