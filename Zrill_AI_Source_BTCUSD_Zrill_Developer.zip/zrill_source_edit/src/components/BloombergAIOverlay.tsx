import React from 'react';
import { Newspaper, TrendingUp, AlertCircle } from 'lucide-react';

export const BloombergAIOverlay = () => {
  const newsItems = [
    { title: "XAUUSD Breaks Resistance: AI Predicts Bullish Extension", impact: "High", correlation: "Strong" },
    { title: "Fed Interest Rate Speculation Drives Volatility", impact: "High", correlation: "Moderate" },
    { title: "Geopolitical Tension Spurs Safe-Haven Demand", impact: "Medium", correlation: "Strong" },
  ];

  return (
    <div className="absolute bottom-4 left-4 z-40 bg-[#131722]/90 backdrop-blur border border-gray-800 p-2.5 rounded-lg shadow-2xl max-w-[240px] w-full">
      <div className="flex items-center gap-1.5 mb-2 border-b border-gray-800 pb-1.5">
        <Newspaper className="w-3 h-3 text-emerald-400" />
        <h3 className="text-[10px] font-bold text-gray-200 uppercase tracking-wider">Bloomberg AI</h3>
      </div>
      <div className="space-y-2">
        {newsItems.map((item, i) => (
          <div key={`bbg_news_${i}`} className="flex gap-2 items-start">
            <TrendingUp className="w-2.5 h-2.5 text-emerald-500 mt-0.5 shrink-0" />
            <div>
              <p className="text-[9px] text-gray-300 font-medium leading-tight">{item.title}</p>
              <div className="flex gap-1 mt-0.5">
                <span className="text-[8px] bg-gray-800 text-gray-400 px-1 py-0 rounded">{item.impact}</span>
                <span className="text-[8px] bg-emerald-900/30 text-emerald-400 px-1 py-0 rounded">{item.correlation}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
