import React from "react";
import { Cpu, Activity, Info, BarChart2 } from "lucide-react";
import { motion } from "motion/react";

interface DRLMetrics {
  stateValue: number;
  advantage: number;
  buyProb: number;
  sellProb: number;
  waitProb: number;
}

interface DRLMetricsOverlayProps {
  metrics: DRLMetrics | null;
  signal: string | null;
  isLoading: boolean;
}

export const DRLMetricsOverlay: React.FC<DRLMetricsOverlayProps> = ({
  metrics,
  signal,
  isLoading,
}) => {
  // Default fallback metrics if none provided
  const activeMetrics: DRLMetrics = metrics || {
    stateValue: 0.352,
    advantage: 0.084,
    buyProb: 0.65,
    sellProb: 0.25,
    waitProb: 0.10,
  };

  const getProbColor = (type: "BUY" | "SELL" | "WAIT") => {
    if (type === "BUY") return "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]";
    if (type === "SELL") return "bg-rose-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]";
    return "bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]";
  };

  const getProbBg = (type: "BUY" | "SELL" | "WAIT") => {
    if (type === "BUY") return "text-emerald-400";
    if (type === "SELL") return "text-rose-400";
    return "text-amber-400";
  };

  return (
    <div className="bg-[#131722]/95 border border-indigo-500/20 rounded-2xl p-4 shadow-2xl relative overflow-hidden backdrop-blur-md">
      <div className="absolute top-0 right-0 p-2 text-[8px] font-mono font-bold text-indigo-400/40 tracking-wider">
        PPO_PUPIL_V2
      </div>
      
      <div className="flex items-center gap-2 mb-3 pb-2 border-b border-gray-800/60">
        <Cpu className="w-4 h-4 text-indigo-400 animate-pulse" />
        <span className="text-xs font-bold text-white uppercase tracking-wider">
          DRL Neural Dashboard
        </span>
        <div className="ml-auto flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping"></span>
          <span className="text-[8px] text-indigo-400 font-bold uppercase tracking-widest">
            DRL CORE ACTIVE
          </span>
        </div>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-6 gap-3">
          <Activity className="w-6 h-6 text-indigo-400 animate-spin" />
          <span className="text-[10px] text-gray-400 font-mono animate-pulse">
            Calculating policy distributions...
          </span>
        </div>
      ) : (
        <div className="space-y-3.5">
          {/* Main DRL Stats */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#1A1D24]/80 p-2.5 rounded-xl border border-gray-800/60 flex flex-col justify-between">
              <div className="flex items-center gap-1 justify-between">
                <span className="text-[9px] text-gray-500 font-bold uppercase tracking-wider">
                  State Value V(s)
                </span>
                <Info className="w-2.5 h-2.5 text-gray-600 hover:text-gray-400 cursor-pointer" title="Expected discounted return of the current state" />
              </div>
              <div className="mt-1.5 flex items-baseline gap-1">
                <span className="text-lg font-black text-white font-mono leading-none">
                  {activeMetrics.stateValue.toFixed(4)}
                </span>
                <span className="text-[8px] text-emerald-400 font-mono font-bold">
                  ▲ {((activeMetrics.stateValue * 100) % 2).toFixed(1)}%
                </span>
              </div>
            </div>

            <div className="bg-[#1A1D24]/80 p-2.5 rounded-xl border border-gray-800/60 flex flex-col justify-between">
              <div className="flex items-center gap-1 justify-between">
                <span className="text-[9px] text-gray-500 font-bold uppercase tracking-wider">
                  Advantage A(s,a)
                </span>
                <Info className="w-2.5 h-2.5 text-gray-600 hover:text-gray-400 cursor-pointer" title="Quality of the chosen action relative to other actions" />
              </div>
              <div className="mt-1.5 flex items-baseline gap-1">
                <span className={`text-lg font-black font-mono leading-none ${activeMetrics.advantage >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                  {activeMetrics.advantage >= 0 ? "+" : ""}
                  {activeMetrics.advantage.toFixed(4)}
                </span>
                <span className={`text-[8px] font-mono font-bold ${activeMetrics.advantage >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                  {activeMetrics.advantage >= 0 ? "OPTIMAL" : "SUBOPTIMAL"}
                </span>
              </div>
            </div>
          </div>

          {/* Action Policy Probabilities (PPO/SAC Pi Distribution) */}
          <div className="bg-[#1A1D24]/40 border border-gray-800/40 p-3 rounded-xl space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[9px] text-gray-400 font-bold uppercase tracking-wider">
                Policy Probability Distribution π(a|s)
              </span>
              <BarChart2 className="w-3 h-3 text-gray-500" />
            </div>

            <div className="space-y-2">
              {/* Buy Probability */}
              <div className="space-y-1">
                <div className="flex justify-between items-center text-[9px] font-mono">
                  <span className="text-gray-400 font-bold">BUY ACTION π(Buy)</span>
                  <span className="text-emerald-400 font-extrabold font-sans">
                    {(activeMetrics.buyProb * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="h-1.5 bg-gray-800/60 rounded-full overflow-hidden relative">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${activeMetrics.buyProb * 100}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className={`h-full rounded-full ${getProbColor("BUY")}`}
                  />
                </div>
              </div>

              {/* Sell Probability */}
              <div className="space-y-1">
                <div className="flex justify-between items-center text-[9px] font-mono">
                  <span className="text-gray-400 font-bold">SELL ACTION π(Sell)</span>
                  <span className="text-rose-400 font-extrabold font-sans">
                    {(activeMetrics.sellProb * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="h-1.5 bg-gray-800/60 rounded-full overflow-hidden relative">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${activeMetrics.sellProb * 100}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className={`h-full rounded-full ${getProbColor("SELL")}`}
                  />
                </div>
              </div>

              {/* Wait Probability */}
              <div className="space-y-1">
                <div className="flex justify-between items-center text-[9px] font-mono">
                  <span className="text-gray-400 font-bold">WAIT ACTION π(Wait)</span>
                  <span className="text-amber-400 font-extrabold font-sans">
                    {(activeMetrics.waitProb * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="h-1.5 bg-gray-800/60 rounded-full overflow-hidden relative">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${activeMetrics.waitProb * 100}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className={`h-full rounded-full ${getProbColor("WAIT")}`}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
