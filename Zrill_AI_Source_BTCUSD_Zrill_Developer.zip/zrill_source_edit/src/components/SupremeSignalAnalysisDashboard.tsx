import React, { useState } from "react";
import {
  Zap,
  Shield,
  Layers,
  TrendingUp,
  TrendingDown,
  Target,
  Clock,
  Copy,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Cpu,
  BarChart2,
  DollarSign,
  Activity,
  Flame,
  Globe,
  Radio,
  Sliders,
  Award,
  Sparkles,
  Info,
  Maximize2,
  Minimize2,
  X,
  Crosshair,
  Brain,
  ArrowRight,
  AlertTriangle,
  HelpCircle,
  Percent,
  Calculator,
  ShieldCheck,
  Compass,
  Gauge,
  Waves,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import {
  PrecisionSignalResult,
  SupremeSignalMetrics,
  TimeframeSignalProfile,
  EntryThinkingStep,
  BestEntryZoneArchitecture,
  TimeframeCertaintyItem,
  OmnipresentMtfCertaintySynthesis,
  PrecisionVolatilityTracker,
  InstitutionalMoneyFlowTracker,
} from "../services/precisionSignalEngine";
import {
  GacorRiskCalculator,
  RiskCalculatorConfig,
  formatCurrencyVal
} from "./GacorRiskCalculator";

interface SupremeSignalAnalysisDashboardProps {
  currentSignal: PrecisionSignalResult | null;
  activeSymbol: { id: string; name: string };
  activeTimeframe: { id: string; name: string };
  currentPrice: number;
  onRefreshSignal?: () => void;
  isGenerating?: boolean;
  onSelectTimeframe?: (tf: string) => void;
  isOpen?: boolean;
  onClose?: () => void;
  isEmbedded?: boolean;
  riskCalculatorConfig?: RiskCalculatorConfig;
  onChangeRiskCalculatorConfig?: (config: RiskCalculatorConfig) => void;
}

export const SupremeSignalAnalysisDashboard: React.FC<SupremeSignalAnalysisDashboardProps> = ({
  currentSignal,
  activeSymbol,
  activeTimeframe,
  currentPrice,
  onRefreshSignal,
  isGenerating = false,
  onSelectTimeframe,
  isOpen = true,
  onClose,
  isEmbedded = false,
  riskCalculatorConfig,
  onChangeRiskCalculatorConfig,
}) => {
  const [activeTab, setActiveTab] = useState<"BEST_ZONE" | "VOLATILITY" | "FLOW" | "MTF_CERTAINTY" | "THOUGHT" | "SIZING" | "BLUEPRINT">("BEST_ZONE");
  const [selectedThoughtStep, setSelectedThoughtStep] = useState<number | null>(null);
  const [copiedStatus, setCopiedStatus] = useState<"IDLE" | "COPIED">("IDLE");
  const [copiedZoneStatus, setCopiedZoneStatus] = useState<"IDLE" | "COPIED">("IDLE");

  const [internalRiskConfig, setInternalRiskConfig] = useState<RiskCalculatorConfig>({
    isEnabled: false,
    currency: "USD",
    balance: 1000,
    riskPercent: 1.5,
    mode: "GOLDEN_ASYMMETRIC",
    customSlDistance: 4.5,
    customTp1Multiplier: 1.8,
    customTp2Multiplier: 3.6,
    customTp3Multiplier: 6.0,
  });

  const activeRiskConfig = riskCalculatorConfig || internalRiskConfig;
  const handleRiskConfigChange = (newConfig: RiskCalculatorConfig) => {
    if (onChangeRiskCalculatorConfig) {
      onChangeRiskCalculatorConfig(newConfig);
    } else {
      setInternalRiskConfig(newConfig);
    }
  };

  if (!isOpen) return null;

  const metrics: SupremeSignalMetrics | undefined = currentSignal?.supremeSignalMetrics;
  const bestZone: BestEntryZoneArchitecture | undefined = metrics?.bestEntryZone || currentSignal?.bestEntryZone;
  const thoughtChain: EntryThinkingStep[] = metrics?.entryThinkingChain || currentSignal?.entryThinkingChain || [];
  const isBuy = currentSignal?.type?.includes("BUY") ?? true;
  const signalType = currentSignal?.type || "BUY";
  const status = currentSignal?.status || "WAITING";

  const entry = currentSignal?.entry || currentPrice || 0;
  const sl = currentSignal?.sl || 0;
  const tp1 = currentSignal?.tp1 || currentSignal?.tp || 0;
  const tp2 = currentSignal?.tp2 || 0;
  const tp3 = currentSignal?.tp3 || 0;
  const rr = currentSignal?.rr || "1:3.0";
  const confidence = currentSignal?.confidence || 97;
  const omnipotence = metrics?.omnipotenceScore || confidence || 97.5;

  const omnipresentMtf: OmnipresentMtfCertaintySynthesis | undefined = metrics?.omnipresentMtfCertainty || currentSignal?.omnipresentMtfCertainty;
  const certaintyList: TimeframeCertaintyItem[] = omnipresentMtf?.timeframeCertaintyList || [
    { timeframe: "M1", name: "1-Minute", role: "Micro Precision Trigger", trend: isBuy ? "BULLISH" : "BEARISH", certaintyPercent: 99, status: "SANGAT PASTI (100%)", keyFactor: "Micro Sweet Spot Swept & Rejection Active", weightPercent: 5, alignmentWithSignal: true, entrySuggestion: "Eksekusi sniper timing dengan SL terkecil" },
    { timeframe: "M5", name: "5-Minute", role: "Structural Shift Trigger", trend: isBuy ? "BULLISH" : "BEARISH", certaintyPercent: 97, status: "TERKONFIRMASI (97%)", keyFactor: "CHoCH Displacement Valid", weightPercent: 8, alignmentWithSignal: true, entrySuggestion: "Trigger entri setelah retest swing micro" },
    { timeframe: "M15", name: "15-Minute", role: "Intraday Execution Setup", trend: isBuy ? "BULLISH" : "BEARISH", certaintyPercent: 98, status: "SANGAT PASTI (100%)", keyFactor: "Fair Value Gap Mitigated & Aligned", weightPercent: 10, alignmentWithSignal: true, entrySuggestion: "Eksekusi entri saat FVG M15 termitigasi" },
    { timeframe: "M30", name: "30-Minute", role: "Session Momentum Flow", trend: isBuy ? "BULLISH" : "BEARISH", certaintyPercent: 96, status: "TERKONFIRMASI (97%)", keyFactor: "Break of Structure Valid", weightPercent: 14, alignmentWithSignal: true, entrySuggestion: "Konfirmasi momentum ekspansi sesi aktif" },
    { timeframe: "H1", name: "1-Hour", role: "Institutional Bias & POC", trend: isBuy ? "BULLISH" : "BEARISH", certaintyPercent: 97, status: "TERKONFIRMASI (97%)", keyFactor: "0.618 OTE Golden Ratio Rejection", weightPercent: 18, alignmentWithSignal: true, entrySuggestion: "Validasi entri intraday pada candle H1" },
    { timeframe: "H4", name: "4-Hour", role: "Structural Swing Wave", trend: isBuy ? "BULLISH" : "BEARISH", certaintyPercent: 98, status: "SANGAT PASTI (100%)", keyFactor: "Institutional Order Block Unmitigated", weightPercent: 20, alignmentWithSignal: true, entrySuggestion: "Tahan runner hingga Swing High/Low terambil" },
    { timeframe: "D1", name: "Daily", role: "Macro Absolute Anchor", trend: isBuy ? "BULLISH" : "BEARISH", certaintyPercent: 99, status: "SANGAT PASTI (100%)", keyFactor: "Daily Expansion & PDH/PDL Target", weightPercent: 25, alignmentWithSignal: true, entrySuggestion: "Jangkar tren makro utama" },
  ];

  const handleCopySignal = async () => {
    const textToCopy = metrics?.quickMtCopyText || `⚡ ZRILL AI SUPREME SIGNAL: ${signalType} ${activeSymbol.id} @ ${entry.toFixed(2)} | SL: ${sl.toFixed(2)} | TP1: ${tp1.toFixed(2)} | TP2: ${tp2.toFixed(2)} | TP3: ${tp3.toFixed(2)}`;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(textToCopy);
      } else {
        const textArea = document.createElement("textarea");
        textArea.value = textToCopy;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
      }
      setCopiedStatus("COPIED");
      setTimeout(() => setCopiedStatus("IDLE"), 2500);
    } catch (e) {
      console.error("Copy failed", e);
    }
  };

  const handleCopyBestZone = async () => {
    const zoneText = bestZone?.limitOrderSetupText || `🎯 ZONA TERBAIK ENTRY ${activeSymbol.id}: ${bestZone?.zoneRangeMin.toFixed(2)} - ${bestZone?.zoneRangeMax.toFixed(2)} (Sweet Spot: ${bestZone?.sweetSpotSniperPrice.toFixed(2)})`;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(zoneText);
      } else {
        const textArea = document.createElement("textarea");
        textArea.value = zoneText;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
      }
      setCopiedZoneStatus("COPIED");
      setTimeout(() => setCopiedZoneStatus("IDLE"), 2500);
    } catch (e) {
      console.error("Copy failed", e);
    }
  };

  const getPillarCategoryIcon = (cat: string) => {
    switch (cat) {
      case "STRUCTURE":
        return <Layers className="w-3.5 h-3.5 text-cyan-400" />;
      case "LIQUIDITY":
        return <Target className="w-3.5 h-3.5 text-amber-400" />;
      case "FIBONACCI":
        return <Sparkles className="w-3.5 h-3.5 text-yellow-400" />;
      case "ORDER_FLOW":
        return <BarChart2 className="w-3.5 h-3.5 text-emerald-400" />;
      case "RISK_REWARD":
        return <Shield className="w-3.5 h-3.5 text-indigo-400" />;
      case "TIMING":
        return <Clock className="w-3.5 h-3.5 text-purple-400" />;
      case "MACRO":
        return <Globe className="w-3.5 h-3.5 text-blue-400" />;
      default:
        return <Activity className="w-3.5 h-3.5 text-emerald-400" />;
    }
  };

  return (
    <div
      className={`relative overflow-hidden rounded-2xl border transition-all duration-300 font-sans backdrop-blur-2xl ${
        isEmbedded
          ? "bg-[#0b0f19]/95 border-emerald-500/30 shadow-[0_12px_40px_rgba(0,0,0,0.8),0_0_20px_rgba(16,185,129,0.1)] w-full mb-4"
          : "fixed inset-x-2 sm:inset-x-auto sm:right-6 bottom-4 sm:bottom-6 z-50 max-w-4xl w-full max-h-[92vh] bg-[#0b0f19]/98 border-emerald-500/40 shadow-[0_25px_60px_rgba(0,0,0,0.9),0_0_35px_rgba(16,185,129,0.2)] flex flex-col"
      }`}
    >
      {/* Top Ambient Glow Line */}
      <div
        className={`h-1 w-full bg-gradient-to-r ${
          isBuy
            ? "from-emerald-500 via-teal-400 to-cyan-400"
            : "from-rose-500 via-amber-500 to-orange-400"
        }`}
      />

      {/* Header Bar */}
      <div className="p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3 border-b border-gray-800/80 bg-black/40">
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center border shadow-lg ${
                isBuy
                  ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-400 shadow-emerald-500/20"
                  : "bg-rose-500/20 border-rose-500/40 text-rose-400 shadow-rose-500/20"
              }`}
            >
              <Zap className="w-5 h-5 fill-current animate-pulse" />
            </div>
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-black text-white tracking-wider flex items-center gap-1.5">
                ZRILL AI SUPREME SIGNAL TERMINAL
                <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono font-bold">
                  VOLATILITAS &amp; ALIRAN DANA
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-md bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 font-mono font-bold">
                  PRESISI INSTITUSIONAL
                </span>
              </h2>
            </div>
            <p className="text-[11px] text-gray-400 flex items-center gap-2 mt-0.5 flex-wrap">
              <span className="font-mono text-cyan-300 font-bold">{activeSymbol.id}</span>
              <span className="text-gray-600">&bull;</span>
              <span className="font-mono text-gray-300">{activeTimeframe.id}</span>
              <span className="text-gray-600">&bull;</span>
              <span className="text-emerald-400 font-mono">Pelacak Volatilitas Presisi + Aliran Dana Smart Money + Area Sniper</span>
            </p>
          </div>
        </div>

        {/* Right Header Actions */}
        <div className="flex items-center gap-2">
          {onRefreshSignal && (
            <button
              onClick={onRefreshSignal}
              disabled={isGenerating}
              className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 border border-white/10 text-xs font-bold text-gray-200 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Activity className={`w-3.5 h-3.5 text-cyan-400 ${isGenerating ? "animate-spin" : ""}`} />
              <span>{isGenerating ? "Menganalisis..." : "Scan Ulang"}</span>
            </button>
          )}

          <button
            onClick={handleCopySignal}
            className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer active:scale-95 ${
              copiedStatus === "COPIED"
                ? "bg-emerald-400 text-black shadow-[0_0_15px_rgba(52,211,153,0.5)]"
                : "bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40"
            }`}
          >
            {copiedStatus === "COPIED" ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-black" />
                <span>TERSALIN! ✓</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Salin Signal</span>
              </>
            )}
          </button>

          {!isEmbedded && onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Omnipotence Score & Big Verdict Hero Banner */}
      <div className="p-4 sm:p-5 bg-gradient-to-b from-black/50 to-transparent border-b border-gray-800/60">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          {/* Action Callout */}
          <div className="md:col-span-7 flex flex-col justify-center">
            <div className="flex items-center gap-2 mb-1.5">
              <span
                className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${
                  isBuy
                    ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                    : "bg-rose-500/20 text-rose-300 border-rose-500/40"
                }`}
              >
                {metrics?.powerGrade || "SUPREME APEX AAA+"}
              </span>
              <span className="text-[10px] text-gray-400 font-mono">
                {currentSignal?.witaCalendarSync?.activeSession || "LONDON KILLZONE"} (WITA SYNC)
              </span>
            </div>

            <div className="flex items-baseline gap-3">
              <h1
                className={`text-2xl sm:text-3xl font-black tracking-tight ${
                  isBuy
                    ? "text-emerald-400 drop-shadow-[0_0_15px_rgba(16,185,129,0.4)]"
                    : "text-rose-400 drop-shadow-[0_0_15px_rgba(244,63,94,0.4)]"
                }`}
              >
                {status === "WAITING"
                  ? "MEMINDAI SETUP TERBAIK..."
                  : currentSignal?.orderExecutionType || (isBuy ? "BUY NOW" : "SELL NOW")}
              </h1>
              <span className="text-xs sm:text-sm font-black font-mono text-gray-400">
                @ ${entry.toFixed(2)}
              </span>
            </div>

            <p className="text-xs text-gray-300 mt-2 leading-relaxed line-clamp-2">
              {metrics?.aiSupremeVerdict || currentSignal?.analysis || "Analisa 12 Pilar konfluensi penuh membuktikan keunggulan momentum tanpa kontradiksi."}
            </p>
          </div>

          {/* Omnipotence Gauge */}
          <div className="md:col-span-5 bg-white/[0.02] border border-white/[0.08] rounded-2xl p-3.5 flex items-center justify-between gap-3 shadow-inner">
            <div className="flex flex-col">
              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider font-mono">
                OMNIPOTENCE SCORE
              </span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono">
                  {omnipotence}%
                </span>
                <span className="text-[10px] font-bold text-gray-500 font-mono">/ 100%</span>
              </div>
              <span className="text-[9px] font-bold text-cyan-300 mt-1 flex items-center gap-1">
                <Waves className="w-3 h-3 text-cyan-400" />
                Aliran Dana &amp; Volatilitas Presisi
              </span>
            </div>

            {/* Micro Progress Bar */}
            <div className="flex flex-col items-end gap-1.5 w-28">
              <div className="w-full bg-gray-800 rounded-full h-2.5 overflow-hidden p-0.5 border border-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 shadow-[0_0_8px_rgba(16,185,129,0.7)]"
                  style={{ width: `${Math.min(100, omnipotence)}%` }}
                />
              </div>
              <span className="text-[8px] font-mono text-gray-400 font-bold uppercase">
                R:R Terjamin {rr}
              </span>
            </div>
          </div>
        </div>

        {/* SPOTLIGHT: AREA TERBAIK UNTUK ENTRY (SNIPER ZONE BANNER) */}
        {bestZone && (
          <div className="mt-4 p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-teal-950/30 to-cyan-950/40 border border-emerald-400/40 shadow-[0_0_20px_rgba(16,185,129,0.15)] flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center text-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.3)] shrink-0">
                <Crosshair className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-black text-white tracking-wide uppercase flex items-center gap-1">
                    <span>AREA TERBAIK UNTUK ENTRY (SNIPER ZONE)</span>
                  </span>
                  <span className="text-[9.5px] px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 font-bold font-mono">
                    {bestZone.valuationLabel.split("(")[0]}
                  </span>
                </div>
                <div className="flex items-baseline gap-2 mt-0.5 flex-wrap">
                  <span className="text-sm sm:text-base font-black font-mono text-emerald-300">
                    ${bestZone.zoneRangeMin.toFixed(2)} &ndash; ${bestZone.zoneRangeMax.toFixed(2)}
                  </span>
                  <span className="text-xs font-bold font-mono text-cyan-300">
                    (Sweet Spot: ${bestZone.sweetSpotSniperPrice.toFixed(2)})
                  </span>
                  <span className="text-[10px] font-mono text-gray-400">
                    &bull; {bestZone.isPriceCurrentlyInZone ? "🟢 Sedang di Zona" : `Jarak: ${bestZone.distanceFromCurrentPricePipsStr}`}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab("BEST_ZONE")}
                className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-400/40 text-xs font-bold font-mono transition-all flex items-center gap-1 cursor-pointer active:scale-95"
              >
                <span>Lihat Detail Area</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={handleCopyBestZone}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-gray-200 border border-white/20 text-xs font-bold font-mono transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                title="Salin Setup Pending Limit Area Terbaik"
              >
                {copiedZoneStatus === "COPIED" ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Disalin!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-gray-300" />
                    <span>Salin Area</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* 4 Execution Levels Grid: Entry, SL, TP1, TP2, TP3 */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mt-3">
          <div className="bg-[#121622] p-2.5 rounded-xl border border-gray-800/80 flex flex-col">
            <span className="text-[9px] font-bold text-gray-400 font-mono uppercase">1. ENTRY LEVEL</span>
            <span className="text-sm sm:text-base font-black text-white font-mono mt-0.5">
              ${entry.toFixed(2)}
            </span>
            <span className="text-[8.5px] text-cyan-400 mt-0.5">0.618 OTE Golden Zone</span>
          </div>

          <div className="bg-[#121622] p-2.5 rounded-xl border border-rose-500/20 flex flex-col">
            <span className="text-[9px] font-bold text-rose-400 font-mono uppercase">2. STOP LOSS (SL)</span>
            <span className="text-sm sm:text-base font-black text-rose-400 font-mono mt-0.5">
              ${sl.toFixed(2)}
            </span>
            <span className="text-[8.5px] text-gray-400 mt-0.5">ATR Volatility Shield</span>
          </div>

          <div className="bg-[#121622] p-2.5 rounded-xl border border-emerald-500/20 flex flex-col">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-emerald-400 font-mono uppercase">3. TP 1 (BREAKEVEN)</span>
              <span className="text-[7.5px] bg-emerald-500/20 text-emerald-300 px-1 rounded font-bold">1:1.8</span>
            </div>
            <span className="text-sm sm:text-base font-black text-emerald-400 font-mono mt-0.5">
              ${tp1.toFixed(2)}
            </span>
            <span className="text-[8.5px] text-gray-400 mt-0.5">Geser SL ke Entry saat hit</span>
          </div>

          <div className="bg-[#121622] p-2.5 rounded-xl border border-emerald-500/20 flex flex-col">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-emerald-400 font-mono uppercase">4. TP 2 (LIQUIDITY)</span>
              <span className="text-[7.5px] bg-emerald-500/20 text-emerald-300 px-1 rounded font-bold">1:3.2</span>
            </div>
            <span className="text-sm sm:text-base font-black text-emerald-400 font-mono mt-0.5">
              ${tp2.toFixed(2)}
            </span>
            <span className="text-[8.5px] text-gray-400 mt-0.5">Amankan 70% Profit</span>
          </div>

          <div className="col-span-2 sm:col-span-1 bg-[#121622] p-2.5 rounded-xl border border-cyan-500/30 flex flex-col">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-cyan-400 font-mono uppercase">5. TP 3 (RUNNER)</span>
              <span className="text-[7.5px] bg-cyan-500/20 text-cyan-300 px-1 rounded font-bold">1:5.0</span>
            </div>
            <span className="text-sm sm:text-base font-black text-cyan-300 font-mono mt-0.5">
              ${tp3.toFixed(2)}
            </span>
            <span className="text-[8.5px] text-gray-400 mt-0.5">Runner Gelombang Makro</span>
          </div>
        </div>

        {/* KEPASTIAN SEMUA TIMEFRAME (M1 s/d D1) QUICK CONFLUENCE STRIP */}
        <div className="mt-3.5 p-3 rounded-xl bg-gradient-to-r from-blue-950/40 via-indigo-950/30 to-purple-950/40 border border-cyan-500/30 flex flex-col gap-2 font-mono">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              <span className="text-[11px] font-black uppercase text-cyan-200 tracking-wider">
                KEPASTIAN SEMUA TIMEFRAME (M1 s/d D1)
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                {omnipresentMtf?.consensusRating || "7/7 KONSENSUS MUTLAK"} ({omnipresentMtf?.overallCertaintyScore || 98.4}% PASTI)
              </span>
              <button
                onClick={() => setActiveTab("MTF_CERTAINTY")}
                className="text-[10px] font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer transition-colors"
              >
                <span>Lihat Matriks</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5">
            {[
              { tf: "M1", label: "Micro Sniper", defaultCert: 99, role: "Trigger" },
              { tf: "M5", label: "CHoCH Shift", defaultCert: 97, role: "Reversal" },
              { tf: "M15", label: "Intraday FVG", defaultCert: 98, role: "Setup" },
              { tf: "M30", label: "Session Flow", defaultCert: 96, role: "Momentum" },
              { tf: "H1", label: "Institusi POC", defaultCert: 97, role: "Structure" },
              { tf: "H4", label: "Swing Wave", defaultCert: 98, role: "Liquidity" },
              { tf: "D1", label: "Makro Anchor", defaultCert: 99, role: "Bias" },
            ].map((item) => {
              const isActive = activeTimeframe.id === item.tf;
              const tfData = certaintyList.find((c) => c.timeframe === item.tf);
              const certPercent = tfData?.certaintyPercent || item.defaultCert;

              return (
                <button
                  key={`dash_tf_${item.tf}`}
                  onClick={() => onSelectTimeframe?.(item.tf)}
                  className={`p-1.5 rounded-lg text-left transition-all border relative flex flex-col justify-between cursor-pointer ${
                    isActive
                      ? "bg-cyan-500/20 border-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.4)] ring-1 ring-cyan-400"
                      : "bg-black/40 border-white/10 hover:border-cyan-500/40 hover:bg-white/5"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-white">{item.tf}</span>
                    <span className="text-[8px] font-bold text-emerald-400">{certPercent}%</span>
                  </div>
                  <div className="flex items-center justify-between mt-1 text-[8px]">
                    <span className="text-gray-400 truncate">{item.role}</span>
                    <span className={`font-bold ${isBuy ? "text-emerald-400" : "text-rose-400"}`}>
                      {isBuy ? "BUY" : "SELL"}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="px-4 sm:px-5 pt-3 pb-2 flex items-center gap-2 border-b border-gray-800/80 overflow-x-auto select-none bg-black/20">
        {[
          { id: "BEST_ZONE", label: "Area Terbaik Entry (Sniper Zone)", icon: Crosshair },
          { id: "VOLATILITY", label: "Pelacak Volatilitas Presisi", icon: Activity },
          { id: "FLOW", label: "Pelacak Aliran Dana (Smart Money)", icon: DollarSign },
          { id: "MTF_CERTAINTY", label: "Kepastian 7 TF (M1 - D1)", icon: Layers },
          { id: "THOUGHT", label: "Cara Berpikir Entry (Thought Engine)", icon: Brain },
          { id: "SIZING", label: "Kalkulator Risiko & Lot Gacor", icon: Calculator },
          { id: "BLUEPRINT", label: "Tactical Execution Blueprint", icon: Shield },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={`dash_tab_${tab.id}`}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-500/20"
                  : "text-gray-400 hover:text-gray-200 hover:bg-white/5"
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? "text-emerald-400" : "text-gray-500"}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Tab Content Body */}
      <div className="p-4 sm:p-5 overflow-y-auto max-h-[58vh] space-y-4">
        {/* TAB 0: AREA TERBAIK UNTUK ENTRY (SNIPER ZONE SPOTLIGHT) */}
        {activeTab === "BEST_ZONE" && (
          <div className="space-y-4 font-sans">
            {/* Main Area Blueprint Card */}
            <div className="p-4 rounded-2xl bg-[#111520] border border-emerald-500/30 space-y-4 shadow-xl">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-800/80 pb-3">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 font-mono flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    ARSITEKTUR AREA TERBAIK ENTRY INSTITUSIONAL
                  </span>
                  <h3 className="text-base font-black text-white mt-0.5">
                    Zona Emas Presisi Tinggi: {bestZone?.zoneType || "Unmitigated Demand Block + 0.618 OTE"}
                  </h3>
                </div>
                <span className="text-xs px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono font-black">
                  {bestZone?.zoneQualityGrade || "PRISTINE ZERO-DRAWDOWN ZONE"}
                </span>
              </div>

              {/* Range & Sweet Spot Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-black/40 border border-gray-800 flex flex-col justify-between">
                  <span className="text-[10px] text-gray-400 font-mono font-bold uppercase">RENTANG AREA TERBAIK</span>
                  <div className="mt-1">
                    <span className="text-lg sm:text-xl font-black text-white font-mono">
                      ${bestZone ? `${bestZone.zoneRangeMin.toFixed(2)} - $${bestZone.zoneRangeMax.toFixed(2)}` : `${(entry - 1).toFixed(2)} - ${entry.toFixed(2)}`}
                    </span>
                    <p className="text-[10px] text-emerald-400 mt-0.5">Batas akurasi entry tanpa floating berlebih</p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-400/40 flex flex-col justify-between">
                  <span className="text-[10px] text-emerald-300 font-mono font-bold uppercase">SWEET SPOT SNIPER (0.618 OTE)</span>
                  <div className="mt-1">
                    <span className="text-lg sm:text-xl font-black text-emerald-300 font-mono">
                      ${bestZone ? bestZone.sweetSpotSniperPrice.toFixed(2) : entry.toFixed(2)}
                    </span>
                    <p className="text-[10px] text-cyan-300 mt-0.5">Titik entry matematis probabilitas tertinggi</p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-black/40 border border-gray-800 flex flex-col justify-between">
                  <span className="text-[10px] text-gray-400 font-mono font-bold uppercase">ESTIMASI MAX DRAWDOWN</span>
                  <div className="mt-1">
                    <span className="text-lg sm:text-xl font-black text-cyan-400 font-mono">
                      {bestZone?.expectedDrawdownAtr || "< 0.16 ATR"}
                    </span>
                    <p className="text-[10px] text-gray-400 mt-0.5">Proteksi invalidasi ketat di ${bestZone?.invalidationLevel.toFixed(2) || sl.toFixed(2)}</p>
                  </div>
                </div>
              </div>

              {/* Valuation Meter: Discount vs Premium Equilibrium */}
              <div className="p-3.5 rounded-xl bg-black/50 border border-gray-800/80 space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <span>🟢 DEEP DISCOUNT (Murah / Akumulasi)</span>
                  </span>
                  <span className="text-gray-400 font-bold">50% EQUILIBRIUM</span>
                  <span className="text-rose-400 font-bold flex items-center gap-1">
                    <span>🔴 HIGH PREMIUM (Mahal / Distribusi)</span>
                  </span>
                </div>

                <div className="relative w-full bg-gray-800/80 rounded-full h-4 overflow-hidden border border-white/10">
                  <div className="absolute inset-0 grid grid-cols-2 divide-x divide-white/20">
                    <div className="bg-emerald-500/20" />
                    <div className="bg-rose-500/20" />
                  </div>
                  <div
                    className={`absolute top-0 bottom-0 w-3 rounded-full shadow-[0_0_10px_rgba(255,255,255,0.8)] ${
                      isBuy ? "bg-emerald-400 left-[20%]" : "bg-rose-400 right-[20%]"
                    }`}
                  />
                </div>

                <div className="flex items-center justify-between text-[10px] text-gray-400 font-mono pt-1">
                  <span>Valuasi Sinyal: <strong className="text-emerald-300">{bestZone?.valuationLabel || "Deep Discount"}</strong></span>
                  <span>Diskon/Premium: <strong className="text-cyan-300">{bestZone?.discountOrPremiumPercentage || 68.4}%</strong></span>
                </div>
              </div>

              {/* Why This is the Best Area Explanation */}
              <div className="p-3.5 rounded-xl bg-white/[0.02] border border-white/10 space-y-2">
                <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                  <HelpCircle className="w-4 h-4 text-cyan-400" />
                  MENGAPA INI ADALAH AREA TERBAIK UNTUK ENTRY?
                </h4>
                <p className="text-xs text-gray-300 leading-relaxed">
                  {bestZone?.whyThisIsTheBestArea || "Area ini merupakan titik temu antara Unmitigated Order Block, Fibonacci 0.618 OTE, dan Fair Value Gap (FVG). Memasuki posisi di area ini memberikan Stop Loss tertipis dengan rasio imbal hasil tertinggi serta menghindari risiko drawdown."}
                </p>
              </div>

              {/* Action Banner: Instant Limit Order Setup */}
              <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-black/40 border border-emerald-500/30">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-bold text-gray-200 font-mono">
                    {bestZone?.recommendedExecutionBadge || "PASANG LIMIT DI SWEET SPOT"}
                  </span>
                </div>
                <button
                  onClick={handleCopyBestZone}
                  className="px-4 py-2 rounded-xl bg-emerald-500/25 hover:bg-emerald-500/35 text-emerald-200 border border-emerald-400/50 text-xs font-black font-mono transition-all flex items-center gap-1.5 cursor-pointer active:scale-95 shadow-[0_0_15px_rgba(16,185,129,0.3)]"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedZoneStatus === "COPIED" ? "SETUP TERSALIN! ✓" : "SALIN SETUP AREA TERBAIK"}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 0.5: KEPASTIAN 7 TIMEFRAME (M1 - D1 MATRIX & SYNTHESIS) */}
        {activeTab === "MTF_CERTAINTY" && (
          <div className="space-y-4 font-sans">
            {/* Header Overview Card */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-950/40 via-indigo-950/30 to-purple-950/40 border border-cyan-500/40 space-y-3 shadow-xl">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.3)]">
                    <Layers className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-cyan-400 font-mono flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      SINTESIS KEPASTIAN SPEKTRUM PENUH (M1 s/d D1)
                    </span>
                    <h3 className="text-sm sm:text-base font-black text-white">
                      Konsensus Institusional 7 Timeframe: M1 &bull; M5 &bull; M15 &bull; M30 &bull; H1 &bull; H4 &bull; D1
                    </h3>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono font-black flex items-center gap-1.5 shadow-[0_0_12px_rgba(16,185,129,0.3)]">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    {omnipresentMtf?.consensusRating || "7/7 KONSENSUS MUTLAK (PASTI TINGGI)"}
                  </span>
                </div>
              </div>

              {/* 4 Metric Pillows */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono">
                <div className="bg-black/40 p-2.5 rounded-xl border border-white/10 flex flex-col">
                  <span className="text-[9px] text-gray-400 uppercase font-bold">Skor Kepastian Global</span>
                  <span className="text-base font-black text-emerald-300 mt-0.5">
                    {omnipresentMtf?.overallCertaintyScore || 98.4}%
                  </span>
                  <span className="text-[8.5px] text-gray-400">Pembobotan Matematis</span>
                </div>
                <div className="bg-black/40 p-2.5 rounded-xl border border-white/10 flex flex-col">
                  <span className="text-[9px] text-gray-400 uppercase font-bold">Jangkar Makro (D1/H4)</span>
                  <span className={`text-base font-black mt-0.5 ${isBuy ? "text-emerald-400" : "text-rose-400"}`}>
                    {omnipresentMtf?.macroAnchorD1Bias || (isBuy ? "BULLISH DOMINANT" : "BEARISH DOMINANT")}
                  </span>
                  <span className="text-[8.5px] text-gray-400">Arus Likuiditas Utama</span>
                </div>
                <div className="bg-black/40 p-2.5 rounded-xl border border-white/10 flex flex-col">
                  <span className="text-[9px] text-gray-400 uppercase font-bold">Trigger Sniper (M1/M5)</span>
                  <span className="text-base font-black text-cyan-300 mt-0.5">
                    {omnipresentMtf?.executionTriggerM1Status || "ZERO DRAWDOWN"}
                  </span>
                  <span className="text-[8.5px] text-gray-400">Timing Presisi Tiket</span>
                </div>
                <div className="bg-black/40 p-2.5 rounded-xl border border-white/10 flex flex-col">
                  <span className="text-[9px] text-gray-400 uppercase font-bold">Pencegahan Whipsaw</span>
                  <span className="text-base font-black text-purple-300 mt-0.5">
                    100% TERLINDUNGI
                  </span>
                  <span className="text-[8.5px] text-gray-400">Zero False Break Filter</span>
                </div>
              </div>

              {/* Synthesis Verdict Narrative */}
              <div className="p-3 rounded-xl bg-black/40 border border-cyan-500/20 text-xs text-gray-300 leading-relaxed font-sans">
                <span className="text-cyan-300 font-bold font-mono uppercase text-[10px] block mb-1">
                  💡 KEPUTUSAN SINTESIS MULTI-TIMEFRAME:
                </span>
                {omnipresentMtf?.institutionalSynthesisVerdict ||
                  `Seluruh spektrum timeframe dari M1 hingga D1 telah teranalisis dengan harmoni matematis 100%. Struktur tren makro D1/H4 mendukung penuh arah ekspansi ${signalType}, zona retest intraday H1/M30 berada di Golden OTE (0.618), dan konfirmasi eksekusi micro M15/M5/M1 memberikan timing entri sniper dengan resiko invalidasi sekecil mungkin.`}
              </div>
            </div>

            {/* 7-Timeframe Matrix Cards */}
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-black text-white uppercase tracking-wider font-mono flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-cyan-400" />
                  MATRIKS STATUS KEPASTIAN 7 TIMEFRAME (M1 s/d D1)
                </span>
                <span className="text-[10px] text-gray-400 font-mono">
                  Klik timeframe untuk mengganti chart & eksekusi
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {certaintyList.map((item) => {
                  const isActive = activeTimeframe.id === item.timeframe;
                  const isItemBuy = item.trend.includes("BUY") || item.trend.includes("BULLISH");

                  return (
                    <div
                      key={`cert_tf_${item.timeframe}`}
                      className={`p-3.5 rounded-xl border transition-all flex flex-col justify-between font-mono relative ${
                        isActive
                          ? "bg-gradient-to-b from-cyan-950/50 to-[#0d1522] border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.25)] ring-1 ring-cyan-400/60"
                          : "bg-[#111520] border-gray-800/80 hover:border-gray-700 hover:bg-[#151a28]"
                      }`}
                    >
                      {isActive && (
                        <span className="absolute -top-2 right-2 px-1.5 py-0.2 rounded bg-cyan-400 text-[8px] font-black text-black uppercase shadow-sm">
                          AKTIF DI CHART
                        </span>
                      )}

                      {/* Top: TF, Role, Status */}
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-black text-white px-2 py-0.5 rounded bg-white/10 border border-white/15">
                              {item.timeframe}
                            </span>
                            <span className="text-[10px] text-cyan-300 font-bold">
                              {item.role}
                            </span>
                          </div>
                          <span
                            className={`text-[9px] font-black px-1.5 py-0.5 rounded ${
                              isItemBuy
                                ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                                : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                            }`}
                          >
                            {item.trend}
                          </span>
                        </div>

                        {/* Progress Bar & Percentage */}
                        <div className="space-y-1 my-2">
                          <div className="flex items-center justify-between text-[9px]">
                            <span className="text-gray-400">Kepastian</span>
                            <span className="text-emerald-300 font-bold">
                              {item.certaintyPercent}% ({item.status})
                            </span>
                          </div>
                          <div className="w-full bg-gray-800 rounded-full h-1.5 overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400 rounded-full shadow-[0_0_6px_rgba(16,185,129,0.6)]"
                              style={{ width: `${item.certaintyPercent}%` }}
                            />
                          </div>
                        </div>

                        {/* Factor & Suggestion */}
                        <div className="space-y-1 pt-1.5 border-t border-white/5 text-[9.5px]">
                          <div className="text-gray-300 flex items-start gap-1">
                            <span className="text-gray-500 shrink-0">&bull;</span>
                            <span className="text-gray-300 font-sans leading-tight">
                              <span className="text-gray-400 font-bold font-mono">Faktor: </span>
                              {item.keyFactor}
                            </span>
                          </div>
                          <div className="text-emerald-300 flex items-start gap-1">
                            <span className="text-emerald-500 shrink-0">&bull;</span>
                            <span className="font-sans leading-tight">
                              <span className="text-emerald-400 font-bold font-mono">Aksi: </span>
                              {item.entrySuggestion}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Bottom Button Action */}
                      <div className="pt-2.5 mt-2 border-t border-white/5 flex items-center justify-between">
                        <span className="text-[8.5px] text-gray-500">
                          Bobot Sinyal: {item.weightPercent}%
                        </span>
                        <button
                          onClick={() => onSelectTimeframe?.(item.timeframe)}
                          className={`text-[9.5px] font-bold px-2 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1 ${
                            isActive
                              ? "bg-cyan-500 text-black font-black"
                              : "bg-white/5 hover:bg-cyan-500/20 text-cyan-300 border border-white/10 hover:border-cyan-500/40"
                          }`}
                        >
                          <span>{isActive ? "Sedang Dilihat" : `Beralih ke ${item.timeframe}`}</span>
                          <ArrowRight className="w-2.5 h-2.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 3 Hierarchical Spheres Explanation Card */}
            <div className="p-4 rounded-2xl bg-[#111520] border border-white/10 space-y-3 font-sans">
              <div className="flex items-center gap-2 border-b border-white/10 pb-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs font-black text-white font-mono uppercase tracking-wider">
                  ARSITEKTUR HIERARKI 3 TINGKATAN EKSEKUSI (ANTI-TABRAKAN)
                </h4>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-black/30 border border-purple-500/30 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-purple-300 font-mono">1. JANGKAR MAKRO (D1 & H4)</span>
                    <span className="text-[8.5px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono font-bold">BOBOT 45%</span>
                  </div>
                  <p className="text-[11px] text-gray-300 leading-relaxed">
                    Menentukan arah likuiditas absolut dan target Previous Daily High/Low (PDH/PDL). Melarang mutlak posisi counter-trend makro demi keselamatan akun.
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-black/30 border border-blue-500/30 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-blue-300 font-mono">2. STRUKTUR INTRADAY (H1 & M30)</span>
                    <span className="text-[8.5px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 font-mono font-bold">BOBOT 32%</span>
                  </div>
                  <p className="text-[11px] text-gray-300 leading-relaxed">
                    Memetakan Fair Value Gap (FVG), Point of Control (POC), dan Golden Ratio 0.618 OTE. Memastikan order dieksekusi pada harga diskon/premium terbaik.
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-black/30 border border-cyan-500/30 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-cyan-300 font-mono">3. SNIPER TRIGGER (M15, M5, M1)</span>
                    <span className="text-[8.5px] px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-mono font-bold">BOBOT 23%</span>
                  </div>
                  <p className="text-[11px] text-gray-300 leading-relaxed">
                    Menangkap Change of Character (CHoCH), sapuan likuiditas micro, dan delta volume order flow. Menghasilkan entri presisi tinggi dengan floating loss minim.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
        {activeTab === "THOUGHT" && (
          <div className="space-y-4 font-sans">
            <div className="p-4 rounded-2xl bg-[#111520] border border-cyan-500/30 space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Brain className="w-4 h-4 text-cyan-400" />
                  CARA BERPIKIR INSTITUSIONAL (6-STAGE COGNITIVE CHAIN)
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 font-mono font-bold border border-cyan-500/40">
                  Akurasi Logika 100% Bebas Asumsi
                </span>
              </div>
              <p className="text-[11px] text-gray-300 leading-relaxed">
                Smart money dan algoritma institusional tidak pernah mengambil posisi tanpa melalui 6 gerbang logika berikut secara berurutan:
              </p>
            </div>

            {/* 6-Stage Steps */}
            <div className="space-y-3">
              {thoughtChain.map((step, sIdx) => {
                const isSelected = selectedThoughtStep === step.stepNumber;
                return (
                  <div
                    key={`thought_step_${step.stepNumber || sIdx}`}
                    className={`rounded-2xl border transition-all overflow-hidden ${
                      isSelected
                        ? "bg-[#141926] border-cyan-400/50 shadow-[0_0_20px_rgba(6,182,212,0.2)]"
                        : "bg-[#0e121c] border-gray-800/90 hover:border-gray-700"
                    }`}
                  >
                    {/* Header */}
                    <div
                      onClick={() => setSelectedThoughtStep(isSelected ? null : step.stepNumber)}
                      className="p-3.5 flex items-center justify-between gap-3 cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-7 h-7 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center justify-center font-mono font-black text-xs shrink-0">
                          {step.stepNumber}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <h4 className="text-xs sm:text-sm font-bold text-white">
                              {step.title}
                            </h4>
                            <span className="text-[9px] px-2 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono font-bold">
                              {step.statusBadge}
                            </span>
                          </div>
                          <span className="text-[10px] text-gray-400 font-mono">
                            {step.stageName}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="hidden sm:inline-block text-[10px] font-mono text-cyan-300 font-bold bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-800/50">
                          {step.keyMetric}
                        </span>
                        {isSelected ? (
                          <ChevronUp className="w-4 h-4 text-gray-400" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-gray-400" />
                        )}
                      </div>
                    </div>

                    {/* Expandable Content */}
                    <AnimatePresence>
                      {isSelected && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.2 }}
                          className="px-4 pb-4 pt-1 border-t border-gray-800/80 space-y-3 bg-black/20"
                        >
                          {/* Core Question Asked by Smart Money */}
                          <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/10">
                            <span className="text-[9px] font-bold text-amber-400 uppercase font-mono block">
                              PERTANYAAN KRUSIAL INSTITUSI:
                            </span>
                            <p className="text-xs text-amber-200 mt-0.5 font-medium italic">
                              "{step.coreQuestion}"
                            </p>
                          </div>

                          {/* Institutional Observation */}
                          <div className="space-y-1">
                            <span className="text-[9px] font-bold text-gray-400 uppercase font-mono block">
                              FAKTA ANALISA PASAR:
                            </span>
                            <p className="text-xs text-gray-200 leading-relaxed">
                              {step.institutionalObservation}
                            </p>
                          </div>

                          {/* Final Verdict of this Step */}
                          <div className="flex items-center justify-between gap-2 pt-2 border-t border-gray-800/60 text-[10px] font-mono">
                            <span className="text-emerald-400 font-bold flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              {step.verdict}
                            </span>
                            <span className="text-gray-400">
                              Metrik Kunci: <strong className="text-white">{step.keyMetric}</strong>
                            </span>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 1: PELACAK VOLATILITAS PRESISI PASAR (ATR SIGMA & BOLLINGER DYNAMICS) */}
        {activeTab === "VOLATILITY" && (
          <div className="space-y-4 font-sans">
            {/* Header Status & Gauge Grid */}
            {(() => {
              const vol = metrics?.precisionVolatilityTracker;
              const atrPips = vol?.atrPips || 24;
              const regime = vol?.volatilityRegime || "EKSPANSI MODERAT";
              const score = vol?.volatilityIndexScore || 82;
              const bollinger = vol?.bollingerPhase || "EXPANSION RIDING";
              const bw = vol?.bollingerBandwidthPercent || 2.45;
              const histPerc = vol?.historicalVolatilityPercentile || 84;
              const sigma = vol?.sigmaBands || {
                sigma1Range: { lower: entry - 4.5, upper: entry + 4.5, pips: 18 },
                sigma2Range: { lower: entry - 9.0, upper: entry + 9.0, pips: 36 },
                sigma26GoldenRange: { lower: entry - 11.7, upper: entry + 11.7, pips: 47 },
                sigma3ExtremeRange: { lower: entry - 13.5, upper: entry + 13.5, pips: 54 },
              };
              const proj = vol?.sessionProjectedRange || {
                expectedHigh: entry + 12.5,
                expectedLow: entry - 5.0,
                pipSpanTotal: 70,
                remainingRoomPips: 48,
                dailyAtrLimit: 85,
              };

              return (
                <>
                  {/* Top Volatility Dashboard Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {/* Card 1: Volatility Regime */}
                    <div className="bg-[#111520] p-3.5 rounded-2xl border border-emerald-500/30 flex flex-col justify-between shadow-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">
                          REGIME VOLATILITAS
                        </span>
                        <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                      </div>
                      <div className="my-2">
                        <div className="text-sm sm:text-base font-black text-emerald-300 font-mono tracking-tight leading-snug">
                          {regime}
                        </div>
                        <span className="text-[10px] font-mono text-cyan-300 font-bold">
                          ATR Live: {atrPips} Pips (${vol?.atrPrice || 2.40})
                        </span>
                      </div>
                      <div className="w-full bg-gray-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400"
                          style={{ width: `${Math.min(100, score)}%` }}
                        />
                      </div>
                    </div>

                    {/* Card 2: Volatility Score */}
                    <div className="bg-[#111520] p-3.5 rounded-2xl border border-cyan-500/30 flex flex-col justify-between shadow-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">
                          VOLATILITY INDEX SCORE
                        </span>
                        <Gauge className="w-3.5 h-3.5 text-cyan-400" />
                      </div>
                      <div className="my-2 flex items-baseline gap-1.5">
                        <span className="text-2xl font-black text-cyan-300 font-mono">
                          {score}
                        </span>
                        <span className="text-[10px] font-mono text-gray-400">/ 100</span>
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-mono font-bold border border-cyan-500/40 ml-auto">
                          Top {histPerc}% Histori
                        </span>
                      </div>
                      <span className="text-[10px] text-gray-400 font-mono">
                        Bandwidth BB: <strong className="text-white">{bw}%</strong>
                      </span>
                    </div>

                    {/* Card 3: Bollinger Dynamics */}
                    <div className="bg-[#111520] p-3.5 rounded-2xl border border-indigo-500/30 flex flex-col justify-between shadow-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">
                          FASE BOLLINGER
                        </span>
                        <Waves className="w-3.5 h-3.5 text-indigo-400" />
                      </div>
                      <div className="my-2">
                        <div className="text-xs font-black text-indigo-300 font-mono uppercase">
                          {bollinger}
                        </div>
                        <span className="text-[10px] text-gray-400 font-mono">
                          Ekspansi searah sinyal {isBuy ? 'BUY' : 'SELL'}
                        </span>
                      </div>
                      <div className="text-[9px] text-indigo-300 font-bold font-mono">
                        Bebas Squeeze Trap ✓
                      </div>
                    </div>

                    {/* Card 4: Safety SL Buffer Armor */}
                    <div className="bg-[#111520] p-3.5 rounded-2xl border border-amber-500/30 flex flex-col justify-between shadow-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">
                          SL SAFETY BUFFER
                        </span>
                        <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                      </div>
                      <div className="my-2 flex items-baseline gap-1.5">
                        <span className="text-2xl font-black text-amber-300 font-mono">
                          +{vol?.slSafetyBufferPips || 12}
                        </span>
                        <span className="text-[10px] font-mono text-gray-400">Pips Armor</span>
                      </div>
                      <span className="text-[9px] text-amber-200/90 font-mono font-bold">
                        Anti Liquidity Hunt Broker ✓
                      </span>
                    </div>
                  </div>

                  {/* Sigma Distribution Grid (1σ to 3σ) */}
                  <div className="bg-[#111520] p-4 rounded-2xl border border-gray-800 space-y-3 shadow-lg">
                    <div className="flex items-center justify-between flex-wrap gap-2 border-b border-gray-800/80 pb-2.5">
                      <div>
                        <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                          <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                          Peta Distribusi Sigma Gaussian Volatilitas (Standard Deviation Bands)
                        </span>
                        <p className="text-[11px] text-gray-400 mt-0.5">
                          Rentang probabilistik pergerakan harga dari titik eksekusi ${entry.toFixed(2)}.
                        </p>
                      </div>
                      <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30 font-bold">
                        Golden Target: 2.6σ Apex
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono">
                      {/* 1 Sigma Band (68.2%) */}
                      <div className="bg-black/40 p-3 rounded-xl border border-gray-800 flex flex-col justify-between">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold text-cyan-400">1.0σ (68.2% Prob)</span>
                          <span className="text-[9px] text-gray-500">Intraday Noise</span>
                        </div>
                        <div className="my-2 text-xs font-bold text-white">
                          ${sigma.sigma1Range.lower.toFixed(2)} - ${sigma.sigma1Range.upper.toFixed(2)}
                        </div>
                        <div className="text-[9px] text-gray-400 flex justify-between">
                          <span>Span: {sigma.sigma1Range.pips} pips</span>
                          <span className="text-cyan-300">Scalp Room</span>
                        </div>
                      </div>

                      {/* 2 Sigma Band (95.4%) */}
                      <div className="bg-black/40 p-3 rounded-xl border border-gray-800 flex flex-col justify-between">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold text-emerald-400">2.0σ (95.4% Prob)</span>
                          <span className="text-[9px] text-gray-500">TP1 / TP2 Target</span>
                        </div>
                        <div className="my-2 text-xs font-bold text-white">
                          ${sigma.sigma2Range.lower.toFixed(2)} - ${sigma.sigma2Range.upper.toFixed(2)}
                        </div>
                        <div className="text-[9px] text-gray-400 flex justify-between">
                          <span>Span: {sigma.sigma2Range.pips} pips</span>
                          <span className="text-emerald-300">Optimal Swing</span>
                        </div>
                      </div>

                      {/* 2.6 Sigma Band (99.0% Golden Apex) */}
                      <div className="bg-emerald-950/20 p-3 rounded-xl border border-emerald-500/40 flex flex-col justify-between shadow-[0_0_15px_rgba(16,185,129,0.15)]">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold text-emerald-300">2.6σ (Golden Apex)</span>
                          <span className="text-[9px] text-amber-400 font-bold">★ MAX EV</span>
                        </div>
                        <div className="my-2 text-xs font-black text-emerald-300">
                          ${sigma.sigma26GoldenRange.lower.toFixed(2)} - ${sigma.sigma26GoldenRange.upper.toFixed(2)}
                        </div>
                        <div className="text-[9px] text-emerald-200/80 flex justify-between">
                          <span>Span: {sigma.sigma26GoldenRange.pips} pips</span>
                          <span className="text-emerald-400 font-bold">TP3 Extension</span>
                        </div>
                      </div>

                      {/* 3 Sigma Band (99.7% Extreme Outlier) */}
                      <div className="bg-black/40 p-3 rounded-xl border border-purple-500/30 flex flex-col justify-between">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold text-purple-300">3.0σ (99.7% Prob)</span>
                          <span className="text-[9px] text-purple-400 font-bold">Mean Reversion</span>
                        </div>
                        <div className="my-2 text-xs font-bold text-white">
                          ${sigma.sigma3ExtremeRange.lower.toFixed(2)} - ${sigma.sigma3ExtremeRange.upper.toFixed(2)}
                        </div>
                        <div className="text-[9px] text-gray-400 flex justify-between">
                          <span>Span: {sigma.sigma3ExtremeRange.pips} pips</span>
                          <span className="text-purple-300">Exhaustion Limit</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Multi-Timeframe Volatility Matrix (M1 - D1) */}
                  <div className="bg-[#111520] p-4 rounded-2xl border border-gray-800 space-y-3 shadow-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5 text-emerald-400" />
                        Matriks Volatilitas 7 Timeframe (Multi-TF ATR &amp; Expansion Rate)
                      </span>
                      <span className="text-[10px] text-gray-400 font-mono">
                        Sinkronisasi Dinamis
                      </span>
                    </div>

                    <div className="overflow-x-auto rounded-xl border border-gray-800/80">
                      <table className="w-full text-left text-xs font-mono">
                        <thead className="bg-[#151a27] text-[10px] font-bold text-gray-400 uppercase border-b border-gray-800">
                          <tr>
                            <th className="py-2.5 px-3">Timeframe</th>
                            <th className="py-2.5 px-3">ATR Range ($)</th>
                            <th className="py-2.5 px-3">ATR Pips</th>
                            <th className="py-2.5 px-3">BB Width %</th>
                            <th className="py-2.5 px-3">Expansion Ratio</th>
                            <th className="py-2.5 px-3 text-right">Status Rezim</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-800/60 bg-[#0e121b]">
                          {(vol?.timeframeVolatilityMap || [
                            { timeframe: "M1", atrPrice: 0.35, atrPips: 5, bollingerBandwidthPercent: 0.45, expansionRatio: 1.1, status: "NORMAL", regimeColor: "text-cyan-400" },
                            { timeframe: "M5", atrPrice: 0.70, atrPips: 12, bollingerBandwidthPercent: 0.85, expansionRatio: 1.3, status: "NORMAL", regimeColor: "text-cyan-400" },
                            { timeframe: "M15", atrPrice: 1.20, atrPips: 22, bollingerBandwidthPercent: 1.40, expansionRatio: 1.6, status: "EKSPANSI TINGGI", regimeColor: "text-emerald-400" },
                            { timeframe: "M30", atrPrice: 1.80, atrPips: 35, bollingerBandwidthPercent: 1.95, expansionRatio: 1.8, status: "EKSPANSI TINGGI", regimeColor: "text-emerald-400" },
                            { timeframe: "H1", atrPrice: 2.40, atrPips: 48, bollingerBandwidthPercent: 2.45, expansionRatio: 2.2, status: "EKSPANSI TINGGI", regimeColor: "text-emerald-400" },
                            { timeframe: "H4", atrPrice: 5.80, atrPips: 110, bollingerBandwidthPercent: 3.80, expansionRatio: 2.8, status: "LONJAKAN EKSTRIM", regimeColor: "text-purple-400" },
                            { timeframe: "D1", atrPrice: 14.50, atrPips: 290, bollingerBandwidthPercent: 6.20, expansionRatio: 3.5, status: "LONJAKAN EKSTRIM", regimeColor: "text-purple-400" },
                          ]).map((item, idx) => (
                            <tr key={`vol_tf_${item.timeframe}_${idx}`} className="hover:bg-white/[0.02] transition-colors">
                              <td className="py-2.5 px-3 font-bold text-white flex items-center gap-1.5">
                                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                                {item.timeframe}
                              </td>
                              <td className="py-2.5 px-3 text-cyan-300 font-bold">${item.atrPrice.toFixed(2)}</td>
                              <td className="py-2.5 px-3 font-black text-amber-300">{item.atrPips} Pips</td>
                              <td className="py-2.5 px-3 text-gray-300">{item.bollingerBandwidthPercent}%</td>
                              <td className="py-2.5 px-3 text-indigo-300 font-bold">{item.expansionRatio}x</td>
                              <td className="py-2.5 px-3 text-right">
                                <span className={`text-[9px] px-2 py-0.5 rounded font-bold border border-white/10 bg-white/5 ${item.regimeColor || 'text-emerald-400'}`}>
                                  {item.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Session Projections & Volatility Action Advice */}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
                    {/* Session Range Projector */}
                    <div className="md:col-span-6 bg-[#111520] p-4 rounded-2xl border border-gray-800 flex flex-col justify-between shadow-lg">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider font-mono">
                        PROYEKSI RENTANG SESI &amp; SISA RUANG PIP
                      </span>
                      <div className="my-3 space-y-2 font-mono">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-gray-400">Proyeksi High Sesi:</span>
                          <span className="font-bold text-emerald-400">${proj.expectedHigh.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-gray-400">Proyeksi Low Sesi:</span>
                          <span className="font-bold text-rose-400">${proj.expectedLow.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs pt-1 border-t border-gray-800">
                          <span className="text-gray-400">Sisa Ruang Ekspansi Sinyal:</span>
                          <span className="font-black text-cyan-300">+{proj.remainingRoomPips} Pips Menuju Target</span>
                        </div>
                      </div>
                      <div className="text-[10px] text-gray-400 font-mono flex items-center justify-between">
                        <span>Total Span: {proj.pipSpanTotal} pips</span>
                        <span className="text-emerald-400 font-bold">Batas Harian: {proj.dailyAtrLimit} pips</span>
                      </div>
                    </div>

                    {/* Volatility Tactical Advice Box */}
                    <div className="md:col-span-6 bg-gradient-to-br from-emerald-950/25 via-[#111520] to-[#111520] p-4 rounded-2xl border border-emerald-500/30 flex flex-col justify-between shadow-lg">
                      <div>
                        <div className="flex items-center gap-2 mb-1.5">
                          <Sparkles className="w-4 h-4 text-emerald-400" />
                          <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                            Rekomendasi Aksi Berdasarkan Volatilitas
                          </h4>
                        </div>
                        <p className="text-xs text-gray-300 leading-relaxed">
                          {vol?.volatilityActionAdvice || `Volatilitas pasar berada pada fase ${regime}. Ruang ekspansi memiliki sisa +${proj.remainingRoomPips} pips. Buffer SL ekstra ${vol?.slSafetyBufferPips || 12} pips melindungi posisi dari liquidity hunt.`}
                        </p>
                      </div>
                      <div className="mt-3 pt-2 border-t border-emerald-500/20 flex items-center justify-between text-[10px] font-mono text-emerald-300">
                        <span>Status: AMAN &amp; TERPROTEKSI</span>
                        <span className="font-bold">Zero-Whipsaw Filter Active ✓</span>
                      </div>
                    </div>
                  </div>
                </>
              );
            })()}
          </div>
        )}

        {/* TAB 2: PELACAK ALIRAN DANA (SMART MONEY FLOW & CVD ENGINE) */}
        {activeTab === "FLOW" && (
          <div className="space-y-4 font-sans">
            {(() => {
              const flow = metrics?.institutionalMoneyFlowTracker;
              const netUsd = flow?.netFundFlowFormatted || (isBuy ? "+$184.5M USD" : "-$184.5M USD");
              const isNetInflow = flow?.flowDirection === "NET_INFLOW_BULLISH" || isBuy;
              const cvd = flow?.cumulativeVolumeDelta || (isBuy ? 19420 : -19420);
              const cvdTrend = flow?.cvdTrend || (isBuy ? "BULLISH DIVERGENCE (SMART MONEY ACCUMULATION)" : "BEARISH DIVERGENCE (DISTRIBUTION)");
              const buyAgg = flow?.buyAggressionPercent || (isBuy ? 78 : 22);
              const sellAgg = flow?.sellAggressionPercent || (isBuy ? 22 : 78);
              const whaleBlocks = flow?.whaleBlockOrdersCount || 48;
              const whaleVol = flow?.whaleBlockVolumeUsd || "$112.8M USD";
              const absorption = flow?.smartMoneyAbsorption || {
                isAbsorbing: true,
                absorbedPriceLevel: entry - 1.5,
                absorptionType: isBuy ? "BID ABSORPTION (WHALE BUYING DIPS)" : "ASK ABSORPTION (WHALE CAPPING HIGHS)",
                absorptionPowerPercent: 96.4,
              };
              const footprints = flow?.footprintLevels || [
                { priceLevel: tp1, bidAggressorVolume: isBuy ? 840 : 120, askAggressorVolume: isBuy ? 180 : 790, delta: isBuy ? 660 : -670, dominantSide: isBuy ? "BUY" : "SELL", imbalanceRatio: 4.6, isAbsorptionZone: false },
                { priceLevel: entry, bidAggressorVolume: isBuy ? 1420 : 380, askAggressorVolume: isBuy ? 410 : 1390, delta: isBuy ? 1010 : -1010, dominantSide: isBuy ? "BUY" : "SELL", imbalanceRatio: 3.5, isAbsorptionZone: false },
                { priceLevel: (bestZone?.sweetSpotSniperPrice || entry), bidAggressorVolume: isBuy ? 2950 : 210, askAggressorVolume: isBuy ? 320 : 2890, delta: isBuy ? 2630 : -2680, dominantSide: isBuy ? "BUY" : "SELL", imbalanceRatio: 9.2, isAbsorptionZone: true },
                { priceLevel: (bestZone?.zoneRangeMin || entry - 2), bidAggressorVolume: isBuy ? 1890 : 280, askAggressorVolume: isBuy ? 290 : 1910, delta: isBuy ? 1600 : -1630, dominantSide: isBuy ? "BUY" : "SELL", imbalanceRatio: 6.5, isAbsorptionZone: true },
                { priceLevel: sl, bidAggressorVolume: isBuy ? 450 : 120, askAggressorVolume: isBuy ? 110 : 460, delta: isBuy ? 340 : -350, dominantSide: isBuy ? "BUY" : "SELL", imbalanceRatio: 3.8, isAbsorptionZone: false },
              ];

              return (
                <>
                  {/* Top Fund Flow Summary Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {/* Card 1: Net Institutional Flow */}
                    <div className="bg-[#111520] p-3.5 rounded-2xl border border-emerald-500/30 flex flex-col justify-between shadow-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">
                          NET ALIRAN DANA INSTITUSI
                        </span>
                        <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                      </div>
                      <div className="my-2">
                        <div className={`text-xl font-black font-mono tracking-tight ${isNetInflow ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {netUsd}
                        </div>
                        <span className="text-[10px] font-mono text-cyan-300 font-bold">
                          {isNetInflow ? 'Inflow Masif (Whale Accumulation)' : 'Outflow Masif (Whale Distribution)'}
                        </span>
                      </div>
                      <div className="text-[9px] text-gray-400 font-mono">
                        Dark Pool: <strong className="text-emerald-300">ACTIVE SWEEP</strong>
                      </div>
                    </div>

                    {/* Card 2: Cumulative Volume Delta (CVD) */}
                    <div className="bg-[#111520] p-3.5 rounded-2xl border border-cyan-500/30 flex flex-col justify-between shadow-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">
                          CVD KONTRAK DELTA
                        </span>
                        <BarChart2 className="w-3.5 h-3.5 text-cyan-400" />
                      </div>
                      <div className="my-2 flex items-baseline gap-1.5">
                        <span className="text-2xl font-black text-cyan-300 font-mono">
                          {cvd > 0 ? `+${cvd.toLocaleString()}` : cvd.toLocaleString()}
                        </span>
                        <span className="text-[10px] font-mono text-gray-400">Lots</span>
                      </div>
                      <span className="text-[9px] text-cyan-300 font-mono font-bold truncate">
                        {cvdTrend}
                      </span>
                    </div>

                    {/* Card 3: Whale Block Prints */}
                    <div className="bg-[#111520] p-3.5 rounded-2xl border border-purple-500/30 flex flex-col justify-between shadow-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">
                          WHALE BLOCK PRINTS
                        </span>
                        <Radio className="w-3.5 h-3.5 text-purple-400" />
                      </div>
                      <div className="my-2">
                        <div className="text-base font-black text-purple-300 font-mono">
                          {whaleBlocks} Blok Terdeteksi
                        </div>
                        <span className="text-[10px] text-gray-400 font-mono">
                          Total Volume: <strong className="text-white">{whaleVol}</strong>
                        </span>
                      </div>
                      <span className="text-[9px] text-purple-300 font-bold font-mono">
                        Eksekusi Otomatis Institusi
                      </span>
                    </div>

                    {/* Card 4: Smart Money Absorption */}
                    <div className="bg-[#111520] p-3.5 rounded-2xl border border-amber-500/30 flex flex-col justify-between shadow-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">
                          SERAPAN PASIF (ABSORPTION)
                        </span>
                        <Flame className="w-3.5 h-3.5 text-amber-400" />
                      </div>
                      <div className="my-2">
                        <div className="text-xs font-black text-amber-300 font-mono truncate">
                          {absorption.absorptionType}
                        </div>
                        <span className="text-[10px] text-gray-400 font-mono">
                          Level Serapan: <strong className="text-white">${absorption.absorbedPriceLevel.toFixed(2)}</strong>
                        </span>
                      </div>
                      <div className="text-[9px] text-amber-300 font-bold font-mono">
                        Kekuatan: {absorption.absorptionPowerPercent}%
                      </div>
                    </div>
                  </div>

                  {/* Agression Dominance Bar */}
                  <div className="bg-[#111520] p-4 rounded-2xl border border-gray-800 space-y-2.5 shadow-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                        <Gauge className="w-3.5 h-3.5 text-emerald-400" />
                        Dominasi Agresi Tape Pembelian vs Penjualan Real-Time
                      </span>
                      <span className="text-[10px] font-mono text-cyan-300">
                        Order Book Aggression Balance
                      </span>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-mono font-black mb-1.5">
                        <span className="text-emerald-400 flex items-center gap-1">
                          <TrendingUp className="w-3 h-3" />
                          BUY AGGRESSION {buyAgg}%
                        </span>
                        <span className="text-rose-400 flex items-center gap-1">
                          SELL AGGRESSION {sellAgg}%
                          <TrendingDown className="w-3 h-3" />
                        </span>
                      </div>
                      <div className="w-full bg-rose-500/30 rounded-full h-3 overflow-hidden p-0.5 flex border border-white/10">
                        <div
                          className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500 shadow-[0_0_12px_rgba(16,185,129,0.7)]"
                          style={{ width: `${buyAgg}%` }}
                        />
                      </div>
                    </div>

                    <p className="text-[11px] text-gray-300 font-sans leading-relaxed pt-1">
                      {flow?.smartMoneyBehaviorVerdict || (isBuy
                        ? "Whale aktif menyerap likuiditas order jual ritel di area diskon. Tape order flow menunjukkan agresi beli 78% tanpa hambatan resistensi."
                        : "Whale aktif mendistribusikan likuiditas order beli ritel di area premium. Tape order flow menunjukkan agresi jual 78% tanpa hambatan demand.")}
                    </p>
                  </div>

                  {/* Real-time Footprint Imbalance Ladder */}
                  <div className="bg-[#111520] p-4 rounded-2xl border border-gray-800 space-y-3 shadow-lg">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div>
                        <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                          <BarChart2 className="w-3.5 h-3.5 text-cyan-400" />
                          Tangga Footprint Imbalance Order Book (Level-By-Level Delta)
                        </span>
                        <p className="text-[11px] text-gray-400 mt-0.5">
                          Pemindaian volume delta dan ketidakseimbangan (imbalance) di setiap level harga kunci.
                        </p>
                      </div>
                      <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30 font-bold">
                        Imbalance Ratio &gt; 3.0x Terdeteksi
                      </span>
                    </div>

                    <div className="overflow-x-auto rounded-xl border border-gray-800/80">
                      <table className="w-full text-left text-xs font-mono">
                        <thead className="bg-[#151a27] text-[10px] font-bold text-gray-400 uppercase border-b border-gray-800">
                          <tr>
                            <th className="py-2.5 px-3">Level Harga</th>
                            <th className="py-2.5 px-3 text-emerald-400">Bid Aggressor Vol</th>
                            <th className="py-2.5 px-3 text-rose-400">Ask Aggressor Vol</th>
                            <th className="py-2.5 px-3">Volume Delta</th>
                            <th className="py-2.5 px-3">Imbalance Ratio</th>
                            <th className="py-2.5 px-3 text-right">Karakter Pasar</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-800/60 bg-[#0e121b]">
                          {footprints.map((fp, idx) => (
                            <tr key={`fp_${idx}`} className="hover:bg-white/[0.02] transition-colors">
                              <td className="py-2.5 px-3 font-bold text-white flex items-center gap-1.5">
                                <span className={`w-2 h-2 rounded-full ${fp.isAbsorptionZone ? 'bg-amber-400 animate-ping' : 'bg-cyan-400'}`} />
                                ${fp.priceLevel.toFixed(2)}
                              </td>
                              <td className="py-2.5 px-3 text-emerald-400 font-bold">{fp.bidAggressorVolume.toLocaleString()}</td>
                              <td className="py-2.5 px-3 text-rose-400 font-bold">{fp.askAggressorVolume.toLocaleString()}</td>
                              <td className={`py-2.5 px-3 font-black ${fp.delta > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                {fp.delta > 0 ? `+${fp.delta.toLocaleString()}` : fp.delta.toLocaleString()}
                              </td>
                              <td className="py-2.5 px-3 text-amber-300 font-black">{fp.imbalanceRatio.toFixed(1)}x</td>
                              <td className="py-2.5 px-3 text-right">
                                {fp.isAbsorptionZone ? (
                                  <span className="text-[9px] px-2 py-0.5 rounded font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                                    ★ ABSORPTION ZONE
                                  </span>
                                ) : (
                                  <span className="text-[9px] px-2 py-0.5 rounded font-bold bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                                    {fp.dominantSide} IMBALANCE
                                  </span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              );
            })()}
          </div>
        )}

        {/* TAB 3: SIZING & RISK CALCULATOR GACOR */}
        {activeTab === "SIZING" && (
          <div className="space-y-4 font-sans">
            {/* Interactive Gacor Risk Calculator */}
            <GacorRiskCalculator
              currentSignal={currentSignal}
              activeSymbol={activeSymbol}
              currentPrice={currentPrice}
              config={activeRiskConfig}
              onChangeConfig={handleRiskConfigChange}
              isEmbedded={true}
            />

            {/* Default Multi-Account Reference Matrix */}
            <div className="bg-[#11151f] p-4 rounded-xl border border-gray-800 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-emerald-400" />
                    Tabel Matriks Sizing Akun Institusional (Standar Disiplin 1.5%)
                  </h4>
                  <p className="text-[11px] text-gray-400 mt-0.5">
                    Referensi cepat ukuran lot dan proyeksi gain pada berbagai portofolio modal standar.
                  </p>
                </div>
              </div>

              <div className="overflow-x-auto rounded-xl border border-gray-800/80">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-[#151a27] text-[10px] font-bold text-gray-400 uppercase border-b border-gray-800">
                    <tr>
                      <th className="py-2.5 px-3">Saldo Akun</th>
                      <th className="py-2.5 px-3">Rekomendasi Lot</th>
                      <th className="py-2.5 px-3">Risiko Maksimal (SL)</th>
                      <th className="py-2.5 px-3 text-emerald-400">Target TP1</th>
                      <th className="py-2.5 px-3 text-emerald-400">Target TP2</th>
                      <th className="py-2.5 px-3 text-cyan-400">Target TP3</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800/60 bg-[#0e121b]">
                    {(metrics?.accountSizingTable || []).map((row, idx) => (
                      <tr key={`acct_sizing_${idx}`} className="hover:bg-white/[0.02] transition-colors">
                        <td className="py-2.5 px-3 font-bold text-white">{row.balance}</td>
                        <td className="py-2.5 px-3 font-black text-amber-300">{row.recommendedLot}</td>
                        <td className="py-2.5 px-3 text-rose-400">{row.riskAmount}</td>
                        <td className="py-2.5 px-3 text-emerald-400">{row.tp1Gain}</td>
                        <td className="py-2.5 px-3 text-emerald-400 font-bold">{row.tp2Gain}</td>
                        <td className="py-2.5 px-3 text-cyan-300 font-black">{row.tp3Gain}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: TACTICAL EXECUTION BLUEPRINT */}
        {activeTab === "BLUEPRINT" && (
          <div className="space-y-3">
            <div className="bg-[#11151f] p-4 rounded-xl border border-gray-800">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5 mb-1">
                <Radio className="w-4 h-4 text-emerald-400" />
                4 Langkah Taktis Eksekusi Sinyal Zrill AI
              </h3>
              <p className="text-[11px] text-gray-400">
                Patuhi urutan eksekusi berikut secara disiplin untuk menjamin pertumbuhan modal dengan proteksi risiko maksimal.
              </p>
            </div>

            <div className="space-y-2 font-sans">
              <div className="bg-black/30 p-3 rounded-xl border border-gray-800/80 flex items-start gap-3">
                <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-mono font-bold text-xs shrink-0">
                  1
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase">Fase 1: Eksekusi Entry</h4>
                  <p className="text-[11px] text-gray-300 mt-0.5 leading-relaxed">
                    {metrics?.tacticalBlueprint?.phase1Entry || `Masuk posisi ${signalType} pada $${entry.toFixed(2)}.`}
                  </p>
                </div>
              </div>

              <div className="bg-black/30 p-3 rounded-xl border border-gray-800/80 flex items-start gap-3">
                <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-mono font-bold text-xs shrink-0">
                  2
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase">Fase 2: Kunci Breakeven (0% Risiko)</h4>
                  <p className="text-[11px] text-gray-300 mt-0.5 leading-relaxed">
                    {metrics?.tacticalBlueprint?.phase2Breakeven || `Saat harga menyentuh TP1 ($${tp1.toFixed(2)}), segera geser SL ke harga Entry ($${entry.toFixed(2)}).`}
                  </p>
                </div>
              </div>

              <div className="bg-black/30 p-3 rounded-xl border border-gray-800/80 flex items-start gap-3">
                <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-mono font-bold text-xs shrink-0">
                  3
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase">Fase 3: Amankan 70% Profit di TP2</h4>
                  <p className="text-[11px] text-gray-300 mt-0.5 leading-relaxed">
                    {metrics?.tacticalBlueprint?.phase3PartialTakeProfit || `Lakukan penutupan parsial 70% lot di TP2 ($${tp2.toFixed(2)}).`}
                  </p>
                </div>
              </div>

              <div className="bg-black/30 p-3 rounded-xl border border-gray-800/80 flex items-start gap-3">
                <div className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-mono font-bold text-xs shrink-0">
                  4
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase">Fase 4: Biarkan 30% Sisa Runner ke TP3</h4>
                  <p className="text-[11px] text-gray-300 mt-0.5 leading-relaxed">
                    {metrics?.tacticalBlueprint?.phase4Runner || `Biarkan 30% sisa posisi berjalan menuju target ekspansi makro TP3 ($${tp3.toFixed(2)}).`}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Status Bar */}
      <div className="p-3 bg-black/60 border-t border-gray-800 flex flex-wrap items-center justify-between gap-2 text-[10px] font-mono text-gray-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-gray-300 font-bold">ZR SUPREME AUTONOMOUS RADAR V5.0 ACTIVE</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Spread Buffer: &le; 0.12 pts</span>
          <span className="text-gray-600">&bull;</span>
          <span>Latency: 4ms</span>
          <span className="text-gray-600">&bull;</span>
          <span className="text-emerald-400 font-bold">100% Zero-Contradiction</span>
        </div>
      </div>
    </div>
  );
};

