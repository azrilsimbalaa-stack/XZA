import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import firebaseConfig from "../firebase-applet-config.json";

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

let firestoreDb: any = null;

try {
  const customDbId = firebaseConfig.firestoreDatabaseId;
  if (customDbId && customDbId !== "(default)") {
    try {
      firestoreDb = initializeFirestore(app, {}, customDbId);
    } catch {
      firestoreDb = getFirestore(app, customDbId);
    }
  } else {
    firestoreDb = getFirestore(app);
  }
} catch (e1) {
  console.warn("[Firebase] Failed initializing custom database ID, falling back to default instance:", e1);
  try {
    firestoreDb = getFirestore(app);
  } catch (e2) {
    console.error("[Firebase] Firestore service unavailable:", e2);
  }
}

export const db = firestoreDb;

