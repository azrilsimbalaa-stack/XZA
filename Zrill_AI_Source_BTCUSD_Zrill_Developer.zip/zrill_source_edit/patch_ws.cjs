const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

const wsCode = `
        let yahooInterval: any;
        if (symbol.id === "XAUUSD") {
          if (!isUsingLocalMT5) {
            onStatusUpdate(
              priceOffset !== 0
                ? "YAHOO MT5 CALIBRATED"
                : "YAHOO REALTIME (POLLING)"
            );
          }
          
          // Poll Yahoo every 10 seconds for current candle (simulating real-time)
          yahooInterval = setInterval(async () => {
            if (!isMounted || isUsingLocalMT5) return;
            try {
              const res = await fetch(\`/api/yahoo/klines?symbol=GC=F&interval=\${timeframe.binance}&limit=2\`);
              const klines = await res.json();
              if (klines && klines.length > 0) {
                const kline = klines[klines.length - 1]; // latest candle
                const klineTime = kline[0] / 1000;
                
                targetTickPrice = parseFloat(kline[4]) + priceOffset;
                lastWsMessageTime = Date.now();

                const lastCandle = candleData[candleData.length - 1];
                if (lastCandle && lastCandle.time === klineTime) {
                  lastCandle.high = Math.max(lastCandle.high, parseFloat(kline[2]) + priceOffset);
                  lastCandle.low = Math.min(lastCandle.low, parseFloat(kline[3]) + priceOffset);
                  lastCandle.close = parseFloat(kline[4]) + priceOffset;
                } else if (lastCandle && klineTime > lastCandle.time) {
                  candleData.push({
                    time: klineTime as any,
                    open: parseFloat(kline[1]) + priceOffset,
                    high: parseFloat(kline[2]) + priceOffset,
                    low: parseFloat(kline[3]) + priceOffset,
                    close: parseFloat(kline[4]) + priceOffset,
                  });
                  if (candleData.length > 1000) candleData.splice(0, candleData.length - 1000);
                  candlestickSeries.setData(candleData);
                }
              }
            } catch (e) {
              console.warn("Yahoo polling failed:", e);
            }
          }, 5000); // 5 sec interval for more real-time feel
        } else {
          ws = new WebSocket(
            \`wss://stream.binance.com:9443/ws/\${symbol.binanceSymbol.toLowerCase()}@kline_\${timeframe.binance}\`,
          );
          ws.onopen = () => {
            if (!isMounted) return;
            if (!isUsingLocalMT5)
              onStatusUpdate(
                priceOffset !== 0
                  ? "MT5 CALIBRATED SYNC"
                  : "MT5 EXACT SYNC (REALTIME)",
              );
          };
          ws.onmessage = (event) => {
            if (!isMounted || isUsingLocalMT5) return;
            const message = JSON.parse(event.data);
            if (message.e === "kline") {
              const kline = message.k;
              const lastCandle = candleData[candleData.length - 1];
              const klineTime = kline.t / 1000;
              if (lastCandle && lastCandle.time === klineTime) {
                lastCandle.high = Math.max(
                  lastCandle.high,
                  parseFloat(kline.h) + priceOffset,
                );
                lastCandle.low = Math.min(
                  lastCandle.low,
                  parseFloat(kline.l) + priceOffset,
                );
                lastCandle.close = parseFloat(kline.c) + priceOffset;
              } else if (lastCandle && klineTime > lastCandle.time) {
                const intervalSec = getTimeframeSeconds(timeframe.id);
                // Self-Healing: fill gaps if we missed any candles between lastCandle.time and klineTime
                let gapTime = lastCandle.time + intervalSec;
                while (gapTime < klineTime) {
                  candleData.push({
                    time: gapTime as any,
                    open: lastCandle.close,
                    high: lastCandle.close,
                    low: lastCandle.close,
                    close: lastCandle.close,
                  });
                  gapTime += intervalSec;
                }
                // Ensure no duplicate timestamps are entered
                if (!candleData.some((c) => c.time === klineTime)) {
                  candleData.push({
                    time: klineTime as any,
                    open: parseFloat(kline.o) + priceOffset,
                    high: parseFloat(kline.h) + priceOffset,
                    low: parseFloat(kline.l) + priceOffset,
                    close: parseFloat(kline.c) + priceOffset,
                  });
                }
                if (candleData.length > 1000)
                  candleData.splice(0, candleData.length - 1000);
                candlestickSeries.setData(candleData);
              }
            }
          };

          // Super High-Frequency Live Trade feed (zero delay, direct from Binance match engine)
          fastWs = new WebSocket(
            \`wss://stream.binance.com:9443/ws/\${symbol.binanceSymbol.toLowerCase()}@aggTrade\`
          );
          fastWs.onmessage = (event) => {
            if (!isMounted || isUsingLocalMT5) return;
            lastWsMessageTime = Date.now();
            try {
              const trade = JSON.parse(event.data);
              if (trade.p) {
                  targetTickPrice = parseFloat(trade.p) + priceOffset;
              }
            } catch (e) {
              console.warn("Failed parsing aggTrade data:", e);
            }
          };
        }
`;

const targetWsBlockRegex = /ws = new WebSocket\([\s\S]*?fastWs\.onmessage = \(event\) => \{[\s\S]*?console\.warn\("Failed parsing aggTrade data:", e\);\n          }\n        };/;
code = code.replace(targetWsBlockRegex, wsCode.trim());

fs.writeFileSync('src/App.tsx', code);
