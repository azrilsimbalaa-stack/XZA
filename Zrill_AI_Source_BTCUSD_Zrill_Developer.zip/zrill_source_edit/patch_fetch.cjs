const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

// Helper
const helperCode = `
const getKlinesUrl = (symId: string, binanceSym: string, interval: string, limit: number) => {
  if (symId === "XAUUSD") {
    return \`/api/yahoo/klines?symbol=GC=F&interval=\${interval}&limit=\${limit}\`;
  }
  return \`https://api.binance.com/api/v3/klines?symbol=\${binanceSym}&interval=\${interval}&limit=\${limit}\`;
};
`;
code = code.replace('// --- Advanced Technical Indicator Helpers ---', helperCode + '\n// --- Advanced Technical Indicator Helpers ---');

// Replace fetch in fetchTimeframes
code = code.replace(
  /\`https:\/\/api\.binance\.com\/api\/v3\/klines\?symbol=\$\{activeSymbol\.binanceSymbol\}&interval=\$\{tf\}&limit=100\`,/,
  'getKlinesUrl(activeSymbol.id, activeSymbol.binanceSymbol, tf, 100)'
);
code = code.replace(
  /\`https:\/\/api\.binance\.com\/api\/v3\/klines\?symbol=\$\{activeSymbol\.binanceSymbol\}&interval=1h&limit=50\`,/,
  'getKlinesUrl(activeSymbol.id, activeSymbol.binanceSymbol, "1h", 50)'
);

// Replace fetch in Chart Component
code = code.replace(
  /\`https:\/\/api\.binance\.com\/api\/v3\/klines\?symbol=\$\{symbol\.binanceSymbol\}&interval=\$\{timeframe\.binance\}&limit=40\`,/,
  'getKlinesUrl(symbol.id, symbol.binanceSymbol, timeframe.binance, 40)'
);
code = code.replace(
  /\`https:\/\/api\.binance\.com\/api\/v3\/klines\?symbol=\$\{symbol\.binanceSymbol\}&interval=\$\{timeframe\.binance\}&limit=150\`,/,
  'getKlinesUrl(symbol.id, symbol.binanceSymbol, timeframe.binance, 150)'
);

fs.writeFileSync('src/App.tsx', code);
