async function test() {
  const proxy = 'https://api.allorigins.win/raw?url=';
  const url = 'https://query1.finance.yahoo.com/v8/finance/chart/GC=F?range=1d&interval=1m';
  const res = await fetch(proxy + encodeURIComponent(url));
  console.log(res.status);
  const data = await res.json();
  console.log(data.chart?.result?.[0]?.meta?.regularMarketPrice);
}
test();
