async function test() {
  const url = 'https://query1.finance.yahoo.com/v8/finance/chart/GC=F?range=1d&interval=1m';
  const res = await fetch(url);
  const data = await res.json();
  const timestamps = data.chart.result[0].timestamp;
  const quote = data.chart.result[0].indicators.quote[0];
  const formattedData = timestamps.map((t, i) => {
    if (quote.open[i] == null) return null;
    return [
      t * 1000,
      quote.open[i].toString(),
      quote.high[i].toString(),
      quote.low[i].toString(),
      quote.close[i].toString(),
      quote.volume[i].toString()
    ];
  }).filter(d => d !== null);
  console.log(formattedData.slice(0, 2));
}
test();
