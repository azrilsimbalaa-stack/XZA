# ZRILL AI — BiQuote Calendar + C++/Python Analytics

## Perubahan pada paket ini

- Pengambilan kalender ekonomi menggunakan **BiQuote** (`https://biquote.io/api/calendar`) melalui `scripts/fetch_biquote_calendar.py`. Tidak ada fallback atau scraping Forex Factory.
- Logika prediksi/interpretasi kalender yang ada tetap berada pada `src/services/institutionalCalendarEngine.ts` dan file tersebut dipertahankan tanpa perubahan.
- Tampilan kalender menyaring teks yang menampilkan klaim probabilitas/akurasi dalam persen. Skor internal kalender tidak diubah; angka persen untuk data ekonomi itu sendiri, seperti forecast suku bunga, tetap dipertahankan karena itu nilai data, bukan probabilitas sinyal.
- Klaim akurasi persen sintetis pada ringkasan API kalender dihilangkan; hasil evaluasi disediakan sebagai jumlah kejadian.
- Mesin C++ untuk validasi OHLC serta indikator ringkas ada pada `engines/cpp/`.
- Backtest historis Python ada pada `engines/python/`.
- UI chart dan lapisan aplikasi masih menggunakan React/TypeScript. Ini belum merupakan port total seluruh proyek ke C++/Python: browser memerlukan frontend web (JavaScript/WebAssembly), sementara migrasi penuh dari signal engine dan semua endpoint lama memerlukan penulisan ulang terpisah. File kalender sengaja tidak dirombak agar logika prediksinya tetap persis.

## BiQuote calendar provider

Adapter meminta data UTC dari endpoint kalender BiQuote dan menormalkan bentuknya agar diterima oleh model kalender yang sudah ada. Endpoint refresh:

- `GET /api/calendar`
- `GET /api/calendar/refresh-biquote`
- `POST /api/calendar/refresh-biquote`

API yang digunakan oleh adapter: `GET https://biquote.io/api/calendar?from=<UTC ISO>&to=<UTC ISO>&limit=500`.

Jika BiQuote tidak dapat dijangkau, adapter melaporkan error dan tidak mengambil data dari sumber lama. Cache BiQuote yang sudah tersedia dapat tetap digunakan selama TTL aplikasi; tidak ada fallback Forex Factory.

> Catatan pengujian: unit test adapter dapat dijalankan offline. Akses langsung ke host BiQuote perlu diverifikasi pada deployment yang memiliki koneksi internet/DNS; live fetch tidak dianggap lulus hanya karena unit test lulus.

## Mesin analisis C++

Prasyarat: CMake dan compiler C++17 (misalnya GCC/Clang; Windows memerlukan toolchain C++ yang sesuai).

```bash
npm install
npm run build:cpp
```

Endpoint:

`POST /api/analysis/cpp-ohlc`

Contoh body JSON, bisa berupa array posisi `[timestamp, open, high, low, close]` atau array objek:

```json
{
  "candles": [
    [1791936000, 4200.0, 4205.0, 4197.0, 4203.0],
    [1791936060, 4203.0, 4208.0, 4201.0, 4207.0]
  ]
}
```

Mesin memvalidasi OHLC, mengurutkan timestamp, menghapus duplikat, lalu mengembalikan ringkasan candle terakhir, EMA20/EMA50, ATR14, momentum, rentang harga, dan bias teknikal dasar. Ini adalah engine analisis OHLC dasar, bukan klaim tingkat akurasi sinyal tertentu.

## Backtest Python

Prasyarat: Python 3.

Endpoint:

`POST /api/analysis/backtest`

Body contoh:

```json
{
  "candles": [
    {"timestamp": 1791936000, "open": 4200, "high": 4205, "low": 4197, "close": 4203}
  ],
  "fastPeriod": 12,
  "slowPeriod": 26,
  "costBpsPerSide": 1
}
```

Strategi contoh yang disediakan adalah EMA crossover untuk simulasi historis; hasilnya bukan prediksi atau jaminan masa depan. Jumlah candle harus cukup untuk periode strategi.

## Build dan test

```bash
npm install
npm run build:cpp
npm run test:python
npm run lint
npm run dev
```

- `npm run test:python` menjalankan unit test untuk normalisasi BiQuote, validasi OHLC C++, dan backtest Python.
- `npm run lint` membutuhkan dependensi Node/TypeScript terpasang lengkap.
- `npm run dev` membangun binary C++ lebih dahulu kemudian menjalankan server web.

## Catatan batasan

C++ dan Python telah ditambahkan sebagai mesin analisis/backtest yang dapat dipanggil via API. Logika signal engine utama dan UI React/TypeScript belum seluruhnya diport menjadi C++/Python pada paket ini. Klaim bahwa semua kode telah diganti akan tidak akurat. Calendar prediction engine sengaja tidak dimodifikasi sesuai permintaan.
