#!/usr/bin/env python3
"""Fetch and normalize BiQuote's economic calendar for the existing ZRILL calendar engine.

The prediction engine remains responsible for interpreting these normalized events. This
script only acquires and maps source data; it never generates trade predictions.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

BASE_URL = "https://biquote.io/api/calendar"
SOURCE_NAME = "BiQuote Economic Calendar"
SOURCE_URL = "https://biquote.io/docs/"
IMPORTANCE_LEVELS = {"high": 1, "medium": 0, "low": -1, "holiday": -1}


def _display_value(value: Any) -> str:
    """Match the legacy calendar input convention without collapsing numeric zero."""
    if value is None or value == "":
        return "---"
    return str(value)


def _valid_timestamp(value: Any) -> bool:
    if not isinstance(value, str) or not value.strip():
        return False
    try:
        datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
        return True
    except ValueError:
        return False


def normalize_event(raw: Any) -> dict[str, Any] | None:
    """Map one BiQuote event to the shape expected by buildComprehensiveEconomicEvent."""
    if not isinstance(raw, dict):
        return None

    event_time = raw.get("time") or raw.get("date")
    title = raw.get("name") or raw.get("title") or raw.get("event")
    if not _valid_timestamp(event_time) or not isinstance(title, str) or not title.strip():
        return None

    raw_importance = str(raw.get("importance") or "low").strip().lower()
    try:
        importance = int(raw_importance)
    except ValueError:
        importance = IMPORTANCE_LEVELS.get(raw_importance, -1)
    importance = 1 if importance > 0 else 0 if importance == 0 else -1
    impact = {1: "HIGH", 0: "MEDIUM", -1: "LOW"}[importance]

    country_code = str(raw.get("countryCode") or raw.get("country") or "").upper()
    currency = str(raw.get("currency") or country_code or "UNKNOWN").upper()
    event_id = str(raw.get("id") or raw.get("eventId") or f"{event_time}:{country_code}:{title}")

    return {
        "id": f"biquote:{event_id}",
        "eventId": str(raw.get("eventId") or event_id),
        "title": title.strip(),
        "currency": currency,
        "country": country_code or currency,
        "date": event_time,
        "period": raw.get("period"),
        "impact": impact,
        "importance": importance,
        "forecast": _display_value(raw.get("forecast")),
        "previous": _display_value(raw.get("previous")),
        "actual": raw.get("actual") if raw.get("actual") is not None else None,
        "type": raw.get("type") or "event",
        "sector": raw.get("sector"),
        "unit": raw.get("unit") or "",
        "multiplier": raw.get("multiplier"),
        "digits": raw.get("digits"),
        "timeMode": raw.get("timeMode") or "exact",
        "source": f"{SOURCE_NAME} ({SOURCE_URL})",
        "sourceUrl": SOURCE_URL,
        "provider": "BiQuote",
        # Legacy property names are retained as adapter fields only. The calendar
        # prediction module is intentionally not edited in this change.
        "forexFactoryImpact": impact,
        "forexFactoryFolder": "RED_FOLDER" if importance == 1 else "ORANGE_FOLDER" if importance == 0 else "YELLOW_FOLDER",
        "forexFactoryLabel": f"[{impact}] BIQUOTE ECONOMIC CALENDAR",
        "isForexFactoryOfficial": False,
        "isForexFactoryCalibrated": False,
    }


def build_url(start: datetime | None = None, end: datetime | None = None) -> str:
    now = datetime.now(timezone.utc)
    start = start or (now - timedelta(days=7))
    end = end or (now + timedelta(days=30))
    params = {
        "from": start.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "to": end.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "limit": 500,
    }
    return f"{BASE_URL}?{urlencode(params)}"


def fetch_events(timeout: float = 12.0) -> list[dict[str, Any]]:
    url = build_url()
    request = Request(
        url,
        headers={"Accept": "application/json", "User-Agent": "ZRILL-AI/1.0 (BiQuote calendar adapter)"},
        method="GET",
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            if response.status < 200 or response.status >= 300:
                raise RuntimeError(f"BiQuote returned HTTP {response.status}")
            payload = json.loads(response.read().decode("utf-8"))
    except (HTTPError, URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"BiQuote calendar fetch failed: {exc}") from exc

    if not isinstance(payload, list):
        raise RuntimeError("BiQuote calendar response format changed: expected a JSON array")

    events = [normalized for raw in payload if (normalized := normalize_event(raw)) is not None]
    events.sort(key=lambda event: event["date"])
    if payload and not events:
        raise RuntimeError("BiQuote returned events, but none had a valid timestamp/title")
    return events


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--timeout", type=float, default=12.0)
    parser.add_argument("--self-test", action="store_true", help="validate normalization without network access")
    args = parser.parse_args()

    if args.self_test:
        sample = normalize_event({
            "id": "self-test", "time": "2026-10-15T12:30:00Z", "name": "CPI",
            "countryCode": "US", "currency": "USD", "importance": "high",
            "actual": None, "forecast": 3.1, "previous": 3.0,
        })
        if not sample or sample["importance"] != 1 or sample["forecast"] != "3.1":
            print("BiQuote adapter self-test failed", file=sys.stderr)
            return 1
        print(json.dumps([sample], ensure_ascii=False))
        return 0

    try:
        print(json.dumps(fetch_events(args.timeout), ensure_ascii=False, separators=(",", ":")))
        return 0
    except Exception as exc:  # Report a clear error to the caller; never fall back to Forex Factory.
        print(str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
