// Sumber candle OHLC ASLI untuk mesin analisa. Tidak pernah membuat candle acak/sintetis.
// Urutan sumber dicoba satu per satu; satu sumber diterima hanya bila SEMUA timeframe yang diminta lengkap,
// supaya semua timeframe memakai skala harga yang sama.
import { fetchTradingViewHistory } from "./tradingviewService.js";

export type TfId = "M1" | "M5" | "M15" | "M30" | "H1" | "H4" | "D1";
export type Row = [number, number, number, number, number, number]; // [ms, o, h, l, c, v]

const TF: Record<TfId, { sec: number; bn: string; tv: string; kr: number; cb: number | null; yf: string | null }> = {
  M1: { sec: 60, bn: "1m", tv: "1", kr: 1, cb: 60, yf: "1m" },
  M5: { sec: 300, bn: "5m", tv: "5", kr: 5, cb: 300, yf: "5m" },
  M15: { sec: 900, bn: "15m", tv: "15", kr: 15, cb: 900, yf: "15m" },
  M30: { sec: 1800, bn: "30m", tv: "30", kr: 30, cb: null, yf: "30m" },
  H1: { sec: 3600, bn: "1h", tv: "60", kr: 60, cb: 3600, yf: "60m" },
  H4: { sec: 14400, bn: "4h", tv: "240", kr: 240, cb: null, yf: null },
  D1: { sec: 86400, bn: "1d", tv: "1D", kr: 1440, cb: 86400, yf: "1d" },
};
export const ALL_TFS = Object.keys(TF) as TfId[];

type SourceId = "TRADINGVIEW" | "BINANCE" | "BINANCE_VISION" | "COINBASE" | "KRAKEN" | "YAHOO";
interface SourceDef {
  id: SourceId;
  label: string;
  /** true bila harga sumber ini bukan harga spot yang sama dengan feed tick (mis. PAXG untuk emas). */
  proxy: boolean;
  fetch: (symbol: string, tf: TfId, limit: number) => Promise<Row[]>;
}

const isBtc = (s: string) => s.includes("BTC");

async function getJson(url: string, ms = 3500): Promise<any> {
  const res = await fetch(url, {
    signal: AbortSignal.timeout(ms),
    headers: { "User-Agent": "Mozilla/5.0 ZrillTerminal", Accept: "application/json" },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${new URL(url).host}`);
  return res.json();
}

/** Bersihkan baris: angka valid, urut naik, tanpa duplikat, high/low konsisten. */
export function sanitizeRows(rows: Row[]): Row[] {
  const map = new Map<number, Row>();
  for (const r of rows) {
    if (!r || r.length < 5) continue;
    let [t, o, h, l, c, v] = r;
    if (![t, o, h, l, c].every((x) => Number.isFinite(x)) || o <= 0 || h <= 0 || l <= 0 || c <= 0) continue;
    h = Math.max(h, o, c, l);
    l = Math.min(l, o, c, h);
    map.set(t, [t, o, h, l, c, Number.isFinite(v) ? v : 0]);
  }
  return [...map.values()].sort((a, b) => a[0] - b[0]);
}

const fromBinanceArr = (arr: any[]): Row[] =>
  arr.map((k) => [Number(k[0]), parseFloat(k[1]), parseFloat(k[2]), parseFloat(k[3]), parseFloat(k[4]), parseFloat(k[5])] as Row);

function binanceSource(id: "BINANCE" | "BINANCE_VISION", host: string): SourceDef {
  return {
    id,
    label: id === "BINANCE" ? "Binance" : "Binance (mirror)",
    proxy: false, // diatur per simbol di bawah
    fetch: async (symbol, tf, limit) => {
      const pair = isBtc(symbol) ? "BTCUSDT" : "PAXGUSDT";
      const data = await getJson(`${host}/api/v3/klines?symbol=${pair}&interval=${TF[tf].bn}&limit=${Math.min(1000, limit)}`);
      if (!Array.isArray(data)) throw new Error("Binance: respons bukan array");
      return fromBinanceArr(data);
    },
  };
}

const coinbase: SourceDef = {
  id: "COINBASE",
  label: "Coinbase",
  proxy: false,
  fetch: async (symbol, tf, limit) => {
    if (!isBtc(symbol)) throw new Error("Coinbase: hanya BTC");
    const g = TF[tf].cb;
    if (!g) throw new Error("Coinbase: timeframe tidak didukung");
    const data = await getJson(`https://api.exchange.coinbase.com/products/BTC-USD/candles?granularity=${g}`);
    if (!Array.isArray(data)) throw new Error("Coinbase: respons bukan array");
    // [time, low, high, open, close, volume], terbaru dulu
    return data.slice(0, limit).map((c: any) => [c[0] * 1000, c[3], c[2], c[1], c[4], c[5]] as Row);
  },
};

const kraken: SourceDef = {
  id: "KRAKEN",
  label: "Kraken",
  proxy: false,
  fetch: async (symbol, tf, limit) => {
    const pair = isBtc(symbol) ? "XBTUSD" : "PAXGUSD";
    const data = await getJson(`https://api.kraken.com/0/public/OHLC?pair=${pair}&interval=${TF[tf].kr}`);
    if (data.error && data.error.length) throw new Error(`Kraken: ${data.error[0]}`);
    const key = Object.keys(data.result || {}).find((k) => k !== "last");
    const arr = key ? data.result[key] : null;
    if (!Array.isArray(arr)) throw new Error("Kraken: data kosong");
    return arr.slice(-limit).map((c: any) => [c[0] * 1000, parseFloat(c[1]), parseFloat(c[2]), parseFloat(c[3]), parseFloat(c[4]), parseFloat(c[6])] as Row);
  },
};

function aggregate(rows: Row[], bucketSec: number): Row[] {
  const out = new Map<number, Row>();
  for (const [t, o, h, l, c, v] of rows) {
    const b = Math.floor(t / 1000 / bucketSec) * bucketSec * 1000;
    const cur = out.get(b);
    if (!cur) out.set(b, [b, o, h, l, c, v]);
    else { cur[2] = Math.max(cur[2], h); cur[3] = Math.min(cur[3], l); cur[4] = c; cur[5] += v; }
  }
  return [...out.values()].sort((a, b) => a[0] - b[0]);
}

const yahoo: SourceDef = {
  id: "YAHOO",
  label: "Yahoo Finance",
  proxy: false,
  fetch: async (symbol, tf, limit) => {
    const syms = isBtc(symbol) ? ["BTC-USD"] : ["XAUUSD=X", "GC=F"];
    const interval = TF[tf].yf || "60m";
    const range = interval === "1m" ? "5d" : interval === "1d" ? "2y" : interval === "60m" ? "6mo" : "1mo";
    let lastErr: any;
    for (const ys of syms) {
      try {
        const data = await getJson(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ys)}?interval=${interval}&range=${range}`, 4500);
        const r = data?.chart?.result?.[0];
        const ts: number[] = r?.timestamp || [];
        const q = r?.indicators?.quote?.[0];
        if (!q || ts.length === 0) throw new Error("Yahoo: data kosong");
        let rows: Row[] = [];
        for (let i = 0; i < ts.length; i++) {
          if (q.open[i] == null || q.high[i] == null || q.low[i] == null || q.close[i] == null) continue;
          rows.push([ts[i] * 1000, q.open[i], q.high[i], q.low[i], q.close[i], q.volume?.[i] || 0]);
        }
        if (tf === "H4") rows = aggregate(rows, 14400);
        return rows.slice(-limit);
      } catch (e) { lastErr = e; }
    }
    throw lastErr || new Error("Yahoo gagal");
  },
};

const tradingview: SourceDef = {
  id: "TRADINGVIEW",
  label: "TradingView",
  proxy: false,
  fetch: async () => { throw new Error("dipakai lewat jalur multi-timeframe"); },
};

function chainFor(symbol: string): SourceDef[] {
  const bn = binanceSource("BINANCE", "https://api.binance.com");
  const bv = binanceSource("BINANCE_VISION", "https://data-api.binance.vision");
  // Emas: Binance/Kraken hanya punya PAXG (token emas) -> bukan spot persis, ditandai proxy.
  if (!isBtc(symbol)) return [tradingview, { ...bn, proxy: true, label: "Binance PAXG" }, { ...bv, proxy: true, label: "Binance PAXG (mirror)" }, { ...kraken, proxy: true, label: "Kraken PAXG" }, yahoo];
  return [bn, bv, coinbase, kraken, tradingview, yahoo];
}

export interface OhlcResult {
  symbol: string;
  source: SourceId;
  sourceLabel: string;
  /** true bila sumber adalah proxy harga (mis. PAXG), skala bisa beda beberapa dolar dari spot. */
  proxy: boolean;
  fetchedAt: number;
  candles: Partial<Record<TfId, Row[]>>;
  tried: { source: string; ok: boolean; error?: string }[];
}

const cache = new Map<string, { at: number; res: OhlcResult }>();
const ttlFor = (tfs: TfId[]) => Math.min(...tfs.map((t) => Math.max(1500, Math.min(15000, (TF[t].sec * 1000) / 6))));
let lastGood: Record<string, SourceId> = {};

async function fromSource(src: SourceDef, symbol: string, tfs: TfId[], limit: number): Promise<Partial<Record<TfId, Row[]>>> {
  const out: Partial<Record<TfId, Row[]>> = {};
  if (src.id === "TRADINGVIEW") {
    const tvTfs = tfs.map((t) => TF[t].tv);
    const hist = await fetchTradingViewHistory(symbol, tvTfs, Math.min(limit, 600));
    for (const t of tfs) {
      const rows = (hist[TF[t].tv] || []).map((r) => [r[0] * 1000, r[1], r[2], r[3], r[4], r[5]] as Row);
      out[t] = sanitizeRows(rows).slice(-limit);
    }
    return out;
  }
  const results = await Promise.all(tfs.map((t) => src.fetch(symbol, t, limit)));
  tfs.forEach((t, i) => { out[t] = sanitizeRows(results[i]).slice(-limit); });
  return out;
}

export async function getOhlc(opts: { symbol: string; tfs: TfId[]; limit: number; prefer?: string }): Promise<OhlcResult> {
  const symbol = opts.symbol.toUpperCase() === "BTCUSDT" ? "BTCUSD" : opts.symbol.toUpperCase();
  const tfs = opts.tfs.filter((t) => t in TF);
  const limit = Math.max(3, Math.min(1000, opts.limit));
  const minBars = limit >= 60 ? 50 : 2;
  const ckey = `${symbol}|${tfs.join(",")}|${limit}|${opts.prefer || ""}`;
  const hit = cache.get(ckey);
  if (hit && Date.now() - hit.at < ttlFor(tfs)) return hit.res;

  let chain = chainFor(symbol);
  const pin = opts.prefer || lastGood[symbol];
  if (pin) chain = [...chain.filter((s) => s.id === pin), ...chain.filter((s) => s.id !== pin)];

  const tried: OhlcResult["tried"] = [];
  for (const src of chain) {
    try {
      const candles = await fromSource(src, symbol, tfs, limit);
      const complete = tfs.every((t) => (candles[t]?.length || 0) >= Math.min(minBars, limit));
      if (!complete) throw new Error("data kurang lengkap");
      tried.push({ source: src.id, ok: true });
      lastGood[symbol] = src.id;
      const res: OhlcResult = { symbol, source: src.id, sourceLabel: src.label, proxy: src.proxy, fetchedAt: Date.now(), candles, tried };
      cache.set(ckey, { at: Date.now(), res });
      return res;
    } catch (e: any) {
      tried.push({ source: src.id, ok: false, error: String(e?.message || e).slice(0, 120) });
    }
  }
  const err: any = new Error("Tidak ada sumber OHLC yang bisa dijangkau");
  err.tried = tried;
  throw err;
}
