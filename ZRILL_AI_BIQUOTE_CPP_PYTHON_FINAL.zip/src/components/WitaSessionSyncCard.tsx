import React from "react";
import { motion } from "motion/react";
import {
  Clock,
  Globe,
  Radio,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Zap,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  Calendar,
} from "lucide-react";
import { WitaCalendarSync } from "../services/precisionSignalEngine";

interface WitaSessionSyncCardProps {
  data?: WitaCalendarSync;
  liveWitaTimeStr?: string;
  onNavigateToCalendar?: () => void;
  visualTheme?: "SLATE" | "IPHONE_GLASS";
}

export const WitaSessionSyncCard: React.FC<WitaSessionSyncCardProps> = ({
  data,
  liveWitaTimeStr,
  onNavigateToCalendar,
  visualTheme = "IPHONE_GLASS",
}) => {
  const currentWitaTime = liveWitaTimeStr || data?.currentWitaTime || new Date().toLocaleTimeString("id-ID", {
    timeZone: "Asia/Makassar",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }) + " WITA";

  const activeSession = data?.activeSession || "SESI LONDON (Eropa)";
  const isKillzone = data?.isKillzone ?? true;
  const killzoneBadge = data?.killzoneBadge || "LONDON KILLZONE AKTIF";
  const progressPct = data?.sessionProgressPct ?? 65;
  const nextSession = data?.nextSessionName || "Sesi New York (AS)";
  const timeToNext = data?.timeToNextSession || "1j 45m";

  const nearestEvent = data?.nearestHighImpactEvent;
  const safetyStatus = data?.newsSafetyStatus || " SAFE TRADING WINDOW (No High Impact News in next 2 hours)";
  const isSafe = safetyStatus.startsWith("");
  const isImminent = safetyStatus.startsWith("");

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="rounded-2xl border transition-all relative overflow-hidden font-mono shadow-xl bg-neutral-950/75 border-neutral-800/80 backdrop-blur-md hover:border-orange-500/30"
    >
      {/* Top ambient highlight */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-500 via-amber-400 to-orange-600 shadow-[0_0_12px_rgba(249,115,22,0.6)]" />

      <div className="p-4 sm:p-5 flex flex-col gap-4">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-400 shadow-[0_0_15px_rgba(249,115,22,0.2)]">
              <Globe className="w-5 h-5 animate-spin" style={{ animationDuration: "20s" }} />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider flex items-center gap-1.5 font-mono">
                  WITA REALTIME CALENDAR &amp; SESSION SYNCHRONIZER
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[8px] font-bold bg-neutral-900 text-neutral-300 border border-neutral-800 font-mono flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-400 animate-pulse" />
                  UTC+8 MAKASSAR / BALI
                </span>
              </div>
              <p className="text-[10px] text-neutral-400 mt-0.5 font-sans">
                Sinkronisasi Terpadu Jam WITA (UTC+8) &amp; Dampak Berita Ekonomi Makro
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-neutral-900/90 border border-orange-500/30 text-orange-300 font-mono">
              <Clock className="w-4 h-4 text-orange-400 animate-pulse" />
              <span className="text-sm font-black tracking-wider tabular-nums">{currentWitaTime}</span>
            </div>
          </div>
        </div>

        {/* 3 Interactive Synchronizer Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Pillar 1: Sesi Bursa Aktif & Killzone */}
          <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col justify-between gap-2.5">
            <div className="flex items-center justify-between font-mono">
              <span className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest flex items-center gap-1">
                <Radio className="w-3 h-3 text-orange-400" /> Sesi Bursa Global
              </span>
              <span
                className={`text-[8px] font-black px-1.5 py-0.5 rounded border uppercase ${
                  isKillzone
                    ? "bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse"
                    : "bg-orange-500/20 text-orange-300 border-orange-500/40"
                }`}
              >
                {killzoneBadge}
              </span>
            </div>

            <div>
              <div className="text-sm font-black text-white tracking-wide flex items-center gap-1.5 font-mono">
                {activeSession}
              </div>
              <div className="text-[9px] text-neutral-400 mt-0.5 font-sans">
                Menuju {nextSession} dlm <strong className="text-orange-400 font-mono">{timeToNext}</strong>
              </div>
            </div>

            {/* Session Progress Bar */}
            <div className="flex flex-col gap-1 font-mono">
              <div className="flex items-center justify-between text-[8px] text-neutral-400">
                <span>Progres Sesi</span>
                <span className="text-orange-400 font-bold tabular-nums">{progressPct}%</span>
              </div>
              <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden border border-neutral-700/50">
                <div
                  className="h-full bg-gradient-to-r from-orange-500 to-amber-400 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, Math.max(5, progressPct))}%` }}
                />
              </div>
            </div>
          </div>

          {/* Pillar 2: Status Keselamatan Berita Makro (Macro Guard) */}
          <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col justify-between gap-2.5">
            <div className="flex items-center justify-between font-mono">
              <span className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-orange-400" /> Filter Keselamatan Berita
              </span>
              <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300 border border-neutral-700">
                VOLATILITAS: {data?.volatilityMultiplier || "1.0x"}
              </span>
            </div>

            <div>
              <div
                className={`text-xs font-black tracking-wide flex items-center gap-1.5 ${
                  isSafe ? "text-emerald-400" : isImminent ? "text-amber-400" : "text-rose-400"
                }`}
              >
                {isSafe ? <ShieldCheck className="w-4 h-4 shrink-0" /> : <AlertTriangle className="w-4 h-4 shrink-0" />}
                <span className="line-clamp-1">{safetyStatus.split("(")[0]}</span>
              </div>
              <p className="text-[9px] text-gray-400 mt-1 leading-relaxed">
                {isSafe
                  ? "Jendela waktu trading aman: Tidak ada berita berdampak tinggi merah dalam 2 jam ke depan."
                  : "Peringatan volatilitas makro: Harap batasi risiko dan gunakan trailing SL protektif."}
              </p>
            </div>

            <div className="flex items-center gap-1.5 text-[8px] text-gray-400 bg-white/[0.02] p-1.5 rounded-lg border border-white/5">
              <Flame className="w-3 h-3 text-amber-400 shrink-0" />
              <span>Proteksi Slippage &amp; Spike Spreading Otomatis Terkunci</span>
            </div>
          </div>

          {/* Pillar 3: Peristiwa Berdampak Tinggi Terdekat */}
          <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col justify-between gap-2.5">
            <div className="flex items-center justify-between font-mono">
              <span className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest flex items-center gap-1">
                <Calendar className="w-3 h-3 text-orange-400" /> Berita Terdekat
              </span>
              {nearestEvent && (
                <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  {nearestEvent.currency}
                </span>
              )}
            </div>

            {nearestEvent ? (
              <div>
                <div className="text-xs font-black text-white tracking-wide line-clamp-1">
                  {nearestEvent.title}
                </div>
                <div className="flex items-center gap-2 mt-1 text-[9px] font-mono">
                  <span className="text-orange-300 font-bold flex items-center gap-1">
                    <Clock className="w-3 h-3 text-orange-400" /> {nearestEvent.witaReleaseTime}
                  </span>
                  <span className="text-neutral-500">|</span>
                  <span className="text-amber-300 font-bold">
                    {nearestEvent.countdownStr}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-1 text-[8px] text-neutral-300 font-mono">
                  <span>Estimasi: <strong>{nearestEvent.forecast}</strong></span>
                  <span>Prev: <strong>{nearestEvent.previous}</strong></span>
                  <span
                    className={`font-bold ml-auto flex items-center gap-0.5 ${
                      nearestEvent.impactDirection === "BUY" ? "text-orange-400" : "text-rose-400"
                    }`}
                  >
                    {nearestEvent.impactDirection === "BUY" ? (
                      <TrendingUp className="w-2.5 h-2.5" />
                    ) : (
                      <TrendingDown className="w-2.5 h-2.5" />
                    )}
                    {nearestEvent.impactDirection}
                  </span>
                </div>
              </div>
            ) : (
              <div className="text-[10px] text-neutral-400 py-1 font-mono">
                Sedang memindai kalender ekonomi makro langsung...
              </div>
            )}

            {onNavigateToCalendar && (
              <button
                onClick={onNavigateToCalendar}
                className="mt-1 w-full py-1.5 px-2 rounded-lg bg-orange-500/10 hover:bg-orange-500/20 text-orange-300 border border-orange-500/30 text-[9px] font-bold uppercase tracking-wider flex items-center justify-center gap-1 transition-all cursor-pointer"
              >
                <span>Lihat Seluruh Jadwal di Kalender Live</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};
