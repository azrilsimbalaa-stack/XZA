import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class CppOhlcEngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        compiler = shutil.which("g++") or shutil.which("c++")
        if not compiler:
            raise unittest.SkipTest("C++ compiler not installed")
        cls.temp_dir = tempfile.TemporaryDirectory()
        cls.binary = Path(cls.temp_dir.name) / "zrill_ohlc_engine"
        subprocess.run([
            compiler, "-std=c++17", "-O2", "-Wall", "-Wextra", "-Wpedantic",
            str(ROOT / "engines/cpp/ohlc_engine.cpp"), "-o", str(cls.binary)
        ], check=True, capture_output=True, text=True)

    @classmethod
    def tearDownClass(cls):
        if hasattr(cls, "temp_dir"):
            cls.temp_dir.cleanup()

    def test_valid_uptrend_ohlc_returns_indicators_and_directional_bias(self):
        rows = ["timestamp,open,high,low,close"]
        price = 100.0
        for i in range(60):
            opening = price
            closing = price + 0.5
            rows.append(f"{i},{opening},{closing + 0.25},{opening - 0.25},{closing}")
            price = closing
        result = subprocess.run([str(self.binary)], input="\n".join(rows), capture_output=True, text=True, check=True)
        payload = json.loads(result.stdout)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["candles"], 60)
        self.assertIsNotNone(payload["ema20"])
        self.assertIsNotNone(payload["ema50"])
        self.assertIsNotNone(payload["atr14"])
        self.assertEqual(payload["bias"], "BULLISH")

    def test_rejects_impossible_ohlc_ranges(self):
        result = subprocess.run([str(self.binary)], input="1,10,9,8,11\n", capture_output=True, text=True)
        payload = json.loads(result.stdout)
        self.assertFalse(payload["ok"])
        self.assertIn("No valid OHLC candles", payload["error"])


if __name__ == "__main__":
    unittest.main()
