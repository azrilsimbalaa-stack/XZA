import importlib.util
import unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "fetch_biquote_calendar.py"
spec = importlib.util.spec_from_file_location("biquote_calendar", SCRIPT)
provider = importlib.util.module_from_spec(spec)
if spec and spec.loader:
    spec.loader.exec_module(provider)


class BiQuoteCalendarNormalizationTests(unittest.TestCase):
    def test_maps_biquote_event_to_legacy_calendar_input_without_changing_prediction_logic(self):
        raw = {
            "id": "mql5:900001",
            "eventId": "mql5:840",
            "time": "2026-10-15T12:30:00Z",
            "countryCode": "US",
            "currency": "USD",
            "name": "Nonfarm Payrolls",
            "importance": "high",
            "type": "indicator",
            "actual": None,
            "forecast": 145000,
            "previous": 147000,
            "timeMode": "exact",
            "source": "mql5",
        }
        event = provider.normalize_event(raw)
        self.assertEqual(event["title"], "Nonfarm Payrolls")
        self.assertEqual(event["date"], "2026-10-15T12:30:00Z")
        self.assertEqual(event["currency"], "USD")
        self.assertEqual(event["importance"], 1)
        self.assertEqual(event["impact"], "HIGH")
        self.assertEqual(event["forecast"], "145000")
        self.assertEqual(event["previous"], "147000")
        self.assertIsNone(event["actual"])
        self.assertEqual(event["provider"], "BiQuote")

    def test_preserves_zero_as_actual_value(self):
        event = provider.normalize_event({
            "time": "2026-10-15T12:30:00Z",
            "name": "Test Indicator",
            "countryCode": "US",
            "currency": "USD",
            "importance": "medium",
            "actual": 0,
            "forecast": 0,
            "previous": 0,
        })
        self.assertEqual(event["actual"], 0)
        self.assertEqual(event["forecast"], "0")
        self.assertEqual(event["previous"], "0")

    def test_skips_events_without_valid_timestamp_or_title(self):
        self.assertIsNone(provider.normalize_event({"name": "No time"}))
        self.assertIsNone(provider.normalize_event({"time": "not-a-date", "name": "Bad date"}))


if __name__ == "__main__":
    unittest.main()
