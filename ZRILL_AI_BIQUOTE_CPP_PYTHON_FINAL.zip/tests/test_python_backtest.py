import tempfile
import unittest
from pathlib import Path

from engines.python.backtest import Candle, run_backtest, load_candles


class PythonBacktestTests(unittest.TestCase):
    def test_backtest_is_deterministic_and_accounts_for_costs(self):
        candles = []
        price = 100.0
        for i in range(120):
            # Alternating cycles exercise both long and short crossovers.
            delta = 0.9 if (i // 15) % 2 == 0 else -0.8
            next_price = max(10.0, price + delta)
            candles.append(Candle(str(i).zfill(4), price, max(price, next_price) + 0.2,
                                  min(price, next_price) - 0.2, next_price))
            price = next_price
        without_costs = run_backtest(candles, 5, 12, 0.0)
        with_costs = run_backtest(candles, 5, 12, 2.0)
        self.assertTrue(with_costs["ok"])
        self.assertGreater(with_costs["closedTrades"], 0)
        self.assertLessEqual(with_costs["netReturnFraction"], without_costs["netReturnFraction"])
        self.assertGreaterEqual(with_costs["maxDrawdownFraction"], 0.0)

    def test_csv_loader_rejects_impossible_ranges_and_keeps_valid_ohlc(self):
        with tempfile.TemporaryDirectory() as td:
            csv_path = Path(td) / "candles.csv"
            csv_path.write_text(
                "timestamp,open,high,low,close\n"
                "1,10,11,9,10.5\n"
                "2,10,9,8,11\n",
                encoding="utf-8",
            )
            candles = load_candles(csv_path)
            self.assertEqual(len(candles), 1)
            self.assertEqual(candles[0].timestamp, "1")


if __name__ == "__main__":
    unittest.main()
