#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

struct Candle {
    double timestamp{};
    double open{};
    double high{};
    double low{};
    double close{};
};

static bool parse_number(const std::string& text, double& output) {
    try {
        std::size_t used = 0;
        output = std::stod(text, &used);
        return used == text.size() && std::isfinite(output);
    } catch (...) {
        return false;
    }
}

static std::vector<std::string> split_csv(const std::string& line) {
    std::vector<std::string> fields;
    std::stringstream stream(line);
    std::string field;
    while (std::getline(stream, field, ',')) fields.push_back(field);
    return fields;
}

static bool valid_candle(const Candle& c) {
    return std::isfinite(c.timestamp) && c.timestamp >= 0.0 &&
           std::isfinite(c.open) && std::isfinite(c.high) &&
           std::isfinite(c.low) && std::isfinite(c.close) &&
           c.open > 0.0 && c.high > 0.0 && c.low > 0.0 && c.close > 0.0 &&
           c.high >= c.low && c.high >= std::max(c.open, c.close) &&
           c.low <= std::min(c.open, c.close);
}

static double ema(const std::vector<Candle>& candles, std::size_t period) {
    if (candles.size() < period || period == 0) return std::numeric_limits<double>::quiet_NaN();
    const double alpha = 2.0 / (static_cast<double>(period) + 1.0);
    double value = candles.front().close;
    for (std::size_t i = 1; i < candles.size(); ++i) value = alpha * candles[i].close + (1.0 - alpha) * value;
    return value;
}

static double atr14(const std::vector<Candle>& candles) {
    if (candles.size() < 15) return std::numeric_limits<double>::quiet_NaN();
    double sum = 0.0;
    const std::size_t begin = candles.size() - 14;
    for (std::size_t i = begin; i < candles.size(); ++i) {
        const double previous_close = candles[i - 1].close;
        const double tr = std::max({candles[i].high - candles[i].low,
                                    std::abs(candles[i].high - previous_close),
                                    std::abs(candles[i].low - previous_close)});
        sum += tr;
    }
    return sum / 14.0;
}

static void print_number(double value) {
    if (!std::isfinite(value)) std::cout << "null";
    else std::cout << std::setprecision(12) << value;
}

int main() {
    std::vector<Candle> candles;
    std::string line;
    int invalid_rows = 0;
    while (std::getline(std::cin, line)) {
        if (line.empty()) continue;
        const auto fields = split_csv(line);
        if (fields.size() < 5) { ++invalid_rows; continue; }
        Candle c;
        if (!parse_number(fields[0], c.timestamp) || !parse_number(fields[1], c.open) ||
            !parse_number(fields[2], c.high) || !parse_number(fields[3], c.low) ||
            !parse_number(fields[4], c.close)) {
            // Permit a single CSV header row.
            if (candles.empty() && (fields[0].find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_ ") == std::string::npos)) continue;
            ++invalid_rows;
            continue;
        }
        if (!valid_candle(c)) { ++invalid_rows; continue; }
        candles.push_back(c);
    }

    std::stable_sort(candles.begin(), candles.end(), [](const Candle& a, const Candle& b) {
        return a.timestamp < b.timestamp;
    });
    candles.erase(std::unique(candles.begin(), candles.end(), [](const Candle& a, const Candle& b) {
        return a.timestamp == b.timestamp;
    }), candles.end());

    if (candles.empty()) {
        std::cout << "{\"ok\":false,\"error\":\"No valid OHLC candles\",\"invalidRows\":" << invalid_rows << "}\n";
        return 2;
    }

    const double ema20 = ema(candles, 20);
    const double ema50 = ema(candles, 50);
    const double atr = atr14(candles);
    double momentum_bps = std::numeric_limits<double>::quiet_NaN();
    if (candles.size() >= 6) {
        momentum_bps = ((candles.back().close / candles[candles.size() - 6].close) - 1.0) * 10000.0;
    }
    const std::size_t range_begin = candles.size() > 20 ? candles.size() - 20 : 0;
    double range_high = candles[range_begin].high;
    double range_low = candles[range_begin].low;
    for (std::size_t i = range_begin; i < candles.size(); ++i) {
        range_high = std::max(range_high, candles[i].high);
        range_low = std::min(range_low, candles[i].low);
    }

    std::string bias = "NEUTRAL";
    if (std::isfinite(ema20) && std::isfinite(ema50) && std::isfinite(momentum_bps)) {
        if (ema20 > ema50 && momentum_bps > 0) bias = "BULLISH";
        else if (ema20 < ema50 && momentum_bps < 0) bias = "BEARISH";
    }

    std::cout << "{\"ok\":true,\"candles\":" << candles.size()
              << ",\"invalidRows\":" << invalid_rows
              << ",\"timestamp\":"; print_number(candles.back().timestamp);
    std::cout << ",\"open\":"; print_number(candles.back().open);
    std::cout << ",\"high\":"; print_number(candles.back().high);
    std::cout << ",\"low\":"; print_number(candles.back().low);
    std::cout << ",\"close\":"; print_number(candles.back().close);
    std::cout << ",\"ema20\":"; print_number(ema20);
    std::cout << ",\"ema50\":"; print_number(ema50);
    std::cout << ",\"atr14\":"; print_number(atr);
    std::cout << ",\"momentumBps\":"; print_number(momentum_bps);
    std::cout << ",\"rangeHigh\":"; print_number(range_high);
    std::cout << ",\"rangeLow\":"; print_number(range_low);
    std::cout << ",\"bias\":\"" << bias << "\"}\n";
    return 0;
}
