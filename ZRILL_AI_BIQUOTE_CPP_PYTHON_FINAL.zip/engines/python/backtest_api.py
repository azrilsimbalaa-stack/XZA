#!/usr/bin/env python3
"""JSON-in/JSON-out bridge for the Python backtest service."""
from __future__ import annotations

import json
import math
import sys
from backtest import Candle, run_backtest


def parse_timestamp(value, index: int) -> str:
    if value is None:
        return str(index).zfill(12)
    if isinstance(value, (int, float)) and math.isfinite(float(value)):
        return f"{float(value):024.6f}"
    text = str(value).strip()
    try:
        numeric = float(text)
        if math.isfinite(numeric):
            return f"{numeric:024.6f}"
    except ValueError:
        pass
    return text or str(index).zfill(12)


def normalize_candles(raw_candles):
    if not isinstance(raw_candles, list):
        raise ValueError("candles must be an array")
    candles = []
    for index, raw in enumerate(raw_candles):
        if isinstance(raw, dict):
            ts = raw.get("timestamp", raw.get("time", raw.get("date")))
            values = [raw.get(key) for key in ("open", "high", "low", "close")]
        elif isinstance(raw, (list, tuple)) and len(raw) >= 5:
            ts, *values = raw[:5]
            values = values[1:] if len(values) == 5 else values
            # For positional OHLC arrays the first element is time, followed by O,H,L,C.
            values = list(raw[1:5])
        else:
            continue
        try:
            o, h, l, c = (float(value) for value in values)
        except (TypeError, ValueError):
            continue
        if not all(math.isfinite(value) and value > 0 for value in (o, h, l, c)):
            continue
        if h < max(o, c) or l > min(o, c) or h < l:
            continue
        candles.append(Candle(parse_timestamp(ts, index), o, h, l, c))
    candles.sort(key=lambda candle: candle.timestamp)
    by_time = {candle.timestamp: candle for candle in candles}
    return [by_time[key] for key in sorted(by_time)]


def main() -> int:
    try:
        request = json.load(sys.stdin)
        candles = normalize_candles(request.get("candles"))
        result = run_backtest(
            candles,
            int(request.get("fastPeriod", 12)),
            int(request.get("slowPeriod", 26)),
            float(request.get("costBpsPerSide", 1.0)),
        )
        print(json.dumps(result, separators=(",", ":")))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, separators=(",", ":")), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
