#!/usr/bin/env python3
"""Deterministic OHLC EMA-cross backtest. Input CSV: timestamp,open,high,low,close[,volume]."""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence


@dataclass(frozen=True)
class Candle:
    timestamp: str
    open: float
    high: float
    low: float
    close: float


def load_candles(path: Path) -> list[Candle]:
    out: list[Candle] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError("CSV must have a header row")
        columns = {name.strip().lower(): name for name in reader.fieldnames}
        required = {"open", "high", "low", "close"}
        missing = required - set(columns)
        if missing:
            raise ValueError(f"Missing required CSV columns: {', '.join(sorted(missing))}")
        time_col = columns.get("timestamp") or columns.get("time") or columns.get("date")
        for row in reader:
            try:
                candle = Candle(
                    timestamp=str(row.get(time_col, "") if time_col else len(out)),
                    open=float(row[columns["open"]]),
                    high=float(row[columns["high"]]),
                    low=float(row[columns["low"]]),
                    close=float(row[columns["close"]]),
                )
            except (TypeError, ValueError):
                continue
            values = (candle.open, candle.high, candle.low, candle.close)
            if not all(math.isfinite(v) and v > 0 for v in values):
                continue
            if candle.high < max(candle.open, candle.close) or candle.low > min(candle.open, candle.close) or candle.high < candle.low:
                continue
            out.append(candle)
    out.sort(key=lambda c: c.timestamp)
    dedup: dict[str, Candle] = {c.timestamp: c for c in out}
    return [dedup[t] for t in sorted(dedup)]


def ema(values: Sequence[float], period: int) -> list[float]:
    if period < 1:
        raise ValueError("EMA period must be positive")
    alpha = 2.0 / (period + 1.0)
    result: list[float] = []
    current = values[0]
    for value in values:
        current = alpha * value + (1.0 - alpha) * current if result else value
        result.append(current)
    return result


def max_drawdown(equity: Sequence[float]) -> float:
    peak = 1.0
    worst = 0.0
    for value in equity:
        peak = max(peak, value)
        if peak > 0:
            worst = min(worst, value / peak - 1.0)
    return abs(worst)


def run_backtest(candles: Sequence[Candle], fast_period: int = 12, slow_period: int = 26,
                 cost_bps_per_side: float = 1.0) -> dict:
    if not 2 <= fast_period < slow_period:
        raise ValueError("Periods must satisfy 2 <= fast_period < slow_period")
    if len(candles) < slow_period + 2:
        raise ValueError(f"Need at least {slow_period + 2} valid candles; got {len(candles)}")
    if cost_bps_per_side < 0:
        raise ValueError("Transaction costs cannot be negative")

    closes = [c.close for c in candles]
    fast = ema(closes, fast_period)
    slow = ema(closes, slow_period)
    position = 0  # +1 long, -1 short, 0 flat
    entry_price = 0.0
    entry_timestamp = ""
    equity = 1.0
    curve = [equity]
    trades = []
    cost = cost_bps_per_side / 10000.0

    for i in range(2, len(candles)):
        prior_side = 1 if fast[i - 1] > slow[i - 1] else -1 if fast[i - 1] < slow[i - 1] else 0
        prior_prior_side = 1 if fast[i - 2] > slow[i - 2] else -1 if fast[i - 2] < slow[i - 2] else 0
        crossed = prior_side != 0 and prior_side != prior_prior_side
        desired = prior_side if crossed else position
        if crossed and desired != position:
            execution_price = candles[i].open
            if position != 0:
                gross = (execution_price / entry_price - 1.0) * position
                net = gross - 2.0 * cost
                equity *= max(0.0, 1.0 + net)
                trades.append({"entryTime": entry_timestamp, "exitTime": candles[i].timestamp,
                               "side": "LONG" if position > 0 else "SHORT", "netReturn": net})
            position = desired
            entry_price = execution_price
            entry_timestamp = candles[i].timestamp
            equity *= max(0.0, 1.0 - cost)
        curve.append(equity)

    if position != 0:
        execution_price = candles[-1].close
        gross = (execution_price / entry_price - 1.0) * position
        net = gross - 2.0 * cost
        equity *= max(0.0, 1.0 + net)
        trades.append({"entryTime": entry_timestamp, "exitTime": candles[-1].timestamp,
                       "side": "LONG" if position > 0 else "SHORT", "netReturn": net})
        curve.append(equity)

    wins = sum(1 for t in trades if t["netReturn"] > 0)
    return {
        "ok": True,
        "strategy": "EMA crossover (signal on prior close, execution at next candle open)",
        "candles": len(candles),
        "parameters": {"fastPeriod": fast_period, "slowPeriod": slow_period,
                       "costBpsPerSide": cost_bps_per_side},
        "closedTrades": len(trades),
        "winFraction": wins / len(trades) if trades else None,
        "netReturnFraction": equity - 1.0,
        "maxDrawdownFraction": max_drawdown(curve),
        "trades": trades,
        "note": "Historical simulation only; not a forecast or guarantee of future performance.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path, help="historical OHLC CSV")
    parser.add_argument("--fast", type=int, default=12)
    parser.add_argument("--slow", type=int, default=26)
    parser.add_argument("--cost-bps-per-side", type=float, default=1.0)
    args = parser.parse_args()
    try:
        candles = load_candles(args.csv)
        result = run_backtest(candles, args.fast, args.slow, args.cost_bps_per_side)
        print(json.dumps(result, separators=(",", ":")))
        return 0
    except (OSError, ValueError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
