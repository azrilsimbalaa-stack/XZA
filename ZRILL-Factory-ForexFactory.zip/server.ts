import { timingSafeEqual } from "node:crypto";
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import cors from "cors";
import {
  initTradingViewEngine,
  getTradingViewPrice,
  getAllTradingViewPrices,
} from "./src/server/tradingviewService.js";
import {
  buildComprehensiveEconomicEvent,
} from "./src/services/institutionalCalendarEngine.js";
import {
  BIQUOTE_BASE_URL,
  normalizeBiQuoteBars,
  normalizeBiQuoteTick,
} from "./src/server/biquoteService.js";
import {
  FOREX_FACTORY_WEEKLY_FEED_URL,
  normalizeForexFactoryCalendarPayload,
} from "./src/server/forexFactoryService.js";

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT || 3000);
  
  const allowedOrigins = [
    ...(process.env.ALLOWED_ORIGINS || "http://localhost:3000,http://127.0.0.1:3000").split(","),
    ...(process.env.APP_URL ? [process.env.APP_URL] : []),
  ].map((origin) => origin.trim()).filter(Boolean);
  app.use(cors({
    origin(origin, callback) {
      if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
      return callback(new Error("Origin not allowed"));
    },
    methods: ["GET", "POST", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  }));
  app.use(express.json({ limit: "1mb" }));
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    next();
  });

  // Initialize Real-Time TradingView WebSocket Engine (from cloned repository module)
  initTradingViewEngine();

  // Real-Time TradingView Prices Endpoint
  app.get("/api/binance-time", async (req, res) => {
    try {
      const response = await fetch("https://api.binance.com/api/v3/time", { signal: AbortSignal.timeout(5000) });
      const data = await response.json();
      res.json(data);
    } catch (e) {
      console.error(e);
      res.status(500).json({ error: "Failed to fetch Binance time" });
    }
  });

  app.get("/api/tradingview/prices", (req, res) => {
    const prices = getAllTradingViewPrices();
    res.json({
      prices,
      source: "TRADINGVIEW_WEBSOCKET",
      dataStatus: Object.keys(prices).length ? "LIVE" : "OFFLINE",
      timestamp: Date.now(),
    });
  });

  // TradingView MCP Server Integration Endpoints (cloned from tradesdontlie/tradingview-mcp)
  app.get("/api/mcp/status", (req, res) => {
    res.json({
      mcpVersion: "partial",
      status: "PARTIAL",
      availableToolGroups: ["quote"],
      description: "Local quote bridge only. Full TradingView MCP/CDP tool execution is not configured.",
      timestamp: Date.now()
    });
  });

  app.get("/api/mcp/tools", (_req, res) => {
    res.json({
      tools: [
        { name: "quote_get", description: "Get a fresh quote from the local TradingView WebSocket cache" },
      ],
      unavailable: ["data_get_ohlcv", "data_get_study_values", "data_get_pine_lines", "data_get_pine_labels", "data_get_pine_tables", "data_get_pine_boxes", "chart_get_state", "chart_set_symbol", "chart_set_timeframe", "data_get_strategy_results", "data_get_trades"],
    });
  });

  app.post("/api/mcp/execute", async (req, res) => {
    const tool = typeof req.body?.tool === "string" ? req.body.tool : "";
    const params = req.body?.params && typeof req.body.params === "object" ? req.body.params : {};
    if (!tool) return res.status(400).json({ success: false, error: "Tool name is required" });
    try {
      if (tool === "quote_get") {
        const symbol = typeof params.symbol === "string" ? params.symbol : "XAUUSD";
        const tvPrice = getTradingViewPrice(symbol);
        if (!tvPrice) return res.status(503).json({
          success: false,
          tool,
          status: "DATA_UNAVAILABLE",
          error: "No fresh quote is available from the TradingView feed.",
        });
        return res.json({ success: true, tool, data: tvPrice });
      }
      return res.status(501).json({
        success: false,
        tool,
        status: "NOT_IMPLEMENTED",
        error: "This tool is not connected to a TradingView MCP/CDP session.",
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message || "Execution error" });
    }
  });

  // Primary quote source: BiQuote MT5 feed. A quote is LIVE only when open and <=30s old.
  let biQuoteQuoteHealth: { status: string; symbol: string | null; ageMs: number | null; checkedAt: number } = {
    status: "UNKNOWN", symbol: null, ageMs: null, checkedAt: 0,
  };
  app.get("/api/biquote/price", async (req, res) => {
    const symbol = String(req.query.symbol || "XAUUSD").toUpperCase();
    const allowedQuoteSymbols = new Set(["XAUUSD", "BTCUSD", "ETHUSD", "EURUSD", "GBPUSD", "USDJPY", "AUDUSD"]);
    if (!allowedQuoteSymbols.has(symbol)) return res.status(400).json({ error: "Unsupported symbol" });
    try {
      const response = await fetch(`${BIQUOTE_BASE_URL}/api/${encodeURIComponent(symbol)}?allowStale=false`, {
        signal: AbortSignal.timeout(5000),
        headers: { Accept: "application/json" },
      });
      if (!response.ok) {
        biQuoteQuoteHealth = { status: "OFFLINE", symbol, ageMs: null, checkedAt: Date.now() };
        return res.status(503).json({ error: "BiQuote quote unavailable", code: "BIQUOTE_QUOTE_UNAVAILABLE", symbol });
      }
      const payload = await response.json();
      const quote = normalizeBiQuoteTick(payload);
      if (!quote || quote.symbol !== symbol) {
        biQuoteQuoteHealth = { status: "OFFLINE", symbol, ageMs: null, checkedAt: Date.now() };
        return res.status(503).json({ error: "BiQuote returned an invalid quote", code: "BIQUOTE_INVALID_QUOTE", symbol });
      }
      biQuoteQuoteHealth = { status: quote.dataStatus, symbol, ageMs: quote.ageMs, checkedAt: Date.now() };
      res.setHeader("Cache-Control", "no-store");
      return res.json({
        symbol: quote.symbol,
        price: quote.price,
        bid: quote.bid,
        ask: quote.ask,
        ch: Number.isFinite(Number(payload.dayDiffAmount)) ? Number(payload.dayDiffAmount) : 0,
        chp: Number.isFinite(Number(payload.dayDiffPercent)) ? Number(payload.dayDiffPercent) : 0,
        timestamp: new Date(quote.timestamp).toISOString(),
        quoteAgeSeconds: Math.round(quote.ageMs / 1000),
        marketState: quote.marketState,
        dataStatus: quote.dataStatus,
        source: quote.source,
      });
    } catch (error: any) {
      biQuoteQuoteHealth = { status: "OFFLINE", symbol, ageMs: null, checkedAt: Date.now() };
      console.warn("BiQuote quote request failed:", error?.message);
      return res.status(503).json({ error: "BiQuote quote provider failed", code: "BIQUOTE_PROVIDER_OFFLINE", symbol });
    }
  });

  // Legacy TradingView quote bridge retained for MCP quote_get only.
  app.get("/api/tradingview/price", (req, res) => {
    const rawSymbol = (req.query.symbol as string) || "XAUUSD";
    const tvPrice = getTradingViewPrice(rawSymbol);
    if (tvPrice && tvPrice.price > 0) {
      return res.json({
        symbol: rawSymbol,
        price: tvPrice.price,
        bid: tvPrice.bid,
        ask: tvPrice.ask,
        ch: tvPrice.ch,
        chp: tvPrice.chp,
        volume: tvPrice.volume,
        high: tvPrice.high,
        low: tvPrice.low,
        open: tvPrice.open,
        source: "TRADINGVIEW_WEBSOCKET",
        updatedAt: tvPrice.updatedAt,
      });
    }
    res.status(404).json({ error: "TradingView symbol price connecting...", symbol: rawSymbol });
  });

  // Primary OHLC source: BiQuote. Never splice candles from a different venue.
  app.get("/api/klines", async (req, res) => {
    const symbol = String(req.query.symbol || "XAUUSD").toUpperCase();
    const interval = String(req.query.interval || "1m");
    const allowedSymbols = new Set(["XAUUSD", "BTCUSD", "ETHUSD", "EURUSD", "GBPUSD", "USDJPY", "AUDUSD"]);
    const allowedIntervals = new Set(["1m", "5m", "15m", "30m", "1h", "4h", "1d"]);
    if (!allowedSymbols.has(symbol) || !allowedIntervals.has(interval)) {
      return res.status(400).json({ error: "Unsupported symbol or interval" });
    }
    const parsedLimit = Number.parseInt(String(req.query.limit || "150"), 10);
    const limit = Number.isFinite(parsedLimit) ? Math.max(30, Math.min(1000, parsedLimit)) : 150;
    try {
      const url = `${BIQUOTE_BASE_URL}/api/${encodeURIComponent(symbol)}/ohlc?interval=${encodeURIComponent(interval)}&limit=${limit}`;
      const response = await fetch(url, { signal: AbortSignal.timeout(7000), headers: { Accept: "application/json" } });
      if (!response.ok) return res.status(503).json({ error: "BiQuote OHLC provider unavailable", code: "BIQUOTE_OHLC_UNAVAILABLE", symbol, interval });
      const payload = await response.json();
      const bars = normalizeBiQuoteBars(payload);
      if (bars.length < 30 || payload.symbol?.toUpperCase() !== symbol || payload.interval !== interval) {
        return res.status(503).json({ error: "BiQuote OHLC response failed validation", code: "BIQUOTE_OHLC_INVALID", symbol, interval });
      }
      res.setHeader("Cache-Control", "no-store");
      res.setHeader("X-Market-Data-Source", "BIQUOTE");
      res.setHeader("X-Market-Data-Instrument", symbol);
      res.setHeader("X-Market-Data-Interval", interval);
      res.setHeader("X-Market-Data-Open-Bar", bars[bars.length - 1].isOpen ? "true" : "false");
      return res.json(bars.slice(-limit).map((bar) => [
        bar.time,
        String(bar.open),
        String(bar.high),
        String(bar.low),
        String(bar.close),
        String(bar.volume || bar.tickVolume || 0),
      ]));
    } catch (error: any) {
      console.warn("BiQuote OHLC request failed:", error?.message);
      return res.status(503).json({ error: "BiQuote OHLC provider failed", code: "BIQUOTE_PROVIDER_OFFLINE", symbol, interval });
    }
  });

  app.get("/api/yahoo/klines", async (req, res) => {
    try {
      const symbol = String(req.query.symbol || "XAUUSD=X").toUpperCase();
      let interval = String(req.query.interval || "1m");
      if (!/^[A-Z0-9=^._-]{1,20}$/.test(symbol) || !["1m", "5m", "15m", "30m", "1h", "4h", "1d"].includes(interval)) {
        return res.status(400).json({ error: "Unsupported symbol or interval" });
      }
      
      // Map provider intervals to Yahoo intervals & ranges
      let range = "1d";
      let yahooInterval = interval;
      let is4h = false;
      
      switch (interval) {
        case "1m": range = "1d"; yahooInterval = "1m"; break;
        case "5m": range = "5d"; yahooInterval = "5m"; break;
        case "15m": range = "5d"; yahooInterval = "15m"; break;
        case "30m": range = "1mo"; yahooInterval = "30m"; break;
        case "1h": range = "1mo"; yahooInterval = "60m"; break;
        case "4h": range = "3mo"; yahooInterval = "60m"; is4h = true; break;
        case "1d": range = "1y"; yahooInterval = "1d"; break;
        default: range = "1mo"; yahooInterval = "60m";
      }

      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${yahooInterval}&range=${range}`;
      const yahooRes = await fetch(url, { signal: AbortSignal.timeout(4000) });
      const data = await yahooRes.json();
      
      const timestamps = data.chart?.result?.[0]?.timestamp || [];
      const quote = data.chart?.result?.[0]?.indicators?.quote?.[0] || {};
      
      let formattedData = timestamps.map((t: number, i: number) => {
        if (quote.open?.[i] == null) return null;
        return [
          t * 1000,
          (quote.open[i] ?? 0).toString(),
          (quote.high[i] ?? 0).toString(),
          (quote.low[i] ?? 0).toString(),
          (quote.close[i] ?? 0).toString(),
          quote.volume?.[i]?.toString() || "0"
        ];
      }).filter((d: any) => d !== null);

      if (is4h) {
        const h4Map = new Map<number, any>();
        for (const item of formattedData) {
          const tSec = Math.floor(item[0] / 1000);
          const h4Sec = Math.floor(tSec / 14400) * 14400;
          const h4Ms = h4Sec * 1000;

          const open = parseFloat(item[1]);
          const high = parseFloat(item[2]);
          const low = parseFloat(item[3]);
          const close = parseFloat(item[4]);
          const vol = parseFloat(item[5]);

          if (!h4Map.has(h4Ms)) {
            h4Map.set(h4Ms, [h4Ms, item[1], item[2], item[3], item[4], item[5]]);
          } else {
            const existing = h4Map.get(h4Ms);
            existing[2] = Math.max(parseFloat(existing[2]), high).toString();
            existing[3] = Math.min(parseFloat(existing[3]), low).toString();
            existing[4] = item[4];
            existing[5] = (parseFloat(existing[5]) + vol).toString();
          }
        }
        formattedData = Array.from(h4Map.values());
      }
      
      const requestedLimit = Number.parseInt(String(req.query.limit || "1000"), 10);
      const limit = Number.isFinite(requestedLimit) ? Math.max(1, Math.min(1000, requestedLimit)) : 1000;
      const limitedData = formattedData.slice(-limit);
      if (!limitedData.length) return res.status(503).json({ error: "Yahoo OHLCV data unavailable", code: "MARKET_DATA_UNAVAILABLE" });
      res.json(limitedData);
    } catch (e) {
      console.warn("Yahoo klines fetch error:", e);
      res.status(503).json({ error: "Yahoo OHLCV provider failed", code: "MARKET_DATA_UNAVAILABLE" });
    }
  });

  app.get("/api/yahoo/price", async (req, res) => {
    try {
      const symbol = String(req.query.symbol || "XAUUSD=X").toUpperCase();
      if (!/^[A-Z0-9=^._-]{1,20}$/.test(symbol)) return res.status(400).json({ error: "Invalid symbol" });
      const cleanSym = symbol.replace("=X", "").replace("-USD", "");

      // Check TradingView Live WebSocket cache first
      const tvPrice = getTradingViewPrice(cleanSym);
      if (tvPrice && tvPrice.price > 0) {
        return res.json({
          price: tvPrice.price,
          bid: tvPrice.bid,
          ask: tvPrice.ask,
          symbol,
          source: "TRADINGVIEW_WEBSOCKET",
        });
      }

      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=1m&range=1d`;
      const yahooRes = await fetch(url, { signal: AbortSignal.timeout(3000) });
      const data = await yahooRes.json();
      
      const result = data.chart?.result?.[0];
      const meta = result?.meta;
      const price = meta?.regularMarketPrice;
      
      if (!Number.isFinite(price) || price <= 0) return res.status(503).json({ error: "Yahoo quote unavailable", code: "MARKET_DATA_UNAVAILABLE", symbol });
      res.json({ price, symbol, source: "YAHOO" });
    } catch (e) {
      console.warn("Yahoo price fetch error:", e);
      res.status(503).json({ error: "Yahoo quote provider failed", code: "MARKET_DATA_UNAVAILABLE" });
    }
  });

  app.get("/api/live-rates", async (req, res) => {
    try {
      const rate = String(req.query.rate || "XAUUSD").toUpperCase();
      if (!/^[A-Z0-9._=-]{1,20}$/.test(rate)) return res.status(400).json({ error: "Invalid rate symbol" });
      const url = `https://www.live-rates.com/api/price?rate=${encodeURIComponent(rate)}`;
      const apiRes = await fetch(url, { signal: AbortSignal.timeout(3000) });
      const data = await apiRes.json();
      if (!apiRes.ok) return res.status(503).json({ error: "Live Rates provider unavailable" });
      res.json(data);
    } catch (e) {
      console.warn("Live Rates fetch error:", e);
      res.status(503).json({ error: "Live Rates provider failed" });
    }
  });

  app.post("/api/ai/analyze", (req, res) => {
    const body = req.body;
    const hasValidPrice = Number.isFinite(body?.currentPrice) && body.currentPrice > 0;
    const hasSymbol = typeof body?.symbol === "string" && body.symbol.trim().length > 0;
    if (!hasSymbol || !hasValidPrice) {
      return res.status(422).json({
        error: "A valid symbol and live currentPrice are required",
        code: "INVALID_ANALYSIS_INPUT",
      });
    }
    // Do not return a fabricated BUY/SELL. The full OHLCV + indicator pipeline must be
    // connected to the precision engine before this endpoint can issue trade signals.
    return res.status(503).json({
      error: "Signal engine is not yet connected to verified market candles and indicators",
      code: "SIGNAL_ENGINE_DATA_PIPELINE_UNAVAILABLE",
      symbol: body.symbol,
      sourceStatus: "NOT_READY",
    });
  });


  // Forex Factory weekly economic calendar export. No missing values are synthesized.
  let calendarCache: { data: any[]; timestamp: number; providerOk: boolean } = { data: [], timestamp: 0, providerOk: false };
  const CALENDAR_CACHE_TTL_MS = 5 * 60 * 1000;

  app.get("/api/calendar", async (_req, res) => {
    if (process.env.FOREX_FACTORY_LICENSE_CONFIRMED !== "true") {
      return res.status(503).json({
        result: [],
        source: "Forex Factory",
        dataStatus: "OFFLINE",
        code: "FOREX_FACTORY_LICENSE_REQUIRED",
        warning: "Enable the Forex Factory feed only after obtaining written permission for the intended use and redistribution.",
        timestamp: Date.now(),
      });
    }
    const cacheAge = Date.now() - calendarCache.timestamp;
    if (calendarCache.timestamp > 0 && calendarCache.providerOk && cacheAge < CALENDAR_CACHE_TTL_MS) {
      return res.json({
        result: calendarCache.data,
        source: "Forex Factory",
        sourceUrl: FOREX_FACTORY_WEEKLY_FEED_URL,
        coverage: "CURRENT_WEEK_ONLY",
        dataStatus: "LIVE",
        timestamp: calendarCache.timestamp,
        summary: {
          total: calendarCache.data.length,
          released: calendarCache.data.filter((event) => event.isReleased).length,
          upcoming: calendarCache.data.filter((event) => !event.isReleased).length,
          highImpact: calendarCache.data.filter((event) => event.importance === 1).length,
          accurateCount: null,
          inaccurateCount: null,
          accuracyRate: null,
          accuracyNote: "Forex Factory supplies calendar values; this application does not claim trading accuracy from calendar data.",
        },
      });
    }

    try {
      const response = await fetch(FOREX_FACTORY_WEEKLY_FEED_URL, {
        signal: AbortSignal.timeout(8000),
        headers: { Accept: "application/json", "User-Agent": "ZRILL-Factory/1.0 calendar-client" },
      });
      if (!response.ok) throw new Error(`Forex Factory weekly export HTTP ${response.status}`);
      const payload = await response.json();
      const events = normalizeForexFactoryCalendarPayload(payload)
        .map((item) => {
          const enriched = buildComprehensiveEconomicEvent(item, Date.now());
          // Keep the provider's display strings (including %, K, B, etc.) intact.
          return {
            ...enriched,
            forecast: item.forecast ?? "---",
            previous: item.previous ?? "---",
            actual: item.actual ?? null,
            isReleased: item.actual !== null && item.actual !== undefined && item.actual !== "",
            status: item.actual !== null && item.actual !== undefined && item.actual !== "" ? "RELEASED" : "UPCOMING",
            releasedLabel: item.actual !== null && item.actual !== undefined && item.actual !== ""
              ? "HASIL AKTUAL TERSEDIA"
              : (Date.parse(item.date) <= Date.now() ? "WAKTU RILIS LEWAT • AKTUAL BELUM TERSEDIA" : "MENUNGGU RILIS"),
            source: "Forex Factory",
            sourceUrl: item.sourceUrl,
          };
        });
      if (!Array.isArray(payload) || (payload.length > 0 && events.length === 0)) {
        throw new Error("Forex Factory weekly export returned an invalid event payload");
      }
      calendarCache = { data: events, timestamp: Date.now(), providerOk: true };
      return res.json({
        result: events,
        source: "Forex Factory",
        sourceUrl: FOREX_FACTORY_WEEKLY_FEED_URL,
        coverage: "CURRENT_WEEK_ONLY",
        dataStatus: "LIVE",
        timestamp: calendarCache.timestamp,
        summary: {
          total: events.length,
          released: events.filter((event) => event.isReleased).length,
          upcoming: events.filter((event) => !event.isReleased).length,
          highImpact: events.filter((event) => event.importance === 1).length,
          accurateCount: null,
          inaccurateCount: null,
          accuracyRate: null,
          accuracyNote: "Forex Factory supplies calendar values; this application does not claim trading accuracy from calendar data.",
        },
      });
    } catch (error: any) {
      console.warn("Forex Factory calendar request failed:", error?.message);
      const hasLastGoodData = calendarCache.timestamp > 0 && calendarCache.data.length > 0;
      return res.status(hasLastGoodData ? 200 : 503).json({
        result: hasLastGoodData ? calendarCache.data : [],
        dataStatus: hasLastGoodData ? "STALE" : "OFFLINE",
        source: "Forex Factory",
        sourceUrl: FOREX_FACTORY_WEEKLY_FEED_URL,
        coverage: "CURRENT_WEEK_ONLY",
        warning: hasLastGoodData
          ? "Forex Factory is temporarily unavailable; showing the last successfully retrieved weekly schedule as stale data."
          : "Forex Factory is unavailable; no synthetic events were inserted.",
        timestamp: calendarCache.timestamp || Date.now(),
      });
    }
  });

  // Operational health endpoint: exposes data freshness and disabled integrations explicitly.
  app.get("/api/system/health", (_req, res) => {
    const quotes = getAllTradingViewPrices();
    const quoteAges = Object.values(quotes).map((quote) => ({
      symbol: quote.symbol,
      ageMs: Math.max(0, Date.now() - quote.updatedAt),
    }));
    const calendarFresh = calendarCache.providerOk && Date.now() - calendarCache.timestamp < 10 * 60 * 1000;
    const tradingViewStatus = quoteAges.length > 0 ? "LIVE" : "OFFLINE";
    const biQuoteAgeMs = biQuoteQuoteHealth.ageMs === null ? null : biQuoteQuoteHealth.ageMs + Math.max(0, Date.now() - biQuoteQuoteHealth.checkedAt);
    const primaryMarketDataStatus = biQuoteQuoteHealth.status === "LIVE" && biQuoteAgeMs !== null && biQuoteAgeMs <= 30_000
      ? "LIVE"
      : biQuoteQuoteHealth.status === "CLOSED" ? "CLOSED" : biQuoteQuoteHealth.status === "STALE" ? "STALE" : "OFFLINE";
    const calendarStatus = calendarFresh ? "LIVE" : "UNKNOWN_OR_OFFLINE";
    const degraded = primaryMarketDataStatus !== "LIVE" || calendarStatus !== "LIVE";

    res.status(200).json({
      status: degraded ? "DEGRADED" : "OPERATIONAL",
      timestamp: new Date().toISOString(),
      uptimeSeconds: Math.floor(process.uptime()),
      services: {
        tradingViewQuotes: { status: tradingViewStatus, quotes: quoteAges },
        economicCalendar: { status: calendarStatus, provider: "FOREX_FACTORY", cachedEvents: calendarCache.data.length, coverage: "CURRENT_WEEK_ONLY" },
        signalEngine: { status: "DISABLED_UNTIL_VERIFIED_INPUT_PIPELINE" },
        tradingViewMcp: { status: "PARTIAL_QUOTE_ONLY" },
        institutionalMacroFeeds: { status: "NOT_CONNECTED" },
        primaryMarketData: { provider: "BIQUOTE", status: primaryMarketDataStatus, symbol: biQuoteQuoteHealth.symbol, ageMs: biQuoteAgeMs },
      },
    });
  });

  // Real-time Financial News & Macro Intelligence API
  app.get("/api/news/realtime", async (_req, res) => {
    const cryptoNews: any[] = [];
    const forexNews: any[] = [];
    const providerStatus: Record<string, string> = { crypto: "OFFLINE", forex: "OFFLINE" };

    try {
      const response = await fetch("https://min-api.cryptocompare.com/data/v2/news/?lang=EN", {
        signal: AbortSignal.timeout(5000),
      });
      if (response.ok) {
        const payload = await response.json();
        if (Array.isArray(payload?.Data)) {
          cryptoNews.push(...payload.Data.slice(0, 20).map((item: any) => {
            const text = `${item.title || ""} ${item.body || ""}`.toLowerCase();
            const bullish = /bull|soar|gain|surge|rally|inflow|approval/.test(text);
            const bearish = /bear|drop|fall|crash|plunge|ban|outflow/.test(text);
            return {
              id: String(item.id || item.url || `${item.published_on}-${item.title}`),
              title: item.title || "Untitled",
              source: item.source_info?.name || "CryptoCompare",
              url: item.url || null,
              publishedAt: Number(item.published_on || 0) * 1000,
              body: String(item.body || item.title || "").slice(0, 500),
              category: "CRYPTO",
              sentiment: bullish === bearish ? "NEUTRAL" : bullish ? "BULLISH" : "BEARISH",
            };
          }));
          providerStatus.crypto = "LIVE";
        }
      }
    } catch (error: any) {
      providerStatus.crypto = "OFFLINE";
    }

    try {
      const rssUrl = "https://www.investing.com/rss/news_25.rss";
      const response = await fetch(`https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(rssUrl)}`, {
        headers: { "User-Agent": "Mozilla/5.0" },
        signal: AbortSignal.timeout(5000),
      });
      if (response.ok) {
        const payload = await response.json();
        if (Array.isArray(payload?.items)) {
          forexNews.push(...payload.items.slice(0, 20).map((item: any, index: number) => {
            const headline = String(item.title || "");
            const text = `${headline} ${item.description || ""}`.toLowerCase();
            const bullishUsd = /fed hawkish|rate hike|inflation accelerat|dollar gain|jobs strong/.test(text);
            const bearishUsd = /rate cut|fed dovish|inflation cool|dollar fall|recession/.test(text);
            return {
              id: `fx-${item.guid || item.link || index}`,
              title: headline,
              source: item.author || "Investing.com RSS",
              url: item.link || null,
              publishedAt: item.pubDate ? new Date(item.pubDate).getTime() : null,
              body: String(item.description || headline).replace(/<[^>]*>/g, "").slice(0, 500),
              category: "FOREX",
              sentiment: bullishUsd === bearishUsd ? "NEUTRAL" : bullishUsd ? "USD_BULLISH" : "USD_BEARISH",
            };
          }));
          providerStatus.forex = "LIVE";
        }
      }
    } catch (error: any) {
      providerStatus.forex = "OFFLINE";
    }

    return res.json({
      cryptoNews,
      forexNews,
      providerStatus,
      dataStatus: providerStatus.crypto === "LIVE" || providerStatus.forex === "LIVE" ? "LIVE" : "OFFLINE",
      sentiment: {
        usdSentiment: "UNAVAILABLE",
        xauImpact: "UNAVAILABLE",
        btcImpact: "UNAVAILABLE",
        summary: "Sentimen belum dihitung: diperlukan data makro terverifikasi dan model klasifikasi yang tervalidasi.",
      },
      macroIndicators: null,
      institutionalFlows: null,
      timestamp: Date.now(),
    });
  });

  const authRateBuckets = new Map<string, { count: number; resetAt: number }>();
  app.use("/api/auth", (req, res, next) => {
    const key = req.ip || req.socket.remoteAddress || "unknown";
    const now = Date.now();
    if (authRateBuckets.size > 10000) {
      for (const [ip, entry] of authRateBuckets) if (entry.resetAt <= now) authRateBuckets.delete(ip);
    }
    const bucket = authRateBuckets.get(key);
    if (!bucket || bucket.resetAt <= now) {
      authRateBuckets.set(key, { count: 1, resetAt: now + 15 * 60 * 1000 });
      return next();
    }
    bucket.count += 1;
    if (bucket.count > 10) return res.status(429).json({ error: "Terlalu banyak percobaan. Coba lagi nanti." });
    return next();
  });

  app.post("/api/auth/verify-membership", (req, res) => {
    const code = typeof req.body?.code === "string" ? req.body.code.trim() : "";
    if (!code || code.length > 128) {
      return res.status(400).json({ error: "Kode membership tidak valid" });
    }
    const configured = (process.env.ZRILL_MEMBERSHIP_CODES || "")
      .split(",").map((entry) => entry.trim()).filter(Boolean);
    if (!configured.length) {
      return res.status(503).json({ error: "Membership verification is not configured" });
    }
    const match = configured.map((entry) => {
      const separator = entry.indexOf(":");
      if (separator <= 0) return null;
      const candidateCode = entry.slice(separator + 1);
      const supplied = Buffer.from(code);
      const expected = Buffer.from(candidateCode);
      const matches = supplied.length === expected.length && timingSafeEqual(supplied, expected);
      return matches ? { plan: entry.slice(0, separator).toUpperCase() } : null;
    }).find(Boolean);
    if (!match || !["WEEKLY", "BIWEEKLY", "MONTHLY", "YEARLY"].includes(match.plan)) {
      return res.status(401).json({ error: "Kode membership tidak valid" });
    }
    return res.json({ plan: match.plan });
  });

  const overrideAttempts = new Map<string, { count: number; resetAt: number }>();
  app.post("/api/override", (req, res) => {
    const ip = req.ip || req.socket.remoteAddress || "unknown";
    const now = Date.now();
    const attempt = overrideAttempts.get(ip);
    if (!attempt || attempt.resetAt <= now) overrideAttempts.set(ip, { count: 1, resetAt: now + 15 * 60 * 1000 });
    else {
      attempt.count += 1;
      if (attempt.count > 5) return res.status(429).json({ error: "Terlalu banyak percobaan override. Coba lagi nanti." });
    }
    const code = typeof req.body?.code === "string" ? req.body.code : "";
    const expected = process.env.ZRILL_OVERRIDE_CODE;
    if (!expected) return res.status(503).json({ error: "Admin override is not configured" });
    const supplied = Buffer.from(code);
    const configuredSecret = Buffer.from(expected);
    if (supplied.length === configuredSecret.length && timingSafeEqual(supplied, configuredSecret)) {
      return res.json({ success: true });
    }
    return res.status(401).json({ error: "Incorrect Code" });
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
