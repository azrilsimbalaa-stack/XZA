const test = require('node:test');
const assert = require('node:assert/strict');
const { isFreshMarketQuote, MAX_QUOTE_AGE_MS } = require('../.test-dist/server/marketDataPolicy.js');

test('accepts a positive quote within the freshness window', () => {
  assert.equal(isFreshMarketQuote({ price: 2000, updatedAt: 90_000 }, 100_000), true);
});

test('rejects a stale quote instead of fabricating a replacement', () => {
  assert.equal(isFreshMarketQuote({ price: 2000, updatedAt: 1 }, 100_000), false);
});

test('rejects a future-dated quote', () => {
  assert.equal(isFreshMarketQuote({ price: 2000, updatedAt: 100_001 }, 100_000), false);
});

test('rejects zero, negative, and non-finite prices', () => {
  for (const price of [0, -1, NaN, Infinity]) {
    assert.equal(isFreshMarketQuote({ price, updatedAt: 100_000 }, 100_000), false);
  }
});

test('uses the configured maximum quote age inclusively', () => {
  assert.equal(isFreshMarketQuote({ price: 2000, updatedAt: 100_000 - MAX_QUOTE_AGE_MS }, 100_000), true);
  assert.equal(isFreshMarketQuote({ price: 2000, updatedAt: 100_000 - MAX_QUOTE_AGE_MS - 1 }, 100_000), false);
});

const { getSignalBlockReasons, isTradeSetupAllowed } = require('../.test-dist/services/signalSafetyPolicy.js');

test('blocks sideways markets even when confluence is high', () => {
  const checks = { isSideways: true, confluenceScore: 10, newsBlocked: false, minimumRiskRewardMet: true, directionConfirmed: true };
  assert.equal(isTradeSetupAllowed(checks), false);
  assert.match(getSignalBlockReasons(checks).join(' '), /sideways/);
});

test('blocks setups below the 7/10 confluence threshold', () => {
  assert.equal(isTradeSetupAllowed({ isSideways: false, confluenceScore: 6, newsBlocked: false, minimumRiskRewardMet: true, directionConfirmed: true }), false);
});

test('blocks high-impact news, insufficient RR, and unconfirmed direction', () => {
  const reasons = getSignalBlockReasons({ isSideways: false, confluenceScore: 9, newsBlocked: true, minimumRiskRewardMet: false, directionConfirmed: false });
  assert.equal(reasons.length, 3);
});

test('allows a setup only when every safety condition passes', () => {
  assert.equal(isTradeSetupAllowed({ isSideways: false, confluenceScore: 7, newsBlocked: false, minimumRiskRewardMet: true, directionConfirmed: true }), true);
});

const { buildComprehensiveEconomicEvent } = require('../.test-dist/services/institutionalCalendarEngine.js');

test('calendar event with missing forecast inputs stays neutral and uncalibrated', () => {
  const event = buildComprehensiveEconomicEvent({ id: 'no-inputs', title: 'US Economic Release', currency: 'USD', date: new Date(Date.now() + 60_000).toISOString(), importance: 1, forecast: '---', previous: '---', actual: null });
  assert.equal(event.hasDirectionalInputs, false);
  assert.equal(event.isPredictionCorrect, null);
  assert.equal(event.prediction.direction, 'WAITING');
  assert.equal(event.prediction.confidence, 0);
  assert.equal(event.estimatedActual, 'Belum tersedia');
  assert.equal(event.spikePrediction.spikeType, 'UNAVAILABLE');
  assert.equal(event.spikePrediction.spikeProbability, 0);
  assert.equal(event.isModelCalibrated, false);
});

test('calendar scenario evaluation does not invent profit or pips', () => {
  const event = buildComprehensiveEconomicEvent({ id: 'released-event', title: 'US CPI', currency: 'USD', date: new Date(Date.now() - 60_000).toISOString(), importance: 1, forecast: '3.1', previous: '3.2', actual: '3.0' });
  assert.equal(typeof event.isPredictionCorrect, 'boolean');
  assert.equal(event.pipsGain.includes('Tidak dihitung'), true);
  assert.equal(event.prediction.confidence, 0);
  assert.equal(event.marketOutcome.accuracyScore, 0);
  assert.equal(event.prediction.peganganKuat.anchorScore, 0);
  assert.equal(event.prediction.peganganKuat.historicalPillar.winRateStat, 'NOT MEASURED');
  assert.equal(event.prediction.peganganKuat.riskGuardPillar.invalidationLevelPips, 0);
});

const { computeRealtimeMacroPulse, computeRealtimeMacroSMCFusion } = require('../.test-dist/services/realtimeFundamentalStreamEngine.js');

test('macro pulse never reports fabricated DXY/yield data as live', () => {
  const pulse = computeRealtimeMacroPulse('XAUUSD', 2300);
  assert.equal(pulse.isLiveStreaming, false);
  assert.equal(pulse.dxyPulse.liveValue, 0);
  assert.equal(pulse.us10YYieldPulse.liveYieldPct, 0);
  assert.equal(pulse.dominantMacroDirection, 'UNAVAILABLE');
});

test('SMC fusion refuses to invent order blocks, FVG, or sniper entries', () => {
  const fusion = computeRealtimeMacroSMCFusion({ symbol: { id: 'XAUUSD' }, currentPrice: 2300, timeframe: 'M5' });
  assert.equal(fusion.dataStatus, 'UNAVAILABLE');
  assert.equal(fusion.direction, 'WAITING');
  assert.equal(fusion.orderBlock.type, 'UNAVAILABLE');
  assert.equal(fusion.fairValueGap.type, 'UNAVAILABLE');
  assert.equal(fusion.sniperBlueprint.sniperEntryPrice, 0);
});


const { computeAssetNewsIntelligence } = require('../.test-dist/services/assetNewsIntelligenceService.js');

test('news intelligence stays neutral when no provider headlines are connected', () => {
  const news = computeAssetNewsIntelligence('XAUUSD');
  assert.equal(news.totalArticles, 0);
  assert.equal(news.dominantBias, 'NEUTRAL');
  assert.equal(news.sentimentScore, 0);
  assert.match(news.actionableSignalVerdict, /belum terhubung|unavailable|belum tersedia/i);
});

const { computeZrillV5Core, generatePrecisionSignal } = require('../.test-dist/services/precisionSignalEngine.js');

test('precision core rejects missing measured indicators instead of inventing ATR and EMA values', () => {
  assert.throws(() => computeZrillV5Core({
    symbol: { id: 'XAUUSD' }, timeframe: { id: 'M5' }, currentPrice: 2300,
    isUp: true, indicators: {}, recentCandles: [], isBtc: false,
  }), /VERIFIED_INDICATORS_REQUIRED/);
});

test('precision signal rejects a missing live quote instead of substituting a default price', () => {
  assert.throws(() => generatePrecisionSignal({
    symbol: { id: 'XAUUSD' }, currentPrice: { bid: 0, ask: 0 },
  }), /LIVE_PRICE_REQUIRED/);
});


const { normalizeBiQuoteTick, normalizeBiQuoteBars } = require('../.test-dist/server/biquoteService.js');

test('BiQuote quote is live only when market is open and the timestamp is fresh', () => {
  const now = Date.parse('2026-11-09T12:00:00Z');
  const fresh = normalizeBiQuoteTick({ symbol: 'XAUUSD', mid: 4000, bid: 3999.9, ask: 4000.1, timestamp: '2026-11-09T11:59:45Z', quoteAgeSeconds: 15, marketState: 'open', stale: false }, now);
  assert.equal(fresh.dataStatus, 'LIVE');
  const old = normalizeBiQuoteTick({ symbol: 'XAUUSD', mid: 4000, timestamp: '2026-11-09T11:58:00Z', quoteAgeSeconds: 120, marketState: 'open', stale: false }, now);
  assert.equal(old.dataStatus, 'STALE');
  const closed = normalizeBiQuoteTick({ symbol: 'XAUUSD', mid: 4000, timestamp: '2026-11-09T11:59:45Z', quoteAgeSeconds: 15, marketState: 'closed', stale: false }, now);
  assert.equal(closed.dataStatus, 'CLOSED');
  const unknown = normalizeBiQuoteTick({ symbol: 'XAUUSD', mid: 4000, timestamp: '2026-11-09T11:59:45Z', quoteAgeSeconds: 15 }, now);
  assert.equal(unknown.dataStatus, 'STALE');
});

test('BiQuote quote rejects future timestamps and invalid mid prices', () => {
  const now = Date.parse('2026-11-09T12:00:00Z');
  assert.equal(normalizeBiQuoteTick({ symbol: 'XAUUSD', mid: 0, timestamp: '2026-11-09T11:59:00Z' }, now), null);
  assert.equal(normalizeBiQuoteTick({ symbol: 'XAUUSD', mid: 4000, timestamp: '2026-11-09T12:01:00Z' }, now), null);
});

test('BiQuote OHLC normalizer rejects malformed candles and sorts valid bars', () => {
  const bars = normalizeBiQuoteBars({ bars: [
    { openTime: '2026-11-09T11:00:00Z', open: 10, high: 12, low: 9, close: 11, volume: 0, tickVolume: 2 },
    { openTime: '2026-11-09T10:00:00Z', open: 10, high: 9, low: 8, close: 11, volume: 0, tickVolume: 1 },
  ] });
  assert.equal(bars.length, 1);
  assert.equal(bars[0].open, 10);
});


const { normalizeForexFactoryCalendarEvent, FOREX_FACTORY_WEEKLY_FEED_URL } = require('../.test-dist/server/forexFactoryService.js');

test('Forex Factory weekly event normalization preserves source values and timezone', () => {
  const event = normalizeForexFactoryCalendarEvent({
    title: 'CPI m/m', country: 'USD', date: '2026-11-10T08:30:00-05:00',
    impact: 'High', forecast: '0.3%', previous: '0.4%', actual: '',
  });
  assert.equal(event.currency, 'USD');
  assert.equal(event.title, 'CPI m/m');
  assert.equal(event.importance, 1);
  assert.equal(event.forecast, '0.3%');
  assert.equal(event.previous, '0.4%');
  assert.equal(event.actual, null);
  assert.equal(event.date, '2026-11-10T13:30:00.000Z');
  assert.match(event.source, /Forex Factory/);
  assert.equal(event.timeMode, 'exact');
});

test('Forex Factory event normalization rejects incomplete or invalid events', () => {
  assert.equal(normalizeForexFactoryCalendarEvent({ title: 'CPI', country: 'USD', date: 'invalid', impact: 'High' }), null);
  assert.equal(normalizeForexFactoryCalendarEvent({ title: '', country: 'USD', date: '2026-11-10T13:30:00Z', impact: 'High' }), null);
});

test('Forex Factory weekly feed URL points to the Fair Economy export', () => {
  assert.equal(FOREX_FACTORY_WEEKLY_FEED_URL, 'https://nfs.faireconomy.media/ff_calendar_thisweek.json');
});
