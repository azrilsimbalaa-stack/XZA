import test from 'node:test';
import assert from 'node:assert/strict';
import { getTradingViewPrice } from '../src/server/tradingviewService.ts';

test('does not fabricate a quote when the live feed has no price', () => {
  assert.equal(getTradingViewPrice('XAUUSD'), null);
  assert.equal(getTradingViewPrice('BTCUSD'), null);
});

test('does not invent prices for unsupported symbols', () => {
  assert.equal(getTradingViewPrice('UNKNOWNPAIR'), null);
});
