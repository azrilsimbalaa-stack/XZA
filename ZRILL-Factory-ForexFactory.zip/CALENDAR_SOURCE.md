# Economic calendar source: Forex Factory

ZRILL Factory's `/api/calendar` endpoint uses the Forex Factory weekly JSON export:

- Feed: https://nfs.faireconomy.media/ff_calendar_thisweek.json
- Human-readable calendar: https://www.forexfactory.com/calendar
- Coverage: the currently published week only.
- Refresh policy: server cache for 5 minutes; frontend polling every 5 minutes.
- Time handling: source timestamps include an offset and are normalized to UTC; the UI displays them in WITA (`Asia/Makassar`).
- Data integrity: event title, currency, impact, forecast, previous, and timestamp are taken from the feed. Empty values remain null/blank. No synthetic events or actual values are generated.
- Actual values: the current weekly export may omit `actual`; ZRILL therefore leaves Actual unavailable rather than inferring it from the clock or forecast.
- Failure handling: if the upstream feed fails after a successful fetch, the last good schedule may be returned as `STALE`, not `LIVE`. With no cached schedule, the API returns `OFFLINE`.

## Permission requirement

Forex Factory's notices state that copying, republication, and redistribution of calendar content are restricted without prior written consent. ZRILL disables this endpoint by default. Set `FOREX_FACTORY_LICENSE_CONFIRMED=true` only after obtaining written permission that covers the intended use, including serving the calendar to ZRILL users. The application does not treat public reachability of the weekly export as permission to redistribute its contents.
