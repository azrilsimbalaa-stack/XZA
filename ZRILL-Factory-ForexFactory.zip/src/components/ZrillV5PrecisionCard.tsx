import React, { useState } from "react";
import {
  ZrillV5CoreAnalysis,
  ZrillV5ConfluencePillar,
} from "../services/precisionSignalEngine";
import {
  ShieldCheck,
  Zap,
  TrendingUp,
  TrendingDown,
  Activity,
  Target,
  Layers,
  Copy,
  Check,
  AlertTriangle,
  Clock,
  Flame,
  Award,
  Radio,
  Sliders,
  Sparkles,
} from "lucide-react";

interface ZrillV5PrecisionCardProps {
  zrillCore?: ZrillV5CoreAnalysis;
  symbol: string;
  isBuy: boolean;
  currentPrice: number;
  timeframe: string;
  copyToClipboard?: (text: string) => Promise<boolean>;
}

// Ultra-safe numeric formatting helper preventing any .toFixed runtime errors
const safeNum = (val: any, fallback = 0): number => {
  if (typeof val === "number" && !isNaN(val)) return val;
  if (typeof val === "object" && val !== null) {
    if (typeof val.adx === "number" && !isNaN(val.adx)) return val.adx;
    if (typeof val.value === "number" && !isNaN(val.value)) return val.value;
  }
  const parsed = Number(val);
  return !isNaN(parsed) ? parsed : fallback;
};

export const ZrillV5PrecisionCard: React.FC<ZrillV5PrecisionCardProps> = ({
  zrillCore,
  symbol,
  isBuy,
  currentPrice,
  timeframe,
  copyToClipboard,
}) => {
  const [copied, setCopied] = useState(false);
  const [showPillarDetails, setShowPillarDetails] = useState(true);

  if (!zrillCore) return null;

  const {
    confluenceScore,
    confluenceRating,
    ratingBadgeColor,
    ratingLabel,
    winRateEstimatePct,
    signalType,
    trendDirection,
    trendLabel,
    newsLabel,
    fibonacci,
    emaFilter,
    marketStructure,
    momentum,
    volatilityRisk,
    usdNewsFilter,
    multiTimeframe,
    pillars,
    formattedOutputSignalText,
    reasonSummary,
  } = zrillCore;

  const handleCopy = async () => {
    const text = formattedOutputSignalText;
    if (copyToClipboard) {
      const ok = await copyToClipboard(text);
      if (ok) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2200);
      }
    } else {
      try {
        await navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2200);
      } catch (e) {}
    }
  };

  const isSuperStrong = confluenceScore >= 9;
  const isStrong = confluenceScore >= 7 && confluenceScore < 9;
  const isWaiting = confluenceScore < 7 || signalType === "WAITING";

  return (
    <div
      id="zrill-v5-precision-card"
      className="bg-slate-900/95 border border-amber-500/30 rounded-xl p-5 shadow-2xl backdrop-blur-md text-slate-100 relative overflow-hidden my-4"
    >
      {/* Background Subtle Glow */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none -ml-20 -mb-20" />

      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4 mb-4 relative z-10">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-gradient-to-br from-amber-500/20 to-orange-600/20 border border-amber-500/40 text-amber-400 shadow-inner">
            <Zap className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-amber-500/20 border border-amber-500/40 text-amber-300 uppercase tracking-wide">
                ZRILL AI v5.0
              </span>
              <span className="text-xs font-medium px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                🎯 HIGH WINRATE CORE (≥70% - 85%+)
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-extrabold text-white tracking-tight mt-1 flex items-center gap-1.5">
              Precision Trading System
              <span className="text-xs font-normal text-slate-400">({symbol} • {timeframe})</span>
            </h3>
          </div>
        </div>

        {/* Confluence score — not a statistical win rate */}
        <div className="flex items-center gap-2">
          <div className="text-right">
            <div className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
              Skor Konfluensi
            </div>
            <div className="text-lg font-black text-emerald-400">
              {confluenceScore}/10
            </div>
          </div>
          <div
            className={`px-3 py-1.5 rounded-lg border font-bold text-xs flex items-center gap-1.5 shadow-sm ${
              ratingBadgeColor === "emerald"
                ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-300"
                : ratingBadgeColor === "amber"
                ? "bg-amber-500/20 border-amber-500/40 text-amber-300"
                : "bg-rose-500/20 border-rose-500/40 text-rose-300"
            }`}
          >
            <Award className="w-4 h-4" />
            <span>{ratingLabel}</span>
          </div>
        </div>
      </div>

      {/* Signal Verdict Banner */}
      <div
        className={`p-3.5 rounded-xl border mb-5 flex flex-wrap items-center justify-between gap-3 relative z-10 ${
          signalType === "BUY NOW"
            ? "bg-emerald-950/40 border-emerald-500/50 text-emerald-100"
            : signalType === "SELL NOW"
            ? "bg-rose-950/40 border-rose-500/50 text-rose-100"
            : signalType === "BUY LIMIT"
            ? "bg-cyan-950/40 border-cyan-500/50 text-cyan-100"
            : signalType === "SELL LIMIT"
            ? "bg-amber-950/40 border-amber-500/50 text-amber-100"
            : "bg-slate-800/60 border-slate-700 text-slate-300"
        }`}
      >
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-black/30 border border-white/10 font-black text-sm">
            {signalType === "BUY NOW" && <TrendingUp className="w-5 h-5 text-emerald-400" />}
            {signalType === "SELL NOW" && <TrendingDown className="w-5 h-5 text-rose-400" />}
            {signalType === "BUY LIMIT" && <Target className="w-5 h-5 text-cyan-400" />}
            {signalType === "SELL LIMIT" && <Target className="w-5 h-5 text-amber-400" />}
            {signalType === "WAITING" && <Clock className="w-5 h-5 text-slate-400" />}
          </div>
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider opacity-75">
              Rekomendasi Eksekusi Zrill AI:
            </div>
            <div className="text-base font-extrabold flex items-center gap-2">
              <span>{signalType}</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-black/40 border border-white/10 font-medium">
                {trendLabel}
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-black/40 border border-white/10 font-medium">
                USD: {newsLabel}
              </span>
              {zrillCore?.candleVolLabel && (
                <span className={`text-xs px-2 py-0.5 rounded-full font-bold flex items-center gap-1 border ${
                  zrillCore.candleVolSignal === "VOLUME_CONTINUATION"
                    ? "bg-emerald-500/25 text-emerald-300 border-emerald-400/40 animate-pulse"
                    : zrillCore.candleVolSignal === "VOLUME_REVERSAL"
                    ? "bg-purple-500/25 text-purple-200 border-purple-400/40 animate-pulse"
                    : "bg-slate-700/50 text-slate-300 border-slate-600/40"
                }`}>
                  {zrillCore.candleVolLabel}
                </span>
              )}
            </div>
          </div>
        </div>

        <button
          id="copy-zrill-v5-signal-btn"
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-bold transition-all active:scale-95"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-300">Tersalin!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Salin Sinyal</span>
            </>
          )}
        </button>
      </div>

      {/* Trading Parameter Cockpit: Ditentukan Sepenuhnya oleh ZRILL AI */}
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 border border-amber-500/40 rounded-xl p-4 mb-5 relative z-10 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3 pb-2.5 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-black uppercase text-amber-300 tracking-wider">
              TANGGUNG JAWAB PENUH ZRILL AI — LEVEL EKSEKUSI PRESISI
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 font-bold">
              R:R {zrillCore.volatilityRisk?.riskRewardRatio || "1:2.0"}
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold">
              Lot Rec: {safeNum(zrillCore.recommendedLot, 0.1).toFixed(2)}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
          {/* Entry */}
          <div className="p-2.5 rounded-lg bg-slate-900/90 border border-amber-500/30">
            <div className="text-[10px] uppercase font-bold text-amber-400">ENTRY LEVEL</div>
            <div className="text-sm sm:text-base font-black text-white font-mono mt-0.5">
              ${safeNum(zrillCore.entryPrice || currentPrice).toFixed(2)}
            </div>
            <div className="text-[9px] text-slate-400 mt-0.5">{zrillCore.signalType}</div>
          </div>

          {/* Stop Loss */}
          <div className="p-2.5 rounded-lg bg-slate-900/90 border border-rose-500/30">
            <div className="text-[10px] uppercase font-bold text-rose-400">STOP LOSS</div>
            <div className="text-sm sm:text-base font-black text-rose-300 font-mono mt-0.5">
              ${safeNum(zrillCore.slPrice).toFixed(2)}
            </div>
            <div className="text-[9px] text-rose-400/80 mt-0.5">
              {safeNum(zrillCore.slPipsDistance, 25)} pips risiko
            </div>
          </div>

          {/* TP 1 */}
          <div className="p-2.5 rounded-lg bg-slate-900/90 border border-emerald-500/30">
            <div className="text-[10px] uppercase font-bold text-emerald-400">TP 1 (1:1)</div>
            <div className="text-sm sm:text-base font-black text-emerald-300 font-mono mt-0.5">
              ${safeNum(zrillCore.tp1Price).toFixed(2)}
            </div>
            <div className="text-[9px] text-slate-400 mt-0.5">Kunci 50% Profit</div>
          </div>

          {/* TP 2 (Target Utama) */}
          <div className="p-2.5 rounded-lg bg-slate-900/90 border border-cyan-500/40 shadow-[0_0_15px_rgba(6,182,212,0.15)]">
            <div className="text-[10px] uppercase font-bold text-cyan-400">TP 2 (TARGET UTAMA)</div>
            <div className="text-sm sm:text-base font-black text-cyan-300 font-mono mt-0.5">
              ${safeNum(zrillCore.tp2Price || zrillCore.tpPrice).toFixed(2)}
            </div>
            <div className="text-[9px] text-cyan-400/90 mt-0.5 font-semibold">Pasang BEP</div>
          </div>

          {/* TP 3 */}
          <div className="p-2.5 rounded-lg bg-slate-900/90 border border-purple-500/30 col-span-2 sm:col-span-1">
            <div className="text-[10px] uppercase font-bold text-purple-400">TP 3 (RUNNER 1:3+)</div>
            <div className="text-sm sm:text-base font-black text-purple-300 font-mono mt-0.5">
              ${safeNum(zrillCore.tp3Price).toFixed(2)}
            </div>
            <div className="text-[9px] text-slate-400 mt-0.5">Maksimal Runner</div>
          </div>
        </div>
      </div>

      {/* 10/10 Confluence Scorecard Meter */}
      <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 mb-5 relative z-10">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-slate-200 uppercase tracking-wide">
              Sistem Skor Konfluensi (Syarat Minimum: 7/10)
            </span>
          </div>
          <div className="text-sm font-black text-amber-400">
            {confluenceScore} <span className="text-xs font-normal text-slate-400">/ 10 Pilar Terpenuhi</span>
          </div>
        </div>

        {/* Visual Progress Bar */}
        <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden mb-2 relative">
          {/* Minimum 7/10 Marker Indicator */}
          <div
            className="absolute top-0 bottom-0 w-0.5 bg-amber-400 z-10"
            style={{ left: "70%" }}
            title="Ambang Batas Minimum (7/10)"
          />
          <div
            className={`h-full transition-all duration-700 rounded-full ${
              confluenceScore >= 9
                ? "bg-gradient-to-r from-emerald-500 to-teal-400"
                : confluenceScore >= 7
                ? "bg-gradient-to-r from-amber-500 to-emerald-500"
                : "bg-gradient-to-r from-rose-500 to-amber-500"
            }`}
            style={{ width: `${(confluenceScore / 10) * 100}%` }}
          />
        </div>

        <div className="flex justify-between items-center text-[10px] text-slate-400">
          <span>0 (Ditolak)</span>
          <span className="text-amber-400 font-semibold">Min. 7/10 (Sinyal Keluar)</span>
          <span className="text-emerald-400 font-semibold">≥9/10 (Super Kuat)</span>
        </div>

        {/* Toggle Pillars Detail */}
        <div className="mt-3 flex justify-end">
          <button
            onClick={() => setShowPillarDetails(!showPillarDetails)}
            className="text-[11px] font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1 transition-colors"
          >
            <Sliders className="w-3 h-3" />
            <span>{showPillarDetails ? "Sembunyikan Rincian Pilar" : "Tampilkan 10 Rincian Pilar"}</span>
          </button>
        </div>

        {/* Detailed 10 Pillars Grid */}
        {showPillarDetails && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-800/80">
            {pillars.map((pillar) => (
              <div
                key={pillar.id}
                className={`p-2.5 rounded-lg border text-xs flex items-start gap-2.5 transition-all ${
                  pillar.passed
                    ? "bg-emerald-950/20 border-emerald-500/30 text-slate-200"
                    : "bg-slate-900/40 border-slate-800 text-slate-400"
                }`}
              >
                <div
                  className={`p-1 rounded font-bold text-[10px] shrink-0 mt-0.5 ${
                    pillar.passed
                      ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"
                      : "bg-slate-800 text-slate-500 border border-slate-700"
                  }`}
                >
                  {pillar.passed ? <Check className="w-3 h-3" /> : <span className="px-0.5">✕</span>}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className={`font-bold ${pillar.passed ? "text-emerald-300" : "text-slate-300"}`}>
                      #{pillar.id}. {pillar.title}
                    </span>
                    <span className="text-[9px] font-medium px-1.5 py-0.2 rounded bg-white/5 text-amber-400 shrink-0">
                      {pillar.weightBonus}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                    {pillar.valueDescription}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 4 Core Pillars Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-5 relative z-10">
        {/* Card 1: Fibonacci Golden Ratio */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>1. FIBONACCI GOLDEN RATIO (90%+)</span>
            </div>
            {fibonacci.isUntouchedArea && (
              <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                ⚡ UNTOUCHED (WIN RATE 2×)
              </span>
            )}
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px] mt-1">
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 block text-[9px]">2.618 Sniper Ekstensi</span>
              <span className="font-bold text-amber-300">${fibonacci.zone2618_Sniper}</span>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 block text-[9px]">0.618 Retest Utama</span>
              <span className="font-bold text-emerald-300">${fibonacci.zone0618_Retest}</span>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 block text-[9px]">0.786 Retest Dalam</span>
              <span className="font-bold text-slate-200">${fibonacci.zone0786_Deep}</span>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 block text-[9px]">1.618 TP Ekstensi</span>
              <span className="font-bold text-cyan-300">${fibonacci.zone1618_Extension}</span>
            </div>
          </div>
          <div className="text-[10px] text-slate-400 mt-2 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>{fibonacci.statusDescription}</span>
          </div>
        </div>

        {/* Card 2: EMA 50 + EMA 200 Filter */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-blue-400">
              <Activity className="w-3.5 h-3.5" />
              <span>2. EMA 50 (Biru) & EMA 200 (Merah)</span>
            </div>
            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/40">
              Filter Konfluensi +35%
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px] mt-1">
            <div className="p-2 rounded bg-slate-900/80 border border-blue-900/40">
              <span className="text-blue-300 block text-[9px] flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-blue-500" /> EMA 50 (Biru)
              </span>
              <span className="font-bold text-blue-200">${safeNum(emaFilter.ema50).toFixed(2)}</span>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-rose-900/40">
              <span className="text-rose-300 block text-[9px] flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-rose-500" /> EMA 200 (Merah)
              </span>
              <span className="font-bold text-rose-200">${safeNum(emaFilter.ema200).toFixed(2)}</span>
            </div>
          </div>
          <div className="text-[10px] text-slate-300 mt-2 flex items-center justify-between">
            <span className="font-medium">
              Status Tren:{" "}
              <strong className={emaFilter.trendState === "UPTREND_KUAT" ? "text-emerald-400" : emaFilter.trendState === "DOWNTREND_KUAT" ? "text-rose-400" : "text-amber-400"}>
                {emaFilter.trendState}
              </strong>
            </span>
            <span className="text-[9px] text-slate-400">
              {emaFilter.crossStatus !== "NEUTRAL" ? emaFilter.crossStatus : "Trend Aligned"}
            </span>
          </div>
        </div>

        {/* Card 3: Momentum (RSI + MACD + ADX) */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
              <Flame className="w-3.5 h-3.5" />
              <span>3. MOMENTUM (RSI + MACD + ADX)</span>
            </div>
            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              Konfirmasi Presisi
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-[11px] mt-1">
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800 text-center">
              <span className="text-slate-400 block text-[9px]">ADX(14)</span>
              <span className="font-bold text-amber-300">{safeNum(momentum.adxValue, 25).toFixed(1)}</span>
              <span className="text-[8px] block text-slate-400">{momentum.adxRegime}</span>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800 text-center">
              <span className="text-slate-400 block text-[9px]">RSI(14)</span>
              <span className="font-bold text-emerald-300">{safeNum(momentum.rsi14, 50).toFixed(1)}</span>
              <span className="text-[8px] block text-slate-400">{momentum.rsiStatus}</span>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800 text-center">
              <span className="text-slate-400 block text-[9px]">MACD Hist</span>
              <span className={`font-bold ${safeNum(momentum.macdHistogram) >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                {safeNum(momentum.macdHistogram) >= 0 ? "+" : ""}{safeNum(momentum.macdHistogram).toFixed(2)}
              </span>
              <span className="text-[8px] block text-slate-400">
                {momentum.macdDirectionAligned ? "Mendukung" : "Konflik"}
              </span>
            </div>
          </div>
          <div className="text-[10px] text-slate-400 mt-2">
            Panduan ADX: <strong className="text-slate-200">{momentum.adxActionGuidance}</strong>
          </div>
        </div>

        {/* Card 4: BiQuote USD News Filter */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400">
              <Radio className="w-3.5 h-3.5" />
              <span>4. FILTER NEWS USD (BIQUOTE)</span>
            </div>
            <span
              className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
                usdNewsFilter.newsStatusBadge === "Aman"
                  ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                  : usdNewsFilter.newsStatusBadge === "Menunggu"
                  ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
                  : "bg-rose-500/20 text-rose-300 border-rose-500/40"
              }`}
            >
              {usdNewsFilter.newsStatusBadge === "Aman" ? "✅ Aman" : usdNewsFilter.newsStatusBadge === "Menunggu" ? "⏳ Menunggu" : "🔴 Hindari"}
            </span>
          </div>
          <div className="p-2 rounded bg-slate-900/80 border border-slate-800 text-[11px]">
            <div className="flex justify-between items-center mb-1">
              <span className="text-slate-400 text-[10px]">Rilis Terdekat:</span>
              <span className="font-semibold text-slate-200">{usdNewsFilter.nearestUsdEventTitle}</span>
            </div>
            <div className="text-[10px] text-slate-400 leading-tight">
              {usdNewsFilter.actionRule}
            </div>
          </div>
          <div className="text-[10px] text-slate-400 mt-2 flex justify-between items-center">
            <span>Filter USD Khusus: Non-USD diabaikan</span>
            <span className="text-amber-300 font-semibold">Anti 90% False Signals</span>
          </div>
        </div>
      </div>

      {/* Signal Text Box (Matches Requested Format) */}
      <div className="bg-black/80 border border-slate-800 rounded-xl p-3.5 relative z-10 font-mono text-xs text-slate-300">
        <div className="flex items-center justify-between mb-2 pb-2 border-b border-slate-800 font-sans">
          <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wide">
            Format Output Sinyal Lengkap (ZRILL AI)
          </span>
          <button
            onClick={handleCopy}
            className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 font-mono"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? "Copied" : "Copy"}</span>
          </button>
        </div>
        <pre className="whitespace-pre-wrap leading-relaxed text-[11px] text-slate-200">
          {formattedOutputSignalText}
        </pre>
      </div>
    </div>
  );
};
