export interface QuoteFreshnessInput {
  price: number;
  updatedAt: number;
}

export const MAX_QUOTE_AGE_MS = 30_000;

/**
 * A quote is usable only when it has a positive finite price, a valid timestamp,
 * is not from the future, and is no older than the configured freshness window.
 */
export function isFreshMarketQuote(
  quote: QuoteFreshnessInput,
  now = Date.now(),
  maxAgeMs = MAX_QUOTE_AGE_MS,
): boolean {
  if (!Number.isFinite(now) || !Number.isFinite(maxAgeMs) || maxAgeMs < 0) return false;
  if (!Number.isFinite(quote.price) || quote.price <= 0) return false;
  if (!Number.isFinite(quote.updatedAt)) return false;
  const age = now - quote.updatedAt;
  return age >= 0 && age <= maxAgeMs;
}
