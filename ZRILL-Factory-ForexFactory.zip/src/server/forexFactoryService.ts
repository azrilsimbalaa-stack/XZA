export const FOREX_FACTORY_WEEKLY_FEED_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.json";
export const FOREX_FACTORY_CALENDAR_URL = "https://www.forexfactory.com/calendar";

function nullableSourceValue(value: unknown): string | null {
  if (value === null || value === undefined) return null;
  const normalized = String(value).trim();
  return !normalized || normalized === "---" || normalized.toLowerCase() === "n/a" ? null : normalized;
}

/** Normalize the public Forex Factory weekly export without inventing missing values. */
export function normalizeForexFactoryCalendarEvent(item: any): Record<string, any> | null {
  if (!item || typeof item !== "object") return null;

  const title = typeof item.title === "string" ? item.title.trim() : "";
  const currency = typeof item.country === "string" ? item.country.trim().toUpperCase() : "";
  const rawDate = typeof item.date === "string" ? item.date : "";
  const timestamp = Date.parse(rawDate);
  if (!title || !/^[A-Z]{3}$/.test(currency) || !Number.isFinite(timestamp)) return null;

  const rawImpact = typeof item.impact === "string" ? item.impact.trim().toLowerCase() : "";
  const importance = rawImpact === "high" ? 1 : rawImpact === "medium" ? 0 : -1;
  const id = nullableSourceValue(item.id) || `${currency}_${timestamp}_${title.toLowerCase().replace(/[^a-z0-9]+/g, "_")}`;

  return {
    id,
    title,
    currency,
    country: currency,
    date: new Date(timestamp).toISOString(),
    importance,
    impact: rawImpact || "unknown",
    forecast: nullableSourceValue(item.forecast),
    previous: nullableSourceValue(item.previous),
    actual: nullableSourceValue(item.actual),
    unit: "",
    indicator: title,
    source: "Forex Factory",
    sourceUrl: FOREX_FACTORY_CALENDAR_URL,
    timeMode: "exact",
  };
}

export function normalizeForexFactoryCalendarPayload(payload: unknown): Record<string, any>[] {
  if (!Array.isArray(payload)) return [];
  return payload
    .map(normalizeForexFactoryCalendarEvent)
    .filter((event): event is Record<string, any> => event !== null)
    .sort((a, b) => Date.parse(a.date) - Date.parse(b.date));
}
