export const BIQUOTE_BASE_URL = "https://biquote.io";
export const MAX_BIQUOTE_QUOTE_AGE_MS = 30_000;

export interface NormalizedBiQuoteTick {
  symbol: string;
  price: number;
  bid: number;
  ask: number;
  timestamp: number;
  ageMs: number;
  marketState: "open" | "closed" | "unknown";
  dataStatus: "LIVE" | "STALE" | "CLOSED";
  source: string;
}

export function normalizeBiQuoteTick(
  payload: any,
  now = Date.now(),
  maxAgeMs = MAX_BIQUOTE_QUOTE_AGE_MS,
): NormalizedBiQuoteTick | null {
  if (!payload || typeof payload !== "object") return null;
  const symbol = typeof payload.symbol === "string" ? payload.symbol.toUpperCase() : "";
  const price = Number(payload.mid);
  const bid = Number(payload.bid);
  const ask = Number(payload.ask);
  const timestamp = typeof payload.timestamp === "string" ? Date.parse(payload.timestamp) : Number.NaN;
  if (!symbol || !Number.isFinite(price) || price <= 0 || !Number.isFinite(timestamp)) return null;
  if (!Number.isFinite(now) || !Number.isFinite(maxAgeMs) || maxAgeMs < 0) return null;
  const ageMs = now - timestamp;
  if (ageMs < 0) return null;

  const providerAgeSeconds = Number(payload.quoteAgeSeconds);
  const effectiveAgeMs = Number.isFinite(providerAgeSeconds) && providerAgeSeconds >= 0
    ? Math.max(ageMs, providerAgeSeconds * 1000)
    : ageMs;
  const marketState = payload.marketState === "open"
    ? "open"
    : payload.marketState === "closed" ? "closed" : "unknown";
  const providerStale = payload.stale === true;
  const dataStatus = marketState === "closed"
    ? "CLOSED"
    : (marketState === "open" && !providerStale && effectiveAgeMs <= maxAgeMs ? "LIVE" : "STALE");

  return {
    symbol,
    price,
    bid: Number.isFinite(bid) && bid > 0 ? bid : 0,
    ask: Number.isFinite(ask) && ask > 0 ? ask : 0,
    timestamp,
    ageMs: effectiveAgeMs,
    marketState,
    dataStatus,
    source: typeof payload.source === "string" ? payload.source : "BiQuote",
  };
}

export interface NormalizedBiQuoteBar {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  tickVolume: number;
  isOpen: boolean;
}

export function normalizeBiQuoteBars(payload: any): NormalizedBiQuoteBar[] {
  if (!payload || !Array.isArray(payload.bars)) return [];
  return payload.bars.map((bar: any) => {
    const time = typeof bar?.openTime === "string" ? Date.parse(bar.openTime) : Number.NaN;
    const open = Number(bar?.open);
    const high = Number(bar?.high);
    const low = Number(bar?.low);
    const close = Number(bar?.close);
    const volume = Number(bar?.volume ?? 0);
    const tickVolume = Number(bar?.tickVolume ?? 0);
    return { time, open, high, low, close, volume, tickVolume, isOpen: bar?.isOpen === true };
  }).filter((bar: NormalizedBiQuoteBar) =>
    Number.isFinite(bar.time) &&
    [bar.open, bar.high, bar.low, bar.close, bar.volume, bar.tickVolume].every(Number.isFinite) &&
    bar.open > 0 && bar.high > 0 && bar.low > 0 && bar.close > 0 &&
    bar.high >= Math.max(bar.open, bar.close) &&
    bar.low <= Math.min(bar.open, bar.close) &&
    bar.volume >= 0 && bar.tickVolume >= 0
  ).sort((a: NormalizedBiQuoteBar, b: NormalizedBiQuoteBar) => a.time - b.time);
}
