/**
 * INSTITUTIONAL ECONOMIC CALENDAR & PRECISION PREDICTION ENGINE
 * Zrill AI Macroeconomic Research & Smart Money Quantitative Model
 * 
 * Fitur Utama:
 * 1. 4-Pilar Pegangan Kuat (Macro Transmission, Empirical History, SMC Liquidity, Invalidation Risk Guard)
 * 2. Multi-Factor Categorization (Inflation, Labor, Central Banks, Growth, PMIs, Sentiment)
 * 3. 3-Way Scenario Playbook (Hot / In-Line / Soft) untuk panduan eksekusi sebelum & saat rilis
 * 4. Formula Akurasi Empiris Terkalibrasi (Cross-Asset DXY, US10Y, XAUUSD, EURUSD, BTC)
 */

export type MacroCategory =
  | "INFLATION_CPI_PCE"
  | "LABOR_PAYROLLS_NFP"
  | "LABOR_UNEMPLOYMENT"
  | "LABOR_WAGES"
  | "CENTRAL_BANK_RATES"
  | "GROWTH_GDP_RETAIL"
  | "BUSINESS_PMI"
  | "SENTIMENT_HOUSING"
  | "GLOBAL_MACRO";

export interface MacroPillar {
  title: string;
  transmissionSummary: string;
  dxyMechanism: string;
  yield10yImpact: string;
  goldCorrelation: string;
  btcImpact: string;
}

export interface HistoricalPillar {
  winRateStat: string;
  sampleSize: string;
  avgVolatilityPips: number;
  empiricalPrecedent: string;
}

export interface SmcPillar {
  orderFlowTarget: string;
  liquiditySweepZone: string;
  fvgImbalanceArea: string;
  recommendedEntryTactic: string;
}

export interface RiskGuardPillar {
  invalidationLevelPips: number;
  invalidationRule: string;
  recommendedSl: string;
  recommendedTp1: string;
  recommendedTp2: string;
  riskRewardRatio: string;
}

export interface ScenarioPlaybook {
  hot: {
    condition: string;
    marketReaction: string;
    actionBias: "STRONG SELL" | "STRONG BUY" | "WAITING";
    expectedPips: string;
  };
  inline: {
    condition: string;
    marketReaction: string;
    actionBias: "BUY" | "SELL" | "NEUTRAL / WHIPSAW" | "WAITING";
    expectedPips: string;
  };
  soft: {
    condition: string;
    marketReaction: string;
    actionBias: "STRONG BUY" | "STRONG SELL" | "WAITING";
    expectedPips: string;
  };
}

export interface PeganganKuat {
  anchorGrade: "TIER 1 - PEGANGAN MAKSIMAL (HIGH CONFIDENCE)" | "TIER 2 - PEGANGAN KUAT (INTERMEDIATE)" | "TIER 3 - PEGANGAN TERUKUR (TACTICAL)";
  anchorScore: number; // e.g. 97.8%
  macroPillar: MacroPillar;
  historicalPillar: HistoricalPillar;
  smcPillar: SmcPillar;
  riskGuardPillar: RiskGuardPillar;
  scenarioPlaybook: ScenarioPlaybook;
  institutionalConsensus: string;
}

export interface SpikePredictionData {
  spikeProbability: number;
  spikeLevel: "SPIKE TINGGI" | "SPIKE SEDANG" | "SPIKE RENDAH" | "BELUM TERKALIBRASI";
  spikeType: "HIGH_SPIKE" | "MEDIUM_SPIKE" | "LOW_SPIKE" | "UNAVAILABLE";
  estimatedPipsGold: string;
  estimatedPipsFx: string;
  estimatedPipsBtc: string;
  spikeDirectionBias: string;
  trapRiskLevel: "EKSTREM (WHALE STOP HUNT)" | "TINGGI" | "SEDANG" | "MINIMAL" | "UNAVAILABLE";
  liquiditySpreadRisk: string;
  peakVolatilityWindow: string;
  preReleaseStrategy: string;
  historicalAvgSpikePips: number;
  spikeVolatilityRank: string;
}

export interface UpgradedEconomicEvent {
  id: string;
  title: string;
  currency: string;
  country: string;
  date: string;
  timeMode?: "exact" | "date" | "notime" | "tentative" | string;
  sourceUrl?: string | null;
  importance: number; // 1 = High, 0 = Medium, -1 = Low
  forecast: string;
  previous: string;
  actual: string | null;
  estimatedActual: string;
  estimatedActualNum: number | null;
  predictedDeviation: string;
  a1LeakIntelligence: string;
  unit: string;
  source: string;
  status: "RELEASED" | "UPCOMING";
  isReleased: boolean;
  releasedLabel: string;
  deviation: number | null;
  macroCategory: MacroCategory;
  spikePrediction: SpikePredictionData;
  hasDirectionalInputs: boolean;
  isModelCalibrated: boolean;
  isPredictionCorrect: boolean | null;
  pipsGain: string;
  accuracyStatus: "TEPAT_SASARAN" | "TIDAK_TEPAT" | "MENUNGGU";
  verdictSummary: string;
  marketOutcome: {
    dxyEffect: "BEARISH_USD" | "BULLISH_USD" | "NEUTRAL_CHOP";
    goldImpact: "BUY" | "SELL" | "WAITING";
    recommendation: "STRONG BUY" | "BUY" | "STRONG SELL" | "SELL" | "WAIT";
    accuracyScore: number;
    summary: string;
  };
  prediction: {
    direction: "BUY" | "SELL" | "WAITING";
    biasStrength: "STRONG BUY (BREAKOUT)" | "BUY ON RETEST (DISCOUNT)" | "STRONG SELL (BREAKOUT)" | "SELL ON RALLY (PREMIUM)" | "WAITING / NO BIAS";
    targetSymbol: string;
    confidence: number;
    peganganKuat: PeganganKuat;
    reasoning: string;
    fundamentalAspect: string;
    technicalConfluence: string;
    macroSentiment: string;
    statusLabel: string;
  };
}

/**
 * 1. Klasifikasi Mendalam Kategori Makro Ekonomi
 */
export function classifyIndicator(title: string, indicator: string = ""): {
  category: MacroCategory;
  higherIsBullishUSD: boolean;
  weightTier: 1 | 2 | 3;
} {
  const text = (title + " " + indicator).toLowerCase();

  // A. Inflasi & Indeks Harga (CPI, PPI, PCE) -> Nilai Tinggi = Inflasi Panas = The Fed Hawkish = USD Menguat / Gold Turun
  if (/cpi|consumer price|inflation|pce|core pce|personal consumption expenditures/i.test(text)) {
    return { category: "INFLATION_CPI_PCE", higherIsBullishUSD: true, weightTier: 1 };
  }
  if (/ppi|producer price|import price|export price/i.test(text)) {
    return { category: "INFLATION_CPI_PCE", higherIsBullishUSD: true, weightTier: 2 };
  }

  // B. Suku Bunga & Kebijakan Bank Sentral (FOMC, Fed Rate, Powell, ECB, BOE, BOJ)
  if (/fomc|federal funds|fed rate|interest rate|ecb rate|boe rate|boj rate|monetary policy|powell|lagarde/i.test(text)) {
    return { category: "CENTRAL_BANK_RATES", higherIsBullishUSD: true, weightTier: 1 };
  }

  // C. Ketenagakerjaan - Payrolls (NFP, ADP, JOLTS) -> Nilai Tinggi = Pekerjaan Bertambah = USD Menguat / Gold Turun
  if (/non-farm|nonfarm|nfp|payrolls|adp employment|jolts|job openings/i.test(text)) {
    return { category: "LABOR_PAYROLLS_NFP", higherIsBullishUSD: true, weightTier: 1 };
  }

  // D. Ketenagakerjaan - Tingkat Pengangguran & Klaim Pengangguran -> Nilai Tinggi = Tenaga Kerja Melemah = USD Melemah / Gold Naik
  if (/unemployment rate|jobless claim|initial claim|continuing claim|unemployed/i.test(text)) {
    return { category: "LABOR_UNEMPLOYMENT", higherIsBullishUSD: false, weightTier: 1 };
  }

  // E. Upah Tenaga Kerja (Average Hourly Earnings) -> Nilai Tinggi = Inflasi Upah = USD Menguat / Gold Turun
  if (/hourly earnings|wage growth|employment cost|unit labor/i.test(text)) {
    return { category: "LABOR_WAGES", higherIsBullishUSD: true, weightTier: 1 };
  }

  // F. Pertumbuhan Ekonomi & Konsumsi (GDP, Retail Sales, Durable Goods)
  if (/gdp|gross domestic product|retail sales|core retail/i.test(text)) {
    return { category: "GROWTH_GDP_RETAIL", higherIsBullishUSD: true, weightTier: 1 };
  }
  if (/durable goods|factory orders|wholesale trade/i.test(text)) {
    return { category: "GROWTH_GDP_RETAIL", higherIsBullishUSD: true, weightTier: 2 };
  }

  // G. Indeks Manufaktur & Jasa (ISM, PMI, S&P Global)
  if (/ism services|services pmi/i.test(text)) {
    return { category: "BUSINESS_PMI", higherIsBullishUSD: true, weightTier: 1 };
  }
  if (/ism manufacturing|manufacturing pmi|s&p global|chicago pmi|philly fed|empire state/i.test(text)) {
    return { category: "BUSINESS_PMI", higherIsBullishUSD: true, weightTier: 2 };
  }

  // H. Sentimen Konsumen & Pasar Perumahan (Michigan, Building Permits, Home Sales)
  if (/michigan|consumer sentiment|consumer confidence|inflation expectation/i.test(text)) {
    return { category: "SENTIMENT_HOUSING", higherIsBullishUSD: true, weightTier: 2 };
  }
  if (/building permits|housing starts|existing home|new home/i.test(text)) {
    return { category: "SENTIMENT_HOUSING", higherIsBullishUSD: true, weightTier: 3 };
  }

  // I. Default Global Macro
  return { category: "GLOBAL_MACRO", higherIsBullishUSD: true, weightTier: 2 };
}

/**
 * 2. Generator 4-Pilar Pegangan Kuat Institusional (Pegangan yang Kokoh & Ilmiah)
 */
export function generatePeganganKuat(
  title: string,
  currency: string,
  category: MacroCategory,
  weightTier: 1 | 2 | 3,
  forecast: number | null,
  previous: number | null,
  actual: number | null,
  unit: string,
  isReleased: boolean,
  predictedDirection: "BUY" | "SELL"
): PeganganKuat {
  const unavailable = "UNAVAILABLE — belum ada sumber data / riset historis terverifikasi";
  return {
    anchorGrade: "TIER 3 - PEGANGAN TERUKUR (TACTICAL)",
    anchorScore: 0,
    macroPillar: {
      title: "Transmisi makro belum tervalidasi",
      transmissionSummary: unavailable,
      dxyMechanism: unavailable,
      yield10yImpact: unavailable,
      goldCorrelation: unavailable,
      btcImpact: unavailable,
    },
    historicalPillar: {
      winRateStat: "NOT MEASURED",
      sampleSize: "0 — no verified historical dataset",
      avgVolatilityPips: 0,
      empiricalPrecedent: "Win rate, sample size, dan dampak pips tidak tersedia sebelum pengujian historis out-of-sample.",
    },
    smcPillar: {
      orderFlowTarget: unavailable,
      liquiditySweepZone: unavailable,
      fvgImbalanceArea: unavailable,
      recommendedEntryTactic: "WAITING — struktur harga dan order flow belum diverifikasi.",
    },
    riskGuardPillar: {
      invalidationLevelPips: 0,
      invalidationRule: "Belum ada level invalidasi karena data harga dan struktur belum diverifikasi.",
      recommendedSl: "UNAVAILABLE — jangan membuat SL dari asumsi kalender.",
      recommendedTp1: "UNAVAILABLE — jangan membuat TP dari asumsi kalender.",
      recommendedTp2: "UNAVAILABLE — jangan membuat TP dari asumsi kalender.",
      riskRewardRatio: "NOT CALCULATED",
    },
    scenarioPlaybook: {
      hot: { condition: "Actual di atas forecast", marketReaction: unavailable, actionBias: "WAITING", expectedPips: "NOT MEASURED" },
      inline: { condition: "Actual sesuai forecast", marketReaction: unavailable, actionBias: "WAITING", expectedPips: "NOT MEASURED" },
      soft: { condition: "Actual di bawah forecast", marketReaction: unavailable, actionBias: "WAITING", expectedPips: "NOT MEASURED" },
    },
    institutionalConsensus: "UNAVAILABLE — tidak ada data positioning institusi yang terhubung.",
  };
}

/**
 * 3. Mesin Prediksi Spike Kuantitatif Terintegrasi
 */
export function calculateUpgradedSpikePrediction(
  title: string,
  indicator: string,
  currency: string,
  importance: number,
  category: MacroCategory,
  weightTier: 1 | 2 | 3,
  forecast: number | null,
  previous: number | null,
  actual: number | null,
  isReleased: boolean,
  finalDirection: "BUY" | "SELL"
): SpikePredictionData {
  // No calibrated historical event-to-price dataset is connected yet.
  // Return an explicit unavailable state instead of inventing probabilities or pip ranges.
  return {
    spikeProbability: 0,
    spikeLevel: "BELUM TERKALIBRASI",
    spikeType: "UNAVAILABLE",
    estimatedPipsGold: "Belum tersedia",
    estimatedPipsFx: "Belum tersedia",
    estimatedPipsBtc: "Belum tersedia",
    spikeDirectionBias: "Belum tersedia — menunggu data reaksi harga historis",
    trapRiskLevel: "UNAVAILABLE",
    liquiditySpreadRisk: "Belum tersedia",
    peakVolatilityWindow: "Belum tersedia",
    preReleaseStrategy: "Jangan mengasumsikan besaran spike. Tunggu rilis aktual dan konfirmasi spread/volatilitas dari feed broker.",
    historicalAvgSpikePips: 0,
    spikeVolatilityRank: "NOT CALIBRATED",
  };
}

/**
 * 4. Master Evaluator untuk Setiap Event Kalender Ekonomi
 */
export function buildComprehensiveEconomicEvent(
  item: any,
  nowMs: number = Date.now()
): UpgradedEconomicEvent {
  const evDate = new Date(item.date);
  const isPastTime = evDate.getTime() <= nowMs;
  const hasActual = item.actual !== null && item.actual !== undefined && item.actual !== "" && item.actual !== "---";
  const isReleased = hasActual || isPastTime;

  const currency = item.currency || (item.country === "US" ? "USD" : item.country === "EU" ? "EUR" : item.country === "GB" ? "GBP" : item.country === "JP" ? "JPY" : "USD");
  const title = item.title || item.indicator || item.event || "Economic Event";
  const unit = item.unit || item.scale || "";

  const parseFiniteNumber = (value: unknown): number | null => {
    if (value === null || value === undefined || value === "" || value === "---") return null;
    const parsed = Number.parseFloat(String(value).replace(/[^0-9.-]+/g, ""));
    return Number.isFinite(parsed) ? parsed : null;
  };
  const actNum = hasActual ? parseFiniteNumber(item.actual) : null;
  const fcNum = parseFiniteNumber(item.forecast);
  const prevNum = parseFiniteNumber(item.previous);

  const { category, higherIsBullishUSD, weightTier } = classifyIndicator(title, item.indicator || "");

  // Tentukan Arah Prediksi (Direction Bias)
  let finalDirection: "BUY" | "SELL" = "BUY";
  const hasDirectionalInputs = fcNum !== null && Number.isFinite(fcNum) && prevNum !== null && Number.isFinite(prevNum);
  const confidenceScore = 0; // No calibrated probability model is connected.
  let deviation: number | null = null;

  if (isReleased && actNum !== null && hasDirectionalInputs) {
    const compareBase = fcNum as number;
    deviation = parseFloat((actNum - compareBase).toFixed(2));
    const isHigher = actNum >= compareBase;

    if (currency === "USD") {
      if (higherIsBullishUSD) {
        // Higher USD indicator -> USD Bullish -> Gold SELL
        finalDirection = isHigher ? "SELL" : "BUY";
      } else {
        // Higher indicator (e.g. unemployment) -> USD Bearish -> Gold BUY
        finalDirection = isHigher ? "BUY" : "SELL";
      }
    } else {
      // Non-USD Currencies (EUR, GBP, JPY, AUD)
      finalDirection = isHigher ? "BUY" : "SELL";
    }
  } else {
    // PRE-RELEASE PREDICTIVE BIAS (Based on Consensus vs Previous & Institutional Flow)
    if (currency === "USD") {
      if (fcNum !== null && prevNum !== null) {
        const expectedDiff = fcNum - prevNum;
        if (higherIsBullishUSD) {
          finalDirection = expectedDiff >= 0 ? "SELL" : "BUY";
        } else {
          finalDirection = expectedDiff >= 0 ? "BUY" : "SELL";
        }
      } else {
        // No forecast/previous pair: do not invent a directional bias.
        finalDirection = "BUY";
      }
    } else {
      finalDirection = "BUY";
    }
  }

  // Deterministic Stable ID (No Math.random to prevent re-render flickers)
  const deterministicId = item.id
    ? String(item.id)
    : `${currency}_${title.replace(/[^a-zA-Z0-9]+/g, "_")}_${evDate.getTime()}`;

  // No trained/validated actual-value forecasting model is connected.
  const estimatedActualNum: number | null = null;
  const estimatedActual = "Belum tersedia";
  const predictedDeviation = "Belum tersedia";
  const a1LeakIntelligence = "Estimasi angka aktual belum tersedia: belum ada model forecasting yang dilatih dan diuji pada data historis rilis ekonomi.";

  // Generate 4-Pilar Pegangan Kuat
  const peganganKuat = generatePeganganKuat(
    title,
    currency,
    category,
    weightTier,
    fcNum,
    prevNum,
    actNum,
    unit,
    isReleased,
    finalDirection
  );

  // Calculate Spike Prediction
  const spikePrediction = calculateUpgradedSpikePrediction(
    title,
    item.indicator || "",
    currency,
    item.importance === 1 ? 1 : item.importance === 0 ? 0 : -1,
    category,
    weightTier,
    fcNum,
    prevNum,
    actNum,
    isReleased,
    finalDirection
  );

  // Evaluate directional scenario only when actual, forecast, and previous values exist.
  let isPredictionCorrect: boolean | null = null;
  let pipsGain = "Tidak dihitung — data reaksi harga belum terhubung";
  let accuracyStatus: "TEPAT_SASARAN" | "TIDAK_TEPAT" | "MENUNGGU" = "MENUNGGU";
  let verdictSummary = "Menunggu rilis aktual. Bias arah hanya tersedia jika forecast dan previous valid; profit/pips tidak dihitung tanpa data harga pasca-rilis.";

  if (isReleased && actNum !== null && hasDirectionalInputs) {
    const compareBase = fcNum as number;
    const dev = actNum - compareBase;
    const isHigher = dev >= 0;
    const actualDirection: "BUY" | "SELL" = currency === "USD"
      ? (higherIsBullishUSD ? (isHigher ? "SELL" : "BUY") : (isHigher ? "BUY" : "SELL"))
      : (isHigher ? "BUY" : "SELL");
    isPredictionCorrect = finalDirection === actualDirection;
    accuracyStatus = isPredictionCorrect ? "TEPAT_SASARAN" : "TIDAK_TEPAT";
    verdictSummary = isPredictionCorrect
      ? "Bias skenario berbasis forecast/previous searah dengan kejutan data aktual. Ini bukan bukti profit trading atau akurasi harga."
      : "Bias skenario berbasis forecast/previous tidak searah dengan kejutan data aktual. Ini bukan pengukuran hasil eksekusi trading.";
  }

  const biasStrength: UpgradedEconomicEvent["prediction"]["biasStrength"] = !hasDirectionalInputs
    ? "WAITING / NO BIAS"
    : finalDirection === "BUY"
      ? (weightTier === 1 ? "STRONG BUY (BREAKOUT)" : "BUY ON RETEST (DISCOUNT)")
      : (weightTier === 1 ? "STRONG SELL (BREAKOUT)" : "SELL ON RALLY (PREMIUM)");

  const releasedLabel = isReleased ? "TELAH DIRILIS" : "MENUNGGU RILIS";

  return {
    id: deterministicId,
    title,
    currency,
    country: item.country || currency,
    date: evDate.toISOString(),
    timeMode: typeof item.timeMode === "string" ? item.timeMode : "exact",
    sourceUrl: typeof item.sourceUrl === "string" ? item.sourceUrl : null,
    importance: item.importance === 1 ? 1 : item.importance === 0 ? 0 : -1,
    forecast: fcNum !== null ? String(fcNum) : item.forecast ? String(item.forecast) : "---",
    previous: prevNum !== null ? String(prevNum) : item.previous ? String(item.previous) : "---",
    actual: actNum !== null ? String(actNum) : null,
    estimatedActual,
    estimatedActualNum,
    predictedDeviation,
    a1LeakIntelligence,
    unit,
    source: item.source || "Economic Calendar Provider",
    status: isReleased ? "RELEASED" : "UPCOMING",
    isReleased,
    releasedLabel,
    deviation,
    macroCategory: category,
    spikePrediction,
    hasDirectionalInputs,
    isModelCalibrated: false,
    isPredictionCorrect,
    pipsGain,
    accuracyStatus,
    verdictSummary,
    marketOutcome: {
      dxyEffect: !hasDirectionalInputs ? "NEUTRAL_CHOP" : finalDirection === "BUY" ? "BEARISH_USD" : "BULLISH_USD",
      goldImpact: hasDirectionalInputs ? finalDirection : "WAITING",
      recommendation: !hasDirectionalInputs ? "WAIT" : finalDirection === "BUY" ? (weightTier === 1 ? "STRONG BUY" : "BUY") : (weightTier === 1 ? "STRONG SELL" : "SELL"),
      accuracyScore: 0,
      summary: isReleased && actNum !== null
        ? `Aktual resmi ${actNum}${unit}; evaluasi bias skenario: ${accuracyStatus}. Dampak harga dan profit belum dihitung karena feed harga pasca-rilis tidak tersedia.`
        : `Forecast (${fcNum !== null ? fcNum + unit : "---"}) dan previous (${prevNum !== null ? prevNum + unit : "---"}). Estimasi aktual dan probabilitas spike belum tersedia.`
    },
    prediction: {
      direction: hasDirectionalInputs ? finalDirection : "WAITING",
      biasStrength,
      targetSymbol: "XAUUSD",
      confidence: confidenceScore,
      peganganKuat,
      reasoning: `${a1LeakIntelligence} [Pegangan Teknis: ${peganganKuat.smcPillar.orderFlowTarget} | Batas Risiko: ${peganganKuat.riskGuardPillar.recommendedSl}]`,
      fundamentalAspect: peganganKuat.macroPillar.transmissionSummary,
      technicalConfluence: peganganKuat.smcPillar.recommendedEntryTactic,
      macroSentiment: peganganKuat.macroPillar.dxyMechanism,
      statusLabel: !hasDirectionalInputs ? "WAITING_FOR_FORECAST_INPUTS" : releasedLabel
    }
  };
}
