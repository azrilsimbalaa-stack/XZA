export interface SignalSafetyChecks {
  isSideways: boolean;
  confluenceScore: number;
  newsBlocked: boolean;
  minimumRiskRewardMet: boolean;
  directionConfirmed: boolean;
}

/** Returns every hard block that must be resolved before a signal can be ACTIVE. */
export function getSignalBlockReasons(checks: SignalSafetyChecks): string[] {
  const reasons: string[] = [];
  if (checks.isSideways) reasons.push("struktur sideways / momentum lemah");
  if (!Number.isFinite(checks.confluenceScore) || checks.confluenceScore < 7) {
    reasons.push(`konfluensi di bawah 7/10`);
  }
  if (checks.newsBlocked) reasons.push("jendela berita berisiko tinggi");
  if (!checks.minimumRiskRewardMet) reasons.push("risk-reward minimum belum terpenuhi");
  if (!checks.directionConfirmed) reasons.push("arah tren belum terkonfirmasi");
  return reasons;
}

export function isTradeSetupAllowed(checks: SignalSafetyChecks): boolean {
  return getSignalBlockReasons(checks).length === 0;
}
