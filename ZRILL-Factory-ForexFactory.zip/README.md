# ZRILL Factory

ZRILL Factory is a React + TypeScript application with an Express API. BiQuote is the primary market-data provider; Forex Factory is the economic-calendar supplier; TradingView remains a limited quote-only MCP bridge.

## Requirements

- Node.js 20+
- npm
- Provider access from the deployment environment

## Local setup

1. Install dependencies: `npm ci`
2. Copy `.env.example` to `.env.local` and configure the required values.
3. Start the development server: `npm run dev`
4. Run source checks: `npm run lint`
5. Run focused tests: `npm test`
6. Create a production build: `npm run build`

## Environment configuration

- `GEMINI_API_KEY`: optional until an LLM-backed workflow is connected.
- `APP_URL`: public application origin.
- `ALLOWED_ORIGINS`: comma-separated browser origins permitted by the API.
- `ZRILL_MEMBERSHIP_CODES`: comma-separated `PLAN:CODE` pairs, such as `WEEKLY:unique-code,MONTHLY:another-unique-code`. Keep real values in deployment secrets only.
- `ZRILL_OVERRIDE_CODE`: long, random admin override secret. Keep it out of source control.

## Data integrity rules

- `/api/biquote/price` uses BiQuote's `mid` price and requires an open market plus a quote age of at most 30 seconds to report `LIVE`. Closed, stale, future-dated, or invalid quotes cannot unlock signal generation.
- `/api/klines` uses one BiQuote OHLC response per request. It validates timestamps and OHLC geometry and never splices a TradingView tick into a candle from another venue.
- `/api/calendar` uses Forex Factory's public weekly JSON export (`ff_calendar_thisweek.json`). Source values for forecast, previous, impact, currency, and event date are preserved; missing values remain null. The currently published weekly export may omit actual results, so ZRILL leaves Actual blank and marks past events as "release time passed / actual unavailable" rather than inventing a result. The feed covers the current week only, so no historical or future-week data is fabricated.
- Forex Factory weekly export: https://nfs.faireconomy.media/ff_calendar_thisweek.json. Forex Factory's notices restrict copying, republication, and redistribution of calendar content without prior written consent. The endpoint is disabled by default; set `FOREX_FACTORY_LICENSE_CONFIRMED=true` only after written permission covers your intended use, including serving the calendar to ZRILL users.
- BiQuote market-data API documentation: https://biquote.io/docs/ (REST quotes and OHLC bars).
- The legacy TradingView quote bridge remains separate and is used only by the quote-only MCP adapter.
- The news endpoint returns provider-backed articles and reports provider status. Macro indicators and institutional flow values remain unavailable until real data providers are connected.
- `/api/ai/analyze` intentionally fails closed with `503` until a trusted server-side OHLC/indicator pipeline and multi-timeframe validator are connected. Client-supplied `isLiveDataVerified` flags cannot activate a signal.
- XAUUSD spot OHLC is sourced through BiQuote. The old Yahoo `GC=F` futures fallback is no longer used by the primary `/api/klines` endpoint.
- The TradingView MCP bridge currently supports only its quote operation. Other MCP operations return `501 NOT_IMPLEMENTED` rather than falsely claiming execution.

## Firestore security

The included rules make the public signal collection read-only for clients and restrict journals/settings to authenticated owners. Configure Firebase Authentication and ensure journal documents include `ownerUid` matching the authenticated UID before deploying these rules. Trusted signal publication should use a server-side Admin SDK service account, never a public client write.

## Important production note

This archive has received source hardening and focused regression tests. A full dependency install, frontend typecheck, production build, live BiQuote API contract run, Firebase Auth flow, and browser end-to-end run were not completed in this environment. The signal endpoint therefore remains deliberately disabled. DXY, US10Y/TIPS, Fed policy, ETF flows, order flow, and institutional SMC feeds are not connected. Do not deploy for live execution until those dependencies and a server-owned validation pipeline are implemented and verified. Confluence scores are not win rates; no performance guarantee is made.
