# ZRILL Factory — hardening notes

## Changes in this revision

- Removed the server-side mock BUY/SELL generator. `/api/ai/analyze` now returns a clear `503` until verified OHLCV, indicators, and multi-timeframe inputs are wired into the signal engine.
- Removed generated price ticks and generated OHLCV candles. TradingView quotes are returned only when a fresh quote (maximum age 30 seconds) exists in the WebSocket cache.
- Removed the fabricated economic-calendar fallback and fake default accuracy values. Calendar responses now report `LIVE` or `OFFLINE`; historical accuracy is explicitly unmeasured.
- Replaced fabricated news and institutional-flow payloads with provider-backed news only. Macro indicators and institutional flow are marked unavailable until connected to real sources.
- Restricted MCP reporting to the quote operation. Unsupported operations return `501 NOT_IMPLEMENTED`; missing quotes return `503`.
- Removed hard-coded membership/override shortcuts. Membership plans must be configured as `PLAN:CODE` secrets; override requires a deployment secret. Added a basic per-process auth attempt limiter.
- Added API request size limits, origin allowlisting, security headers, query validation, and provider failure status codes.
- Restricted Firestore signal writes to trusted server code and scoped journal/settings access to authenticated owners. Journal documents must include `ownerUid`.
- Updated the UI to show offline states rather than default XAUUSD prices or falsely claiming a live calendar connection.
- Added `/api/system/health` for quote/calendar freshness and integration status.
- Added a focused quote integrity test and an npm test script.
- Removed an unused nested `public/project-source.zip` that failed archive integrity checks.

## Verification performed

- TypeScript syntax/transpile parse: 24 `.ts` / `.tsx` files parsed with zero syntax diagnostics.
- Quote integrity behavior: manually executed the transpiled quote module with a stub WebSocket dependency; empty-cache XAUUSD, BTCUSD, BTCUSDT, and unknown symbols returned no quote.
- Full `npm ci`, TypeScript type-check, Vite build, and integration tests were not completed: dependency installation timed out in this environment. These checks must be run after installing dependencies in the target environment.

## Remaining production blockers

- The legacy `precisionSignalEngine` and experimental fundamental modules still contain hard-coded macro assumptions, generated confluence scores, and static news examples. Their outputs must not be treated as validated live signals. The server analysis endpoint is intentionally disabled until the data pipeline is replaced.
- Configure `ALLOWED_ORIGINS`, membership secrets, and the admin override secret in deployment settings. Do not commit real values.
- Configure Firebase Authentication and deploy the updated Firestore rules only after journal/settings writes include the authenticated UID.
- The current TradingView connection is a quote bridge, not the full TradingView MCP/CDP integration.
- Provider terms, symbol mapping, feed delays, and instrument differences (for example gold futures vs spot gold) still need integration-level verification.
