# ZRILL Factory — Remediation Report

**Status:** Source hardening completed; production release is still blocked pending full dependency/build/runtime verification and the trusted signal-data pipeline.

## What changed

### 1. BiQuote market-data integration

- Added `src/server/biquoteService.ts` for strict normalization of BiQuote quote and OHLC payloads. Added `src/server/forexFactoryService.ts` for the Forex Factory weekly economic-calendar export.
- Added `GET /api/biquote/price?symbol=XAUUSD`. It uses BiQuote `mid`, validates timestamp/freshness, and reports `LIVE` only when the market is open and the quote is no older than 30 seconds. Closed, stale, unknown-state, future-dated, invalid, or unavailable quotes cannot be labelled live.
- Replaced the primary `/api/klines` route with one-provider-per-response BiQuote OHLC. It validates OHLC geometry, timestamps, symbol, timeframe, and minimum history. It does not merge TradingView ticks into candles from another venue.
- Removed `GC=F` futures fallback from the primary XAUUSD spot OHLC route.
- Configured `/api/calendar` to use Forex Factory's current-week JSON export. Forecast/previous strings and timezone-bearing event timestamps are preserved; missing `actual` values remain null. The UI labels last-known data as stale when the upstream feed fails. A license confirmation environment flag keeps third-party calendar redistribution disabled until written permission is obtained.
- Switched the app's XAUUSD quote fetch to the BiQuote proxy.
- Added BiQuote quote freshness to `/api/system/health`.

### 2. No fabricated market / macro values

- Removed synthetic DXY, US10Y, FedWatch, ETF-flow, institutional-flow, CVD, whale-footprint, and MTF-certainty fixtures from the hardened service paths.
- Missing macro, news, SMC, or order-flow providers now return explicit unavailable/neutral states.
- Removed fallback bid/ask synthesis from the TradingView quote bridge. Missing bid/ask values remain unavailable.
- TradingView quote cache rejects stale/future-dated quotes via the shared freshness policy.

### 3. Signal safety

- Precision core rejects missing price, ATR, EMA50, EMA200, RSI, or insufficient valid OHLC history instead of inventing default values.
- Client-side `isLiveDataVerified` flags cannot unlock an active signal. The signal suite remains `WAITING` until server-side verification exists.
- `/api/ai/analyze` remains fail-closed with `503`; this is intentional because the full trusted multi-timeframe server-side indicator pipeline is not yet connected.
- Calendar prediction output no longer invents an estimated actual, spike probability, win rate, stop-loss, take-profit, or pips outcome.
- Calendar UI counts only explicitly evaluated outcomes. Missing evaluation is shown as `N/A` / `BELUM DIEVALUASI`, not as a win.
- Replaced false accuracy / profit / risk-free claims in visible components with unavailable or non-guarantee labels.

### 4. Security and API honesty

- MCP tool discovery advertises only the implemented quote tool; unsupported tools are explicitly listed as unavailable and return `501`.
- Added a separate per-IP attempt limit for admin override code checks.
- Server port now respects `process.env.PORT`.
- Existing Firestore rules remain default-deny, public-signal read-only, and owner-scoped for journal/settings documents.

## Verification performed

| Check | Result |
|---|---|
| Focused service compilation + regression tests | **20/20 passed** |
| TypeScript/TSX syntax scan | **28 files, 0 syntax diagnostics** |
| Full `npm run build` | **Not completed** — `vite: not found` because dependency installation did not complete |
| Full `npm run lint` / project typecheck | **Not completed** — dependency type packages are missing in the incomplete install |
| Live BiQuote HTTP contract test | **Not completed** — API shape was implemented from the published documentation, but live calls were not reachable in this runtime |
| Browser E2E / Firebase Auth flow | **Not completed** |

## Remaining release blockers

1. Complete a clean `npm ci`, then run `npm run lint` and `npm run build` in the target deployment environment.
2. Run live contract tests against BiQuote quote and OHLC endpoints plus the Forex Factory weekly calendar export; confirm symbols and response shapes for the account/deployment region.
3. Implement a trusted server-owned multi-timeframe pipeline that fetches closed OHLC bars, computes indicators, validates BOS/CHoCH/liquidity sweep/OB/FVG, and calls the signal engine only after provider freshness and consistency checks.
4. Connect and independently validate macro sources (DXY, US yields/TIPS, Fed policy), institutional flows, and news classification. Until then, those sections must remain unavailable.
5. Implement Firebase Authentication in the app before enabling Firestore journal/settings writes under the included owner-scoped rules.
6. Add historical backtests, walk-forward validation, and a persistent prediction ledger before displaying any win rate or calibrated probability.

## Important

This archive is safer and more honest about unavailable data, but it is **not certified for live trade execution**. The signal endpoint intentionally returns `503` until the remaining server-side validation pipeline is implemented and tested. No win-rate or profit guarantee is made.
