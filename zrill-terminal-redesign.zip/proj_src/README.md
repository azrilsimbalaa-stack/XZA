# Zrill AI Terminal

Terminal analisis XAUUSD dan BTCUSD (React + Vite + Express).

## Menjalankan
1. `npm install`
2. Salin `.env.example` ke `.env.local`, isi `GEMINI_API_KEY`.
3. `npm run dev`

## Login
- Kode akses divalidasi server di `POST /api/auth/login` dan menghasilkan sesi bertanda tangan.
- Mode ketat: set `ZRILL_ACCESS_CODES="KODE1:MONTHLY,KODE2:WEEKLY"` dan `SESSION_SECRET` di environment.
  Tanpa itu, aturan format kode lama tetap berlaku.

## Struktur
- `src/TerminalCore.tsx` — mesin terminal (harga live, sinyal, kalender, jurnal) sebagai hook `useTerminal()`.
- `src/Shell.tsx` — navigasi; `src/pages/*` — Ringkasan, Chart, Sinyal, Kalender, Berita, Risiko, Jurnal, Pengaturan.
- `src/auth/*` — login dan sesi. `src/ui/*` — komponen desain. `src/index.css` — token warna dan font.
