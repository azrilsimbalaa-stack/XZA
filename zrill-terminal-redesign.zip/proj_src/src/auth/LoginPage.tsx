import React, { useState } from "react";
import { useAuth } from "./AuthContext";
import { Button, Field } from "../ui/kit";
import { Icon } from "../ui/Icon";

/** Deret candlestick dekoratif (deterministik) untuk latar panel merek. */
function CandleField() {
  const bars = React.useMemo(() => {
    let seed = 7;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    let p = 120;
    return Array.from({ length: 64 }, (_, i) => {
      const o = p;
      const c = o + (rnd() - 0.42) * 16;
      const h = Math.max(o, c) + rnd() * 9;
      const l = Math.min(o, c) - rnd() * 9;
      p = c;
      return { i, o, c, h, l };
    });
  }, []);
  const min = Math.min(...bars.map((b) => b.l));
  const max = Math.max(...bars.map((b) => b.h));
  const y = (v: number) => 100 - ((v - min) / (max - min)) * 100;
  return (
    <svg viewBox="0 0 640 100" preserveAspectRatio="none" className="absolute inset-x-0 bottom-0 h-[46%] w-full opacity-[0.28]" aria-hidden="true">
      {bars.map((b) => {
        const up = b.c >= b.o;
        const col = up ? "#2fe0a0" : "#ff5c74";
        const x = b.i * 10 + 5;
        return (
          <g key={b.i}>
            <line x1={x} x2={x} y1={y(b.h)} y2={y(b.l)} stroke={col} strokeWidth="0.9" />
            <rect x={x - 2.6} width="5.2" y={Math.min(y(b.o), y(b.c))} height={Math.max(1.2, Math.abs(y(b.o) - y(b.c)))} fill={col} />
          </g>
        );
      })}
    </svg>
  );
}

export default function LoginPage() {
  const { login, loginDemo } = useAuth();
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) { setError("Masukkan kode akses Anda."); return; }
    setBusy(true); setError("");
    try { await login(code, name); }
    catch (err: any) { setError(err?.message || "Masuk gagal."); }
    finally { setBusy(false); }
  };

  return (
    <div className="min-h-full grid lg:grid-cols-[1.15fr_1fr] bg-abyss">
      {/* Panel merek */}
      <aside className="relative overflow-hidden min-h-[236px] lg:min-h-screen border-b lg:border-b-0 lg:border-r border-line">
        <img src="/zrill-art.webp" alt="" className="absolute inset-0 w-full h-full object-cover object-[50%_42%] opacity-[0.55]" />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(7,11,16,0.2)_0%,rgba(7,11,16,0.55)_55%,#070b10_100%)]" />
        <CandleField />
        <div className="relative z-10 h-full flex flex-col justify-between p-6 sm:p-10 lg:p-14">
          <div className="flex items-center gap-3">
            <img src="/zrill-icon-192.png" alt="" className="w-10 h-10 rounded-xl border border-jade/30" />
            <span className="font-display text-[20px] font-bold tracking-tight">Zrill AI</span>
          </div>
          <div className="hidden lg:block max-w-[30rem] pb-6">
            <h1 className="font-display text-[44px] leading-[1.04] font-extrabold tracking-[-0.03em] text-text">
              Baca emas dan Bitcoin lewat struktur pasar, bukan tebakan.
            </h1>
            <ul className="mt-7 space-y-3 text-[15px] text-gray-200">
              {[
                ["target", "Sinyal SMC lintas timeframe dengan entry, stop loss, dan tiga target"],
                ["calendar", "Kalender ekonomi USD dalam waktu WITA, lengkap dengan jam rilis"],
                ["calculator", "Kalkulator lot dan jurnal untuk menjaga risiko tetap terukur"],
              ].map(([ic, t]) => (
                <li key={t} className="flex gap-3 items-start">
                  <span className="mt-0.5 w-6 h-6 rounded-md bg-jade/10 border border-jade/25 grid place-items-center text-jade shrink-0"><Icon name={ic as any} size={14} /></span>
                  <span>{t}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </aside>

      {/* Form */}
      <main className="flex items-center justify-center px-5 sm:px-10 py-9 lg:py-0">
        <div className="w-full max-w-[400px]">
          <h2 className="font-display text-[30px] font-bold tracking-tight leading-tight">Masuk ke terminal</h2>
          <p className="text-[14.5px] text-mute mt-1.5">Gunakan kode akses dari paket langganan Anda.</p>

          <form onSubmit={submit} className="mt-7 space-y-4" noValidate>
            <Field label="Nama panggilan" placeholder="Misalnya Nomir" icon="user" value={name} onChange={(e) => setName(e.target.value)} autoComplete="nickname" maxLength={40} />
            <Field
              label="Kode akses"
              placeholder="AZR_MONTH01"
              icon="key"
              type={show ? "text" : "password"}
              value={code}
              onChange={(e) => { setCode(e.target.value); setError(""); }}
              autoComplete="one-time-code"
              autoCapitalize="characters"
              spellCheck={false}
              error={error}
              trailing={
                <button type="button" onClick={() => setShow((v) => !v)} aria-label={show ? "Sembunyikan kode" : "Tampilkan kode"} className="text-faint hover:text-text cursor-pointer p-1">
                  <Icon name={show ? "eyeOff" : "eye"} size={18} />
                </button>
              }
            />
            <Button type="submit" variant="primary" size="lg" className="w-full" loading={busy}>Masuk</Button>
          </form>

          <div className="flex items-center gap-3 my-6 text-[12.5px] text-faint">
            <span className="flex-1 h-px bg-line" /> atau <span className="flex-1 h-px bg-line" />
          </div>
          <Button variant="soft" size="lg" className="w-full" onClick={loginDemo}>Lihat dulu dengan mode demo</Button>
          <p className="text-[12.5px] text-faint mt-3 text-center">Mode demo berlaku 12 jam di perangkat ini.</p>

          <p className="mt-9 pt-5 border-t border-line text-[12.5px] leading-relaxed text-faint">
            Trading emas dan kripto berisiko tinggi. Sinyal dan analisis di sini adalah alat bantu keputusan, bukan jaminan hasil. Gunakan stop loss dan risiko per transaksi yang sanggup Anda tanggung.
          </p>
        </div>
      </main>
    </div>
  );
}
