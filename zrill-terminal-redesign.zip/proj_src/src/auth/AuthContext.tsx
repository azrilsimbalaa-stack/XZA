import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

export type Session = {
  name: string;
  plan: "WEEKLY" | "BIWEEKLY" | "MONTHLY" | "DEMO" | string;
  expiresAt: number;
  token?: string;
  demo?: boolean;
};

type AuthCtx = {
  session: Session | null;
  ready: boolean;
  login: (code: string, name: string) => Promise<void>;
  loginDemo: () => void;
  logout: () => void;
};

const KEY = "zrill_session_v2";
const Ctx = createContext<AuthCtx | null>(null);

const read = (): Session | null => {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as Session;
    return s.expiresAt > Date.now() ? s : null;
  } catch {
    return null;
  }
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(() => read());
  const [ready, setReady] = useState(false);

  // Validasi ulang token ke server; kalau server tidak terjangkau, sesi lokal tetap dipakai.
  useEffect(() => {
    const s = read();
    if (!s || !s.token) { setReady(true); return; }
    fetch("/api/auth/session", { headers: { Authorization: `Bearer ${s.token}` }, signal: AbortSignal.timeout(4000) })
      .then((r) => {
        if (r.status === 401) { localStorage.removeItem(KEY); setSession(null); }
      })
      .catch(() => {})
      .finally(() => setReady(true));
  }, []);

  const persist = (s: Session | null) => {
    setSession(s);
    try { s ? localStorage.setItem(KEY, JSON.stringify(s)) : localStorage.removeItem(KEY); } catch {}
  };

  const login = useCallback(async (code: string, name: string) => {
    let res: Response;
    try {
      res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, name }),
        signal: AbortSignal.timeout(8000),
      });
    } catch {
      throw new Error("Server tidak merespons. Periksa koneksi lalu coba lagi.");
    }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Masuk gagal. Coba lagi.");
    persist({ name: data.name, plan: data.plan, expiresAt: data.expiresAt, token: data.token });
  }, []);

  const loginDemo = useCallback(() => {
    persist({ name: "Tamu", plan: "DEMO", expiresAt: Date.now() + 12 * 3600 * 1000, demo: true });
  }, []);

  const logout = useCallback(() => persist(null), []);

  const value = useMemo(() => ({ session, ready, login, loginDemo, logout }), [session, ready, login, loginDemo, logout]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth harus dipakai di dalam AuthProvider");
  return c;
}

export const PLAN_LABEL: Record<string, string> = {
  WEEKLY: "Mingguan",
  BIWEEKLY: "Dua mingguan",
  MONTHLY: "Bulanan",
  DEMO: "Demo",
};
