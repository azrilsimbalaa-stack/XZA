import { isBuySignal, isSellSignal, type SignalState } from "../TerminalCore";

export type Side = "BUY" | "SELL" | "WAIT";

export interface SignalView {
  raw: SignalState;
  side: Side;
  /** Label aksi: "Buy sekarang", "Sell limit", dll. */
  action: string;
  isLimit: boolean;
  isLive: boolean;      // ada setup valid
  entry: number;
  sl: number;
  tps: { label: string; price: number }[];
  rrNum: number | null; // reward:risk ke TP terjauh
  riskDist: number;
  confidence: number | null;
  grade: string | null;
  checks: { id: string; name: string; category: string; passed: boolean; details: string }[];
  passed: number;
  total: number;
}

const num = (v: any): number => (typeof v === "number" && isFinite(v) ? v : 0);

export function buildSignalView(sig: SignalState | undefined | null, hasValid: boolean): SignalView {
  const s = (sig || {}) as SignalState;
  const type = String(s.orderExecutionType || s.type || "WAIT");
  const buy = isBuySignal(type) || isBuySignal(s.type);
  const sell = isSellSignal(type) || isSellSignal(s.type);
  const side: Side = hasValid ? (buy ? "BUY" : sell ? "SELL" : "WAIT") : "WAIT";
  const isLimit = /LIMIT|RETEST/i.test(type);
  const entry = num(s.entry);
  const sl = num(s.sl);
  const tps = [
    { label: "TP1", price: num(s.tp1) },
    { label: "TP2", price: num(s.tp2) || num(s.tp) },
    { label: "TP3", price: num(s.tp3) },
  ].filter((t) => t.price > 0);
  const far = tps.length ? tps[tps.length - 1].price : 0;
  const riskDist = entry > 0 && sl > 0 ? Math.abs(entry - sl) : 0;
  const rrNum = riskDist > 0 && far > 0 ? Math.abs(far - entry) / riskDist : null;
  const checks = (s.confluenceChecks || []).map((c) => ({
    id: c.id, name: c.name, category: c.category, passed: c.passed, details: c.details,
  }));
  const action = !hasValid
    ? "Belum ada setup"
    : `${side === "BUY" ? "Buy" : side === "SELL" ? "Sell" : "Tunggu"}${isLimit ? " limit" : /NOW/i.test(type) ? " sekarang" : ""}`;
  return {
    raw: s, side, action, isLimit, isLive: hasValid, entry, sl, tps, rrNum, riskDist,
    confidence: typeof s.confidence === "number" && s.confidence > 0 ? Math.round(s.confidence) : null,
    grade: s.qualityGrade || null,
    checks,
    passed: checks.filter((c) => c.passed).length,
    total: checks.length,
  };
}

export const CATEGORY_LABEL: Record<string, string> = {
  STRUCTURE: "Struktur",
  LIQUIDITY: "Likuiditas",
  IMBALANCE: "Imbalance",
  MOMENTUM: "Momentum",
  RISK: "Risiko",
  TIMING: "Waktu",
  MACRO: "Makro",
};
