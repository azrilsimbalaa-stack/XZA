import { useEffect, useState } from "react";

export type Route = "ringkasan" | "chart" | "sinyal" | "kalender" | "berita" | "risiko" | "jurnal" | "pengaturan";
export const ROUTES: Route[] = ["ringkasan", "chart", "sinyal", "kalender", "berita", "risiko", "jurnal", "pengaturan"];

const parse = (): Route => {
  const h = window.location.hash.replace(/^#\/?/, "") as Route;
  return ROUTES.includes(h) ? h : "ringkasan";
};

export function useRoute(): [Route, (r: Route) => void] {
  const [route, setRoute] = useState<Route>(parse);
  useEffect(() => {
    const on = () => { setRoute(parse()); window.scrollTo({ top: 0 }); };
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return [route, (r) => { window.location.hash = `/${r}`; }];
}
