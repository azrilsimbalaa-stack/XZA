import { witaParts } from "./format";

export type Ev = any; // UpgradedEconomicEvent dari server

export const dayKey = (d: Date | number | string) => witaParts(new Date(d)).key;

export function groupByDay(events: Ev[]): Map<string, Ev[]> {
  const m = new Map<string, Ev[]>();
  [...events]
    .sort((a, b) => +new Date(a.date) - +new Date(b.date))
    .forEach((e) => {
      const k = dayKey(e.date);
      if (!m.has(k)) m.set(k, []);
      m.get(k)!.push(e);
    });
  return m;
}

export interface Cell { key: string; day: number; inMonth: boolean }

/** Grid bulan (minggu mulai Senin). month: 0-11 */
export function monthGrid(year: number, month: number): Cell[][] {
  const first = new Date(Date.UTC(year, month, 1));
  const startDow = (first.getUTCDay() + 6) % 7; // Senin=0
  const dim = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
  const cells: Cell[] = [];
  const pad = (n: number) => String(n).padStart(2, "0");
  for (let i = 0; i < startDow; i++) {
    const d = new Date(Date.UTC(year, month, 1 - (startDow - i)));
    cells.push({ key: `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`, day: d.getUTCDate(), inMonth: false });
  }
  for (let d = 1; d <= dim; d++) cells.push({ key: `${year}-${pad(month + 1)}-${pad(d)}`, day: d, inMonth: true });
  while (cells.length % 7 !== 0) {
    const n = cells.length - (startDow + dim) + 1;
    const d = new Date(Date.UTC(year, month + 1, n));
    cells.push({ key: `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`, day: d.getUTCDate(), inMonth: false });
  }
  const weeks: Cell[][] = [];
  for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));
  return weeks;
}

export const MONTHS = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
export const DOW = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"];

export const topImpact = (evs: Ev[] | undefined): number | null =>
  !evs || evs.length === 0 ? null : evs.some((e) => e.importance === 1) ? 1 : evs.some((e) => e.importance === 0) ? 0 : -1;

export interface Surprise { kind: "above" | "below" | "inline"; delta: number }
export function surpriseOf(e: Ev): Surprise | null {
  if (!e.isReleased || e.actual === null || e.actual === undefined) return null;
  const a = parseFloat(e.actual), f = parseFloat(e.forecast);
  if (!isFinite(a) || !isFinite(f)) return null;
  const d = +(a - f).toFixed(3);
  return { kind: Math.abs(d) < 1e-9 ? "inline" : d > 0 ? "above" : "below", delta: d };
}

export const val = (v: any, unit = "") => (v === null || v === undefined || v === "" || v === "---" ? "—" : `${v}${unit}`);

/** Pembacaan bias emas dalam bahasa sederhana. */
export function goldRead(e: Ev): { tone: "jade" | "coral"; text: string } {
  const up = e.marketOutcome?.goldImpact === "BUY";
  const usd = e.marketOutcome?.dxyEffect === "BULLISH_USD" ? "USD menguat" : e.marketOutcome?.dxyEffect === "BEARISH_USD" ? "USD melemah" : "USD datar";
  const pre = e.isReleased ? "" : "condong ";
  return { tone: up ? "jade" : "coral", text: `${usd}, emas ${pre}${up ? "naik" : "turun"}` };
}
