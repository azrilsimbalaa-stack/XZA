export const isBtc = (id?: string) => String(id || "").toUpperCase().includes("BTC");

export function fmtPrice(v: number | null | undefined, id?: string): string {
  if (v === null || v === undefined || !isFinite(v) || v === 0) return "—";
  return v.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export function fmtMoney(v: number, currency = "USD"): string {
  const sign = v < 0 ? "-" : "";
  const abs = Math.abs(v);
  if (currency === "IDR") return `${sign}Rp${Math.round(abs).toLocaleString("id-ID")}`;
  return `${sign}$${abs.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export const WITA = "Asia/Makassar";

export function witaParts(d: Date | number) {
  const f = new Intl.DateTimeFormat("id-ID", {
    timeZone: WITA, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
  });
  const o: Record<string, string> = {};
  f.formatToParts(new Date(d)).forEach((p) => { o[p.type] = p.value; });
  return {
    y: +o.year, m: +o.month, d: +o.day,
    hh: +o.hour % 24, mm: +o.minute, ss: +o.second,
    key: `${o.year}-${o.month}-${o.day}`,
  };
}

export const witaTime = (d: Date | number, withSec = false) =>
  new Intl.DateTimeFormat("id-ID", {
    timeZone: WITA, hour: "2-digit", minute: "2-digit",
    ...(withSec ? { second: "2-digit" } : {}), hour12: false,
  }).format(new Date(d)).replace(".", ":").replace(".", ":");

export const witaDayLabel = (d: Date | number) =>
  new Intl.DateTimeFormat("id-ID", { timeZone: WITA, weekday: "long", day: "numeric", month: "long" }).format(new Date(d));

export function countdown(ms: number): string {
  if (ms <= 0) return "sekarang";
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (d > 0) return `${d}h ${h}j`;
  if (h > 0) return `${h}j ${m}m`;
  return `${m}m ${String(sec).padStart(2, "0")}d`;
}

export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(" ");
