import { useT } from "../TerminalContext";
import { Route } from "../lib/router";
import { TradingChart, TIMEFRAMES, SIGNAL_METHODS } from "../TerminalCore";
import { ChartPatternPredictionCard } from "../components/ChartPatternPredictionCard";
import SignalTicket, { AnalyzeButton } from "../ui/SignalTicket";
import { Segmented, Section } from "../ui/kit";
import { biasLabel, biasTone } from "../ui/bits";
import { cx } from "../lib/format";

export default function ChartPage({ active }: { go: (r: Route) => void; active: boolean }) {
  const T = useT();
  const ind = T.indicators || {};

  return (
    <div className="grid gap-4 xl:grid-cols-[1fr_380px]">
      <div className="min-w-0 grid gap-4 content-start">
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="overflow-x-auto max-w-full">
            <Segmented
              value={T.activeTimeframe.id}
              onChange={(id) => {
                const tf = TIMEFRAMES.find((x) => x.id === id);
                if (tf) { T.setActiveTimeframe(tf); T.setCurrentPrice({ bid: 0, ask: 0 }); }
              }}
              options={TIMEFRAMES.map((t) => ({ value: t.id, label: t.id }))}
            />
          </div>
          <label className="sr-only" htmlFor="method">Metode sinyal</label>
          <select
            id="method"
            value={T.signalMethod}
            onChange={(e) => T.setSignalMethod(e.target.value)}
            className="h-9 max-w-[220px] rounded-xl bg-abyss border border-line px-3 text-[13px] text-text outline-none focus:border-gold/70 cursor-pointer"
          >
            {SIGNAL_METHODS.map((m) => (
              <option key={m.id} value={m.id}>{m.label.split(":")[0].split("(")[0].trim()}</option>
            ))}
          </select>
          <div className="ml-auto xl:hidden"><AnalyzeButton size="sm" /></div>
        </div>

        <div className="rounded-2xl border border-line overflow-hidden bg-panel h-[54vh] min-h-[380px] lg:h-[580px] relative">
          <TradingChart
            symbol={T.activeSymbol}
            timeframe={T.activeTimeframe}
            priceOffset={T.priceOffset}
            onPriceUpdate={T.handlePriceUpdate}
            onIndicatorUpdate={T.setIndicators}
            onStatusUpdate={T.setMt5Status}
            onSelectSymbol={(s: any) => { T.setActiveSymbol(s); T.setCurrentPrice({ bid: 0, ask: 0 }); }}
            currentSignal={T.currentSignal}
            isGeneratingSignal={T.isGeneratingSignal}
            isLowSpecMode={true}
          />
        </div>

        <div className="surface px-4 py-3 grid grid-cols-3 sm:grid-cols-6 gap-x-4 gap-y-3 text-[12.5px]">
          {[
            ["Bias tinggi", <span className={cx("font-medium", biasTone(T.htfData?.overall))}>{biasLabel(T.htfData?.overall)}</span>],
            ["Bias rendah", <span className={cx("font-medium", biasTone(T.ltfData?.overall))}>{biasLabel(T.ltfData?.overall)}</span>],
            ["EMA 20", <span className="num">{Number(ind.ema20 || 0).toFixed(2)}</span>],
            ["EMA 50", <span className="num">{Number(ind.ema50 || 0).toFixed(2)}</span>],
            ["RSI 14", <span className="num">{Number(ind.rsi || 0).toFixed(0)}</span>],
            ["ATR", <span className="num">{Number(ind.atr || 0).toFixed(2)}</span>],
          ].map(([k, v], i) => (
            <div key={i}><div className="text-faint">{k as string}</div><div className="text-[14px] mt-0.5">{v}</div></div>
          ))}
        </div>

        {active && (
          <Section title="Pola chart klasik" pad={false}>
            <ChartPatternPredictionCard
              activePattern={ind?.activeClassicPattern || ind?.classicPatterns?.[0] || null}
              allPatterns={ind?.classicPatterns || []}
              currentPrice={T.currentPrice?.bid || T.currentSignal.entry || 0}
              symbol={T.activeSymbol.id}
              timeframe={T.activeTimeframe.id}
              notificationEnabled={T.patternNotificationEnabled}
              onToggleNotification={T.handleTogglePatternNotification}
              onTestNotification={T.handleTestPatternNotification}
            />
          </Section>
        )}
      </div>

      <div className="hidden xl:grid gap-4 content-start sticky top-[72px] self-start">
        <AnalyzeButton size="lg" className="w-full" />
        <SignalTicket compact />
      </div>
      <div className="xl:hidden"><SignalTicket compact /></div>
    </div>
  );
}
