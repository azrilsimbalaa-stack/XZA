import { useEffect, useMemo, useState } from "react";
import { useT } from "../TerminalContext";
import { Badge, Button, Segmented, Section, Empty } from "../ui/kit";
import { Icon } from "../ui/Icon";
import { ImpactDot, impactLabel } from "../ui/bits";
import { cx, countdown, witaTime, witaDayLabel, witaParts } from "../lib/format";
import { DOW, MONTHS, dayKey, goldRead, groupByDay, monthGrid, surpriseOf, topImpact, val, Ev } from "../lib/calendarModel";

type ImpactF = "all" | "1" | "0";
type StatusF = "all" | "upcoming" | "released";

export default function KalenderPage() {
  const T = useT();
  const nowKey = dayKey(T.nowTicker);
  const [sel, setSel] = useState(nowKey);
  const [view, setView] = useState(() => { const p = witaParts(Date.now()); return { y: p.y, m: p.m - 1 }; });
  const [impact, setImpact] = useState<ImpactF>("all");
  const [status, setStatus] = useState<StatusF>("all");
  const [open, setOpen] = useState<Set<string>>(new Set());

  const events = T.economicEvents as Ev[];
  const filtered = useMemo(
    () => events.filter((e) => {
      if (impact === "1" && e.importance !== 1) return false;
      if (impact === "0" && e.importance !== 0) return false;
      if (status === "upcoming" && e.isReleased) return false;
      if (status === "released" && !e.isReleased) return false;
      return true;
    }),
    [events, impact, status],
  );
  const byDay = useMemo(() => groupByDay(filtered), [filtered]);
  const allByDay = useMemo(() => groupByDay(events), [events]);
  const dayEvents = byDay.get(sel) || [];

  const next = useMemo(
    () => events.filter((e) => !e.isReleased && +new Date(e.date) > T.nowTicker).sort((a, b) => +new Date(a.date) - +new Date(b.date)),
    [events, T.nowTicker],
  );
  const nextHigh = next.find((e) => e.importance === 1) || next[0];

  const weeks = useMemo(() => monthGrid(view.y, view.m), [view]);
  const shiftMonth = (d: number) => setView((v) => { const n = v.m + d; return n < 0 ? { y: v.y - 1, m: 11 } : n > 11 ? { y: v.y + 1, m: 0 } : { y: v.y, m: n }; });
  const goToday = () => { const p = witaParts(Date.now()); setView({ y: p.y, m: p.m - 1 }); setSel(nowKey); };

  // Strip hari (mobile): hari dengan data + hari ini
  const stripDays = useMemo(() => {
    const keys = new Set<string>([nowKey, ...allByDay.keys()]);
    return [...keys].sort().slice(0, 9);
  }, [allByDay, nowKey]);

  useEffect(() => {
    if (!allByDay.has(sel) && allByDay.size > 0 && sel === nowKey) {
      /* tetap di hari ini; empty state menjelaskan cakupan data */
    }
  }, [allByDay, sel, nowKey]);

  const toggle = (id: string) => setOpen((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const syncAgo = Math.max(0, Math.floor((T.nowTicker - T.calendarLastSync) / 1000));

  const selDate = (() => { const [y, m, d] = sel.split("-").map(Number); return new Date(Date.UTC(y, m - 1, d, 4)); })(); // 12:00 WITA
  const isToday = sel === nowKey;
  const nowMs = T.nowTicker;
  const highCount = dayEvents.filter((e) => e.importance === 1).length;

  return (
    <div className="grid gap-4">
      {T.calendarMeta.isSample && (
        <div className="rounded-2xl border border-gold/35 bg-gold/8 px-4 py-3 flex gap-3 text-[13.5px]" role="status">
          <Icon name="alert" size={18} className="text-gold shrink-0 mt-0.5" />
          <p><span className="font-medium text-gold">Ini jadwal contoh.</span> Feed kalender live tidak terjangkau dari server, jadi angka rilis di bawah bukan data resmi. Jangan dipakai untuk keputusan trading.</p>
        </div>
      )}

      {/* Rilis berikutnya */}
      <section className="surface relative overflow-hidden">
        <span className={cx("absolute left-0 top-0 bottom-0 w-1", nextHigh?.importance === 1 ? "bg-gold" : "bg-sky")} />
        <div className="p-4 sm:p-5 pl-5 sm:pl-6 flex flex-wrap items-center gap-x-8 gap-y-3">
          {nextHigh ? (
            <>
              <div className="min-w-0 flex-1 basis-[260px]">
                <div className="flex items-center gap-2 text-[12.5px] text-mute"><ImpactDot level={nextHigh.importance} /> Rilis berikutnya · {impactLabel(nextHigh.importance)}</div>
                <h2 className="font-display text-[20px] sm:text-[22px] font-semibold leading-tight mt-1">{nextHigh.title}</h2>
                <p className="text-[13px] text-faint mt-1 num">{witaDayLabel(nextHigh.date)} · {witaTime(nextHigh.date)} WITA · forecast {val(nextHigh.forecast, nextHigh.unit)} · sebelumnya {val(nextHigh.previous, nextHigh.unit)}</p>
              </div>
              <div className="text-right">
                <div className="text-[12px] text-mute">Rilis dalam</div>
                <div className={cx("num font-display text-[34px] font-semibold leading-none mt-1", nextHigh.importance === 1 && "text-gold")}>{countdown(+new Date(nextHigh.date) - nowMs)}</div>
              </div>
            </>
          ) : (
            <p className="text-[14px] text-mute">Tidak ada rilis USD yang menunggu dalam jangkauan data saat ini.</p>
          )}
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-[336px_1fr] items-start">
        {/* Kiri: bulan + filter */}
        <div className="grid gap-4 lg:sticky lg:top-[72px]">
          <section className="surface p-4 hidden lg:block">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display text-[16px] font-semibold">{MONTHS[view.m]} {view.y}</h3>
              <div className="flex items-center gap-1">
                <button onClick={() => shiftMonth(-1)} aria-label="Bulan sebelumnya" className="w-8 h-8 grid place-items-center rounded-lg text-mute hover:text-text hover:bg-raised cursor-pointer"><Icon name="chevronLeft" size={17} /></button>
                <button onClick={() => shiftMonth(1)} aria-label="Bulan berikutnya" className="w-8 h-8 grid place-items-center rounded-lg text-mute hover:text-text hover:bg-raised cursor-pointer"><Icon name="chevronRight" size={17} /></button>
              </div>
            </div>
            <div className="grid grid-cols-7 text-center text-[11.5px] text-faint mb-1.5">{DOW.map((d) => <span key={d}>{d}</span>)}</div>
            <div className="grid grid-cols-7 gap-y-1">
              {weeks.flat().map((c) => {
                const evs = allByDay.get(c.key);
                const top = topImpact(byDay.get(c.key));
                const isSel = c.key === sel;
                const isNow = c.key === nowKey;
                return (
                  <button
                    key={c.key}
                    onClick={() => setSel(c.key)}
                    aria-label={`${c.day} ${MONTHS[view.m]}${evs ? `, ${evs.length} rilis` : ""}`}
                    aria-pressed={isSel}
                    className={cx(
                      "relative h-11 mx-auto w-11 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[13.5px] cursor-pointer transition-colors",
                      !c.inMonth && "text-gray-600",
                      c.inMonth && !isSel && "hover:bg-raised",
                      isSel ? "bg-raised text-text shadow-[inset_0_0_0_1.5px_var(--color-jade)]" : isNow ? "text-gold font-semibold shadow-[inset_0_0_0_1px_var(--color-gold)]" : "text-gray-200",
                    )}
                  >
                    <span className="num leading-none">{c.day}</span>
                    <span className="h-1.5 flex items-center">{top !== null && <ImpactDot level={top} className="!w-1.5 !h-1.5" />}</span>
                  </button>
                );
              })}
            </div>
            <div className="flex items-center justify-between mt-3 pt-3 border-t border-line text-[12px] text-faint">
              <span className="flex items-center gap-3"><span className="flex items-center gap-1.5"><ImpactDot level={1} /> Tinggi</span><span className="flex items-center gap-1.5"><ImpactDot level={0} /> Sedang</span><span className="flex items-center gap-1.5"><ImpactDot level={-1} /> Rendah</span></span>
              <Button size="sm" variant="ghost" onClick={goToday}>Hari ini</Button>
            </div>
          </section>

          <section className="surface p-4 grid gap-3">
            <div>
              <div className="text-[12.5px] text-mute mb-1.5">Dampak</div>
              <Segmented size="sm" value={impact} onChange={setImpact} options={[{ value: "all", label: "Semua" }, { value: "1", label: "Tinggi" }, { value: "0", label: "Sedang" }]} />
            </div>
            <div>
              <div className="text-[12.5px] text-mute mb-1.5">Status</div>
              <Segmented size="sm" value={status} onChange={setStatus} options={[{ value: "all", label: "Semua" }, { value: "upcoming", label: "Menunggu" }, { value: "released", label: "Sudah rilis" }]} />
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-line text-[12px] text-faint">
              <span className="num">Diperbarui {syncAgo} detik lalu</span>
              <Button size="sm" variant="ghost" icon="refresh" loading={T.isCalendarSyncing} onClick={() => T.fetchCalendar()}>Muat ulang</Button>
            </div>
          </section>
        </div>

        {/* Kanan: agenda */}
        <div className="min-w-0 grid gap-3">
          {/* Strip hari (mobile) */}
          <div className="lg:hidden -mx-4 px-4 overflow-x-auto flex gap-2 pb-1">
            {stripDays.map((k) => {
              const [y, m, d] = k.split("-").map(Number);
              const dt = new Date(Date.UTC(y, m - 1, d, 4));
              const top = topImpact(byDay.get(k));
              const on = k === sel;
              return (
                <button key={k} onClick={() => setSel(k)} aria-pressed={on} className={cx("shrink-0 w-[58px] py-2 rounded-2xl border text-center cursor-pointer", on ? "bg-raised border-jade" : "bg-panel border-line")}>
                  <div className={cx("text-[11.5px]", k === nowKey ? "text-gold" : "text-faint")}>{new Intl.DateTimeFormat("id-ID", { timeZone: "Asia/Makassar", weekday: "short" }).format(dt)}</div>
                  <div className="num font-display text-[19px] font-semibold leading-tight">{d}</div>
                  <div className="h-2 flex justify-center items-center">{top !== null && <ImpactDot level={top} />}</div>
                </button>
              );
            })}
          </div>

          <div className="flex items-end justify-between gap-3 px-1">
            <div>
              <h2 className="font-display text-[22px] font-semibold tracking-tight capitalize">{witaDayLabel(selDate)}</h2>
              <p className="text-[13px] text-mute mt-0.5">
                {dayEvents.length === 0 ? "Tidak ada rilis" : `${dayEvents.length} rilis`}{highCount > 0 && <> · <span className="text-gold">{highCount} berdampak tinggi</span></>} · waktu WITA
              </p>
            </div>
          </div>

          {dayEvents.length === 0 ? (
            <section className="surface">
              <Empty icon="calendar" title="Tidak ada rilis di hari ini">
                {allByDay.size === 0
                  ? "Data kalender belum termuat. Coba muat ulang."
                  : "Feed mencakup 36 jam ke belakang sampai 5 hari ke depan, dan filter aktif bisa menyembunyikan sebagian rilis."}
              </Empty>
            </section>
          ) : (
            <ol className="relative grid gap-3 pl-[74px] sm:pl-[88px]">
              <span className="absolute left-[60px] sm:left-[72px] top-3 bottom-3 w-px bg-line" aria-hidden="true" />
              {dayEvents.map((e, i) => {
                const t = +new Date(e.date);
                const showNow = isToday && t > nowMs && (i === 0 || +new Date(dayEvents[i - 1].date) <= nowMs);
                const sur = surpriseOf(e);
                const read = goldRead(e);
                const isOpen = open.has(e.id);
                const sp = e.spikePrediction, pb = e.prediction?.peganganKuat;
                return (
                  <li key={e.id} className="relative">
                    {showNow && (
                      <div className="absolute -left-[74px] sm:-left-[88px] right-0 -top-[13px] flex items-center gap-2 text-[11.5px] text-gold font-medium pointer-events-none" aria-label="Sekarang">
                        <span className="w-[60px] sm:w-[72px] text-right num">{witaTime(nowMs)}</span>
                        <span className="h-px flex-1 bg-gold/60" />
                        <span className="bg-abyss px-1.5">sekarang</span>
                      </div>
                    )}
                    <div className="absolute -left-[74px] sm:-left-[88px] top-4 w-[52px] sm:w-[64px] text-right">
                      <div className={cx("num text-[14px] font-semibold", e.isReleased ? "text-mute" : "text-text")}>{witaTime(e.date)}</div>
                    </div>
                    <span className={cx("absolute -left-[18px] sm:-left-[20px] top-[22px] w-2.5 h-2.5 rounded-full ring-4 ring-abyss", e.importance === 1 ? "bg-gold" : e.importance === 0 ? "bg-sky" : "bg-faint", e.isReleased && "opacity-55")} />

                    <article className={cx("surface overflow-hidden", e.isReleased && "bg-[#0b1118]")}>
                      <button onClick={() => toggle(e.id)} aria-expanded={isOpen} className="w-full text-left p-4 cursor-pointer">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <h3 className="text-[15px] font-medium leading-snug">{e.title}</h3>
                            <div className="flex flex-wrap items-center gap-1.5 mt-2">
                              <Badge tone={e.importance === 1 ? "gold" : e.importance === 0 ? "sky" : "mute"}>{impactLabel(e.importance)}</Badge>
                              {e.isReleased ? <Badge>Sudah rilis</Badge> : <Badge tone="mute"><Icon name="clock" size={11} />{countdown(t - nowMs)}</Badge>}
                              {sur && <Badge tone="sky">{sur.kind === "inline" ? "Sesuai forecast" : sur.kind === "above" ? "Di atas forecast" : "Di bawah forecast"}</Badge>}
                            </div>
                          </div>
                          <Icon name="chevronDown" size={18} className={cx("text-faint shrink-0 mt-1 transition-transform", isOpen && "rotate-180")} />
                        </div>

                        <dl className="grid grid-cols-3 gap-3 mt-4">
                          {[
                            ["Aktual", val(e.actual, e.unit), e.isReleased],
                            ["Forecast", val(e.forecast, e.unit), false],
                            ["Sebelumnya", val(e.previous, e.unit), false],
                          ].map(([k, v, strong]) => (
                            <div key={k as string} className={cx("rounded-xl px-3 py-2 border", strong ? "bg-abyss border-line" : "border-transparent bg-raised/50")}>
                              <dt className="text-[11.5px] text-faint">{k as string}</dt>
                              <dd className={cx("num font-display text-[18px] font-semibold mt-0.5", strong && v !== "—" && "text-text", v === "—" && "text-faint")}>{v as string}</dd>
                            </div>
                          ))}
                        </dl>

                        <p className={cx("mt-3 text-[13px] flex items-center gap-2", read.tone === "jade" ? "text-jade" : "text-coral")}>
                          <Icon name={read.tone === "jade" ? "trendUp" : "trendDown"} size={15} /> {read.text}
                        </p>
                      </button>

                      {isOpen && (
                        <div className="border-t border-line p-4 grid gap-4 bg-abyss/40">
                          {pb?.scenarioPlaybook && (
                            <div>
                              <h4 className="text-[13px] font-medium mb-2">Skenario saat rilis</h4>
                              <div className="grid sm:grid-cols-3 gap-2">
                                {([
                                  ["Lebih panas dari forecast", pb.scenarioPlaybook.hot],
                                  ["Sesuai forecast", pb.scenarioPlaybook.inline],
                                  ["Lebih lemah dari forecast", pb.scenarioPlaybook.soft],
                                ] as const).map(([lbl, s]: any) => (
                                  <div key={lbl} className="rounded-xl border border-line p-3 bg-panel">
                                    <div className="text-[12px] text-mute">{lbl}</div>
                                    <div className={cx("text-[13px] font-medium mt-1", /BUY/.test(s.actionBias) ? "text-jade" : /SELL/.test(s.actionBias) ? "text-coral" : "text-gold")}>
                                      {s.actionBias.replace("STRONG ", "").replace("NEUTRAL / WHIPSAW", "Netral, rawan whipsaw").replace("BUY", "Emas naik").replace("SELL", "Emas turun")}
                                    </div>
                                    <p className="text-[12.5px] text-faint mt-1 leading-snug">{s.marketReaction}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          <div className="grid sm:grid-cols-2 gap-4 text-[13px]">
                            {sp && (
                              <div>
                                <h4 className="font-medium mb-1.5">Volatilitas</h4>
                                <p className="text-mute leading-snug">Potensi lonjakan <span className="text-text">{String(sp.spikeLevel).replace("SPIKE ", "").toLowerCase()}</span>, puncaknya {sp.peakVolatilityWindow}.</p>
                                <p className="text-faint leading-snug mt-1.5">{sp.preReleaseStrategy}</p>
                              </div>
                            )}
                            {pb?.riskGuardPillar && (
                              <div>
                                <h4 className="font-medium mb-1.5">Batas risiko</h4>
                                <p className="text-mute leading-snug">{pb.riskGuardPillar.invalidationRule}</p>
                              </div>
                            )}
                          </div>
                          <p className="text-[12px] text-faint leading-snug">{e.verdictSummary}</p>
                        </div>
                      )}
                    </article>
                  </li>
                );
              })}
            </ol>
          )}

          <p className="text-[12px] text-faint px-1 leading-relaxed">
            Bias emas dibaca dari selisih aktual terhadap forecast dan jenis indikatornya, misalnya CPI lebih tinggi berarti USD menguat dan emas tertekan. Ini pembacaan awal, bukan prediksi harga. Sumber: {T.calendarMeta.source || "memuat…"}.
          </p>
        </div>
      </div>
    </div>
  );
}
