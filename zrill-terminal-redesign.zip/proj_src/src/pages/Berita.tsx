import { useState } from "react";
import { useT } from "../TerminalContext";
import { Section, Segmented, Badge, Empty, Button } from "../ui/kit";
import { Icon } from "../ui/Icon";

const ago = (ms: number) => {
  const m = Math.max(0, Math.round((Date.now() - ms) / 60000));
  if (m < 1) return "baru saja";
  if (m < 60) return `${m} menit lalu`;
  const h = Math.round(m / 60);
  return h < 24 ? `${h} jam lalu` : `${Math.round(h / 24)} hari lalu`;
};
const tone = (s: string) => (/BULL/.test(s) && !/USD_BULL/.test(s) ? "jade" : /BEAR/.test(s) && !/USD_BEAR/.test(s) ? "coral" : "mute");
const label = (s: string) =>
  s === "BULLISH" ? "Nada positif" : s === "BEARISH" ? "Nada negatif" : s === "USD_BULLISH" ? "Nada USD kuat" : s === "USD_BEARISH" ? "Nada USD lemah" : "Netral";

export default function BeritaPage() {
  const T = useT();
  const [tab, setTab] = useState<"forex" | "crypto">(T.activeSymbol.id === "BTCUSD" ? "crypto" : "forex");
  const list = ((tab === "forex" ? T.forexNewsList : T.cryptoNewsList) as any[]).filter((n) => n.live);

  return (
    <div className="grid gap-4 max-w-3xl">
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <Segmented value={tab} onChange={setTab} options={[{ value: "forex", label: "Forex dan emas" }, { value: "crypto", label: "Kripto" }]} />
        <Button size="sm" variant="ghost" icon="refresh" onClick={T.handleSyncUsDiscourse} loading={T.isSyncingUsDiscourse}>Muat ulang</Button>
      </div>

      <Section pad={false}>
        {list.length === 0 ? (
          <Empty icon="newspaper" title="Belum ada berita live">
            Server belum berhasil mengambil headline dari sumbernya. Berita contoh sengaja tidak ditampilkan supaya tidak menyesatkan.
          </Empty>
        ) : (
          <ul className="divide-y divide-line">
            {list.map((n) => (
              <li key={n.id}>
                <a href={n.url} target="_blank" rel="noopener noreferrer" className="block px-4 py-4 hover:bg-raised/50 transition-colors">
                  <div className="flex items-center gap-2 text-[12.5px] text-faint">
                    <span>{n.source}</span><span>·</span><span>{ago(n.publishedAt)}</span>
                    <Badge tone={tone(n.sentiment) as any} className="ml-auto">{label(n.sentiment)}</Badge>
                  </div>
                  <h3 className="text-[15.5px] font-medium leading-snug mt-1.5">{n.title}</h3>
                  {n.body && n.body !== n.title && <p className="text-[13.5px] text-mute leading-snug mt-1.5 line-clamp-2">{n.body}</p>}
                  <span className="inline-flex items-center gap-1 text-[12.5px] text-sky mt-2">Baca di sumber <Icon name="arrowUpRight" size={13} /></span>
                </a>
              </li>
            ))}
          </ul>
        )}
      </Section>
      <p className="text-[12px] text-faint leading-relaxed">
        Label nada dihitung otomatis dari kata kunci pada judul dan ringkasan, jadi hanya gambaran kasar. Baca artikelnya sebelum mengambil keputusan.
      </p>
    </div>
  );
}
