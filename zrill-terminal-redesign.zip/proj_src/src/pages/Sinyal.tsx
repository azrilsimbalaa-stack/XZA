import { useMemo, useState } from "react";
import { useT } from "../TerminalContext";
import { Route } from "../lib/router";
import SignalTicket, { AnalyzeButton, useSignalView } from "../ui/SignalTicket";
import { Section, Badge, Button } from "../ui/kit";
import { Icon } from "../ui/Icon";
import { CATEGORY_LABEL } from "../lib/signal";
import { RetestAdvisoryModal } from "../components/RetestAdvisoryModal";
import { isBuySignal, copyToClipboardSafely } from "../TerminalCore";
import { cx, fmtPrice } from "../lib/format";

const EXEC_LABEL: [string, string][] = [
  ["htfBias", "Bias timeframe tinggi"],
  ["liquidityTrap", "Jebakan likuiditas"],
  ["ltfTrigger", "Pemicu timeframe rendah"],
  ["riskManagement", "Manajemen risiko"],
];

export default function SinyalPage({ go }: { go: (r: Route) => void }) {
  const T = useT();
  const v = useSignalView();
  const [openCheck, setOpenCheck] = useState<string | null>(null);
  const sig: any = T.currentSignal;

  const groups = useMemo(() => {
    const m = new Map<string, typeof v.checks>();
    v.checks.forEach((c) => { if (!m.has(c.category)) m.set(c.category, []); m.get(c.category)!.push(c); });
    return [...m.entries()];
  }, [v.checks]);

  const matrix = sig?.timeframeMatrix ? Object.entries(sig.timeframeMatrix as Record<string, any>) : [];

  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-center gap-3">
        <p className="text-[14px] text-mute flex-1 min-w-[240px]">
          Setup untuk <span className="text-text font-medium">{T.activeSymbol.id}</span> di {T.activeTimeframe.id}. Selalu cek apakah risikonya masuk akal sebelum eksekusi.
        </p>
        <AnalyzeButton />
        <Button variant="soft" icon="calculator" onClick={() => go("risiko")} disabled={!v.isLive}>Hitung lot</Button>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)] items-start">
        <div className="grid gap-4">
          <SignalTicket />
          {v.isLive && sig?.optimalRetestAdvisory && (
            <Button variant="soft" icon="target" onClick={() => T.setIsRetestModalOpen(true)}>Lihat saran harga retest</Button>
          )}
        </div>

        <div className="grid gap-4">
          {v.isLive && (
            <Section title="Alasan setup">
              {sig?.analysis && <p className="text-[14px] text-gray-200 leading-relaxed whitespace-pre-line">{String(sig.analysis).slice(0, 700)}</p>}
              {sig?.executionLogic && (
                <dl className="mt-4 grid gap-3 sm:grid-cols-2">
                  {EXEC_LABEL.filter(([k]) => sig.executionLogic[k]).map(([k, label]) => (
                    <div key={k} className="rounded-xl border border-line bg-abyss/50 p-3">
                      <dt className="text-[12px] text-mute">{label}</dt>
                      <dd className="text-[13px] mt-1 leading-snug">{String(sig.executionLogic[k]).slice(0, 220)}</dd>
                    </div>
                  ))}
                </dl>
              )}
            </Section>
          )}

          {groups.length > 0 && (
            <Section title="Daftar periksa konfluensi" aside={<Badge tone={v.passed / Math.max(1, v.total) >= 0.7 ? "jade" : "gold"}>{v.passed} dari {v.total} terpenuhi</Badge>} pad={false}>
              <div className="divide-y divide-line">
                {groups.map(([cat, items]) => (
                  <div key={cat} className="px-4 py-3">
                    <div className="text-[12.5px] text-mute mb-1.5">{CATEGORY_LABEL[cat] || cat}</div>
                    <ul className="grid gap-0.5">
                      {items.map((c) => (
                        <li key={c.id}>
                          <button onClick={() => setOpenCheck(openCheck === c.id ? null : c.id)} className="w-full flex items-start gap-2.5 text-left py-1.5 cursor-pointer" aria-expanded={openCheck === c.id}>
                            <span className={cx("mt-0.5 w-[18px] h-[18px] rounded-full grid place-items-center shrink-0", c.passed ? "bg-jade/15 text-jade" : "bg-coral/12 text-coral")}>
                              <Icon name={c.passed ? "check" : "x"} size={11} strokeWidth={2.4} />
                            </span>
                            <span className={cx("text-[13.5px] leading-snug", c.passed ? "text-text" : "text-mute")}>{c.name}</span>
                          </button>
                          {openCheck === c.id && <p className="text-[12.5px] text-faint leading-snug pl-[28px] pb-2">{c.details}</p>}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </Section>
          )}

          {matrix.length > 0 && (
            <Section title="Setup per timeframe" pad={false}>
              <div className="overflow-x-auto">
                <table className="w-full text-[13px] num">
                  <thead>
                    <tr className="text-left text-faint text-[12px]">
                      <th className="font-normal px-4 py-2.5">TF</th><th className="font-normal px-2">Arah</th><th className="font-normal px-2 text-right">Entry</th><th className="font-normal px-2 text-right">SL</th><th className="font-normal px-4 text-right">TP2</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {matrix.map(([tf, p]: [string, any]) => (
                      <tr key={tf} className={cx(tf === T.activeTimeframe.id && "bg-raised/60")}>
                        <td className="px-4 py-2.5 font-medium">{tf}</td>
                        <td className={cx("px-2", isBuySignal(p.type) ? "text-jade" : "text-coral")}>{isBuySignal(p.type) ? "Buy" : "Sell"}</td>
                        <td className="px-2 text-right">{fmtPrice(p.entry)}</td>
                        <td className="px-2 text-right text-coral">{fmtPrice(p.sl)}</td>
                        <td className="px-4 text-right text-jade">{fmtPrice(p.tp2 || p.tp)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Section>
          )}
        </div>
      </div>

      <RetestAdvisoryModal
        isOpen={T.isRetestModalOpen}
        onClose={() => T.setIsRetestModalOpen(false)}
        advisory={sig?.optimalRetestAdvisory}
        goldenZoneQuality={sig?.goldenZone0618Quality}
        amdAnalysis={sig?.amdPhaseAnalysis}
        zrillCore={sig?.zrillV5Core}
        symbol={T.activeSymbol.name}
        currentPrice={T.currentPrice?.bid || sig?.entry || 0}
        isOrderBuy={isBuySignal(sig?.type)}
        fibMatrix={sig?.mathematicalAreas?.fibonacciMatrix}
        onApplyLimitOrder={(limitPrice: number) => {
          copyToClipboardSafely(limitPrice.toFixed(2));
          T.setCopiedRetestStatus("SUCCESS");
          setTimeout(() => T.setCopiedRetestStatus("IDLE"), 2500);
        }}
        copyToClipboard={copyToClipboardSafely}
      />
    </div>
  );
}
