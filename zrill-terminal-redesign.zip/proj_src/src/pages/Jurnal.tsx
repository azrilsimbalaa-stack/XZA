import { useState } from "react";
import { useT } from "../TerminalContext";
import { Section, Stat, Badge, Button, Sheet, Empty, Segmented, Field } from "../ui/kit";
import { Icon } from "../ui/Icon";
import { cx, fmtMoney, fmtPrice } from "../lib/format";
import { isBuySignal } from "../TerminalCore";

const RES: Record<string, { label: string; tone: "jade" | "coral" | "gold" | "mute" }> = {
  WIN: { label: "Menang", tone: "jade" },
  LOSS: { label: "Kalah", tone: "coral" },
  BREAKEVEN: { label: "Impas", tone: "gold" },
  EVALUATION_PENDING: { label: "Belum dinilai", tone: "mute" },
};

export default function JurnalPage() {
  const T = useT();
  const trades = T.sessionTrades as any[];
  const [edit, setEdit] = useState<any | null>(null);
  const [result, setResult] = useState("WIN");
  const [pl, setPl] = useState("");
  const [notes, setNotes] = useState("");
  const [filter, setFilter] = useState<"all" | "pending" | "done">("all");

  const shown = trades.filter((t) => (filter === "all" ? true : filter === "pending" ? !t.result || t.result === "EVALUATION_PENDING" : t.result && t.result !== "EVALUATION_PENDING"));
  const has = T.evaluatedCount > 0;

  const openEdit = (t: any) => {
    setEdit(t);
    setResult(t.result && t.result !== "EVALUATION_PENDING" ? t.result : "WIN");
    setPl(t.profit ? String(t.profit) : "");
    setNotes(t.notes || "");
  };
  const save = async () => {
    const amount = pl.trim() === "" ? undefined : parseFloat(pl.replace(",", "."));
    // Hasil kalah selalu negatif, menang selalu positif, supaya statistik tidak terbalik.
    let profit = amount;
    if (typeof profit === "number" && isFinite(profit)) {
      profit = result === "LOSS" ? -Math.abs(profit) : result === "WIN" ? Math.abs(profit) : 0;
    }
    await T.handleUpdateJournalDocResult(edit.docId || edit.id, result, notes, profit);
    setEdit(null);
  };

  return (
    <div className="grid gap-4">
      <section className="surface p-5 grid grid-cols-2 md:grid-cols-4 gap-5">
        <Stat label="Tingkat menang" value={has ? `${T.winRatePercent}%` : "—"} sub={has ? `${T.winsCount} menang, ${T.lossCount} kalah` : "belum ada hasil yang dinilai"} />
        <Stat label="Profit factor" value={has ? T.profitFactor : "—"} sub="total untung dibagi total rugi" />
        <Stat label="Hasil bersih" value={has ? fmtMoney(T.netProfit) : "—"} tone={T.netProfit > 0 ? "jade" : T.netProfit < 0 ? "coral" : undefined} sub="dari nilai yang Anda isi" />
        <Stat label="Total catatan" value={T.totalTradesCount} sub={`${T.pendingCount} belum dinilai`} />
      </section>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <Segmented value={filter} onChange={setFilter} options={[{ value: "all", label: "Semua" }, { value: "pending", label: "Belum dinilai" }, { value: "done", label: "Sudah dinilai" }]} />
        <div className="flex gap-2">
          <Button variant="soft" size="sm" icon="camera" onClick={T.handleSaveSnapshotToJournal}>Simpan sinyal saat ini</Button>
          <Button variant="soft" size="sm" icon="download" onClick={T.exportJournalToCsv} disabled={trades.length === 0}>Ekspor CSV</Button>
        </div>
      </div>

      <Section pad={false}>
        {shown.length === 0 ? (
          <Empty icon="book" title={trades.length === 0 ? "Jurnal masih kosong" : "Tidak ada catatan di filter ini"}>
            {trades.length === 0 ? "Simpan setup dari halaman Sinyal, lalu catat hasilnya setelah posisi ditutup. Statistik di atas dihitung dari catatan Anda sendiri." : "Ganti filter untuk melihat catatan lain."}
          </Empty>
        ) : (
          <ul className="divide-y divide-line">
            {shown.map((t) => {
              const r = RES[t.result] || RES.EVALUATION_PENDING;
              const buy = isBuySignal(t.type);
              const when = t.timestamp ? new Date(t.timestamp).toLocaleString("id-ID", { timeZone: "Asia/Makassar", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : t.time;
              return (
                <li key={t.docId || t.id}>
                  <button onClick={() => openEdit(t)} className="w-full text-left px-4 py-3.5 flex items-center gap-3 hover:bg-raised/50 transition-colors cursor-pointer">
                    <span className={cx("w-9 h-9 rounded-xl grid place-items-center shrink-0", buy ? "bg-jade/10 text-jade" : "bg-coral/10 text-coral")}><Icon name={buy ? "arrowUp" : "arrowDown"} size={17} /></span>
                    <div className="min-w-0 flex-1">
                      <div className="text-[14.5px] font-medium">{t.symbol} <span className="text-mute font-normal">{t.timeframe}</span> · {String(t.type || "").toLowerCase().replace(/^\w/, (c: string) => c.toUpperCase())}</div>
                      <div className="text-[12.5px] text-faint num">Entry {fmtPrice(t.entryPrice ?? t.entry)} · SL {fmtPrice(t.sl)} · {when}</div>
                    </div>
                    <div className="text-right shrink-0">
                      <Badge tone={r.tone}>{r.label}</Badge>
                      {t.result && t.result !== "EVALUATION_PENDING" && <div className={cx("num text-[13px] mt-1", t.profit > 0 ? "text-jade" : t.profit < 0 ? "text-coral" : "text-mute")}>{fmtMoney(t.profit || 0)}</div>}
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </Section>

      <Sheet open={!!edit} onClose={() => setEdit(null)} title="Nilai hasil trading">
        {edit && (
          <div className="grid gap-4">
            <p className="text-[13.5px] text-mute">{edit.symbol} {edit.timeframe} · entry <span className="num text-text">{fmtPrice(edit.entryPrice ?? edit.entry)}</span> · SL <span className="num text-text">{fmtPrice(edit.sl)}</span></p>
            <Segmented value={result} onChange={setResult} options={[{ value: "WIN", label: "Menang" }, { value: "LOSS", label: "Kalah" }, { value: "BREAKEVEN", label: "Impas" }]} />
            {result !== "BREAKEVEN" && <Field label="Nominal hasil (USD)" inputMode="decimal" value={pl} onChange={(e) => setPl(e.target.value)} placeholder="Misalnya 85" hint="Isi angka sebenarnya dari akun Anda. Tanda plus atau minus diatur otomatis." />}
            <div>
              <label htmlFor="notes" className="block text-[13px] font-medium mb-1.5">Catatan</label>
              <textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} maxLength={900} className="w-full rounded-xl bg-abyss border border-line p-3 text-[14px] outline-none focus:border-gold/70 resize-none" placeholder="Apa yang berjalan baik, apa yang perlu diperbaiki?" />
            </div>
            <Button variant="primary" size="lg" onClick={save}>Simpan penilaian</Button>
          </div>
        )}
      </Sheet>
    </div>
  );
}
