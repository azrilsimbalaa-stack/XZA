import { useState } from "react";
import { useT } from "../TerminalContext";
import { useAuth, PLAN_LABEL } from "../auth/AuthContext";
import { Section, Toggle, Segmented, Button, Field } from "../ui/kit";
import { TRADING_STYLES, SIGNAL_METHODS } from "../TerminalCore";

function Row({ title, desc, children }: { title: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 py-3.5 border-b border-line last:border-0">
      <div className="min-w-0">
        <div className="text-[14.5px] font-medium">{title}</div>
        {desc && <div className="text-[12.5px] text-faint mt-0.5 leading-snug max-w-[46ch]">{desc}</div>}
      </div>
      {children}
    </div>
  );
}

export default function PengaturanPage() {
  const T = useT();
  const { session, logout } = useAuth();
  const [perm, setPerm] = useState<string>(typeof Notification !== "undefined" ? Notification.permission : "unsupported");
  const left = session ? Math.max(0, Math.ceil((session.expiresAt - Date.now()) / 86400000)) : 0;

  const askPerm = async () => {
    if (typeof Notification === "undefined") return;
    setPerm(await Notification.requestPermission());
  };

  return (
    <div className="grid gap-4 max-w-3xl">
      <Section title="Akun">
        <div className="flex items-center justify-between gap-4">
          <div>
            <div className="text-[16px] font-medium">{session?.name}</div>
            <div className="text-[13px] text-mute mt-0.5">Paket {PLAN_LABEL[session?.plan || ""] || session?.plan} · sisa {left} hari{session?.demo && " (mode demo)"}</div>
          </div>
          <Button variant="danger" icon="logout" onClick={logout}>Keluar</Button>
        </div>
      </Section>

      <Section title="Analisis">
        <Row title="Metode sinyal" desc="Kerangka yang dipakai mesin saat mencari setup.">
          <select value={T.signalMethod} onChange={(e) => T.setSignalMethod(e.target.value)} className="h-10 max-w-[220px] rounded-xl bg-abyss border border-line px-3 text-[13.5px] outline-none focus:border-gold/70 cursor-pointer">
            {SIGNAL_METHODS.map((m) => <option key={m.id} value={m.id}>{m.label.split(":")[0].split("(")[0].trim()}</option>)}
          </select>
        </Row>
        <Row title="Gaya trading" desc="Auto mengikuti timeframe yang sedang dibuka.">
          <select value={T.tradingStyle} onChange={(e) => T.setTradingStyle(e.target.value)} className="h-10 rounded-xl bg-abyss border border-line px-3 text-[13.5px] outline-none focus:border-gold/70 cursor-pointer">
            {TRADING_STYLES.map((m) => <option key={m.id} value={m.id}>{m.label.replace(/\(.*\)/, "").trim()}</option>)}
          </select>
        </Row>
        <div className="pt-3.5">
          <Field label="Selisih harga dengan broker" inputMode="decimal" value={String(T.priceOffset)} onChange={(e) => T.setPriceOffset(parseFloat(e.target.value) || 0)} hint="Tambahkan angka ini ke harga chart bila broker Anda selalu berbeda dari feed. Biasanya 0." />
        </div>
      </Section>

      <Section title="Notifikasi">
        <Row title="Izin notifikasi browser" desc={perm === "granted" ? "Aktif. Peringatan muncul saat Anda berada di tab lain." : perm === "denied" ? "Diblokir. Ubah lewat pengaturan situs di browser." : "Diperlukan agar peringatan bisa muncul di luar aplikasi."}>
          {perm === "granted" ? <span className="text-jade text-[13px] font-medium">Aktif</span> : <Button size="sm" variant="soft" onClick={askPerm} disabled={perm === "denied" || perm === "unsupported"}>Izinkan</Button>}
        </Row>
        <Row title="Peringatan rilis berdampak tinggi" desc="Pengingat sebelum rilis data USD yang besar.">
          <Toggle label="Peringatan rilis" checked={T.spikeNotificationEnabled} onChange={T.setSpikeNotificationEnabled} />
        </Row>
        <Row title="Peringatan breakout pola chart">
          <Toggle label="Peringatan pola" checked={T.patternNotificationEnabled} onChange={() => T.handleTogglePatternNotification()} />
        </Row>
        <Row title="Suara"><Toggle label="Suara" checked={T.soundEnabled} onChange={T.setSoundEnabled} /></Row>
        <Row title="Suara pembaca analisis">
          <Segmented size="sm" value={T.selectedVoiceGender} onChange={(v) => T.setSelectedVoiceGender(v)} options={[{ value: "FEMALE", label: "Perempuan" }, { value: "MALE", label: "Laki-laki" }]} />
        </Row>
      </Section>

      <Section title="Tentang data">
        <p className="text-[13.5px] text-mute leading-relaxed">
          Harga datang dari feed pasar yang disambungkan server. Skor konfluensi adalah daftar periksa teknis, bukan peluang menang. Tidak ada jaminan hasil, dan statistik di Jurnal hanya berasal dari catatan yang Anda isi sendiri.
        </p>
      </Section>
    </div>
  );
}
