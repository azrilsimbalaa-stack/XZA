import { useT } from "../TerminalContext";
import { Route } from "../lib/router";
import { Section, Stat, Badge, Button } from "../ui/kit";
import { Icon } from "../ui/Icon";
import SignalTicket from "../ui/SignalTicket";
import { ImpactDot, SessionStrip, biasLabel, biasTone } from "../ui/bits";
import { cx, countdown, fmtPrice, fmtMoney, witaTime, isBtc } from "../lib/format";

export default function RingkasanPage({ go }: { go: (r: Route) => void }) {
  const T = useT();
  const sym = T.activeSymbol;
  const { bid, ask } = T.currentPrice;
  const live = bid > 0;
  const prev = T.indicators?.prevClose || 0;
  const chg = live && prev > 0 ? bid - prev : 0;
  const chgPct = prev > 0 ? (chg / prev) * 100 : 0;
  const up = chg >= 0;
  const clock = T.realtimeWitaClock;
  const closed = !isBtc(sym.id) && T.currentMarketClosedInfo?.isClosed;

  const upcoming = (T.economicEvents as any[])
    .filter((e) => !e.isReleased && new Date(e.date).getTime() > T.nowTicker)
    .sort((a, b) => +new Date(a.date) - +new Date(b.date))
    .slice(0, 4);

  const trades = T.sessionTrades as any[];
  const hasStats = T.evaluatedCount > 0;

  return (
    <div className="grid gap-4 lg:grid-cols-12">
      <div className="lg:col-span-8 grid gap-4 content-start">
        {/* Harga */}
        <section className="surface p-5 sm:p-6 relative overflow-hidden">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[14px] text-mute">{sym.id} · {sym.name === "GOLD" ? "Emas" : "Bitcoin"}</span>
                {closed ? <Badge tone="gold">Pasar tutup</Badge> : <Badge tone="jade" dot>{live ? "Live" : "Menyambung"}</Badge>}
              </div>
              <div className="num font-display text-[44px] sm:text-[60px] leading-none font-semibold tracking-[-0.03em] mt-3">
                {live ? fmtPrice(bid, sym.id) : "—"}
              </div>
              {live && prev > 0 && (
                <div className={cx("mt-2 text-[15px] font-medium num flex items-center gap-1.5", up ? "text-jade" : "text-coral")}>
                  <Icon name={up ? "arrowUp" : "arrowDown"} size={15} />
                  {Math.abs(chg).toFixed(2)} ({Math.abs(chgPct).toFixed(2)}%)
                  <span className="text-faint font-normal">dari penutupan sebelumnya</span>
                </div>
              )}
            </div>
            <div className="hidden sm:grid grid-cols-2 gap-x-6 gap-y-3 text-right">
              <Stat label="Bid" value={live ? fmtPrice(bid) : "—"} />
              <Stat label="Ask" value={live ? fmtPrice(ask) : "—"} />
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-5 border-t border-line">
            <div>
              <div className="text-[12px] text-mute">Bias timeframe tinggi</div>
              <div className={cx("font-display text-[19px] font-semibold mt-0.5", biasTone(T.htfData?.overall))}>{biasLabel(T.htfData?.overall)}</div>
            </div>
            <div>
              <div className="text-[12px] text-mute">Bias timeframe rendah</div>
              <div className={cx("font-display text-[19px] font-semibold mt-0.5", biasTone(T.ltfData?.overall))}>{biasLabel(T.ltfData?.overall)}</div>
            </div>
            <Stat label={`RSI ${T.activeTimeframe.id}`} value={Number(T.indicators?.rsi || 0).toFixed(0)} />
            <Stat label="ATR" value={Number(T.indicators?.atr || 0).toFixed(2)} />
          </div>
        </section>

        <div className="grid gap-4 md:grid-cols-2">
          {/* Kalender berikutnya */}
          <Section title="Rilis berikutnya" aside={<Button size="sm" variant="ghost" onClick={() => go("kalender")}>Semua <Icon name="chevronRight" size={14} /></Button>} pad={false}>
            {upcoming.length === 0 ? (
              <p className="p-4 text-[13.5px] text-mute">Tidak ada rilis USD terjadwal dalam beberapa hari ke depan.</p>
            ) : (
              <ul className="divide-y divide-line">
                {upcoming.map((e) => (
                  <li key={e.id} className="px-4 py-3 flex items-center gap-3">
                    <ImpactDot level={e.importance} />
                    <div className="min-w-0 flex-1">
                      <div className="text-[13.5px] font-medium truncate">{e.title}</div>
                      <div className="text-[12px] text-faint num">{witaTime(e.date)} WITA</div>
                    </div>
                    <span className={cx("num text-[12.5px] shrink-0", e.importance === 1 ? "text-gold font-medium" : "text-mute")}>{countdown(new Date(e.date).getTime() - T.nowTicker)}</span>
                  </li>
                ))}
              </ul>
            )}
          </Section>

          {/* Sesi */}
          <Section title="Sesi pasar (WITA)" aside={clock.isKillzone ? <Badge tone="gold" dot>Killzone</Badge> : undefined}>
            <SessionStrip hours={clock.hours} minutes={clock.minutes} />
          </Section>
        </div>

        {/* Jurnal */}
        <Section title="Jurnal Anda" aside={<Button size="sm" variant="ghost" onClick={() => go("jurnal")}>Buka <Icon name="chevronRight" size={14} /></Button>}>
          {trades.length === 0 ? (
            <p className="text-[13.5px] text-mute">Belum ada catatan. Simpan setup dari halaman Sinyal untuk mulai melacak hasil Anda.</p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Stat label="Tingkat menang" value={hasStats ? `${T.winRatePercent}%` : "—"} sub={hasStats ? `${T.winsCount} dari ${T.evaluatedCount} dinilai` : "belum ada yang dinilai"} />
              <Stat label="Profit factor" value={hasStats ? T.profitFactor : "—"} />
              <Stat label="Hasil bersih" value={hasStats ? fmtMoney(T.netProfit) : "—"} tone={T.netProfit > 0 ? "jade" : T.netProfit < 0 ? "coral" : undefined} />
              <Stat label="Menunggu dinilai" value={T.pendingCount} />
            </div>
          )}
        </Section>
      </div>

      <div className="lg:col-span-4 grid gap-4 content-start">
        <SignalTicket compact />
      </div>
    </div>
  );
}
