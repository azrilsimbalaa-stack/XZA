import { useEffect, useMemo, useState } from "react";
import { useT } from "../TerminalContext";
import { useSignalView } from "../ui/SignalTicket";
import { Section, Field, Segmented, Button, Badge } from "../ui/kit";
import { fmtMoney, fmtPrice, isBtc, cx } from "../lib/format";

type Cfg = { balance: string; currency: "USD" | "IDR"; idr: string; risk: string; contract: Record<string, string> };
const KEY = "zrill_risk_v2";
const DEFAULT: Cfg = { balance: "1000", currency: "USD", idr: "16000", risk: "1", contract: { XAUUSD: "100", BTCUSD: "1" } };

export default function RisikoPage() {
  const T = useT();
  const v = useSignalView();
  const id = T.activeSymbol.id;
  const [cfg, setCfg] = useState<Cfg>(() => { try { return { ...DEFAULT, ...JSON.parse(localStorage.getItem(KEY) || "{}") }; } catch { return DEFAULT; } });
  const [entry, setEntry] = useState("");
  const [sl, setSl] = useState("");
  const [tps, setTps] = useState<string[]>(["", "", ""]);

  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch {} }, [cfg]);

  const fill = () => {
    setEntry(v.entry ? String(v.entry) : "");
    setSl(v.sl ? String(v.sl) : "");
    setTps([0, 1, 2].map((i) => (v.tps[i] ? String(v.tps[i].price) : "")));
  };
  useEffect(() => { if (v.isLive && !entry && !sl) fill(); /* eslint-disable-next-line */ }, [v.isLive]);

  const contract = parseFloat(cfg.contract[id] ?? (isBtc(id) ? "1" : "100")) || 0;
  const rate = cfg.currency === "IDR" ? parseFloat(cfg.idr) || 0 : 1;
  const balUsd = rate > 0 ? (parseFloat(cfg.balance) || 0) / rate : 0;
  const riskPct = parseFloat(cfg.risk) || 0;
  const e = parseFloat(entry), s = parseFloat(sl);

  const r = useMemo(() => {
    if (!(e > 0) || !(s > 0) || e === s || contract <= 0 || balUsd <= 0) return null;
    const dist = Math.abs(e - s);
    const riskUsd = (balUsd * riskPct) / 100;
    const lotRaw = riskUsd / (dist * contract);
    const lot = Math.floor(lotRaw * 100) / 100;
    const realRisk = lot * dist * contract;
    const side = e > s ? "BUY" : "SELL";
    const targets = tps.map((t, i) => {
      const p = parseFloat(t);
      if (!(p > 0)) return null;
      const okSide = side === "BUY" ? p > e : p < e;
      const gain = lot * Math.abs(p - e) * contract;
      return { label: `TP${i + 1}`, price: p, gain, rr: Math.abs(p - e) / dist, okSide };
    }).filter(Boolean) as { label: string; price: number; gain: number; rr: number; okSide: boolean }[];
    return { dist, riskUsd, lot, lotRaw, realRisk, side, targets };
  }, [e, s, tps, contract, balUsd, riskPct]);

  const money = (usd: number) => fmtMoney(usd * rate, cfg.currency);

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] max-w-5xl items-start">
      <Section title="Parameter akun" aside={<Segmented size="sm" value={cfg.currency} onChange={(c) => setCfg({ ...cfg, currency: c })} options={[{ value: "USD", label: "USD" }, { value: "IDR", label: "Rupiah" }]} />}>
        <div className="grid gap-4">
          <Field label={`Saldo (${cfg.currency === "IDR" ? "Rp" : "$"})`} inputMode="decimal" value={cfg.balance} onChange={(x) => setCfg({ ...cfg, balance: x.target.value })} />
          {cfg.currency === "IDR" && <Field label="Kurs (Rp per 1 USD)" inputMode="decimal" value={cfg.idr} onChange={(x) => setCfg({ ...cfg, idr: x.target.value })} hint="Isi kurs yang dipakai broker Anda." />}
          <Field label="Risiko per transaksi (%)" inputMode="decimal" value={cfg.risk} onChange={(x) => setCfg({ ...cfg, risk: x.target.value })} hint={riskPct > 2 ? "Di atas 2% per transaksi dianggap agresif." : "Banyak trader memakai 0,5% sampai 2%."} />
          <Field
            label={`Ukuran kontrak ${id}`}
            inputMode="decimal"
            value={cfg.contract[id] ?? (isBtc(id) ? "1" : "100")}
            onChange={(x) => setCfg({ ...cfg, contract: { ...cfg.contract, [id]: x.target.value } })}
            hint={isBtc(id) ? "Umumnya 1 lot = 1 BTC, tetapi cek spesifikasi di broker Anda." : "Umumnya 1 lot = 100 oz, jadi gerak $1 bernilai $100 per lot. Cek di broker Anda."}
          />
        </div>
      </Section>

      <div className="grid gap-4">
        <Section title="Level transaksi" aside={<Button size="sm" variant="soft" icon="target" onClick={fill} disabled={!v.isLive}>Isi dari sinyal</Button>}>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Entry" inputMode="decimal" value={entry} onChange={(x) => setEntry(x.target.value)} />
            <Field label="Stop loss" inputMode="decimal" value={sl} onChange={(x) => setSl(x.target.value)} />
            {[0, 1, 2].map((i) => (
              <Field key={i} label={`TP${i + 1}`} inputMode="decimal" value={tps[i]} onChange={(x) => setTps(tps.map((t, j) => (j === i ? x.target.value : t)))} />
            ))}
          </div>
        </Section>

        <section className="surface p-5">
          {!r ? (
            <p className="text-[14px] text-mute">Isi saldo, entry, dan stop loss untuk melihat ukuran lot.</p>
          ) : (
            <>
              <div className="flex items-end justify-between gap-4">
                <div>
                  <div className="text-[13px] text-mute">Ukuran lot maksimal</div>
                  <div className="num font-display text-[52px] leading-none font-semibold mt-1">{r.lot.toFixed(2)}</div>
                </div>
                <Badge tone={r.side === "BUY" ? "jade" : "coral"}>{r.side === "BUY" ? "Buy" : "Sell"}</Badge>
              </div>
              {r.lot < 0.01 && <p className="text-[13px] text-coral mt-3">Saldo terlalu kecil untuk jarak SL ini. Perkecil jarak SL atau naikkan risiko dengan hati-hati.</p>}
              <dl className="grid grid-cols-2 gap-4 mt-5 pt-4 border-t border-line text-[13.5px]">
                <div><dt className="text-faint">Risiko sebenarnya</dt><dd className="num font-medium text-coral mt-0.5">{money(r.realRisk)}</dd></div>
                <div><dt className="text-faint">Jarak SL</dt><dd className="num font-medium mt-0.5">{fmtPrice(r.dist)}</dd></div>
              </dl>
              {r.targets.length > 0 && (
                <ul className="mt-4 pt-4 border-t border-line grid gap-2">
                  {r.targets.map((t) => (
                    <li key={t.label} className="flex items-center justify-between text-[13.5px]">
                      <span className="flex items-center gap-2"><span className="w-9 text-mute">{t.label}</span><span className="num">{fmtPrice(t.price)}</span>{!t.okSide && <Badge tone="coral">Arah salah</Badge>}</span>
                      <span className="num"><span className={cx("font-medium", t.okSide ? "text-jade" : "text-faint")}>{t.okSide ? `+${money(t.gain)}` : "—"}</span> <span className="text-faint">· 1:{t.rr.toFixed(1)}</span></span>
                    </li>
                  ))}
                </ul>
              )}
            </>
          )}
        </section>
        <p className="text-[12px] text-faint leading-relaxed px-1">Hasil dibulatkan ke bawah per 0,01 lot. Spread, slippage, dan komisi tidak dihitung.</p>
      </div>
    </div>
  );
}
