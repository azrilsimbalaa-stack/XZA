import { AuthProvider, useAuth } from "./auth/AuthContext";
import LoginPage from "./auth/LoginPage";
import { TerminalProvider } from "./TerminalContext";
import Shell from "./Shell";

function Gate() {
  const { session, ready } = useAuth();
  if (!ready) {
    return (
      <div className="h-full grid place-items-center bg-abyss">
        <img src="/zrill-icon-192.png" alt="Memuat Zrill AI" className="w-14 h-14 rounded-2xl border border-jade/30 animate-pulse" />
      </div>
    );
  }
  if (!session) return <LoginPage />;
  return (
    <TerminalProvider>
      <Shell />
    </TerminalProvider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Gate />
    </AuthProvider>
  );
}
