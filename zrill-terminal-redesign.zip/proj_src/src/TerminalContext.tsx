import React, { createContext, useContext } from "react";
import { useTerminal } from "./TerminalCore";

export type Terminal = ReturnType<typeof useTerminal>;
const Ctx = createContext<Terminal | null>(null);

/** Menjalankan mesin terminal (harga live, sinyal, kalender, jurnal) sekali untuk seluruh halaman. */
export function TerminalProvider({ children }: { children: React.ReactNode }) {
  const t = useTerminal();
  return <Ctx.Provider value={t}>{children}</Ctx.Provider>;
}

export function useT(): Terminal {
  const c = useContext(Ctx);
  if (!c) throw new Error("useT harus dipakai di dalam TerminalProvider");
  return c;
}
