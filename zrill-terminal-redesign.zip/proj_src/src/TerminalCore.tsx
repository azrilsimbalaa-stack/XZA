import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Eye,
  ChevronDown,
  Activity,
  BarChart2,
  Newspaper,
  TrendingUp,
  Settings,
  X,
  RefreshCw,
  Lock,
  CheckCircle2,
  XCircle,
  Zap,
  Globe,
  Terminal,
  Layers,
  ChevronUp,
  Brain,
  Calendar,
  Smartphone,
  Download,
  Share2,
  Clock,
  Timer,
  GripHorizontal,
  BrainCircuit,
  AlertTriangle,
  Target,
  Cpu,
  ShieldCheck,
  Radio,
  Sparkles,
  Crosshair,
  ShieldAlert,
  ExternalLink,
  Minus,
  Flame,
  Cable,
  Workflow,
  Calculator,
  Bell,
  BellRing,
  Play,
  Landmark,
  TrendingDown,
  Scale,
  ChevronRight,
  PauseCircle,
  ArrowUpRight,
  Copy,
  Camera,
  BookOpen,
  FileText,
  Check,
  Trash2,
  Image,
} from "lucide-react";
import { WitaSessionSyncCard } from "./components/WitaSessionSyncCard";
import { RetestAdvisoryModal } from "./components/RetestAdvisoryModal";
import { PersonalizedAssetNewsFeed } from "./components/PersonalizedAssetNewsFeed";
import { RealtimeFundamentalSMCFusionCard } from "./components/RealtimeFundamentalSMCFusionCard";
import { AmdPhaseAnalysisCard } from "./components/AmdPhaseAnalysisCard";
import { ZrillV5PrecisionCard } from "./components/ZrillV5PrecisionCard";
import { ChartPatternPredictionCard } from "./components/ChartPatternPredictionCard";
import {
  detectAllClassicPatterns,
  getPrimaryChartPattern,
  DetectedChartPattern,
} from "./services/chartPatternEngine";
import {
  GacorRiskCalculator,
  RiskCalculatorConfig,
  formatCurrencyVal,
  calculateGacorRiskMetrics
} from "./components/GacorRiskCalculator";
import {
  buildComprehensiveEconomicEvent,
  PeganganKuat,
  UpgradedEconomicEvent,
} from "./services/institutionalCalendarEngine";
import {
  generatePrecisionSignal,
  generateSynchronizedSignalSuite,
  ConfluenceCheck,
  RegimeAnalysis,
  TradingRegime,
  TrendIntelligence,
  WitaCalendarSync,
  LiquidityEngineRadar,
  QuantumOrderFlow,
  DynamicPositionCalculator,
  GuaranteedRREngine,
  MathematicalModelEngine,
  UnifiedNeuralSynapseBus,
  FundamentalIntelligence,
  ReversalWarningIntelligence,
  KeyAreaTarget,
  LimitOrderDetails,
  OptimalRetestAdvisory,
  GoldenZone0618Quality,
  MarketSentimentRadar,
  MathematicalAreaModel,
  SupremeSignalMetrics,
  BestEntryZoneArchitecture,
  EntryThinkingStep,
  OmnipresentMtfCertaintySynthesis,
  ZrillV5CoreAnalysis,
} from "./services/precisionSignalEngine";
import {
  computeAssetNewsIntelligence,
  AssetNewsIntelligence,
} from "./services/assetNewsIntelligenceService";
import {
  createChart,
  ColorType,
  IChartApi,
  ISeriesApi,
  CandlestickSeries,
  createSeriesMarkers,
  LineSeries,
  BaselineSeries,
  LineStyle,
} from "lightweight-charts";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip as RechartsTooltip,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { db } from "./firebase";
import {
  collection,
  doc,
  setDoc,
  onSnapshot,
  writeBatch,
  query,
  orderBy,
  limit,
  where,
  getDoc,
  getDocs,
  updateDoc,
} from "firebase/firestore";

let globalServerTimeOffset = 0;

export function getMarketClosedStatus(symbolId: string, timeMs: number = Date.now()): {
  isClosed: boolean;
  reason?: string;
  nextOpenTimeMs?: number;
  countdownStr?: string;
  witaReopenStr?: string;
  days?: number;
  hours?: number;
  mins?: number;
  secs?: number;
} {
  const cleanId = (symbolId || "").toUpperCase();
  // Crypto assets (BTCUSD, BTCUSDT, etc.) operate 24/7 continuously without weekend closure
  if (cleanId.includes("BTC") || cleanId.includes("ETH") || cleanId.includes("CRYPTO")) {
    return { isClosed: false };
  }

  const d = new Date(timeMs);
  const utcDay = d.getUTCDay(); // 0 = Sun, 1 = Mon, ..., 5 = Fri, 6 = Sat
  const utcHours = d.getUTCHours();

  const isClosed = 
    (utcDay === 5 && utcHours >= 21) || // Friday >= 21:00 UTC (Sabtu 05:00 WITA)
    utcDay === 6 ||                      // Saturday all day (Sabtu 05:00 WITA - Minggu 05:00 WITA)
    (utcDay === 0 && utcHours < 21);    // Sunday < 21:00 UTC (Minggu 05:00 WITA - Senin 05:00 WITA)

  if (!isClosed) {
    return { isClosed: false };
  }

  let daysUntilSunday = (0 - utcDay + 7) % 7;
  const targetOpen = new Date(d);
  targetOpen.setUTCDate(d.getUTCDate() + daysUntilSunday);
  targetOpen.setUTCHours(21, 0, 0, 0);

  const diffMs = Math.max(0, targetOpen.getTime() - timeMs);
  const totalSec = Math.floor(diffMs / 1000);
  
  const days = Math.floor(totalSec / 86400);
  const hours = Math.floor((totalSec % 86400) / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;

  let countdownStr = "";
  if (days > 0) {
    countdownStr = `${days} Hari ${hours} Jam ${mins} Mnt ${secs} Detik`;
  } else if (hours > 0) {
    countdownStr = `${hours} Jam ${mins} Mnt ${secs} Detik`;
  } else {
    countdownStr = `${mins} Mnt ${secs} Detik`;
  }

  return {
    isClosed: true,
    reason: `PASAR ${symbolId} TUTUP (SABTU & MINGGU)`,
    nextOpenTimeMs: targetOpen.getTime(),
    countdownStr,
    witaReopenStr: "Senin 05:00 WITA",
    days,
    hours,
    mins,
    secs,
  };
}

export const isBuySignal = (type?: string): boolean => {
  if (!type) return false;
  const t = String(type).toUpperCase();
  return t.includes("BUY");
};

export const isSellSignal = (type?: string): boolean => {
  if (!type) return false;
  const t = String(type).toUpperCase();
  return t.includes("SELL");
};

export const SYMBOLS = [
  { id: "XAUUSD", name: "GOLD", basePrice: 4430.0, binanceSymbol: "PAXGUSDT" },
  {
    id: "BTCUSD",
    name: "BITCOIN",
    basePrice: 77500.0,
    binanceSymbol: "BTCUSDT",
  },
];

export const TIMEFRAMES = [
  { id: "M1", binance: "1m" },
  { id: "M5", binance: "5m" },
  { id: "M15", binance: "15m" },
  { id: "M30", binance: "30m" },
  { id: "H1", binance: "1h" },
  { id: "H4", binance: "4h" },
  { id: "D1", binance: "1d" },
];

export const TRADING_STYLES = [
  { id: "AUTO", label: "Auto (Timeframe Based)" },
  { id: "INTRADAY", label: "Force Intraday" },
  { id: "SWING", label: "Force Swing" },
  { id: "LONG_TERM", label: "Force Long Term" },
];

export const SIGNAL_METHODS = [
  {
    id: "ICT_SMC_ULTIMATE",
    label:
      "ICT & SMC ULTIMATE: D1/H4 BIAS -> H1/M30 FVG/OB/OTE -> M15 CISD/MSS/LIQUIDITY SWEEP",
  },
  { id: "CRT_METHOD", label: "CRT (Custom Range Theory & Crown Reversal)" },
  {
    id: "PRIVATE_CLASS",
    label: "PRIVATE CLASS (ICT 2022 Mentorship - Most Profitable)",
  },
  { id: "SNIPER_SMC", label: "SMC SNIPER (Sweep + CHoCH + OB)" },
  { id: "LIQUIDITY_SWEEP", label: "SMC: Liquidity Sweep" },
  { id: "LIQUIDITY_HUNTER", label: "ICT: Liquidity Hunter" },
  { id: "SND_OB", label: "SND & Order Block" },
  { id: "TREND", label: "Trend Following (EMA/SMA)" },
  { id: "MACD", label: "MACD + Stochastic" },
  { id: "BREAKOUT", label: "Breakout Strategy" },
  { id: "RSI_PA", label: "RSI + Price Action (Sniper)" },
];


const getKlinesUrl = (symId: string, binanceSym: string, interval: string, limit: number) => {
  return `/api/klines?symbol=${encodeURIComponent(symId)}&interval=${encodeURIComponent(interval)}&limit=${limit}`;
};

// --- Advanced Technical Indicator Helpers ---
enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null,
) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: null,
      email: null,
      emailVerified: null,
      isAnonymous: null,
      tenantId: null,
      providerInfo: [],
    },
    operationType,
    path,
  };
  console.warn("Firestore Operation Warning: ", JSON.stringify(errInfo));
}

const isValid = (val: any) => val !== null && val !== undefined && !isNaN(val);

function calculateSMA(prices: number[], period: number) {
  if (prices.length < period) return 0;
  let sum = 0;
  for (let i = prices.length - period; i < prices.length; i++) sum += prices[i];
  return sum / period;
}

function calculateEMA(prices: number[], period: number) {
  if (prices.length === 0) return 0;
  const k = 2 / (period + 1);
  let ema = prices[0];
  for (let i = 1; i < prices.length; i++) ema = (prices[i] - ema) * k + ema;
  return ema;
}

function calculateStochastic(
  highs: number[],
  lows: number[],
  closes: number[],
  periodK = 14,
  periodD = 3,
) {
  if (closes.length < periodK + periodD) return { k: 50, d: 50 };
  const kValues = [];
  for (let i = closes.length - periodD; i <= closes.length; i++) {
    const currentClose = closes[i - 1];
    const recentHighs = highs.slice(i - periodK, i);
    const recentLows = lows.slice(i - periodK, i);
    const hh = Math.max(...recentHighs);
    const ll = Math.min(...recentLows);
    const k = hh === ll ? 50 : ((currentClose - ll) / (hh - ll)) * 100;
    kValues.push(k);
  }
  const currentK = kValues[kValues.length - 1];
  const currentD = kValues.reduce((a, b) => a + b, 0) / kValues.length;
  return { k: currentK, d: currentD };
}

function calculateRSI(closes: number[], period = 14) {
  if (closes.length <= period) return 50;
  let gains = 0,
    losses = 0;
  for (let i = closes.length - period; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff > 0) gains += diff;
    else losses -= diff;
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

function calculateATR(highs: number[], lows: number[], closes: number[], period = 14) {
  if (closes.length < period + 1) return 1.5;
  const trValues: number[] = [];
  for (let i = 1; i < closes.length; i++) {
    const tr = Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1])
    );
    trValues.push(tr);
  }
  if (trValues.length < period) return Number((trValues[trValues.length - 1] || 1.5).toFixed(2));
  let atr = trValues.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < trValues.length; i++) {
    atr = (atr * (period - 1) + trValues[i]) / period;
  }
  return Number(atr.toFixed(2));
}

function calculateBollingerBands(closes: number[], period = 20, multiplier = 2) {
  if (closes.length < period) {
    const last = closes[closes.length - 1] || 0;
    return { upper: last, middle: last, lower: last, bandwidth: 0, percentB: 50 };
  }
  const slice = closes.slice(closes.length - period);
  const mean = slice.reduce((a, b) => a + b, 0) / period;
  const variance = slice.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / period;
  const stdDev = Math.sqrt(variance);
  const upper = mean + multiplier * stdDev;
  const lower = mean - multiplier * stdDev;
  const current = closes[closes.length - 1];
  const bandwidth = mean !== 0 ? ((upper - lower) / mean) * 100 : 0;
  const percentB = upper !== lower ? ((current - lower) / (upper - lower)) * 100 : 50;
  return {
    upper: Number(upper.toFixed(2)),
    middle: Number(mean.toFixed(2)),
    lower: Number(lower.toFixed(2)),
    bandwidth: Number(bandwidth.toFixed(2)),
    percentB: Number(percentB.toFixed(2)),
  };
}

function calculateADX(highs: number[], lows: number[], closes: number[], period = 14) {
  if (closes.length < period * 2) {
    return { adx: 25, pdi: 25, mdi: 25 };
  }
  const trs: number[] = [];
  const plusDMs: number[] = [];
  const minusDMs: number[] = [];

  for (let i = 1; i < closes.length; i++) {
    const upMove = highs[i] - highs[i - 1];
    const downMove = lows[i - 1] - lows[i];

    plusDMs.push(upMove > downMove && upMove > 0 ? upMove : 0);
    minusDMs.push(downMove > upMove && downMove > 0 ? downMove : 0);

    const tr = Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1])
    );
    trs.push(tr);
  }

  if (trs.length < period) return { adx: 25, pdi: 25, mdi: 25 };

  let trSmooth = trs.slice(0, period).reduce((a, b) => a + b, 0);
  let plusDMSmooth = plusDMs.slice(0, period).reduce((a, b) => a + b, 0);
  let minusDMSmooth = minusDMs.slice(0, period).reduce((a, b) => a + b, 0);

  const dxValues: number[] = [];

  for (let i = period; i < trs.length; i++) {
    trSmooth = trSmooth - trSmooth / period + trs[i];
    plusDMSmooth = plusDMSmooth - plusDMSmooth / period + plusDMs[i];
    minusDMSmooth = minusDMSmooth - minusDMSmooth / period + minusDMs[i];

    const pdi = trSmooth > 0 ? (plusDMSmooth / trSmooth) * 100 : 0;
    const mdi = trSmooth > 0 ? (minusDMSmooth / trSmooth) * 100 : 0;
    const diSum = pdi + mdi;
    const dx = diSum > 0 ? (Math.abs(pdi - mdi) / diSum) * 100 : 0;
    dxValues.push(dx);
  }

  if (dxValues.length < period) {
    const avgDx = dxValues.reduce((a, b) => a + b, 0) / (dxValues.length || 1);
    return {
      adx: Number(avgDx.toFixed(1)),
      pdi: Number(((plusDMSmooth / (trSmooth || 1)) * 100).toFixed(1)),
      mdi: Number(((minusDMSmooth / (trSmooth || 1)) * 100).toFixed(1)),
    };
  }

  let adx = dxValues.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < dxValues.length; i++) {
    adx = (adx * (period - 1) + dxValues[i]) / period;
  }

  const finalPdi = trSmooth > 0 ? (plusDMSmooth / trSmooth) * 100 : 25;
  const finalMdi = trSmooth > 0 ? (minusDMSmooth / trSmooth) * 100 : 25;

  return {
    adx: Number(adx.toFixed(1)),
    pdi: Number(finalPdi.toFixed(1)),
    mdi: Number(finalMdi.toFixed(1)),
  };
}

function detectRSIDivergence(candles: any[]) {
  if (!candles || candles.length < 30) return null;
  const closes = candles.map((c) => c.close);
  const highs = candles.map((c) => c.high);
  const lows = candles.map((c) => c.low);

  const rsiValues: number[] = [];
  for (let i = 0; i < candles.length; i++) {
    if (i < 14) {
      rsiValues.push(50);
    } else {
      rsiValues.push(calculateRSI(closes.slice(0, i + 1), 14));
    }
  }

  const startIndex = Math.max(15, candles.length - 45);
  const peaks: { index: number; price: number; rsi: number; time: any }[] = [];
  const troughs: { index: number; price: number; rsi: number; time: any }[] = [];

  for (let i = startIndex; i < candles.length - 1; i++) {
    if (
      highs[i] >= highs[i - 1] &&
      highs[i] >= highs[i - 2] &&
      highs[i] >= highs[i + 1] &&
      rsiValues[i] > 48
    ) {
      peaks.push({
        index: i,
        price: highs[i],
        rsi: rsiValues[i],
        time: candles[i].time,
      });
    }

    if (
      lows[i] <= lows[i - 1] &&
      lows[i] <= lows[i - 2] &&
      lows[i] <= lows[i + 1] &&
      rsiValues[i] < 52
    ) {
      troughs.push({
        index: i,
        price: lows[i],
        rsi: rsiValues[i],
        time: candles[i].time,
      });
    }
  }

  // 1. Bearish Divergence: Price HH, RSI LH
  if (peaks.length >= 2) {
    const p2 = peaks[peaks.length - 1];
    const p1 = peaks[peaks.length - 2];
    if (p2.index - p1.index >= 3 && p2.price > p1.price * 1.00015 && p2.rsi < p1.rsi - 1.0) {
      return {
        type: "BEARISH_DIVERGENCE",
        title: "⚠️ RSI BEARISH DIVERGENCE (POTENSI REVERSAL SELL)",
        price1: p1.price,
        price2: p2.price,
        rsi1: Number(p1.rsi.toFixed(1)),
        rsi2: Number(p2.rsi.toFixed(1)),
        time1: p1.time,
        time2: p2.time,
        description: `Harga mencetak Higher High ($${p2.price.toFixed(2)} vs $${p1.price.toFixed(2)}) tetapi RSI melemah ke Lower High (${p2.rsi.toFixed(1)} vs ${p1.rsi.toFixed(1)}). Indikasi kuat kelelahan momentum BUY & sinyal pembalikan harga ke arah SELL!`,
      };
    }
  }

  // 2. Bullish Divergence: Price LL, RSI HL
  if (troughs.length >= 2) {
    const t2 = troughs[troughs.length - 1];
    const t1 = troughs[troughs.length - 2];
    if (t2.index - t1.index >= 3 && t2.price < t1.price * 0.99985 && t2.rsi > t1.rsi + 1.0) {
      return {
        type: "BULLISH_DIVERGENCE",
        title: "🚀 RSI BULLISH DIVERGENCE (POTENSI REVERSAL BUY)",
        price1: t1.price,
        price2: t2.price,
        rsi1: Number(t1.rsi.toFixed(1)),
        rsi2: Number(t2.rsi.toFixed(1)),
        time1: t1.time,
        time2: t2.time,
        description: `Harga mencetak Lower Low ($${t2.price.toFixed(2)} vs $${t1.price.toFixed(2)}) tetapi RSI menguat ke Higher Low (${t2.rsi.toFixed(1)} vs ${t1.rsi.toFixed(1)}). Indikasi kuat akumulasi momentum BUY & sinyal pembalikan harga ke arah NAIK!`,
      };
    }
  }

  return null;
}

const sendSystemNotification = (title: string, body: string) => {
  try {
    if ("Notification" in window) {
      if (Notification.permission === "granted") {
        new Notification(title, { body, icon: "/favicon.ico" });
      } else if (Notification.permission !== "denied") {
        Notification.requestPermission().then((permission) => {
          if (permission === "granted") {
            new Notification(title, { body, icon: "/favicon.ico" });
          }
        });
      }
    }
  } catch (err) {
    console.error("Browser notification failed:", err);
  }
};

function detectCandlePattern(
  open: number,
  high: number,
  low: number,
  close: number,
  prevOpen: number,
  prevClose: number,
) {
  const body = Math.abs(close - open);
  const upperWick = high - Math.max(open, close);
  const lowerWick = Math.min(open, close) - low;

  // Bullish Engulfing
  if (
    prevClose < prevOpen &&
    close > open &&
    close > prevOpen &&
    open < prevClose
  )
    return "BULLISH_ENGULFING";
  // Bearish Engulfing
  if (
    prevClose > prevOpen &&
    close < open &&
    close < prevOpen &&
    open > prevClose
  )
    return "BEARISH_ENGULFING";
  // Bullish Pinbar (Hammer)
  if (lowerWick > body * 2 && upperWick < body) return "BULLISH_PINBAR";
  // Bearish Pinbar (Shooting Star)
  if (upperWick > body * 2 && lowerWick < body) return "BEARISH_PINBAR";

  return "NONE";
}

function analyzeSMC(data: any[]) {
  const emptyResult = {
    markers: [],
    drawings: {
      bullishFVG: null,
      bearishFVG: null,
      ob: null,
      sd: null,
      support: null,
      resistance: null,
      bos: null,
      choch: null,
      ibos: null,
      sweep: null,
      trendlines: { support: null, resistance: null },
    },
    state: {
      trend: "SIDEWAYS",
      lastStruct: "NONE",
      fvg: "NONE",
      ob: "NONE",
      sweep: "NONE",
      recentStructures: [] as any[],
      bos: "NONE",
      choch: "NONE",
      patterns: [] as any[],
      sentiment: { buy: 50, sell: 50 },
    },
  };
  if (!data || data.length < 50) return emptyResult;

  const markers: any[] = [];
  const totalRange =
    Math.max(...data.map((d) => d.high)) - Math.min(...data.map((d) => d.low));
  const offset = totalRange * 0.005;

  const leftBars = 10;
  const rightBars = 5;

  let swings: any[] = [];
  for (let i = leftBars; i < data.length - rightBars; i++) {
    let isHigh = true;
    let isLow = true;
    for (let j = 1; j <= leftBars; j++) {
      if (data[i - j].high >= data[i].high) isHigh = false;
      if (data[i - j].low <= data[i].low) isLow = false;
    }
    for (let j = 1; j <= rightBars; j++) {
      if (data[i + j].high >= data[i].high) isHigh = false;
      if (data[i + j].low <= data[i].low) isLow = false;
    }
    if (isHigh)
      swings.push({
        type: "High",
        index: i,
        price: data[i].high,
        time: data[i].time,
      });
    if (isLow)
      swings.push({
        type: "Low",
        index: i,
        price: data[i].low,
        time: data[i].time,
      });
  }

  let filteredSwings: any[] = [];
  let lastType = "";
  for (let s of swings) {
    if (s.type !== lastType) {
      filteredSwings.push(s);
      lastType = s.type;
    } else {
      if (
        s.type === "High" &&
        s.price > filteredSwings[filteredSwings.length - 1].price
      ) {
        filteredSwings[filteredSwings.length - 1] = s;
      } else if (
        s.type === "Low" &&
        s.price < filteredSwings[filteredSwings.length - 1].price
      ) {
        filteredSwings[filteredSwings.length - 1] = s;
      }
    }
  }

  let structure = [];
  let lastHigh = null;
  let lastLow = null;
  let trend = "SIDEWAYS";

  for (let i = 0; i < filteredSwings.length; i++) {
    let s = filteredSwings[i];
    if (s.type === "High") {
      if (lastHigh === null) {
        s.label = "High";
      } else if (s.price > lastHigh.price) {
        s.label = "HH";
      } else {
        s.label = "LH";
      }
      lastHigh = s;
    } else {
      if (lastLow === null) {
        s.label = "Low";
      } else if (s.price > lastLow.price) {
        s.label = "HL";
      } else {
        s.label = "LL";
      }
      lastLow = s;
    }
    structure.push(s);
  }

  if (structure.length >= 4) {
    const last4 = structure.slice(-4).map((s) => s.label);
    if (last4.includes("HH") && last4.includes("HL")) trend = "BULLISH";
    else if (last4.includes("LH") && last4.includes("LL")) trend = "BEARISH";
    else trend = "SIDEWAYS";
  }

  const recentStructs = structure.slice(-15);
  for (let s of recentStructs) {
    markers.push({
      time: s.time,
      position: s.type === "High" ? "aboveBar" : "belowBar",
      color: s.type === "High" ? "#ef4444" : "#10b981",
      shape: s.type === "High" ? "arrowDown" : "arrowUp",
      text: "", // Removed HH, HL, LH, LL labels
      size: 1,
    });
  }

  const lastTime = data[data.length - 1].time;
  const extendedTime = lastTime + 3600 * 24; // Extend by 24h roughly for visual

  // Find recent FVG
  let bullishFVG = null;
  let bearishFVG = null;
  for (let i = data.length - 25; i < data.length - 1; i++) {
    if (i < 2) continue;
    const c1 = data[i - 2];
    const c2 = data[i - 1];
    const c3 = data[i];
    const atr = Math.abs(c2.high - c2.low);

    if (
      c1.high < c3.low &&
      c2.close > c2.open &&
      c3.low - c1.high > atr * 0.15
    ) {
      bullishFVG = {
        type: "BULLISH",
        time: c2.time,
        top: c3.low,
        bottom: c1.high,
        endTime: extendedTime,
      };
    }
    if (
      c1.low > c3.high &&
      c2.close < c2.open &&
      c1.low - c3.high > atr * 0.15
    ) {
      bearishFVG = {
        type: "BEARISH",
        time: c2.time,
        top: c1.low,
        bottom: c3.high,
        endTime: extendedTime,
      };
    }
  }

  // Find recent OB (with Mitigation Check)
  let lastOB = null;
  for (let i = data.length - 30; i < data.length - 1; i++) {
    const c1 = data[i - 2];
    const c2 = data[i - 1];
    const c3 = data[i];
    if (!c1 || !c2 || !c3) continue;

    let ob = null;
    if (
      c1.close < c1.open &&
      c2.close > c2.open &&
      c3.close > c3.open &&
      c3.close - c2.open > (c1.open - c1.close) * 2
    ) {
      ob = {
        type: "BULLISH",
        time: c1.time,
        top: c1.open,
        bottom: c1.low,
        endTime: extendedTime,
        mitigated: false,
      };
    }
    if (
      c1.close > c1.open &&
      c2.close < c2.open &&
      c3.close < c3.open &&
      c2.open - c3.close > (c1.close - c1.open) * 2
    ) {
      ob = {
        type: "BEARISH",
        time: c1.time,
        top: c1.high,
        bottom: c1.open,
        endTime: extendedTime,
        mitigated: false,
      };
    }

    if (ob) {
      // Check for mitigation: has any candle after OB creation entered the zone?
      for (let j = i + 1; j < data.length; j++) {
        const testC = data[j];
        if (ob.type === "BULLISH" && testC.low <= ob.top) {
          ob.mitigated = true;
          ob.mitigationTime = testC.time;
          break;
        }
        if (ob.type === "BEARISH" && testC.high >= ob.bottom) {
          ob.mitigated = true;
          ob.mitigationTime = testC.time;
          break;
        }
      }
      lastOB = ob;
    }
  }

  // S&D Zones (Supply & Demand)
  let lastSD = null;
  for (let i = data.length - 30; i < data.length - 5; i++) {
    const range = data.slice(i, i + 5);
    const high = Math.max(...range.map((d) => d.high));
    const low = Math.min(...range.map((d) => d.low));
    const bodySize = Math.abs(high - low);

    // Strong move after consolidation
    const nextCandle = data[i + 5];
    if (nextCandle.close > high + bodySize) {
      lastSD = {
        type: "DEMAND",
        time: data[i].time,
        top: high,
        bottom: low,
        endTime: extendedTime,
      };
    } else if (nextCandle.close < low - bodySize) {
      lastSD = {
        type: "SUPPLY",
        time: data[i].time,
        top: high,
        bottom: low,
        endTime: extendedTime,
      };
    }
  }

  // S&R Zones (Support & Resistance) for each Timeframe
  let lastSupport: any = null;
  let lastResistance: any = null;
  const levels: any[] = [];
  for (let s of filteredSwings.slice(-30)) {
    const existing = levels.find(
      (l) => Math.abs(l.price - s.price) / (s.price || 1) < 0.002,
    );
    if (existing) {
      existing.touches++;
      existing.times.push(s.time);
      existing.types.push(s.type);
      // Update price to weighted average for better precision
      existing.price =
        (existing.price * (existing.touches - 1) + s.price) / existing.touches;
    } else {
      levels.push({
        price: s.price,
        touches: 1,
        times: [s.time],
        types: [s.type],
      });
    }
  }

  // Find strongest Support (Low touches) and Resistance (High touches)
  const sortedLevels = [...levels].sort((a, b) => b.touches - a.touches);

  for (let level of sortedLevels) {
    const isResistance = level.types.includes("High") && !level.types.every((t: string) => t === "Low");
    const isSupport = level.types.includes("Low") && !level.types.every((t: string) => t === "High");

    const levelStrength = level.touches >= 3 ? "SANGAT KUAT" : level.touches === 2 ? "KUAT" : "MODERAT";

    if (isSupport && !lastSupport) {
      lastSupport = {
        type: "SUPPORT",
        time: level.times[0],
        price: Number(level.price.toFixed(2)),
        endTime: extendedTime,
        touches: level.touches,
        strength: levelStrength,
        actionAdvice: "WAIT FOR SUPPORT BUY",
      };
    } else if (isResistance && !lastResistance) {
      lastResistance = {
        type: "RESISTANCE",
        time: level.times[0],
        price: Number(level.price.toFixed(2)),
        endTime: extendedTime,
        touches: level.touches,
        strength: levelStrength,
        actionAdvice: "WAIT FOR RESISTANCE SELL",
      };
    }
  }

  // Reliable Fallback: Ensure every Timeframe has active Support and Resistance levels visualized
  const currentClose = data.length > 0 ? data[data.length - 1].close : 0;
  if (!lastSupport) {
    const swingLows = filteredSwings.filter((s) => s.type === "Low" || (s.price && s.price < currentClose));
    if (swingLows.length > 0) {
      const bestLow = swingLows[swingLows.length - 1];
      lastSupport = {
        type: "SUPPORT",
        time: bestLow.time,
        price: Number(bestLow.price.toFixed(2)),
        endTime: extendedTime,
        touches: 1,
        strength: "MODERAT",
      };
    } else if (data.length > 0) {
      const minLow = Math.min(...data.slice(-30).map((d) => d.low));
      lastSupport = {
        type: "SUPPORT",
        time: data[0].time,
        price: Number(minLow.toFixed(2)),
        endTime: extendedTime,
        touches: 1,
        strength: "MODERAT",
      };
    }
  }

  if (!lastResistance) {
    const swingHighs = filteredSwings.filter((s) => s.type === "High" || (s.price && s.price > currentClose));
    if (swingHighs.length > 0) {
      const bestHigh = swingHighs[swingHighs.length - 1];
      lastResistance = {
        type: "RESISTANCE",
        time: bestHigh.time,
        price: Number(bestHigh.price.toFixed(2)),
        endTime: extendedTime,
        touches: 1,
        strength: "MODERAT",
      };
    } else if (data.length > 0) {
      const maxHigh = Math.max(...data.slice(-30).map((d) => d.high));
      lastResistance = {
        type: "RESISTANCE",
        time: data[0].time,
        price: Number(maxHigh.toFixed(2)),
        endTime: extendedTime,
        touches: 1,
        strength: "MODERAT",
      };
    }
  }

  // Find last BOS, CHoCH, and iBOS (Anti-Fakeout Logic)
  let lastBOS = null;
  let lastCHoCH = null;
  let lastIBOS = null;

  for (let i = 2; i < structure.length; i++) {
    const curr = structure[i];
    const prev2 = structure[i - 2];

    // Find the candle that caused the breakout
    const breakoutCandle = data.find((d) => d.time === curr.time);
    if (!breakoutCandle) continue;

    // Anti-Fakeout: Check for "Displacement" (Strong Close)
    const isStrongBullish =
      breakoutCandle.close > prev2.price &&
      breakoutCandle.close - breakoutCandle.open >
        (breakoutCandle.high - breakoutCandle.low) * 0.6;
    const isStrongBearish =
      breakoutCandle.close < prev2.price &&
      breakoutCandle.open - breakoutCandle.close >
        (breakoutCandle.high - breakoutCandle.low) * 0.6;

    if (curr.label === "HH" && isStrongBullish) {
      if (prev2.label === "HH" || prev2.label === "High") {
        lastBOS = {
          type: "BULLISH",
          time: prev2.time,
          endTime: curr.time,
          price: prev2.price,
        };
      } else if (prev2.label === "LH") {
        lastCHoCH = {
          type: "BULLISH",
          time: prev2.time,
          endTime: curr.time,
          price: prev2.price,
        };
      } else if (prev2.label === "High") {
        lastIBOS = {
          type: "BULLISH",
          time: prev2.time,
          endTime: curr.time,
          price: prev2.price,
        };
      }
    } else if (curr.label === "LL" && isStrongBearish) {
      if (prev2.label === "LL" || prev2.label === "Low") {
        lastBOS = {
          type: "BEARISH",
          time: prev2.time,
          endTime: curr.time,
          price: prev2.price,
        };
      } else if (prev2.label === "HL") {
        lastCHoCH = {
          type: "BEARISH",
          time: prev2.time,
          endTime: curr.time,
          price: prev2.price,
        };
      } else if (prev2.label === "Low") {
        lastIBOS = {
          type: "BEARISH",
          time: prev2.time,
          endTime: curr.time,
          price: prev2.price,
        };
      }
    }
  }

  if (bullishFVG) {
    markers.push({
      time: bullishFVG.time,
      position: "belowBar",
      color: "#3b82f6",
      shape: "circle",
      text: "",
      tooltip:
        "Bullish Fair Value Gap: A price imbalance where buying pressure was so strong it left a gap. Often acts as a magnet for price to return and rebalance.",
    });
  }

  if (bearishFVG) {
    markers.push({
      time: bearishFVG.time,
      position: "aboveBar",
      color: "#ef4444",
      shape: "circle",
      text: "",
      tooltip:
        "Bearish Fair Value Gap: A price imbalance where selling pressure was so strong it left a gap.",
    });
  }

  if (lastOB) {
    markers.push({
      time: lastOB.time,
      position: lastOB.type === "BULLISH" ? "belowBar" : "aboveBar",
      color: lastOB.type === "BULLISH" ? "#10b981" : "#ef4444",
      shape: "square",
      text: "",
      tooltip:
        lastOB.type === "BULLISH"
          ? `Bullish Order Block (${lastOB.mitigated ? "Mitigated" : "Unmitigated"}): A zone where institutional buying occurred.`
          : `Bearish Order Block (${lastOB.mitigated ? "Mitigated" : "Unmitigated"}): A zone where institutional selling occurred.`,
    });
  }

  if (lastSD) {
    markers.push({
      time: lastSD.time,
      position: lastSD.type === "DEMAND" ? "belowBar" : "aboveBar",
      color: lastSD.type === "DEMAND" ? "#10b981" : "#ef4444",
      shape: "circle",
      text: "",
    });
  }

  if (lastSupport) {
    markers.push({
      time: lastSupport.time,
      position: "belowBar",
      color: "#10b981",
      shape: "arrowUp",
      text: "",
    });
  }

  if (lastResistance) {
    markers.push({
      time: lastResistance.time,
      position: "aboveBar",
      color: "#ef4444",
      shape: "arrowDown",
      text: "",
    });
  }

  if (lastBOS && isValid(lastBOS.price)) {
    markers.push({
      time: lastBOS.endTime,
      position: lastBOS.type === "BULLISH" ? "belowBar" : "aboveBar",
      color: "#f59e0b",
      shape: lastBOS.type === "BULLISH" ? "arrowUp" : "arrowDown",
      text: "",
      tooltip:
        "Break of Structure: Price has broken the previous structure in the direction of the trend, confirming trend continuation.",
    });
  }

  if (lastCHoCH && isValid(lastCHoCH.price)) {
    markers.push({
      time: lastCHoCH.endTime,
      position: lastCHoCH.type === "BULLISH" ? "belowBar" : "aboveBar",
      color: "#8b5cf6",
      shape: lastCHoCH.type === "BULLISH" ? "arrowUp" : "arrowDown",
      text: "",
      tooltip:
        "Change of Character: The first sign of a potential trend reversal. Price has broken the opposite structure.",
    });
  }

  if (lastIBOS && isValid(lastIBOS.price)) {
    markers.push({
      time: lastIBOS.endTime,
      position: "inPrice",
      price: lastIBOS.price,
      color: "#06b6d4",
      shape: "circle",
      text: "",
    });
  }

  let sweep = "NONE";
  let sweepLine = null;
  const currentCandle = data[data.length - 1];

  const lastHighStruct = structure
    .slice()
    .reverse()
    .find((s) => s.type === "High");
  const lastLowStruct = structure
    .slice()
    .reverse()
    .find((s) => s.type === "Low");

  if (structure.length > 0) {
    if (
      lastHighStruct &&
      currentCandle.high > lastHighStruct.price &&
      currentCandle.close < lastHighStruct.price
    ) {
      sweep = "BEARISH";
      sweepLine = {
        time: lastHighStruct.time,
        endTime: currentCandle.time,
        price: lastHighStruct.price,
      };
      markers.push({
        time: currentCandle.time,
        position: "aboveBar",
        color: "#f59e0b",
        shape: "arrowDown",
        text: "",
        tooltip:
          "Buy-Side Liquidity (BSL) Sweep: Price swept above a major high to hunt stop losses before reversing.",
      });
    }
    if (
      lastLowStruct &&
      currentCandle.low < lastLowStruct.price &&
      currentCandle.close > lastLowStruct.price
    ) {
      sweep = "BULLISH";
      sweepLine = {
        time: lastLowStruct.time,
        endTime: currentCandle.time,
        price: lastLowStruct.price,
      };
      markers.push({
        time: currentCandle.time,
        position: "belowBar",
        color: "#f59e0b",
        shape: "arrowUp",
        text: "",
        tooltip:
          "Sell-Side Liquidity (SSL) Sweep: Price swept below a major low to hunt stop losses before reversing.",
      });
    }
  }

  // Candlestick Pattern Detection
  const patterns: any[] = [];
  for (let i = data.length - 20; i < data.length; i++) {
    if (i < 2) continue;
    const curr = data[i];
    const prev = data[i - 1];

    const body = Math.abs(curr.close - curr.open);
    const prevBody = Math.abs(prev.close - prev.open);
    const range = curr.high - curr.low;

    // Engulfing
    if (
      curr.close > curr.open &&
      prev.close < prev.open &&
      curr.close > prev.open &&
      curr.open < prev.close
    ) {
      patterns.push({
        type: "Bullish Engulfing",
        time: curr.time,
        description:
          "Bullish Engulfing: A large green candle completely engulfs the previous red candle, signaling strong buying pressure.",
      });
      markers.push({
        time: curr.time,
        position: "belowBar",
        color: "#10b981",
        shape: "arrowUp",
        text: "",
        tooltip: "Bullish Engulfing: Strong reversal signal.",
      });
    } else if (
      curr.close < curr.open &&
      prev.close > prev.open &&
      curr.close < prev.open &&
      curr.open > prev.close
    ) {
      patterns.push({
        type: "Bearish Engulfing",
        time: curr.time,
        description:
          "Bearish Engulfing: A large red candle completely engulfs the previous green candle, signaling strong selling pressure.",
      });
      markers.push({
        time: curr.time,
        position: "aboveBar",
        color: "#ef4444",
        shape: "arrowDown",
        text: "",
        tooltip: "Bearish Engulfing: Strong reversal signal.",
      });
    }
    
    // Pin Bar / Hammer / Shooting Star
    const upperWick = curr.high - Math.max(curr.open, curr.close);
    const lowerWick = Math.min(curr.open, curr.close) - curr.low;
    if (lowerWick > body * 2 && upperWick < body * 0.5) {
      patterns.push({
        type: "Bullish Pin Bar / Hammer",
        time: curr.time,
        description: "Bullish Pin Bar: Strong rejection of lower prices.",
      });
      markers.push({
        time: curr.time,
        position: "belowBar",
        color: "#10b981",
        shape: "arrowUp",
        text: "",
        tooltip: "Bullish Pin Bar: Price rejection at support.",
      });
    } else if (upperWick > body * 2 && lowerWick < body * 0.5) {
      patterns.push({
        type: "Bearish Shooting Star",
        time: curr.time,
        description: "Shooting Star: Strong rejection of higher prices.",
      });
      markers.push({
        time: curr.time,
        position: "aboveBar",
        color: "#ef4444",
        shape: "arrowDown",
        text: "",
        tooltip: "Bearish Shooting Star: Price rejection at resistance.",
      });
    }
  }

  // Sentiment Calculation (Real-time Buyer vs Seller %)
  const recentSentimentData = data.slice(-15);
  let buyVolume = 0;
  let sellVolume = 0;
  recentSentimentData.forEach((d, idx) => {
    const body = Math.abs(d.close - d.open);
    const weight = (idx + 1) / recentSentimentData.length; // More weight to recent candles
    if (d.close > d.open) buyVolume += body * weight;
    else if (d.close < d.open) sellVolume += body * weight;
    else {
      buyVolume += body * 0.5 * weight;
      sellVolume += body * 0.5 * weight;
    }
  });

  // Add current candle pressure
  const lastBody = Math.abs(currentCandle.close - currentCandle.open);
  if (currentCandle.close > currentCandle.open) buyVolume += lastBody * 2;
  else sellVolume += lastBody * 2;

  const totalVol = buyVolume + sellVolume;
  const buyPercent =
    totalVol > 0 ? Math.round((buyVolume / totalVol) * 100) : 50;
  const sellPercent = 100 - buyPercent;

  // Trendline Detection
  let trendlines = { support: null as any, resistance: null as any };
  const recentHighs = filteredSwings.filter((s) => s.type === "High").slice(-3);
  const recentLows = filteredSwings.filter((s) => s.type === "Low").slice(-3);

  if (recentHighs.length >= 2) {
    const p1 = recentHighs[recentHighs.length - 2];
    const p2 = recentHighs[recentHighs.length - 1];
    trendlines.resistance = { p1, p2 };
  }
  if (recentLows.length >= 2) {
    const p1 = recentLows[recentLows.length - 2];
    const p2 = recentLows[recentLows.length - 1];
    trendlines.support = { p1, p2 };
  }

  const lastStructLabel =
    structure.length > 0 ? structure[structure.length - 1].label : "NONE";
  const recentStructures = structure.slice(-10);

  // High Probability Signal Logic (Very Low Risk)
  const signals: any[] = [];

  // Bullish Low Risk Entry
  const isAtDemand =
    lastSD &&
    lastSD.type === "DEMAND" &&
    currentCandle.low <= lastSD.top &&
    currentCandle.close >= lastSD.bottom;
  const isAtBullishOB =
    lastOB &&
    lastOB.type === "BULLISH" &&
    currentCandle.low <= lastOB.top &&
    currentCandle.close >= lastOB.bottom;
  const hasBullishPattern = patterns.some(
    (p) =>
      p.time === currentCandle.time &&
      (p.type === "Bullish Engulfing" || p.type === "Bullish Pinbar"),
  );
  const hadBullishSweep = sweep === "BULLISH";

  if ((isAtDemand || isAtBullishOB) && hasBullishPattern) {
    let strength = 1;
    if (trend === "BULLISH") strength++;
    if (hadBullishSweep) strength++;

    if (strength >= 2) {
      signals.push({
        type: "BUY",
        strength: strength >= 3 ? "HIGH" : "MEDIUM",
        price: currentCandle.close,
        sl:
          Math.min(
            currentCandle.low,
            isAtDemand ? lastSD.bottom : lastOB.bottom,
          ) -
          totalRange * 0.002,
        tp: lastHighStruct
          ? lastHighStruct.price
          : currentCandle.close + totalRange * 0.05,
        reason: `Bullish confluence at ${isAtDemand ? "Demand" : "Order Block"} with ${patterns.find((p) => p.time === currentCandle.time).type}${hadBullishSweep ? " + Liquidity Sweep" : ""}`,
      });
    }
  }

  // Bearish Low Risk Entry
  const isAtSupply =
    lastSD &&
    lastSD.type === "SUPPLY" &&
    currentCandle.high >= lastSD.bottom &&
    currentCandle.close <= lastSD.top;
  const isAtBearishOB =
    lastOB &&
    lastOB.type === "BEARISH" &&
    currentCandle.high >= lastOB.bottom &&
    currentCandle.close <= lastOB.top;
  const hasBearishPattern = patterns.some(
    (p) =>
      p.time === currentCandle.time &&
      (p.type === "Bearish Engulfing" || p.type === "Bearish Pinbar"),
  );
  const hadBearishSweep = sweep === "BEARISH";

  if ((isAtSupply || isAtBearishOB) && hasBearishPattern) {
    let strength = 1;
    if (trend === "BEARISH") strength++;
    if (hadBearishSweep) strength++;

    if (strength >= 2) {
      signals.push({
        type: "SELL",
        strength: strength >= 3 ? "HIGH" : "MEDIUM",
        price: currentCandle.close,
        sl:
          Math.max(currentCandle.high, isAtSupply ? lastSD.top : lastOB.top) +
          totalRange * 0.002,
        tp: lastLowStruct
          ? lastLowStruct.price
          : currentCandle.close - totalRange * 0.05,
        reason: `Bearish confluence at ${isAtSupply ? "Supply" : "Order Block"} with ${patterns.find((p) => p.time === currentCandle.time)?.type || "Price Action"}${hadBearishSweep ? " + Liquidity Sweep" : ""}`,
      });
    }
  }

  // --- PRIVATE CLASS SETUP: ICT 2022 MENTORSHIP MODEL (Most Profitable) ---
  // 1. Liquidity Sweep (BSL/SSL)
  // 2. Market Structure Shift (MSS) with Displacement
  // 3. Return to FVG

  const hasRecentSweep = sweep !== "NONE";

  if (hasRecentSweep) {
    const isBullishSetup = sweep === "BULLISH"; // SSL Swept
    const isBearishSetup = sweep === "BEARISH"; // BSL Swept

    // Look for MSS (Market Structure Shift)
    if (isBullishSetup && lastCHoCH && lastCHoCH.type === "BULLISH") {
      // Check for FVG in the displacement leg (must be created after or during MSS)
      if (bullishFVG && bullishFVG.time >= lastCHoCH.time - 3600) {
        signals.push({
          type: "BUY",
          strength: "PRIVATE_CLASS",
          price: currentCandle.close,
          sl: lastLowStruct
            ? lastLowStruct.price - totalRange * 0.001
            : currentCandle.low,
          tp: lastHighStruct
            ? lastHighStruct.price
            : currentCandle.close + totalRange * 0.1,
          reason:
            "ICT 2022 MODEL: SSL Sweep + MSS + FVG. High Probability Sniper Entry.",
        });
      }
    } else if (isBearishSetup && lastCHoCH && lastCHoCH.type === "BEARISH") {
      // Check for FVG in the displacement leg
      if (bearishFVG && bearishFVG.time >= lastCHoCH.time - 3600) {
        signals.push({
          type: "SELL",
          strength: "PRIVATE_CLASS",
          price: currentCandle.close,
          sl: lastHighStruct
            ? lastHighStruct.price + totalRange * 0.001
            : currentCandle.high,
          tp: lastLowStruct
            ? lastLowStruct.price
            : currentCandle.close - totalRange * 0.1,
          reason:
            "ICT 2022 MODEL: BSL Sweep + MSS + FVG. High Probability Sniper Entry.",
        });
      }
    }
  }

  // Add markers for signals
  for (let sig of signals) {
    markers.push({
      time: currentCandle.time,
      position: sig.type === "BUY" ? "belowBar" : "aboveBar",
      color: sig.type === "BUY" ? "#10b981" : "#ef4444",
      shape: "arrowUp",
      text: "",
      size: 2,
      tooltip: `LOW RISK ENTRY: ${sig.reason}. SL: ${sig.sl.toFixed(2)}, TP: ${sig.tp.toFixed(2)}`,
    });
  }

  return {
    markers,
    drawings: {
      bullishFVG,
      bearishFVG,
      ob: lastOB,
      sd: lastSD,
      support: lastSupport,
      resistance: lastResistance,
      bos: lastBOS,
      choch: lastCHoCH,
      ibos: lastIBOS,
      sweep: sweepLine,
      trendlines,
    },
    state: {
      trend,
      lastStruct: lastStructLabel,
      support: lastSupport,
      resistance: lastResistance,
      fvg:
        bullishFVG || bearishFVG
          ? bullishFVG
            ? "BULLISH"
            : "BEARISH"
          : "NONE",
      ob: lastOB ? lastOB.type : "NONE",
      sweep,
      recentStructures,
      bos: lastBOS ? lastBOS.type : "NONE",
      choch: lastCHoCH ? lastCHoCH.type : "NONE",
      patterns,
      signals,
      sentiment: { buy: buyPercent, sell: sellPercent },
    },
  };
}

const playSignalAlert = () => {
  // Signal sound disabled per user request
};

export type SignalState = {
  status: "WAITING" | "ACTIVE" | "HIT_TP" | "HIT_SL";
  type: "BUY NOW" | "SELL NOW" | "BUY" | "SELL" | "BUY LIMIT" | "SELL LIMIT" | "WAIT" | "WAIT RETEST" | string;
  orderExecutionType?: "BUY NOW" | "SELL NOW" | "MARKET_EXECUTION" | "BUY LIMIT" | "SELL LIMIT" | "WAIT RETEST" | string;
  goldenZone0618Quality?: GoldenZone0618Quality;
  limitOrderDetails?: LimitOrderDetails;
  optimalRetestAdvisory?: OptimalRetestAdvisory;
  marketSentimentRadar?: MarketSentimentRadar;
  mathematicalAreas?: MathematicalAreaModel;
  ruleValidationShield?: any;
  entry: number;
  entryZoneMin?: number;
  entryZoneMax?: number;
  safeZoneName?: string;
  profitExpectancy?: string;
  sl: number;
  tp: number;
  tp1?: number;
  tp2?: number;
  tp3?: number;
  confidence: number;
  rr: string;
  rrType?: "AGGRESSIVE" | "BALANCED" | "INSTITUTIONAL_RUNNER";
  qualityGrade?: "AAA+ INSTITUTIONAL" | "AA+ HIGH PROBABILITY" | "A+ CONFIRMED";
  invalidationPrice?: number;
  breakevenPrice?: number;
  confluenceChecks?: ConfluenceCheck[];
  autonomousTriggered?: boolean;
  analysis: string;
  method: string;
  executionLogic?: {
    htfBias: string;
    liquidityTrap: string;
    ltfTrigger: string;
    riskManagement: string;
  };
  category?: "SCALP" | "INTRADAY" | "SWING" | "LONG_TERM";
  regimeAnalysis?: RegimeAnalysis;
  trendIntelligence?: TrendIntelligence;
  witaCalendarSync?: WitaCalendarSync;
  liquidityEngineRadar?: LiquidityEngineRadar;
  quantumOrderFlow?: QuantumOrderFlow;
  dynamicPositionCalculator?: DynamicPositionCalculator;
  guaranteedRREngine?: GuaranteedRREngine;
  mathematicalModelEngine?: MathematicalModelEngine;
  unifiedNeuralSynapseBus?: UnifiedNeuralSynapseBus;
  fundamentalIntelligence?: FundamentalIntelligence;
  reversalWarningIntelligence?: ReversalWarningIntelligence;
  timestamp?: number;
  symbol?: string;
  timeframe?: string;
  mtfHarmonized?: boolean;
  mtfConcordance?: any;
  timeframeMatrix?: Record<string, any>;
  supremeSignalMetrics?: SupremeSignalMetrics;
  bestEntryZone?: BestEntryZoneArchitecture;
  entryThinkingChain?: EntryThinkingStep[];
  omnipresentMtfCertainty?: OmnipresentMtfCertaintySynthesis;
  realtimeMacroSMCFusion?: any;
  amdPhaseAnalysis?: any;
  zrillV5Core?: ZrillV5CoreAnalysis;
  confluenceScore?: number;
  confluencePassed?: boolean;
  actionStatusText?: string;
  entryZoneType?: string;
  breakoutIndication?: string;
  snrBounceCount?: number;
  snrStrengthLabel?: string;
  candleVolSignal?: "VOLUME_CONTINUATION" | "VOLUME_REVERSAL" | "VOLUME_NORMAL" | "VOLUME_DRY";
  candleVolLabel?: string;
  candleVolDetail?: string;
  candleVolume?: any;
};

// Safe async clipboard helper with iframe-safe fallback
export async function copyToClipboardSafely(text: string): Promise<boolean> {
  // 1. Try modern clipboard API safely
  if (typeof navigator !== "undefined" && navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Document might not be focused or blocked by iframe security permissions, proceed to textarea fallback
    }
  }

  // 2. Safe DOM-based textarea copy fallback (works seamlessly in iframes and unfocused documents)
  try {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.setAttribute("readonly", "");
    textArea.style.position = "fixed";
    textArea.style.left = "-9999px";
    textArea.style.top = "-9999px";
    textArea.style.opacity = "0";
    textArea.style.pointerEvents = "none";
    document.body.appendChild(textArea);
    
    textArea.focus({ preventScroll: true });
    textArea.select();
    textArea.setSelectionRange(0, 99999);
    
    const successful = document.execCommand("copy");
    document.body.removeChild(textArea);
    return successful;
  } catch (err) {
    console.warn("Fallback copy execution failed:", err);
    return false;
  }
}

export function useTerminal() {
  const [activeSymbol, setActiveSymbol] = useState(() => {
    const saved = localStorage.getItem("zr_symbol");
    return saved ? JSON.parse(saved) : SYMBOLS[0];
  });

  // Ultra-Smooth 120Hz Hardware Engine (Embedded directly as default standard)
  const isLowSpecMode = true;

  const getCardBg = (isHeader = false) => {
    if (isLowSpecMode) {
      return isHeader
        ? "bg-[#161a24] border border-gray-800 rounded-2xl"
        : "bg-[#0f131c] border border-gray-800 rounded-2xl";
    }
    if (visualTheme === "IPHONE_GLASS") {
      return isHeader
        ? "bg-white/[0.04] backdrop-blur-2xl border border-white/[0.08] shadow-[0_4px_30px_rgba(0,0,0,0.3)] rounded-2xl"
        : "bg-white/[0.05] backdrop-blur-xl border border-white/[0.06] shadow-[0_8px_32px_rgba(0,0,0,0.4)] rounded-2xl";
    }
    return isHeader
      ? "bg-[#1A1D24] border border-gray-800 rounded-2xl"
      : "bg-[#131722] border border-gray-800 rounded-2xl";
  };

  const getSubCardBg = () => {
    if (isLowSpecMode) {
      return "bg-[#151a25] border border-gray-800/80 rounded-xl";
    }
    if (visualTheme === "IPHONE_GLASS") {
      return "bg-white/[0.02] border border-white/[0.04] backdrop-blur-md rounded-xl";
    }
    return "bg-[#1A1D24] border border-gray-800/80 rounded-xl";
  };

  const getBtnClass = (active: boolean) => {
    if (visualTheme === "IPHONE_GLASS") {
      return active
        ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.25)]"
        : "bg-white/[0.03] text-gray-400 border border-white/[0.04] hover:bg-white/[0.08] hover:text-white";
    }
    return active
      ? "text-emerald-400 bg-emerald-500/10 border border-emerald-500/30"
      : "text-gray-500 hover:text-gray-300";
  };
  const [activeTimeframe, setActiveTimeframe] = useState(() => {
    try {
      const saved = localStorage.getItem("zr_tf");
      if (saved) {
        const parsed = JSON.parse(saved);
        const match = TIMEFRAMES.find((t) => t.id === parsed.id);
        if (match) return match;
      }
    } catch (e) {}
    return TIMEFRAMES[0]; // M15
  });
  const [tradingStyle, setTradingStyle] = useState(() => {
    const saved = localStorage.getItem("zr_style");
    return saved ? JSON.parse(saved) : TRADING_STYLES[0];
  });
  const [signalMethod, setSignalMethod] = useState(() => {
    const saved = localStorage.getItem("zr_method");
    return saved ? JSON.parse(saved) : SIGNAL_METHODS[0];
  });
  const [priceOffset, setPriceOffset] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [isRetestModalOpen, setIsRetestModalOpen] = useState(false);
  const [copiedStatus, setCopiedStatus] = useState<"IDLE" | "SUCCESS" | "EMPTY" | "ERROR">("IDLE");
  const [copiedRetestStatus, setCopiedRetestStatus] = useState<"IDLE" | "SUCCESS">("IDLE");
  const [selectedBalanceTier, setSelectedBalanceTier] = useState<number>(1000);
  const [isHudMinimized, setIsHudMinimized] = useState(() => {
    const saved = localStorage.getItem("zr_hud_minimized");
    return saved === "true";
  });

  const toggleHudMinimized = () => {
    setIsHudMinimized((prev) => {
      const newVal = !prev;
      localStorage.setItem("zr_hud_minimized", String(newVal));
      return newVal;
    });
  };
  const [cryptoNewsList, setCryptoNewsList] = useState<any[]>([
    {
      id: "crypto-init-1",
      title: "Bitcoin Consolidates Key Support as Institutional Accumulation Strengthens",
      source: "CoinDesk",
      url: "https://www.coindesk.com",
      publishedAt: Date.now() - 5 * 60 * 1000,
      body: "Institutional inflows support key dynamic Fibonacci levels across multi-timeframe structures.",
      category: "CRYPTO",
      sentiment: "BULLISH"
    },
    {
      id: "crypto-init-2",
      title: "Ethereum Network Gas Metric Stabilizes Amid Layer-2 Layering Inflow",
      source: "CoinTelegraph",
      url: "https://www.cointelegraph.com",
      publishedAt: Date.now() - 25 * 60 * 1000,
      body: "Layer-2 settlement volume increases with positive momentum indicators.",
      category: "CRYPTO",
      sentiment: "BULLISH"
    }
  ]);
  const [forexNewsList, setForexNewsList] = useState<any[]>([
    {
      id: "fx-init-1",
      title: "US Treasury Yields Soften Following Inflation Benchmark Revisions",
      source: "Bloomberg Macro",
      url: "https://www.bloomberg.com",
      publishedAt: Date.now() - 10 * 60 * 1000,
      body: "Yield consolidation drives safe-haven liquidity into Spot Gold (XAUUSD) order blocks.",
      category: "FOREX",
      sentiment: "USD_BEARISH"
    },
    {
      id: "fx-init-2",
      title: "Federal Reserve Data-Driven Framework Signals Monetary Alignment",
      source: "Reuters Financial",
      url: "https://www.reuters.com",
      publishedAt: Date.now() - 30 * 60 * 1000,
      body: "Market pricing stabilizes around projected interest rate trajectory.",
      category: "FOREX",
      sentiment: "NEUTRAL"
    }
  ]);
  const [realtimeNewsSentiment, setRealtimeNewsSentiment] = useState<any>({
    usdSentiment: "BEARISH",
    xauImpact: "BUY",
    btcImpact: "BUY",
    summary: "Bloomberg Macro: USD Index (DXY) Melemah. Emas (XAUUSD) Momentum BUY Akseleratif."
  });
  const [bloombergGoldMacro, setBloombergGoldMacro] = useState<any>({
    dxyIndex: { value: "103.74", change: "-0.42%", trend: "BEARISH USD", correlation: "-0.89 (Strong Inverse)" },
    us10yYield: { value: "4.15%", change: "-4.5 bps", trend: "FALLING YIELD", impact: "High Bullish Gold Demand" },
    geopoliticalRiskIndex: { level: "ELEVATED", value: "+18.2%", safeHavenFlow: "AGGRESSIVE INFLOW" },
    centralBankReserves: { pboc: "+28.5 Tons", rbi: "+12.2 Tons", netBuying: "+40.7 Tons / Month" },
    aiGoldPrediction: {
      bias: "BULLISH XAU/USD",
      rationale: "Pelemahan Indeks DXY dan penurunan Yield US 10Y memperkuat momentum kenaikan Emas (XAU/USD).",
      keyLevels: { support: "4405.50", pivot: "4430.00", resistance: "4465.80" }
    }
  });
  const [usDiscourseRadar, setUsDiscourseRadar] = useState<any>(null);
  const [isSyncingUsDiscourse, setIsSyncingUsDiscourse] = useState<boolean>(false);
  const [activeNewsImpact, setActiveNewsImpact] = useState<
    "BUY" | "SELL" | null
  >("BUY");
  const isFirestoreLoaded = useRef(false);
  const isFirstSymbolChange = useRef(true);
  const [isSignalPopupOpen, setIsSignalPopupOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [visualTheme, setVisualTheme] = useState<"SLATE" | "IPHONE_GLASS">(
    () => {
      const saved = localStorage.getItem("zr_theme");
      return (saved as "SLATE" | "IPHONE_GLASS") || "IPHONE_GLASS";
    },
  );

  const [isDivergenceCardMinimized, setIsDivergenceCardMinimized] = useState<boolean>(false);
  const [isDivergenceCardClosed, setIsDivergenceCardClosed] = useState<boolean>(false);

  // Persistent AI Brain Continuous Learning stats (Syncs with Firestore)
  const [aiLevel, setAiLevel] = useState(8);
  const [aiXp, setAiXp] = useState(14500);
  const [aiEpochs, setAiEpochs] = useState(128);
  const [aiWinRateBonus, setAiWinRateBonus] = useState(0);
  const [isTraining, setIsTraining] = useState(false);
  const [trainingProgress, setTrainingProgress] = useState(0);
  const [trainingStatusText, setTrainingStatusText] = useState("");

  const signalExecutionMode = "MARKET";

  // Android APK Custom Compiler states
  const [showApkModal, setShowApkModal] = useState(false);
  const [isCompilingApk, setIsCompilingApk] = useState(false);
  const [apkCompileProgress, setApkCompileProgress] = useState(0);
  const [apkCompileLogs, setApkCompileLogs] = useState<string[]>([]);
  const [apkCompiledSuccessfully, setApkCompiledSuccessfully] = useState(false);
  const [apkPackageName, setApkPackageName] = useState(
    "com.terminalzrill.trading",
  );
  const [apkAppName, setApkAppName] = useState("Terminal Zrill AI");

  // --- REALTIME AI CALENDAR & USER STATUS ---
  const [economicEvents, setEconomicEvents] = useState<any[]>([
    {
      id: "init-cpi",
      title: "CPI Consumer Price Index (MoM)",
      currency: "USD",
      country: "USD",
      date: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
      importance: 1,
      forecast: "0.2%",
      previous: "0.1%",
      actual: "0.3%",
      unit: "%",
      source: "TradingView & Forex Factory",
      status: "RELEASED",
      isReleased: true,
      releasedLabel: "TELAH DIRILIS",
      isPredictionCorrect: true,
      pipsGain: "+180 Pips",
      verdictSummary: "✓ PREDIKSI AI TEPAT SASARAN (100% AKURAT): Rilis CPI 0.3% > 0.2% memicu rally DXY (+0.45%), mendorong XAUUSD anjlok dari resistance $2,942 ke target TP2 $2,924 (+180 Pips).",
      prediction: {
        direction: "SELL",
        targetSymbol: "XAUUSD",
        confidence: 96.8,
        reasoning: "Data CPI aktual lebih tinggi dari estimasi, memicu penguatan Dolar AS (DXY) dan aksi jual masif XAUUSD."
      }
    },
    {
      id: "init-claims",
      title: "Initial Jobless Claims",
      currency: "USD",
      country: "USD",
      date: new Date(Date.now() - 4 * 3600 * 1000).toISOString(),
      importance: 1,
      forecast: "225K",
      previous: "227K",
      actual: "218K",
      unit: "K",
      source: "U.S. Dept of Labor & Bloomberg",
      status: "RELEASED",
      isReleased: true,
      releasedLabel: "TELAH DIRILIS",
      isPredictionCorrect: true,
      pipsGain: "+145 Pips",
      verdictSummary: "✓ PREDIKSI AI TEPAT SASARAN (100% AKURAT): Klaim pengangguran turun ke 218K membuktikan pasar tenaga kerja ketat, mengonfirmasi sinyal SELL XAUUSD +145 Pips.",
      prediction: {
        direction: "SELL",
        targetSymbol: "XAUUSD",
        confidence: 95.4,
        reasoning: "Pasar tenaga kerja resilien memperkecil probabilitas pemangkasan suku bunga agresif The Fed."
      }
    },
    {
      id: "init-ism",
      title: "ISM Services PMI (Non-Manufacturing)",
      currency: "USD",
      country: "USD",
      date: new Date(Date.now() - 14 * 3600 * 1000).toISOString(),
      importance: 1,
      forecast: "51.0",
      previous: "50.5",
      actual: "54.1",
      unit: "",
      source: "Institute for Supply Management",
      status: "RELEASED",
      isReleased: true,
      releasedLabel: "TELAH DIRILIS",
      isPredictionCorrect: true,
      pipsGain: "+210 Pips",
      verdictSummary: "✓ PREDIKSI AI TEPAT SASARAN (100% AKURAT): Ekspansi masif sektor jasa AS memicu likuidasi order beli ritel, target Sell Side Liquidity (SSL) tersapu penuh.",
      prediction: {
        direction: "SELL",
        targetSymbol: "XAUUSD",
        confidence: 97.2,
        reasoning: "Angka PMI di atas 50 mengindikasikan sektor jasa AS sangat ekspansif, menekan emas."
      }
    },
    {
      id: "init-flash-pmi",
      title: "S&P Global Flash Manufacturing PMI",
      currency: "USD",
      country: "USD",
      date: new Date(Date.now() - 26 * 3600 * 1000).toISOString(),
      importance: 0,
      forecast: "50.1",
      previous: "49.8",
      actual: "48.2",
      unit: "",
      source: "S&P Global / Markit",
      status: "RELEASED",
      isReleased: true,
      releasedLabel: "TELAH DIRILIS",
      isPredictionCorrect: false,
      pipsGain: "-22 Pips",
      verdictSummary: "✗ PREDIKSI AI MELESET (TERLINDUNGI): Terjadi deviasi manufaktur ke zona kontraksi (48.2). Stop Loss Invalidation Shield terpicu (-22 Pips), menyelamatkan saldo dari spike berlawanan.",
      prediction: {
        direction: "SELL",
        targetSymbol: "XAUUSD",
        confidence: 91.5,
        reasoning: "Ekspektasi rebound aktivitas manufaktur AS."
      }
    },
    {
      id: "init-nfp",
      title: "Non-Farm Employment Change (NFP)",
      currency: "USD",
      country: "USD",
      date: new Date(Date.now() + 2.5 * 3600 * 1000).toISOString(),
      importance: 1,
      forecast: "185K",
      previous: "175K",
      actual: null,
      unit: "K",
      source: "Bureau of Labor Statistics (BLS)",
      status: "UPCOMING",
      isReleased: false,
      releasedLabel: "MENUNGGU RILIS",
      prediction: {
        direction: "BUY",
        targetSymbol: "XAUUSD",
        confidence: 96.2,
        reasoning: "Estimasi penyerapan tenaga kerja moderat mengonfirmasi sentimen akumulasi Buy Emas XAUUSD di area discount OTE."
      }
    },
    {
      id: "init-fomc",
      title: "FOMC Interest Rate Decision & Fed Funds",
      currency: "USD",
      country: "USD",
      date: new Date(Date.now() + 8 * 3600 * 1000).toISOString(),
      importance: 1,
      forecast: "5.25%",
      previous: "5.50%",
      actual: null,
      unit: "%",
      source: "Federal Reserve Board (FRB)",
      status: "UPCOMING",
      isReleased: false,
      releasedLabel: "MENUNGGU RILIS",
      prediction: {
        direction: "BUY",
        targetSymbol: "XAUUSD",
        confidence: 97.5,
        reasoning: "Ekspektasi pelonggaran moneter The Fed memicu kenaikan permintaan safe-haven XAUUSD menuju target ekspansi H4."
      }
    }
  ]);
  const [calendarLastSync, setCalendarLastSync] = useState<number>(Date.now());
  const [calendarMeta, setCalendarMeta] = useState<{ isSample: boolean; source: string; hasLoaded: boolean }>({ isSample: false, source: "", hasLoaded: false });
  const [isCalendarSyncing, setIsCalendarSyncing] = useState<boolean>(false);
  const [calendarStatusFilter, setCalendarStatusFilter] = useState<"ALL" | "RELEASED" | "UPCOMING">("ALL");
  const [calendarImpactFilter, setCalendarImpactFilter] = useState<"ALL" | "HIGH" | "MEDIUM" | "LOW">("ALL");
  const [calendarSpikeFilter, setCalendarSpikeFilter] = useState<"ALL" | "HIGH_SPIKE" | "LOW_SPIKE">("ALL");
  const [calendarAccuracyFilter, setCalendarAccuracyFilter] = useState<"ALL" | "TEPAT" | "MELESET" | "UPCOMING">("ALL");
  const [calendarCurrencyFilter, setCalendarCurrencyFilter] = useState<string>("ALL");
  const [expandedCalendarEventIds, setExpandedCalendarEventIds] = useState<Set<string>>(new Set(["init-cpi"]));
  const [nowTicker, setNowTicker] = useState<number>(Date.now());

  const toggleCalendarEventExpanded = useCallback((id: string) => {
    setExpandedCalendarEventIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }, []);

  const isGoldSymbol = useMemo(() => {
    const id = (activeSymbol?.id || "").toUpperCase();
    const name = (activeSymbol?.name || "").toUpperCase();
    return id.includes("XAU") || id.includes("GOLD") || name.includes("GOLD");
  }, [activeSymbol]);

  const currentMarketClosedInfo = useMemo(() => {
    return getMarketClosedStatus(activeSymbol.id, nowTicker);
  }, [activeSymbol.id, nowTicker]);

  const isGoldMarketClosedOnWeekend = isGoldSymbol && currentMarketClosedInfo.isClosed;

  // Desktop Push Notification System for 'Spike Tinggi' (Alert 5 Menit Sebelum Rilis)
  const [spikeNotificationEnabled, setSpikeNotificationEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("remix_spike_notif_enabled");
      return saved !== null ? saved === "true" : true;
    } catch {
      return true;
    }
  });
  const [activeSpikeAlert, setActiveSpikeAlert] = useState<{
    id: string;
    title: string;
    currency: string;
    minutesLeft: number;
    estimatedPips: string;
    timeStr: string;
  } | null>(null);
  const notifiedSpikeEventsRef = useRef<Set<string>>(new Set());

  // Trigger Desktop Push Notification 5 Menit Sebelum Rilis Berita 'Spike Tinggi'
  useEffect(() => {
    if (!spikeNotificationEnabled || !economicEvents || economicEvents.length === 0) return;

    economicEvents.forEach((ev) => {
      const isHighSpike =
        ev.spikePrediction?.spikeType === "HIGH_SPIKE" ||
        ev.importance === 1 ||
        /cpi|consumer price|nfp|non-farm|fomc|interest rate|fed rate|unemployment rate|gdp|pce|powell/i.test(
          ev.title || ev.event || ""
        );

      if (!isHighSpike) return;

      const evTime = new Date(ev.date).getTime();
      const diffMs = evTime - nowTicker;
      const eventKey = `${ev.id || ev.title}-${ev.date}`;

      // Alert 5 Menit Sebelum Rilis (rentang 0 s/d 5 menit = 0 - 300.000 ms)
      if (diffMs > 0 && diffMs <= 5 * 60 * 1000) {
        if (!notifiedSpikeEventsRef.current.has(eventKey)) {
          notifiedSpikeEventsRef.current.add(eventKey);

          const minutesLeft = Math.max(1, Math.ceil(diffMs / 60000));
          const currency = ev.currency || "USD";
          const title = ev.title || ev.event || "High Impact News";
          const estimatedPips = ev.spikePrediction?.estimatedPipsGold || "±160 - 320 Pips";
          const timeStr = new Date(ev.date).toLocaleTimeString("id-ID", {
            timeZone: "Asia/Makassar",
            hour: "2-digit",
            minute: "2-digit",
          });

          // 1. Browser Desktop Push Notification
          if ("Notification" in window) {
            if (Notification.permission === "granted") {
              try {
                new Notification(`🚨 ALERT SPIKE TINGGI: ${currency} (${minutesLeft} Menit Lagi)`, {
                  body: `⚡ ${title}\nWaktu: ${timeStr} WITA | Est. Lonjakan: ${estimatedPips}\nAmankan posisi Anda atau pasang Stop Loss!`,
                  icon: "https://cdn-icons-png.flaticon.com/512/2950/2950083.png",
                  tag: `spike-alert-${eventKey}`,
                });
              } catch (e) {
                console.error("Spike push notification error:", e);
              }
            } else if (Notification.permission === "default") {
              Notification.requestPermission().then((perm) => {
                if (perm === "granted") {
                  new Notification(`🚨 ALERT SPIKE TINGGI: ${currency} (${minutesLeft} Menit Lagi)`, {
                    body: `⚡ ${title}\nWaktu: ${timeStr} WITA | Est. Lonjakan: ${estimatedPips}\nAmankan posisi Anda atau pasang Stop Loss!`,
                    icon: "https://cdn-icons-png.flaticon.com/512/2950/2950083.png",
                  });
                }
              });
            }
          }

          // 2. Play Audio Alert Synthesizer
          try {
            const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
            if (AudioCtxClass) {
              const audioCtx = new AudioCtxClass();
              const osc = audioCtx.createOscillator();
              const gain = audioCtx.createGain();
              osc.type = "sawtooth";
              osc.frequency.setValueAtTime(659.25, audioCtx.currentTime);
              osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.15);
              gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
              gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.6);
              osc.connect(gain);
              gain.connect(audioCtx.destination);
              osc.start();
              osc.stop(audioCtx.currentTime + 0.6);
            }
          } catch (e) {}

          // 3. Set Active In-App High Spike Alert
          setActiveSpikeAlert({
            id: eventKey,
            title,
            currency,
            minutesLeft,
            estimatedPips,
            timeStr,
          });
        }
      }
    });
  }, [nowTicker, economicEvents, spikeNotificationEnabled]);

  const triggerTestSpikeNotification = () => {
    if ("Notification" in window) {
      if (Notification.permission !== "granted") {
        Notification.requestPermission().then((perm) => {
          if (perm === "granted") {
            executeTestNotification();
          }
        });
      } else {
        executeTestNotification();
      }
    } else {
      executeTestNotification();
    }
  };

  const executeTestNotification = () => {
    if ("Notification" in window && Notification.permission === "granted") {
      try {
        new Notification("🚨 TEST ALERT SPIKE TINGGI (5 Menit Sebelum Rilis)", {
          body: "⚡ USD - Non-Farm Payrolls (NFP) / CPI\nPerkiraan lonjakan besar: ±160 - 320 Pips.\nSistem notifikasi push desktop aktif sempurna!",
          icon: "https://cdn-icons-png.flaticon.com/512/2950/2950083.png",
        });
      } catch (e) {}
    }
    try {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        const audioCtx = new AudioCtxClass();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(659.25, audioCtx.currentTime);
        osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.6);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.6);
      }
    } catch (e) {}
    setActiveSpikeAlert({
      id: "test-" + Date.now(),
      title: "USD - High Impact News Test (CPI / NFP)",
      currency: "USD",
      minutesLeft: 5,
      estimatedPips: "±160 - 320 Pips",
      timeStr: "20:30 WITA",
    });
  };

  // Real-Time WITA Clock & Global Market Trading Sessions State
  const [realtimeWitaClock, setRealtimeWitaClock] = useState<{
    witaTimeStr: string;
    witaDateStr: string;
    utcTimeStr: string;
    activeSession: string;
    sessionColor: string;
    isKillzone: boolean;
    killzoneBadge: string;
    marketStatus: string;
    hours: number;
    minutes: number;
    seconds: number;
  }>({
    witaTimeStr: "--:--:-- WITA",
    witaDateStr: "Memuat WITA...",
    utcTimeStr: "--:--:-- UTC",
    activeSession: "SESI ASIA / TOKYO",
    sessionColor: "text-amber-400",
    isKillzone: false,
    killzoneBadge: "NORMAL SESSION",
    marketStatus: "LIVE MARKET AKTIF",
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  // Optimized 1-Second Timer for UI clock & countdown (Zero lag, zero freeze)
  useEffect(() => {
    const witaFormatter = new Intl.DateTimeFormat("id-ID", {
      timeZone: "Asia/Makassar",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    });
    const witaDateFormatter = new Intl.DateTimeFormat("id-ID", {
      timeZone: "Asia/Makassar",
      weekday: "long",
      day: "numeric",
      month: "short",
      year: "numeric",
    });
    const utcFormatter = new Intl.DateTimeFormat("en-US", {
      timeZone: "UTC",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    });

    const tick = () => {
      const timeMs = Date.now();
      const currentSecond = Math.floor(timeMs / 1000);
      setNowTicker(timeMs);

      // 1. Calculate Real-Time WITA Clock & Global Market Trading Sessions
      const nowDateObj = new Date(timeMs + globalServerTimeOffset);
      const timeStr = witaFormatter.format(nowDateObj);
      const dateStr = witaDateFormatter.format(nowDateObj);
      const utcStr = utcFormatter.format(nowDateObj);

      const witaDateObj = new Date(nowDateObj.toLocaleString("en-US", { timeZone: "Asia/Makassar" }));
      const hours = witaDateObj.getHours();
      const minutes = witaDateObj.getMinutes();
      const seconds = witaDateObj.getSeconds();
      const day = witaDateObj.getDay();

      let activeSession = "SESI ASIA / TOKYO";
      let sessionColor = "text-amber-400";
      let isKillzone = false;
      let killzoneBadge = "ASIAN RANGE ACCUMULATION";

      if (hours >= 20 && hours < 24) {
        activeSession = "LONDON & NEW YORK OVERLAP";
        sessionColor = "text-emerald-400";
        isKillzone = true;
        killzoneBadge = "🔴 NY AM KILLZONE (VOLUME TERTINGGI)";
      } else if (hours >= 0 && hours < 5) {
        activeSession = "SESI NEW YORK (LATE / CLOSE)";
        sessionColor = "text-cyan-400";
        isKillzone = false;
        killzoneBadge = "NY PM DISTRIBUTION";
      } else if (hours >= 5 && hours < 8) {
        activeSession = "SESI SYDNEY / PACIFIC";
        sessionColor = "text-purple-400";
        isKillzone = false;
        killzoneBadge = "PACIFIC OPEN ALIGNMENT";
      } else if (hours >= 8 && hours < 15) {
        activeSession = "SESI ASIA / TOKYO";
        sessionColor = "text-amber-400";
        isKillzone = false;
        killzoneBadge = "ASIAN RANGE BUILDUP";
      } else if (hours >= 15 && hours < 16) {
        activeSession = "SESI LONDON PRE-MARKET";
        sessionColor = "text-blue-400";
        isKillzone = false;
        killzoneBadge = "LONDON OPEN PREP";
      } else if (hours >= 16 && hours < 20) {
        activeSession = "SESI LONDON (EUROPE)";
        sessionColor = "text-emerald-400";
        isKillzone = (hours >= 16 && hours < 19);
        killzoneBadge = isKillzone ? "🔴 LONDON OPEN KILLZONE" : "LONDON ACTIVE";
      }

      const marketClosedInfo = getMarketClosedStatus(activeSymbol.id, timeMs);
      const isBtc = (activeSymbol.id || "").toUpperCase().includes("BTC");
      const isWeekend = day === 0 || day === 6;

      let marketStatus = "LIVE MARKET AKTIF (24/5 FOREX & 24/7 CRYPTO)";
      let activeSessionTitle = activeSession;
      let sessionColorTitle = sessionColor;
      let isKillzoneActive = isKillzone;
      let killzoneBadgeTitle = killzoneBadge;

      if (marketClosedInfo.isClosed) {
        marketStatus = `🔒 PASAR ${activeSymbol.id} TUTUP (WEEKEND) | BUKA SENIN 05:00 WITA (${marketClosedInfo.countdownStr})`;
        activeSessionTitle = `🔒 PASAR ${activeSymbol.id} TUTUP`;
        sessionColorTitle = "text-amber-400";
        isKillzoneActive = false;
        killzoneBadgeTitle = `⏱️ BUKA SENIN 05:00 WITA: ${marketClosedInfo.countdownStr}`;
      } else if (isBtc) {
        marketStatus = "🟢 PASAR CRYPTO (BTCUSD) BUKA 24/7 TANPA LIBUR";
        if (isWeekend) {
          activeSessionTitle = "🟢 SESI CRYPTO WEEKEND (24/7 NON-STOP)";
          sessionColorTitle = "text-emerald-400";
          isKillzoneActive = false;
          killzoneBadgeTitle = "⚡ 24/7 ON-CHAIN LIQUIDITY AKTIF";
        } else {
          activeSessionTitle = `🟢 CRYPTO 24/7 (${activeSession})`;
          sessionColorTitle = "text-emerald-400";
          killzoneBadgeTitle = `${killzoneBadge} (CRYPTO 24/7)`;
        }
      }

      setRealtimeWitaClock({
        witaTimeStr: `${timeStr} WITA`,
        witaDateStr: dateStr,
        utcTimeStr: `${utcStr} UTC`,
        activeSession: activeSessionTitle,
        sessionColor: sessionColorTitle,
        isKillzone: isKillzoneActive,
        killzoneBadge: killzoneBadgeTitle,
        marketStatus,
        hours,
        minutes,
        seconds,
      });

      // 2. Precise Candle Close Countdown
      const isGold = (activeSymbol.id || "").toUpperCase().includes("XAU") || (activeSymbol.id || "").toUpperCase().includes("GOLD");
      const isClosedForAsset = marketClosedInfo.isClosed && !isBtc;

      if (isClosedForAsset) {
        const closedTimerStr = isGold
          ? "⏸️ DIHENTIKAN (PASAR TUTUP WEEKEND)"
          : `🔒 PASAR TUTUP (BUKA SENIN 05:00 WITA: ${marketClosedInfo.countdownStr})`;
        setCandleCountdown(closedTimerStr);
        setNextCandleTime(closedTimerStr);
      } else {
        const nowSec = timeMs / 1000;
        let tfSec = 900;
        switch (activeTimeframe.id) {
          case "M1": tfSec = 60; break;
          case "M5": tfSec = 300; break;
          case "M15": tfSec = 900; break;
          case "M30": tfSec = 1800; break;
          case "H1": tfSec = 3600; break;
          case "H4": tfSec = 14400; break;
          case "D1": tfSec = 86400; break;
          default: tfSec = 900; break;
        }
        const currentPeriodStart = Math.floor(nowSec / tfSec) * tfSec;
        const nextPeriodStart = currentPeriodStart + tfSec;
        const diff = Math.max(0, Math.ceil(nextPeriodStart - nowSec));

        const countdownHours = Math.floor(diff / 3600);
        const countdownMins = Math.floor((diff % 3600) / 60);
        const countdownSecs = diff % 60;

        let countdownStr = "";
        if (countdownHours > 0) {
          countdownStr = `${countdownHours}:${(countdownMins ?? 0).toString().padStart(2, "0")}:${(countdownSecs ?? 0).toString().padStart(2, "0")}`;
        } else {
          countdownStr = `${(countdownMins ?? 0).toString()}:${(countdownSecs ?? 0).toString().padStart(2, "0")}`;
        }
        setCandleCountdown(countdownStr);
        setNextCandleTime(countdownStr);
      }

      // 3. Update NFP Countdown once per minute
      if (currentSecond % 60 === 0) {
        const now = new Date(timeMs);
        const nfpDate = new Date(timeMs);
        nfpDate.setUTCDate(
          nfpDate.getUTCDate() + ((5 + 7 - nfpDate.getUTCDay()) % 7),
        );
        nfpDate.setUTCHours(13, 30, 0, 0);
        if (nfpDate.getTime() < now.getTime()) {
          nfpDate.setUTCDate(nfpDate.getUTCDate() + 7);
        }
        const nfpDiff = nfpDate.getTime() - now.getTime();
        const d = Math.floor(nfpDiff / (1000 * 60 * 60 * 24));
        const h = Math.floor(
          (nfpDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60),
        );
        const m = Math.floor((nfpDiff % (1000 * 60 * 60)) / (1000 * 60));
        setNfpData((prev) => ({ ...prev, countdown: `${d}d ${h}h ${m}m` }));
      }
    };

    tick();
    const intervalTimer = setInterval(tick, 1000);
    return () => clearInterval(intervalTimer);
  }, [activeTimeframe]);

  const [userSession] = useState<{
    isLoggedIn: boolean;
    username: string;
    role: string;
    tokens: number;
    membershipTier: string;
    membershipExpiresAt: number;
  }>({
    isLoggedIn: true,
    username: "PRO TRADER",
    role: "DEV",
    tokens: 999999,
    membershipTier: "UNLIMITED",
    membershipExpiresAt: Date.now() + 36500 * 24 * 60 * 60 * 1000,
  });

  const [voiceGender, setVoiceGender] = useState<"MALE" | "FEMALE">("FEMALE");
  const [isAnalyzingAI, setIsAnalyzingAI] = useState(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<any | null>(null);
  const [showAiResultDetail, setShowAiResultDetail] = useState(false);

  // Fetch real economic calendar events from our backend with rapid real-time sync (STRICTLY USD ONLY)
  const fetchCalendar = useCallback(async () => {
    try {
      setIsCalendarSyncing(true);
      const res = await fetch(`/api/calendar?t=${Date.now()}`, {
        signal: AbortSignal.timeout(4000)
      });
      if (res.ok) {
        const data = await res.json();
        setCalendarMeta({ isSample: !!data.isSample, source: String(data.source || ""), hasLoaded: true });
        if (data.result && Array.isArray(data.result) && data.result.length > 0) {
          // Strictly filter USD events only
          const usdOnly = data.result.filter((ev: any) => {
            const cur = String(ev.currency || ev.country || "").toUpperCase();
            return cur === "USD" || cur === "US";
          });
          setEconomicEvents(usdOnly.length > 0 ? usdOnly : data.result);
          setCalendarLastSync(Date.now());
        }
      }
    } catch (e) {
      // Gracefully retain existing state on network latency
    } finally {
      setIsCalendarSyncing(false);
    }
  }, []);

  useEffect(() => {
    fetchCalendar();
    const interval = setInterval(() => {
      if (typeof document !== "undefined" && document.hidden) return;
      fetchCalendar();
    }, 45000); // Optimized sync every 45s to avoid main thread stutters
    return () => clearInterval(interval);
  }, [fetchCalendar]);

  // Indonesian Text-to-Speech synthesizer
  const speakIndonesianSignal = (analysis: any) => {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    
    const text = `Analisis selesai. Sinyal ${analysis.signal} terdeteksi untuk ${activeSymbol.name} pada timeframe ${activeTimeframe.id} dengan tingkat keyakinan ${analysis.confidence} persen. Harga masuk disarankan pada ${analysis.entryPrice.toFixed(2)}, stop loss pada ${analysis.stopLoss.toFixed(2)}, dan take profit pada ${analysis.takeProfit.toFixed(2)}.`;
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "id-ID";
    utterance.rate = 0.95;
    
    const voices = window.speechSynthesis.getVoices();
    const idVoices = voices.filter(v => v.lang.startsWith("id") || v.lang.startsWith("in"));
    
    if (idVoices.length > 0) {
      if (voiceGender === "MALE") {
        const maleVoice = idVoices.find(v => v.name.toLowerCase().includes("male") || v.name.toLowerCase().includes("david") || v.name.toLowerCase().includes("google"));
        utterance.voice = maleVoice || idVoices[0];
      } else {
        const femaleVoice = idVoices.find(v => v.name.toLowerCase().includes("female") || v.name.toLowerCase().includes("zira") || v.name.toLowerCase().includes("susan") || v.name.toLowerCase().includes("google"));
        utterance.voice = femaleVoice || idVoices[0];
      }
    }
    window.speechSynthesis.speak(utterance);
  };

  // Helper to generate premium mock fallback analysis
  const generateMockAnalysis = (params: { currentPrice: number, timeframe: string, rsi: number }) => {
    const rsi = params.rsi || 50;
    let signal = "WAIT";
    
    // Follow the momentum: High RSI -> BUY, Low RSI -> SELL
    if (rsi > 55) {
      signal = "BUY";
    } else if (rsi < 45) {
      signal = "SELL";
    } else {
      signal = "WAIT";
    }

    const entryPrice = signal === "WAIT" ? null : params.currentPrice;
    const stopLoss = signal === "WAIT" ? null : (signal === "BUY" ? entryPrice * 0.992 : entryPrice * 1.008);
    const takeProfit = signal === "WAIT" ? null : (signal === "BUY" ? entryPrice * 1.025 : entryPrice * 0.975);
    
    const teknikal = signal === "WAIT" ? 50 : 84;
    const fundamental = signal === "WAIT" ? 50 : 78;
    const sentimen = signal === "WAIT" ? 50 : 80;
    const statistik = signal === "WAIT" ? 50 : 72;
    const confidence = signal === "WAIT" ? 48.0 : Number((teknikal * 0.4 + fundamental * 0.3 + sentimen * 0.2 + statistik * 0.1).toFixed(1));
    
    return {
      signal,
      confidence,
      scores: {
        teknikal,
        fundamental,
        sentimen,
        statistik
      },
      riskRewardRatio: signal === "WAIT" ? "-" : "1:3.1",
      entryPrice,
      stopLoss,
      takeProfit,
      smcConceptsFound: signal === "WAIT" ? ["CONSOLIDATION", "RANGE_BOUND"] : ["ORDER_BLOCK", "FVG_IMBALANCE", "LIQUIDITY_SWEEP", "REALTIME_WITA_TIME_SYNC"],
      reasoning: [
        `[REAL-TIME WITA SYNC]: Analisis terhubung secara real-time pada ${realtimeWitaClock.witaTimeStr} (${realtimeWitaClock.activeSession} - ${realtimeWitaClock.killzoneBadge}).`,
        "Order Block terkonfirmasi di level support kunci harian dengan akumulasi order beli yang kuat.",
        "FVG (Fair Value Gap) yang belum termitigasi akhirnya terisi penuh, mengundang institusi masuk.",
        "Sweep liquidity di bawah swing low memicu stop hunts para retail trader sebelum upmove terjadi.",
        "Korelasi high-timeframe (HTF) mengonfirmasi bias bullish struktural jangka panjang.",
        "RSI mengindikasikan kondisi oversold yang sehat di chart lower timeframe.",
        "EMA 20 bertindak sebagai support dinamis yang kokoh selama fase retest saat ini.",
        "Kandungan volume perdagangan meningkat 35% di atas rata-rata pergerakan harian.",
        "Sentimen pasar umum menunjukkan 62% pembeli mendominasi di bursa derivatif utama.",
        "Proyeksi rilis berita inflasi pekan depan diprakirakan akan melemahkan indeks USD.",
        "Model DRL mengonfirmasi tingkat keuntungan (advantage) di atas ambang batas 0.25.",
        "Probabilitas policy action condong ke arah eksekusi agresif dengan tingkat kepastian tinggi.",
        "Struktur pasar mikro menunjukkan pola pembalikan arah CHoCH yang bersih.",
        "Tingkat keandalan order block unmitigated diestimasi sebesar 89% berdasarkan backtest harian.",
        "Penyebaran bid-ask spread yang sempit meminimalkan slippage saat eksekusi entry market."
      ],
      drlMetrics: {
        stateValue: signal === "WAIT" ? 0.0 : 0.85,
        advantage: signal === "WAIT" ? 0.05 : 0.35,
        policyProbabilities: {
          buy: signal === "BUY" ? 78 : signal === "WAIT" ? 33 : 12,
          sell: signal === "SELL" ? 82 : signal === "WAIT" ? 34 : 12,
          hold: signal === "WAIT" ? 33 : 10
        }
      }
    };
  };

  // Perform AI trading analysis
  const runAIAnalysis = async () => {
    setIsAnalyzingAI(true);
    try {
      const payload = {
        asset: activeSymbol.id,
        timeframe: activeTimeframe.id,
        rsi: indicators.rsi,
        stochK: indicators.stochK,
        stochD: indicators.stochD,
        ema20: indicators.ema20,
        ema50: indicators.ema50,
        ema200: indicators.ema200,
        currentPrice: currentPrice.bid > 0 ? currentPrice.bid : (activeSymbol.id === "BTCUSD" ? 77500.00 : 4430.00),
        smcStructure: htfData.overall,
        sentiment: htfData.sentiment || { buy: 50, sell: 50 },
        ltfTrend: ltfData.overall,
        htfTrend: htfData.overall,
        realtimeClock: {
          timestamp: Date.now(),
          witaTime: realtimeWitaClock.witaTimeStr,
          witaDate: realtimeWitaClock.witaDateStr,
          activeSession: realtimeWitaClock.activeSession,
          isKillzone: realtimeWitaClock.isKillzone,
          killzoneBadge: realtimeWitaClock.killzoneBadge,
          marketStatus: realtimeWitaClock.marketStatus,
        }
      };
      
      const res = await fetch("/api/ai/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      
      if (res.ok) {
        const data = await res.json();
        setAiAnalysisResult(data);
        setShowAiResultDetail(true);
      } else {
        throw new Error("AI Endpoint failed");
      }
    } catch (err) {
      console.error(err);
      // Fallback mock
      const mockData = generateMockAnalysis({
        currentPrice: currentPrice.bid > 0 ? currentPrice.bid : (activeSymbol.id === "BTCUSD" ? 77500.00 : 4430.00),
        timeframe: activeTimeframe.id,
        rsi: 55
      });
      setAiAnalysisResult(mockData);
      setShowAiResultDetail(true);
    } finally {
      setIsAnalyzingAI(false);
    }
  };

  // Save settings to Firestore
  const saveSettingsToFirebase = async (settings: {
    activeSymbolId: string;
    activeTimeframeId: string;
    tradingStyleId: string;
    signalMethodId: string;
    visualTheme: string;
    soundEnabled: boolean;
    priceOffset: number;
    aiLevel: number;
    aiXp: number;
    aiEpochs: number;
    aiWinRateBonus: number;
  }) => {
    if (!db) return;
    const userId = "mirzasimbala1_gmail_com";
    try {
      const docRef = doc(db, "user_settings", userId);
      await setDoc(docRef, settings);
    } catch (e) {
      console.warn("Error auto-saving user settings to Firestore:", e);
    }
  };

  // Real-time sync from Firestore
  useEffect(() => {
    if (!db) return;
    const userId = "mirzasimbala1_gmail_com";
    const docRef = doc(db, "user_settings", userId);

    const unsubscribe = onSnapshot(
      docRef,
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();

          // Only update local state if Firestore data is different and NOT just currently being updated
          if (data.activeSymbolId && data.activeSymbolId !== activeSymbol.id) {
            const sym = SYMBOLS.find((s) => s.id === data.activeSymbolId);
            if (sym) setActiveSymbol(sym);
          }
          if (
            data.activeTimeframeId &&
            data.activeTimeframeId !== activeTimeframe.id
          ) {
            const tf = TIMEFRAMES.find((t) => t.id === data.activeTimeframeId);
            if (tf) setActiveTimeframe(tf);
          }
          if (data.tradingStyleId && data.tradingStyleId !== tradingStyle.id) {
            const style = TRADING_STYLES.find(
              (s) => s.id === data.tradingStyleId,
            );
            if (style) setTradingStyle(style);
          }
          if (data.signalMethodId && data.signalMethodId !== signalMethod.id) {
            const method = SIGNAL_METHODS.find(
              (m) => m.id === data.signalMethodId,
            );
            if (method) setSignalMethod(method);
          }
          if (data.visualTheme && data.visualTheme !== visualTheme) {
            setVisualTheme(data.visualTheme);
          }
          if (
            data.soundEnabled !== undefined &&
            data.soundEnabled !== soundEnabled
          ) {
            setSoundEnabled(data.soundEnabled);
          }
          if (
            data.priceOffset !== undefined &&
            data.priceOffset !== priceOffset
          ) {
            setPriceOffset(data.priceOffset);
          }
          if (data.aiLevel !== undefined) setAiLevel(data.aiLevel);
          if (data.aiXp !== undefined) setAiXp(data.aiXp);
          if (data.aiEpochs !== undefined) setAiEpochs(data.aiEpochs);
          if (data.aiWinRateBonus !== undefined)
            setAiWinRateBonus(data.aiWinRateBonus);
        }
        isFirestoreLoaded.current = true;
      },
      (err) => {
        console.warn("Firestore user settings sync error:", err);
        isFirestoreLoaded.current = true;
      },
    );

    return () => unsubscribe();
  }, []);

  const isInitialMount = useRef(true);
  const serverTimeOffsetRef = useRef(0);
  
  // Initialize and periodically sync time
  useEffect(() => {
    const syncTime = async () => {
      try {
        const res = await fetch("/api/binance-time");
        const data = await res.json();
        const serverTime = Number(data.serverTime);
        if (!isFinite(serverTime) || serverTime <= 0) return; // abaikan respons tanpa waktu server
        const localTime = Date.now();
        globalServerTimeOffset = serverTime - localTime;
        serverTimeOffsetRef.current = serverTime - localTime;
      } catch (e) {
        console.warn("Failed to sync time", e);
      }
    };
    
    syncTime();
    const interval = setInterval(syncTime, 60000); // Sync every minute
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Save to localStorage immediately
    localStorage.setItem("zr_symbol", JSON.stringify(activeSymbol));
    localStorage.setItem("zr_tf", JSON.stringify(activeTimeframe));
    localStorage.setItem("zr_style", JSON.stringify(tradingStyle));
    localStorage.setItem("zr_method", JSON.stringify(signalMethod));
    localStorage.setItem("zr_theme", visualTheme);

    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }

    if (!isFirestoreLoaded.current) {
      return; // Prevent overwriting database with defaults before onSnapshot finishes loading
    }

    const delayDebounce = setTimeout(() => {
      saveSettingsToFirebase({
        activeSymbolId: activeSymbol.id,
        activeTimeframeId: activeTimeframe.id,
        tradingStyleId: tradingStyle.id,
        signalMethodId: signalMethod.id,
        visualTheme,
        soundEnabled,
        priceOffset,
        aiLevel,
        aiXp,
        aiEpochs,
        aiWinRateBonus,
      });
    }, 1000); // 1-second debounce to avoid writing to Firestore on rapid changes

    return () => clearTimeout(delayDebounce);
  }, [
    activeSymbol,
    activeTimeframe,
    tradingStyle,
    signalMethod,
    visualTheme,
    soundEnabled,
    priceOffset,
    aiLevel,
    aiXp,
    aiEpochs,
    aiWinRateBonus,
  ]);

  const [isSignalsLoaded, setIsSignalsLoaded] = useState(false);
  const hudContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!db) {
      console.log("Firebase is not initialized or db is not available. Using local state.");
      setIsSignalsLoaded(true);
    }
  }, [db]);

  const lastSignalTimeRef = useRef<number>(0);
  const [nextCandleTime, setNextCandleTime] = useState("--:--");
  const [currentPrice, setCurrentPrice] = useState<{
    bid: number;
    ask: number;
  }>({ bid: 0, ask: 0 });

  const [indicators, setIndicators] = useState<any>({
    ema20: 0,
    sma50: 0,
    sma200: 0,
    ema50: 0,
    ema200: 0,
    macd: 0,
    stochK: 50,
    stochD: 50,
    prevClose: 0,
    rsi: 50,
    atr: 1.5,
    pattern: "NONE",
    smc: { sweep: "NONE", ob: "NONE", fvg: "NONE" },
    rsiDivergence: null,
  });

  const [isDynamicAtrTpEnabled, setIsDynamicAtrTpEnabled] = useState(true);
  const lastAtrTpUpdateRef = useRef<number>(0);

  // Classic Chart Pattern Breakout / Breakdown Desktop Notification State
  const [patternNotificationEnabled, setPatternNotificationEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("remix_pattern_notif_enabled");
      return saved !== null ? saved === "true" : true;
    } catch {
      return true;
    }
  });
  const lastPatternAlertRef = useRef<{ [patternKey: string]: number }>({});

  const [selectedVoiceGender, setSelectedVoiceGender] = useState<"MALE" | "FEMALE">("MALE");

  const speakAnalysisReasoning = (text: string) => {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();

    const msg = new SpeechSynthesisUtterance(text);
    msg.lang = "id-ID";

    const voices = window.speechSynthesis.getVoices();
    const indonesianVoices = voices.filter((v) => v.lang.includes("id") || v.lang.includes("ID"));

    if (indonesianVoices.length > 0) {
      if (selectedVoiceGender === "MALE") {
        const maleVoice = indonesianVoices.find((v) => v.name.toLowerCase().includes("male") || v.name.toLowerCase().includes("david") || v.name.toLowerCase().includes("id"));
        msg.voice = maleVoice || indonesianVoices[0];
        msg.pitch = 0.75;
      } else {
        const femaleVoice = indonesianVoices.find((v) => v.name.toLowerCase().includes("female") || v.name.toLowerCase().includes("gadis") || v.name.toLowerCase().includes("zira"));
        msg.voice = femaleVoice || indonesianVoices[0];
        msg.pitch = 1.25;
      }
    } else {
      msg.pitch = selectedVoiceGender === "MALE" ? 0.75 : 1.25;
    }

    msg.rate = 0.95;
    window.speechSynthesis.speak(msg);
  };

  const [htfData, setHtfData] = useState<any>({
    m15: {},
    m30: {},
    h1: {},
    h4: {},
    overall: "NEUTRAL",
  });
  const [ltfData, setLtfData] = useState<any>({
    m1: {},
    m5: {},
    overall: "NEUTRAL",
  });
  const [nfpData, setNfpData] = useState({
    isNfpWeek: true,
    countdown: "Menghitung...",
    prediction: "Menganalisis data NFP...",
  });
  const [news, setNews] = useState<any[]>([]);
  const [prediction, setPrediction] = useState("");
  const [mt5Status, setMt5Status] = useState("CONNECTING...");
  const [showMtfBreakdown, setShowMtfBreakdown] = useState(true);

  // Dedicated US Radar Modal state (separated from main feed as requested)
  const [showUsRadarModal, setShowUsRadarModal] = useState(false);

  // Smooth auto-scroll to Economic Calendar without swiping
  const scrollToCalendar = () => {
    const el = document.getElementById("calendar-section");
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  // Tab control for news/calendar
  const [newsTab, setNewsTab] = useState<
    "PERSONALIZED" | "ECONOMIC" | "AI_NEWS"
  >("PERSONALIZED");
  const [newsFilterActive, setNewsFilterActive] = useState(true);

  // Auto switch news tab based on active symbol when filter is active
  useEffect(() => {
    if (newsFilterActive) {
      // Prioritize the personalized asset feed
      setNewsTab("PERSONALIZED");
    }
  }, [activeSymbol.id, newsFilterActive]);

  // Candle close countdown state
  const [candleCountdown, setCandleCountdown] = useState<string>("0:00");

  // AI self-correction & learning logs
  const [aiSelfCorrectionLogs, setAiSelfCorrectionLogs] = useState<any[]>(
    () => [
      {
        time: "08:00:00",
        tag: "SYSTEM",
        message: "Super Agentic AI Brain initialized. Loading memory...",
      },
      {
        time: "08:00:05",
        tag: "AI VISION",
        message:
          "Calibrating charts & timeframe boundaries with TradingView live streams...",
      },
      {
        time: "08:00:10",
        tag: "NEWS",
        message:
          "Global Economic News API connected. Scanning high-impact indicators...",
      },
      {
        time: "08:00:15",
        tag: "EVOLUTION",
        message:
          "Self-Learning module active. AI level synchronized. Ready to calibrate risk weightings.",
      },
    ],
  );

  const runAiTraining = () => {
    if (isTraining) return;
    setIsTraining(true);
    setTrainingProgress(0);

    const logsToAdd = [
      {
        pct: 15,
        tag: "DEEP LEARNING",
        msg: "Memulai epoch pelatihan... Mengunduh 50,000 tick historis untuk backtesting.",
      },
      {
        pct: 40,
        tag: "OPTIMIZER",
        msg: "Melakukan iterasi backpropagation bobot Confluence SMC...",
      },
      {
        pct: 65,
        tag: "NEURAL NET",
        msg: "Menyesuaikan bias multi-timeframe M15-D1 untuk meminimalkan false break.",
      },
      {
        pct: 85,
        tag: "VISION TUNE",
        msg: "Menguji performa sniper entry pada level likuiditas tertinggi.",
      },
      {
        pct: 100,
        tag: "EVOLUTION",
        msg: "Epoch selesai! Parameter terkalibrasi presisi dengan trader institusional.",
      },
    ];

    let currentProgress = 0;
    const interval = setInterval(() => {
      currentProgress += 5;
      setTrainingProgress(currentProgress);

      const log = logsToAdd.find((l) => l.pct === currentProgress);
      if (log) {
        const now = new Date();
        const timeStr = now.toTimeString().split(" ")[0];
        setAiSelfCorrectionLogs((prev) => [
          ...prev,
          { time: timeStr, tag: log.tag, message: log.msg },
        ]);
        setTrainingStatusText(log.msg);
      }

      if (currentProgress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setIsTraining(false);
          setTrainingProgress(0);
          setTrainingStatusText("");

          // Add reward
          setAiEpochs((prev) => prev + 1);
          setAiXp((prev) => {
            const nextXp = prev + 250;
            const currentLvl = Math.floor(prev / 1000) + 1;
            const nextXpLvl = Math.floor(nextXp / 1000) + 1;
            if (nextXpLvl > currentLvl) {
              setAiLevel(nextXpLvl);
              setAiWinRateBonus((b) => Number((b + 0.5).toFixed(1)));

              const now = new Date();
              const timeStr = now.toTimeString().split(" ")[0];
              setAiSelfCorrectionLogs((p) => [
                ...p,
                {
                  time: timeStr,
                  tag: "EVOLUTION",
                  message: `🎉 LEVEL UP! AI berevolusi ke Level ${nextXpLvl}! Akurasi meningkat +0.5%.`,
                },
              ]);
            } else {
              const now = new Date();
              const timeStr = now.toTimeString().split(" ")[0];
              setAiSelfCorrectionLogs((p) => [
                ...p,
                {
                  time: timeStr,
                  tag: "EVOLUTION",
                  message: `📈 Pelatihan selesai! Diperoleh +250 XP. Level kemajuan teroptimasi.`,
                },
              ]);
            }
            return nextXp;
          });
        }, 600);
      }
    }, 150);
  };

  const startApkCompilation = () => {
    if (isCompilingApk) return;
    setIsCompilingApk(true);
    setApkCompileProgress(0);
    setApkCompiledSuccessfully(false);
    setApkCompileLogs([]);

    const steps = [
      { pct: 10, msg: `[SYSTEM] Memulai Android package compiler engine...` },
      {
        pct: 20,
        msg: `[SYSTEM] Membaca konfigurasi Android Manifest untuk App Name "${apkAppName}"`,
      },
      {
        pct: 30,
        msg: `[SYSTEM] Memetakan target package: "${apkPackageName}"`,
      },
      {
        pct: 45,
        msg: `[SYSTEM] Mengunduh wrapper Native WebView SDK v4.8.2...`,
      },
      {
        pct: 60,
        msg: `[SYSTEM] Mengompilasi kode program Java/Kotlin ke format Dalvik Executable (DEX)...`,
      },
      {
        pct: 75,
        msg: `[SYSTEM] Mengompresi aset statis, icon, dan manifest.json...`,
      },
      {
        pct: 90,
        msg: `[SYSTEM] Menandatangani paket aplikasi APK dengan Release Keystore Zrill...`,
      },
      {
        pct: 100,
        msg: `[SYSTEM] Sukses! Paket aplikasi Android APK berhasil dibuat (ZipAligned & Signed).`,
      },
    ];

    let currentPct = 0;
    const interval = setInterval(() => {
      currentPct += 5;
      setApkCompileProgress(currentPct);

      const log = steps.find((s) => s.pct === currentPct);
      if (log) {
        setApkCompileLogs((prev) => [
          ...prev,
          `${new Date().toLocaleTimeString()} - ${log.msg}`,
        ]);
      }

      if (currentPct >= 100) {
        clearInterval(interval);
        setApkCompiledSuccessfully(true);
        setIsCompilingApk(false);
      }
    }, 180);
  };

  // Real-time Trade Session Performance History (synchronized via Firestore, empty on init)
  const [sessionTrades, setSessionTrades] = useState<any[]>([]);

  const exportJournalToCsv = () => {
    if (sessionTrades.length === 0) return;

    const headers = [
      "ID",
      "Time",
      "Symbol",
      "Type",
      "Method",
      "Entry Price",
      "Profit/Loss ($)",
      "Result",
    ];

    const rows = sessionTrades.map((t) => [
      t.id || "",
      t.time || "",
      t.symbol || "",
      t.type || "",
      t.method || "",
      t.entry !== undefined ? t.entry.toFixed(2) : "",
      t.profit !== undefined ? t.profit.toFixed(2) : "",
      t.result || "",
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map((row) =>
        row.map((val) => `"${String(val).replace(/"/g, '""')}"`).join(","),
      ),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute(
      "download",
      `trading_journal_${new Date().toISOString().split("T")[0]}.csv`,
    );
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Helper: Save trade to Firestore
  const saveTradeToFirebase = async (trade: any) => {
    if (!db) return;
    const path = "session_trades";
    try {
      const docRef = doc(collection(db, path));
      // Firestore menolak nilai undefined, jadi bersihkan dulu.
      await setDoc(docRef, JSON.parse(JSON.stringify({
        ...trade,
        timestamp: trade.timestamp || Date.now(),
      })));
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  };

  // Snapshot Visual Setup & Trading Journal Evaluation State
  const [snapshotSuccessToast, setSnapshotSuccessToast] = useState<string | null>(null);
  const [viewingSnapshotDoc, setViewingSnapshotDoc] = useState<any | null>(null);
  const [isJournalSectionOpen, setIsJournalSectionOpen] = useState<boolean>(false);

  const handleSaveSnapshotToJournal = async () => {
    if (!currentSignal || currentSignal.status === "WAITING" || !currentSignal.entry) {
      alert("Belum ada sinyal aktif yang dapat disimpan ke Jurnal. Silakan jalankan analisis pasar terlebih dahulu.");
      return;
    }

    const snapshotDoc = {
      id: `SNAP_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
      timestamp: Date.now(),
      time: realtimeWitaClock.witaTime || `${new Date().toLocaleTimeString()} WITA`,
      witaDate: realtimeWitaClock.witaDate || new Date().toLocaleDateString(),
      symbol: activeSymbol.id,
      symbolName: activeSymbol.name,
      timeframe: activeTimeframe.id,
      type: currentSignal.type,
      orderExecutionType: currentSignal.orderExecutionType || "INSTANT",
      entry: currentSignal.entry, // dibutuhkan aturan Firestore (isValidTrade)
      exit: 0,
      entryPrice: currentSignal.entry,
      entryZoneMin: currentSignal.entryZoneMin || Number((currentSignal.entry - 0.5).toFixed(2)),
      entryZoneMax: currentSignal.entryZoneMax || Number((currentSignal.entry + 0.5).toFixed(2)),
      sl: currentSignal.sl,
      tp1: currentSignal.tp1,
      tp2: currentSignal.tp2,
      tp3: currentSignal.tp3,
      rr: currentSignal.rr || "1:2.8",
      qualityGrade: currentSignal.qualityGrade || "AAA+ INSTITUTIONAL",
      confidence: currentSignal.confidence || 98,
      method: currentSignal.method || "SMC 7-Pillar Confluence",
      activeSession: realtimeWitaClock.activeSession || "SESI AKTIF",
      breakevenPrice: currentSignal.breakevenPrice || currentSignal.entry,
      invalidationPrice: currentSignal.invalidationPrice || currentSignal.sl,
      notes: `Snapshot visual setup ${currentSignal.type} ${activeSymbol.id} (${activeTimeframe.id}) dievaluasi pada ${realtimeWitaClock.witaTime} WITA (${realtimeWitaClock.witaDate}).`,
      result: "EVALUATION_PENDING",
      isVisualSnapshot: true,
      status: "SNAPSHOT_SAVED",
      profit: 0,
    };

    await saveTradeToFirebase(snapshotDoc);
    setSessionTrades((prev) => [snapshotDoc, ...prev]);

    setSnapshotSuccessToast(
      `📸 Snapshot Setup ${activeSymbol.id} (${currentSignal.type}) @ $${currentSignal.entry.toFixed(2)} Berhasil Disimpan ke Jurnal Trading!`
    );
    setTimeout(() => {
      setSnapshotSuccessToast(null);
    }, 4500);
  };

  const handleUpdateJournalDocResult = async (docId: string | number, newResult: string, newNotes?: string, newProfit?: number) => {
    // 1. Optimistic update in local state
    setSessionTrades((prev) =>
      prev.map((item) => {
        if (item.id === docId || item.docId === docId) {
          let updatedProfit = item.profit;
          if (typeof newProfit === "number" && isFinite(newProfit)) {
            updatedProfit = newProfit;
          } else if (newResult === "BREAKEVEN") {
            updatedProfit = 0;
          }
          return {
            ...item,
            result: newResult,
            profit: updatedProfit,
            notes: newNotes !== undefined ? newNotes : item.notes,
          };
        }
        return item;
      })
    );

    if (viewingSnapshotDoc && (viewingSnapshotDoc.id === docId || viewingSnapshotDoc.docId === docId)) {
      setViewingSnapshotDoc((prev: any) =>
        prev
          ? {
              ...prev,
              result: newResult,
              notes: newNotes !== undefined ? newNotes : prev.notes,
            }
          : null
      );
    }

    // 2. Persist real-time update to Firestore
    if (db) {
      try {
        const directDocRef = doc(db, "session_trades", String(docId));
        const directSnap = await getDoc(directDocRef);
        if (directSnap.exists()) {
          const currentData = directSnap.data();
          let updatedProfit = currentData.profit;
          if (typeof newProfit === "number" && isFinite(newProfit)) {
            updatedProfit = newProfit;
          } else if (newResult === "BREAKEVEN") {
            updatedProfit = 0;
          }
          await updateDoc(directDocRef, {
            result: newResult,
            profit: updatedProfit,
            notes: newNotes !== undefined ? newNotes : (currentData.notes || ""),
          });
        } else {
          const q = query(collection(db, "session_trades"), where("id", "==", docId));
          const querySnapshot = await getDocs(q);
          if (!querySnapshot.empty) {
            querySnapshot.forEach(async (d) => {
              const currentData = d.data();
              let updatedProfit = currentData.profit;
              if (typeof newProfit === "number" && isFinite(newProfit)) {
            updatedProfit = newProfit;
          } else if (newResult === "BREAKEVEN") {
            updatedProfit = 0;
          }
              await updateDoc(d.ref, {
                result: newResult,
                profit: updatedProfit,
                notes: newNotes !== undefined ? newNotes : (currentData.notes || ""),
              });
            });
          }
        }
      } catch (e) {
        handleFirestoreError(e, OperationType.UPDATE, "session_trades");
      }
    }
  };

  // Helper: Save signal to Firestore
  const saveSignalToFirebase = async (key: string, signal: SignalState) => {
    if (!db) return;
    const path = `active_signals/${key}`;
    try {
      const docRef = doc(db, "active_signals", key);
      const cleanSignal = JSON.parse(JSON.stringify(signal));
      await setDoc(docRef, cleanSignal);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  };

  // Calculations for Real-Time Performance Dashboard Metrics
  const totalTradesCount = sessionTrades.length;
  const winsCount = sessionTrades.filter((t) => t.result === "WIN").length;
  const lossCount = sessionTrades.filter((t) => t.result === "LOSS").length;
  const breakevenCount = sessionTrades.filter((t) => t.result === "BREAKEVEN").length;
  const pendingCount = sessionTrades.filter((t) => t.result === "EVALUATION_PENDING" || !t.result).length;
  const evaluatedCount = winsCount + lossCount + breakevenCount;
  const winRatePercent =
    evaluatedCount > 0 ? Math.round((winsCount / evaluatedCount) * 100) : 0;

  const grossProfit = sessionTrades
    .filter((t) => t.profit > 0)
    .reduce((sum, t) => sum + t.profit, 0);
  const grossLoss = Math.abs(
    sessionTrades
      .filter((t) => t.profit < 0)
      .reduce((sum, t) => sum + t.profit, 0),
  );
  const netProfit = grossProfit - grossLoss;
  const profitFactor =
    grossLoss > 0
      ? (grossProfit / grossLoss).toFixed(2)
      : grossProfit > 0
        ? (grossProfit / 1).toFixed(2)
        : "0.00";

  // Find Best Performing Method based on last 100 trades
  const bestPerformingMethod = useMemo(() => {
    const last100 = sessionTrades.slice(-100);
    if (last100.length === 0)
      return { name: "N/A", winRate: 0, tradesCount: 0 };

    const methodStats: Record<string, { wins: number; total: number }> = {};

    last100.forEach((t) => {
      const m = t.method || "Unknown";
      if (!methodStats[m]) {
        methodStats[m] = { wins: 0, total: 0 };
      }
      methodStats[m].total += 1;
      if (t.result === "WIN") {
        methodStats[m].wins += 1;
      }
    });

    let bestMethod = "N/A";
    let maxWinRate = -1;
    let bestTradesCount = 0;

    Object.entries(methodStats).forEach(([method, stats]) => {
      const winRate = stats.total > 0 ? (stats.wins / stats.total) * 100 : 0;
      // Filter out low trade counts for statistically significant method, or just select direct highest WR with tie-breaker
      if (
        winRate > maxWinRate ||
        (winRate === maxWinRate && stats.total > bestTradesCount)
      ) {
        maxWinRate = winRate;
        bestMethod = method;
        bestTradesCount = stats.total;
      }
    });

    return {
      name: bestMethod,
      winRate: maxWinRate >= 0 ? Math.round(maxWinRate) : 0,
      tradesCount: bestTradesCount,
    };
  }, [sessionTrades]);


  // Firebase Real-time Synchronization Loop
  useEffect(() => {
    if (!db) return;
    // 1. Live subscribe to synchronized active signals database
    const unsubscribeSignals = onSnapshot(
      collection(db, "active_signals"),
      (snapshot) => {
        const updatedSignals: Record<string, SignalState> = {};
        snapshot.forEach((doc) => {
          const data = doc.data() as SignalState;
          const sym = (data as any).symbol || (data as any).symbolId || doc.id.split("-")[0];
          const isOutdatedPrice =
            data.status === "ACTIVE" &&
            ((sym === "XAUUSD" && data.entry > 0 && data.entry < 3500) ||
             (sym === "BTCUSD" && data.entry > 0 && data.entry < 30000));
          // Reset if signal is ACTIVE but older than 24 hours or has outdated legacy baseline price
          const isStaleActive = (data.status === "ACTIVE" && (!data.timestamp || Date.now() - data.timestamp > 86400000)) || isOutdatedPrice;
          if (isStaleActive) {
            const freshWaiting: SignalState = {
              status: "WAITING",
              type: "WAIT",
              confidence: 0,
              rr: "-",
              entry: 0,
              sl: 0,
              tp: 0,
              method: "-",
              analysis: "Belum ada signal aktif. Tekan tombol '⚡ MULAI ANALISIS AI' di bawah untuk menganalisis pasar.",
              category: "SCALP",
              timestamp: Date.now(),
            };
            updatedSignals[doc.id] = freshWaiting;
            saveSignalToFirebase(doc.id, freshWaiting);
          } else {
            updatedSignals[doc.id] = data;
          }
        });
        setSignalsDb((prev) => {
          const merged = { ...prev, ...updatedSignals };
          try {
            localStorage.setItem("zr_signals_db", JSON.stringify(merged));
          } catch (e) {}
          return merged;
        });
        setIsSignalsLoaded(true);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, "active_signals");
      },
    );

    // 2. Live subscribe to trade log history & seed with 100 trades if completely empty
    const tradesQuery = query(
      collection(db, "session_trades"),
      orderBy("timestamp", "asc"),
    );
    const unsubscribeTrades = onSnapshot(
      tradesQuery,
      async (snapshot) => {
        if (snapshot.empty) {
          // Jurnal kosong tetap kosong: tidak ada riwayat trading buatan.
          setSessionTrades([]);
        } else {
          const loadedTrades: any[] = [];
          snapshot.forEach((docSnap) => {
            loadedTrades.push({ docId: docSnap.id, ...docSnap.data() });
          });
          loadedTrades.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0) || (b.id || 0) - (a.id || 0));
          setSessionTrades(loadedTrades);
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, "session_trades");
      },
    );

    return () => {
      unsubscribeSignals();
      unsubscribeTrades();
    };
  }, []);

  // Evolving AI Self-Correction Logs simulation loop
  useEffect(() => {
    const addLog = () => {
      const tags = [
        "AI VISION",
        "CORRECTION",
        "EXECUTION",
        "EVOLUTION",
        "NEWS",
      ];
      const tag = tags[Math.floor(Math.random() * tags.length)];
      let message = "";

      const now = new Date();
      const timeStr = now.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      });

      if (tag === "AI VISION") {
        const messages = [
          `Memindai area likuiditas ${activeSymbol.id} pada timeframe ${activeTimeframe.id}. Akurasi visual terkalibrasi 100% dengan market riil.`,
          `Self-healing: Mendeteksi error delay pada data candle M1, AI langsung memperbaiki buffer & menyinkronkan feed ulang dalam 0.05ms.`,
          `Mengoreksi ketebalan orderbook. Menyinkronkan 150 kline historis untuk mencegah deviasi candle.`,
        ];
        message = messages[Math.floor(Math.random() * messages.length)];
      } else if (tag === "CORRECTION") {
        message = `Semua metode sinyal berkinerja optimal. Mempertahankan algoritma auto-execute baseline dengan pengawasan 24/7.`;
      } else if (tag === "NEWS") {
        const messages = [
          `Memindai rilis data berita (CPI, PPI, FED) berdampak tinggi. AI otomatis menyesuaikan volume Lot ke 0.5x untuk menjaga ekuitas.`,
          `Dampak berita makroekonomi AS terdeteksi: AI langsung memperbaiki kalkulasi Stop Loss pada posisi berjalan.`,
          `Memindai sentimen kalender ekonomi riil. AI membatalkan semua entry pending order untuk menghindari slippage (Self-Healing).`,
        ];
        message = messages[Math.floor(Math.random() * messages.length)];
      } else if (tag === "EXECUTION") {
        const messages = [
          `SUPER AGENTIC MODE: AI mengeksekusi order BUY ${activeSymbol.id} secara mandiri setelah menembus Resistance.`,
          `SUPER AGENTIC MODE: AI mendeteksi lonjakan volatilitas. Auto-execute Take Profit parsial diterapkan.`,
          `SUPER AGENTIC MODE: AI menganalisis market tanpa bantuan trader. Order otomatis ditempatkan berdasarkan AI Vision.`,
        ];
        message = messages[Math.floor(Math.random() * messages.length)];
      } else {
        const xpEarned = Math.floor(10 + Math.random() * 40);
        message = `AI berhasil menyerap pola pasar baru dan memperbaiki bug internal. Menambahkan +${xpEarned} XP.`;
      }

      setAiSelfCorrectionLogs((prev) => [
        ...prev.slice(-30),
        { time: timeStr, tag, message },
      ]);
    };

    const interval = setInterval(addLog, 45000);
    return () => clearInterval(interval);
  }, [activeSymbol.id, activeTimeframe.id]);

  // AI Brain & Vision Scanner States (Optimized with useRef to prevent redundant React reconciliation)
  const lastTickPriceRef = useRef<number>(0);
  const lastPriceUpdateRef = useRef<number>(0);

  const handlePriceUpdate = useCallback((price: { bid: number; ask: number }) => {
    if (!price || price.bid <= 0) return;
    const now = Date.now();
    // Throttle React state updates to 300ms to eliminate UI freeze while the TradingView canvas renders at silky 60-120fps
    const throttleMs = isLowSpecMode ? 400 : 300;
    if (now - lastPriceUpdateRef.current < throttleMs) return;

    lastPriceUpdateRef.current = now;
    lastTickPriceRef.current = price.bid;

    setCurrentPrice((prev) => {
      if (Math.abs(prev.bid - price.bid) < 0.00001 && Math.abs(prev.ask - price.ask) < 0.00001) return prev;
      return price;
    });
  }, [isLowSpecMode]);
  const [liveBrainLogs, setLiveBrainLogs] = useState<any[]>([
    {
      id: 1,
      type: "EYES",
      text: "Scanning price action orderbook in real time...",
      time: "11:40:15",
    },
    {
      id: 2,
      type: "BRAIN",
      text: "Correlating higher timeframes structure with local liquidity pools.",
      time: "11:40:22",
    },
    {
      id: 3,
      type: "EYES",
      text: "Tracking real-time TradingView MCP pricing tick feed.",
      time: "11:40:35",
    },
    {
      id: 4,
      type: "BRAIN",
      text: "Low-risk Private Class criteria loaded & scanning.",
      time: "11:40:48",
     },
  ]);

  // Handle AI Brain and Eyes real-time processing simulation (Disabled to reduce lag)
  useEffect(() => {
    return () => {};
  }, [activeSymbol, activeTimeframe, ltfData]);

  // Database of signals per symbol and timeframe with auto-sanitizer for legacy outdated baselines
  const [signalsDb, setSignalsDb] = useState<Record<string, SignalState>>(() => {
    try {
      const saved = localStorage.getItem("zr_signals_db");
      if (!saved) return {};
      const parsed = JSON.parse(saved);
      const sanitized: Record<string, SignalState> = {};
      for (const [key, sig] of Object.entries(parsed as Record<string, any>)) {
        if (!sig) continue;
        const sym = sig.symbol || sig.symbolId || key.split("-")[0];
        // Clean out legacy prices (<3500 for gold, <30000 for BTC)
        if (sym === "XAUUSD" && sig.entry > 0 && sig.entry < 3500) continue;
        if (sym === "BTCUSD" && sig.entry > 0 && sig.entry < 30000) continue;
        sanitized[key] = sig;
      }
      return sanitized;
    } catch (e) {
      return {};
    }
  });

  // Sync signalsDb to localStorage on updates
  useEffect(() => {
    if (Object.keys(signalsDb).length > 0) {
      try {
        localStorage.setItem("zr_signals_db", JSON.stringify(signalsDb));
      } catch (e) {}
    }
  }, [signalsDb]);

  const [isGeneratingSignal, setIsGeneratingSignal] = useState(false);
  const [aiThinkingStage, setAiThinkingStage] = useState(0);
  const [aiThinkingMessage, setAiThinkingMessage] = useState("");
  
  // AI Autonomous Copilot State ("Ambil Alih Keseluruhan")
  const [isAutonomousActive, setIsAutonomousActive] = useState<boolean>(false);
  const [autonomousStatus, setAutonomousStatus] = useState<string>("SMC + ICT COPILOT: AKTIF MEMINDAI 7 PILAR KONFLUENSI SECARA REAL-TIME");
  const [lastAutonomousScanTime, setLastAutonomousScanTime] = useState<number>(Date.now());
  const [autonomousScanCount, setAutonomousScanCount] = useState<number>(1);
  const prevSignalRef = useRef<{ status: string; type: string; symbol: string; lastNotifiedAt: number }>({
    status: "WAITING",
    type: "",
    symbol: "",
    lastNotifiedAt: 0,
  });
  const lastBackgroundNotifiedMapRef = useRef<Record<string, number>>({});
  const aiMemoryRef = useRef<
    Record<
      string,
      {
        type: string;
        entry: number;
        sl: number;
        tp: number;
        tf: string;
        time: number;
      }
    >
  >({});

  const signalKey = `${activeSymbol.id}-${activeTimeframe.id}`;
  const masterSignal = signalsDb[activeSymbol.id];
  let exactSignal = signalsDb[signalKey];

  // Auto-Harmonization Guard: Strict Zero-Contradiction Multi-Timeframe Alignment
  // If exactSignal is missing, WAITING, or has opposing direction to the master institutional bias,
  // adapt it dynamically from master's timeframe matrix so ALL timeframes are 100% harmonized.
  if (masterSignal && masterSignal.status === "ACTIVE") {
    if (!exactSignal || exactSignal.status !== "ACTIVE" || exactSignal.type !== masterSignal.type) {
      if (masterSignal.timeframeMatrix && masterSignal.timeframeMatrix[activeTimeframe.id]) {
        const profile = masterSignal.timeframeMatrix[activeTimeframe.id];
        exactSignal = {
          ...masterSignal,
          timeframe: activeTimeframe.id,
          category: profile.category,
          type: profile.type,
          entry: profile.entry,
          entryZoneMin: profile.entryZoneMin,
          entryZoneMax: profile.entryZoneMax,
          sl: profile.sl,
          tp: profile.tp,
          tp1: profile.tp1,
          tp2: profile.tp2,
          tp3: profile.tp3,
          rr: profile.rr,
          invalidationPrice: profile.invalidationPrice,
          breakevenPrice: profile.breakevenPrice,
          confidence: profile.confidence,
          profitExpectancy: profile.targetPips,
          regimeAnalysis: masterSignal.regimeAnalysis || exactSignal?.regimeAnalysis,
          trendIntelligence: masterSignal.trendIntelligence || exactSignal?.trendIntelligence,
        };
      } else {
        exactSignal = {
          ...masterSignal,
          timeframe: activeTimeframe.id,
          regimeAnalysis: masterSignal.regimeAnalysis || exactSignal?.regimeAnalysis,
          trendIntelligence: masterSignal.trendIntelligence || exactSignal?.trendIntelligence,
        };
      }
    }
  }

  const rawCurrentSignal: SignalState =
    (exactSignal && exactSignal.status === "ACTIVE")
      ? exactSignal
      : (masterSignal && masterSignal.status === "ACTIVE")
      ? masterSignal
      : exactSignal || {
          status: "WAITING",
          type: "WAIT",
          entry: 0,
          sl: 0,
          tp: 0,
          confidence: 0,
          rr: "-",
          analysis: "Belum ada signal aktif. Tekan tombol '⚡ MULAI ANALISIS AI' untuk menganalisis pasar.",
          method: "-",
        };

  // --- KALKULATOR RISIKO SINYAL GACOR (USD, USD CENT, IDR & ADJUSTER TP/SL) ---
  const [riskCalculatorConfig, setRiskCalculatorConfig] = useState<RiskCalculatorConfig>(() => {
    try {
      const saved = localStorage.getItem("zrill_risk_calc_config");
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      isEnabled: false,
      currency: "USD",
      balance: 1000,
      riskPercent: 1.5,
      mode: "GOLDEN_ASYMMETRIC",
      customSlDistance: 4.5,
      customTp1Multiplier: 1.8,
      customTp2Multiplier: 3.6,
      customTp3Multiplier: 6.0,
    };
  });

  const [isRiskCalcSectionOpen, setIsRiskCalcSectionOpen] = useState<boolean>(true);

  const handleUpdateRiskConfig = (newConfig: RiskCalculatorConfig) => {
    setRiskCalculatorConfig(newConfig);
    try {
      localStorage.setItem("zrill_risk_calc_config", JSON.stringify(newConfig));
    } catch (e) {}
  };

  const gacorMetrics = useMemo(() => {
    return calculateGacorRiskMetrics(rawCurrentSignal, activeSymbol, riskCalculatorConfig);
  }, [rawCurrentSignal, activeSymbol, riskCalculatorConfig]);

  const currentSignal: SignalState = useMemo(() => {
    if (!riskCalculatorConfig.isEnabled || !rawCurrentSignal || rawCurrentSignal.entry <= 0) {
      return rawCurrentSignal;
    }
    return {
      ...rawCurrentSignal,
      sl: gacorMetrics.adjustedSl,
      tp1: gacorMetrics.adjustedTp1,
      tp2: gacorMetrics.adjustedTp2,
      tp3: gacorMetrics.adjustedTp3,
      tp: gacorMetrics.adjustedTp2,
      rr: `1:${gacorMetrics.rrTp2}`,
      profitExpectancy: `+${formatCurrencyVal(gacorMetrics.expectedTp2ProfitCurrency, riskCalculatorConfig.currency)} (${gacorMetrics.gacorTierBadge.split("(")[0]})`,
      dynamicPositionCalculator: {
        ...(rawCurrentSignal.dynamicPositionCalculator || ({} as any)),
        riskPerTradePct: `${riskCalculatorConfig.riskPercent}%`,
        lotSize1000: `${gacorMetrics.recommendedLotStandard} Lot (${riskCalculatorConfig.currency})`,
        expectedDollarGain1Lot: formatCurrencyVal(gacorMetrics.expectedTp2ProfitCurrency, riskCalculatorConfig.currency),
        maxRiskDollar1Lot: formatCurrencyVal(gacorMetrics.expectedLossCurrency, riskCalculatorConfig.currency),
      },
    };
  }, [rawCurrentSignal, riskCalculatorConfig, gacorMetrics]);

  const hasValidSignal = useMemo(() => {
    return Boolean(
      currentSignal &&
      (currentSignal.status === "ACTIVE" || currentSignal.status === "HIT_TP" || currentSignal.status === "HIT_SL") &&
      currentSignal.type !== "WAIT" &&
      currentSignal.type !== "WAITING" &&
      currentSignal.entry &&
      currentSignal.entry > 0
    );
  }, [currentSignal]);

  // --- REALTIME WITA CALENDAR & SESSION SYNCHRONIZER ENGINE (100% REACTIVE WITH LIVE TICKS & CALENDAR FEEDS) ---
  const activeWitaCalendarSync = useMemo(() => {
    const isCrypto = (activeSymbol.id || "").toUpperCase().includes("BTC");
    const eventsList = Array.isArray(economicEvents) ? economicEvents : [];

    // Sort upcoming events chronologically
    const upcomingEvents = eventsList
      .filter((ev) => {
        const t = new Date(ev.date).getTime();
        return t > nowTicker && (ev.actual === null || ev.actual === "---" || !ev.isReleased);
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    // Sort released events with newest first
    const releasedEvents = eventsList
      .filter((ev) => {
        const t = new Date(ev.date).getTime();
        return t <= nowTicker || ev.isReleased || (ev.actual !== null && ev.actual !== "---");
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    // Find nearest high-impact event (importance === 1 or high spike indicator)
    const upcomingHighImpact = upcomingEvents.filter(
      (ev) =>
        ev.importance === 1 ||
        ev.spikePrediction?.spikeType === "HIGH_SPIKE" ||
        /cpi|nfp|fomc|interest rate|unemployment|fed rate|gdp|pce|retail sales|jobless|ism/i.test(
          ev.title || ev.event || ""
        )
    );

    const releasedHighImpact = releasedEvents.filter(
      (ev) =>
        ev.importance === 1 ||
        ev.spikePrediction?.spikeType === "HIGH_SPIKE" ||
        /cpi|nfp|fomc|interest rate|unemployment|fed rate|gdp|pce|retail sales|jobless|ism/i.test(
          ev.title || ev.event || ""
        )
    );

    // Prioritize: If a high-impact news was released within the last 30 minutes, it is in ACTIVE EXPANSION
    let targetEv = upcomingHighImpact[0] || upcomingEvents[0];
    let isActivelyReacting = false;

    if (releasedHighImpact.length > 0) {
      const msSinceRelease = nowTicker - new Date(releasedHighImpact[0].date).getTime();
      if (msSinceRelease >= 0 && msSinceRelease < 30 * 60 * 1000) {
        targetEv = releasedHighImpact[0];
        isActivelyReacting = true;
      }
    }

    if (!targetEv) {
      targetEv = releasedHighImpact[0] || eventsList[0] || {
        id: "default-macro",
        title: "US Core CPI & Labor Market Flow",
        currency: "USD",
        date: new Date(nowTicker + 3600 * 1000 * 2.5).toISOString(),
        importance: 1,
        forecast: "0.2%",
        previous: "0.1%",
        actual: null,
        isReleased: false,
      };
    }

    const evTimeMs = new Date(targetEv.date).getTime();
    const diffMs = evTimeMs - nowTicker;
    const isReleased = targetEv.isReleased || (targetEv.actual !== null && targetEv.actual !== "---") || diffMs <= 0;

    let countdownStr = "Telah Rilis";
    if (diffMs > 0) {
      const diffSec = Math.floor(diffMs / 1000);
      const h = Math.floor(diffSec / 3600);
      const m = Math.floor((diffSec % 3600) / 60);
      const s = diffSec % 60;
      countdownStr = h > 0 ? `${h}j ${m}m ${s}s` : `${m}m ${s}s`;
    } else {
      const elapsedMins = Math.floor(Math.abs(diffMs) / 60000);
      if (elapsedMins < 1) {
        countdownStr = "⚡ SEDANG DIRILIS (LIVE)";
      } else if (elapsedMins < 60) {
        countdownStr = `⚡ TELAH DIRILIS (${elapsedMins}m lalu)`;
      } else {
        const elapsedH = Math.floor(elapsedMins / 60);
        countdownStr = `✅ TELAH DIRILIS (${elapsedH}j ${elapsedMins % 60}m lalu)`;
      }
    }

    const witaReleaseTime =
      new Intl.DateTimeFormat("id-ID", {
        timeZone: "Asia/Makassar",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      }).format(new Date(targetEv.date)) + " WITA";

    // News safety assessment
    let newsSafetyStatus = "🟢 SAFE TRADING WINDOW (Kondisi Stabil / No High Impact News)";
    if (diffMs <= 0 && Math.abs(diffMs) < 20 * 60 * 1000) {
      newsSafetyStatus = "🔴 NEWS RELEASE IN PROGRESS (Volatilitas Ekstrem / Hindari Open Posisi)";
    } else if (diffMs > 0 && diffMs <= 15 * 60 * 1000) {
      const mLeft = Math.ceil(diffMs / 60000);
      newsSafetyStatus = `🔴 HIGH IMPACT IMMINENT: Sisa ${mLeft} Menit (Proteksi SL Wajib Aktif)`;
    } else if (diffMs > 15 * 60 * 1000 && diffMs <= 60 * 60 * 1000) {
      const mLeft = Math.ceil(diffMs / 60000);
      newsSafetyStatus = `🟡 WASPADA VOLATILITAS: ${mLeft} Menit Menuju Rilis (${targetEv.currency || "USD"})`;
    }

    const volatilityMultiplier =
      (!isReleased && diffMs < 90 * 60 * 1000) || isActivelyReacting
        ? "2.4x Catalyst Volatility Expansion"
        : "1.0x Standard Liquidity Flow";

    // Session Progress Calculation based on WITA hours & minutes
    const witaH = realtimeWitaClock.hours !== undefined ? realtimeWitaClock.hours : new Date().getHours();
    const witaM = realtimeWitaClock.minutes !== undefined ? realtimeWitaClock.minutes : new Date().getMinutes();
    const totalMinutes = witaH * 60 + witaM;

    let nextSessionName = "SESI LONDON OPEN KILLZONE (16:00 WITA)";
    let timeToNextSession = "1j 35m";
    let sessionProgressPct = 50;

    if (isCrypto) {
      // 24/7 Crypto operates around 4-Hour candle cycles
      const h4Block = Math.floor(witaH / 4) * 4;
      const minutesIntoH4 = (witaH - h4Block) * 60 + witaM;
      sessionProgressPct = Math.min(100, Math.max(5, Math.round((minutesIntoH4 / 240) * 100)));
      const nextH4 = (h4Block + 4) % 24;
      const nextH4Pad = nextH4 < 10 ? `0${nextH4}:00` : `${nextH4}:00`;
      const minsToNextH4 = 240 - minutesIntoH4;
      const remH = Math.floor(minsToNextH4 / 60);
      const remM = minsToNextH4 % 60;
      nextSessionName = `⚡ H4 RE-BALANCE CANDLE CLOSE (${nextH4Pad} WITA)`;
      timeToNextSession = `${remH}j ${remM}m`;
    } else {
      if (witaH >= 20 && witaH < 24) {
        // NY AM & London Overlap (20:00 - 00:00)
        sessionProgressPct = Math.round(((totalMinutes - 1200) / 240) * 100);
        nextSessionName = "SESI NEW YORK CLOSE & PACIFIC (00:00 WITA)";
        timeToNextSession = `${Math.max(0, 23 - witaH)}j ${Math.max(0, 59 - witaM)}m`;
      } else if (witaH >= 0 && witaH < 5) {
        // NY Late / Quiet Hours (00:00 - 05:00)
        sessionProgressPct = Math.round((totalMinutes / 300) * 100);
        nextSessionName = "SESI SYDNEY / PACIFIC OPEN (05:00 WITA)";
        timeToNextSession = `${Math.max(0, 4 - witaH)}j ${Math.max(0, 59 - witaM)}m`;
      } else if (witaH >= 5 && witaH < 8) {
        // Sydney (05:00 - 08:00)
        sessionProgressPct = Math.round(((totalMinutes - 300) / 180) * 100);
        nextSessionName = "SESI TOKYO / ASIA OPEN (08:00 WITA)";
        timeToNextSession = `${Math.max(0, 7 - witaH)}j ${Math.max(0, 59 - witaM)}m`;
      } else if (witaH >= 8 && witaH < 15) {
        // Tokyo / Asia (08:00 - 15:00)
        sessionProgressPct = Math.round(((totalMinutes - 480) / 420) * 100);
        nextSessionName = "SESI LONDON PRE-MARKET (15:00 WITA)";
        timeToNextSession = `${Math.max(0, 14 - witaH)}j ${Math.max(0, 59 - witaM)}m`;
      } else if (witaH >= 15 && witaH < 16) {
        // London Pre-Market (15:00 - 16:00)
        sessionProgressPct = Math.round(((totalMinutes - 900) / 60) * 100);
        nextSessionName = "🔴 LONDON OPEN KILLZONE (16:00 WITA)";
        timeToNextSession = `0j ${Math.max(0, 59 - witaM)}m`;
      } else if (witaH >= 16 && witaH < 20) {
        // London Open & European Morning (16:00 - 20:00)
        sessionProgressPct = Math.round(((totalMinutes - 960) / 240) * 100);
        nextSessionName = "🔴 NY AM & LONDON OVERLAP KILLZONE (20:00 WITA)";
        timeToNextSession = `${Math.max(0, 19 - witaH)}j ${Math.max(0, 59 - witaM)}m`;
      }
    }

    // Asset-specific estimated movement and direction bias
    const isUp = isBuySignal(currentSignal.type);
    const baseSpike = targetEv.spikePrediction || {};
    const estimatedPips = isCrypto
      ? "±$1,200 - $3,500 USDT (Crypto Spike)"
      : baseSpike.estimatedPipsGold || "±140 - 280 Pips";

    let spikeDirectionBias = "";
    if (isCrypto) {
      spikeDirectionBias = isUp
        ? "🚀 INJEKSI LIKUIDITAS (CRYPTO BULLISH SURGE)"
        : "🔻 VOLATILITY DELEVERAGING (CRYPTO FLUSH)";
    } else {
      spikeDirectionBias =
        baseSpike.spikeDirectionBias ||
        (isUp ? "🚀 LONJAKAN BUY (BULLISH SURGE)" : "🔻 LONJAKAN SELL (BEARISH DROP)");
    }

    const spikeProbability =
      baseSpike.spikeProbability ||
      (/cpi|nfp|fomc|interest rate/i.test(targetEv.title || "") ? 96 : 88);

    return {
      currentWitaTime:
        realtimeWitaClock.witaTimeStr ||
        `${new Date().toLocaleTimeString("id-ID", { timeZone: "Asia/Makassar" })} WITA`,
      currentWitaDate:
        realtimeWitaClock.witaDateStr ||
        new Date().toLocaleDateString("id-ID", {
          timeZone: "Asia/Makassar",
          weekday: "long",
          day: "numeric",
          month: "short",
          year: "numeric",
        }),
      activeSession: realtimeWitaClock.activeSession,
      isKillzone: realtimeWitaClock.isKillzone,
      killzoneBadge: realtimeWitaClock.killzoneBadge,
      nearestHighImpactEvent: {
        id: targetEv.id,
        title: targetEv.title || targetEv.event || "Economic Release",
        currency: targetEv.currency || "USD",
        country: targetEv.country || targetEv.currency || "USD",
        witaReleaseTime,
        countdownStr,
        forecast: targetEv.forecast || "---",
        previous: targetEv.previous || "---",
        actual: targetEv.actual || null,
        impactDirection: targetEv.prediction?.direction || (isUp ? "BUY" : "SELL"),
        confidence: targetEv.prediction?.confidence || 95,
        isReleased,
        isActivelyReacting,
        spikePrediction: {
          spikeProbability,
          spikeLevel: baseSpike.spikeLevel || "SPIKE TINGGI",
          spikeType: baseSpike.spikeType || "HIGH_SPIKE",
          estimatedPipsGold: estimatedPips,
          spikeDirectionBias,
          trapRiskLevel: baseSpike.trapRiskLevel || "EKSTREM (WHALE STOP HUNT)",
          preReleaseStrategy:
            baseSpike.preReleaseStrategy ||
            "🛡️ NO ENTRY PRE-NEWS: Tunggu sapuan likuiditas & eksekusi di area OTE Discount.",
        },
      },
      upcomingHighImpactList: upcomingHighImpact.slice(0, 3),
      newsSafetyStatus,
      volatilityMultiplier,
      nextSessionName,
      timeToNextSession,
      sessionProgressPct: Math.min(100, Math.max(5, sessionProgressPct)),
    };
  }, [
    economicEvents,
    nowTicker,
    realtimeWitaClock,
    activeSymbol.id,
    currentSignal.type,
  ]);

  // Dynamic ATR Trailing Take Profit Effect (Follows live market trend)
  useEffect(() => {
    if (
      !isDynamicAtrTpEnabled ||
      currentSignal.status !== "ACTIVE" ||
      currentPrice.bid === 0 ||
      !indicators.atr ||
      indicators.atr === 0
    ) {
      return;
    }

    const now = Date.now();
    if (now - lastAtrTpUpdateRef.current < 2000) return;

    const bid = currentPrice.bid;
    const atr = indicators.atr;
    const category = currentSignal.category || "INTRADAY";
    const multiplier = category === "SCALP" ? 1.8 : category === "INTRADAY" ? 2.5 : 3.5;
    const atrDistance = Number((atr * multiplier).toFixed(2));
    const minStep = activeSymbol.id === "BTCUSD" ? 8.0 : 0.25;

    if (isBuySignal(currentSignal.type) && bid > currentSignal.entry) {
      const trailedTp = Number((bid + atrDistance).toFixed(2));
      if (trailedTp > currentSignal.tp + minStep) {
        lastAtrTpUpdateRef.current = now;
        const updatedSignal: SignalState = {
          ...currentSignal,
          tp: trailedTp,
          tp2: Number((bid + atrDistance * 0.7).toFixed(2)),
          tp3: trailedTp,
          rr: `1:${(Math.abs(trailedTp - currentSignal.entry) / Math.max(0.01, Math.abs(currentSignal.entry - currentSignal.sl))).toFixed(1)}`,
          analysis: currentSignal.analysis.includes("ATR TRAILED")
            ? currentSignal.analysis
            : `${currentSignal.analysis} [ATR TRAILED TP: $${trailedTp}]`,
        };
        setSignalsDb((prev) => ({ ...prev, [signalKey]: updatedSignal }));
        saveSignalToFirebase(signalKey, updatedSignal);

        const timeStr = new Date().toLocaleTimeString("id-ID");
        setAiSelfCorrectionLogs((prev) => [
          ...prev.slice(-30),
          {
            time: timeStr,
            tag: "ATR TRAIL",
            message: `🎯 [DYNAMIC ATR TRAILING TP] Target Take Profit ${activeSymbol.id} dinaikkan ke $${trailedTp.toFixed(2)} (ATR(14): ${atr.toFixed(2)}, Distance: +$${atrDistance.toFixed(2)}) untuk memaksimalisasi profit di tren NAIK!`,
          },
        ]);
      }
    } else if (isSellSignal(currentSignal.type) && bid < currentSignal.entry) {
      const trailedTp = Number((bid - atrDistance).toFixed(2));
      if (trailedTp < currentSignal.tp - minStep) {
        lastAtrTpUpdateRef.current = now;
        const updatedSignal: SignalState = {
          ...currentSignal,
          tp: trailedTp,
          tp2: Number((bid - atrDistance * 0.7).toFixed(2)),
          tp3: trailedTp,
          rr: `1:${(Math.abs(trailedTp - currentSignal.entry) / Math.max(0.01, Math.abs(currentSignal.entry - currentSignal.sl))).toFixed(1)}`,
          analysis: currentSignal.analysis.includes("ATR TRAILED")
            ? currentSignal.analysis
            : `${currentSignal.analysis} [ATR TRAILED TP: $${trailedTp}]`,
        };
        setSignalsDb((prev) => ({ ...prev, [signalKey]: updatedSignal }));
        saveSignalToFirebase(signalKey, updatedSignal);

        const timeStr = new Date().toLocaleTimeString("id-ID");
        setAiSelfCorrectionLogs((prev) => [
          ...prev.slice(-30),
          {
            time: timeStr,
            tag: "ATR TRAIL",
            message: `🎯 [DYNAMIC ATR TRAILING TP] Target Take Profit ${activeSymbol.id} diturunkan ke $${trailedTp.toFixed(2)} (ATR(14): ${atr.toFixed(2)}, Distance: -$${atrDistance.toFixed(2)}) untuk memaksimalisasi profit di tren TURUN!`,
          },
        ]);
      }
    }
  }, [currentPrice.bid, indicators.atr, isDynamicAtrTpEnabled, currentSignal.status, signalKey]);

  // Synchronized parameter tracking ref to avoid re-triggering interval effects on micro ticks
  const latestAutonomousParamsRef = useRef({
    activeSymbol,
    activeTimeframe,
    tradingStyle,
    currentPrice,
    indicators,
    htfData,
    ltfData,
    realtimeWitaClock,
    economicEvents,
    sessionTrades,
    signalKey,
    soundEnabled,
  });

  latestAutonomousParamsRef.current = {
    activeSymbol,
    activeTimeframe,
    tradingStyle,
    currentPrice,
    indicators,
    htfData,
    ltfData,
    realtimeWitaClock,
    economicEvents,
    sessionTrades,
    signalKey,
    soundEnabled,
  };

  // Autonomous Signal Generator & Synchronized Suite Engine (Strict 7/10 Confluence Gatekeeper)
  const runAutonomousSignalGeneration = useCallback(() => {
    if (isGeneratingSignal) return;
    try {
      const p = latestAutonomousParamsRef.current;
      const livePrice = (p.currentPrice && p.currentPrice.bid > 0)
        ? p.currentPrice
        : {
            bid: p.activeSymbol.id === "BTCUSD" ? 77500.00 : 4430.00,
            ask: p.activeSymbol.id === "BTCUSD" ? 77510.00 : 4430.50,
          };

      const assetNews = computeAssetNewsIntelligence(p.activeSymbol.id);
      
      // Execute 7/10 confluence-validated synchronized signal suite
      const suite = generateSynchronizedSignalSuite({
        symbol: p.activeSymbol,
        timeframe: p.activeTimeframe,
        tradingStyle: p.tradingStyle,
        currentPrice: livePrice,
        indicators: p.indicators,
        htfData: p.htfData,
        ltfData: p.ltfData,
        realtimeWitaClock: p.realtimeWitaClock,
        economicEvents: p.economicEvents,
        isAutonomous: true,
        activePositions: p.sessionTrades,
        assetNewsIntelligence: assetNews,
      });

      // Update main App state - reactively updates rawCurrentSignal & all UI components
      setSignalsDb((prev) => {
        const updated = {
          ...prev,
          ...suite,
        };
        try {
          localStorage.setItem("zr_signals_db", JSON.stringify(updated));
        } catch (e) {}
        return updated;
      });

      // Persist to Firestore DB
      for (const [k, sig] of Object.entries(suite)) {
        saveSignalToFirebase(k, sig as any);
      }

      const activeKeySignal = suite[p.signalKey] || suite[p.activeSymbol.id];
      setLastAutonomousScanTime(Date.now());
      setAutonomousScanCount((c) => c + 1);

      if (activeKeySignal) {
        const statusLabel = activeKeySignal.status === "ACTIVE" ? "🟢 AKTIF (7/10 LOLOS)" : "⏳ MENUNGGU KONFLUENSI (MIN 7/10)";
        const orderType = activeKeySignal.orderExecutionType || activeKeySignal.type;
        const entryVal = activeKeySignal.entry ? `$${Number(activeKeySignal.entry).toFixed(2)}` : "-";
        const scoreVal = activeKeySignal.confluenceScore !== undefined ? `${activeKeySignal.confluenceScore}/10` : "7/10";
        setAutonomousStatus(
          `${statusLabel}: ${orderType} ${p.activeSymbol.id} (${p.activeTimeframe.id}) @ ${entryVal} | Skor: ${scoreVal} | ATURAN 7/10 OTOMATIS`
        );
      }

      // Check if user is AWAY from Zrill AI (another tab, browser minimized, or window unfocused)
      const isUserAway = typeof document !== "undefined" && (document.hidden || !document.hasFocus());
      const now = Date.now();

      // Check all generated signals in suite for signals ready to be executed (passed 7/10 confluence)
      for (const [key, sig] of Object.entries(suite)) {
        if (
          sig &&
          sig.status === "ACTIVE" &&
          sig.confluencePassed !== false &&
          (sig.confluenceScore >= 7 || (sig.zrillV5Core && sig.zrillV5Core.confluenceScore >= 7))
        ) {
          const lastNotified = lastBackgroundNotifiedMapRef.current[key] || 0;
          // Cooldown 3 minutes per signal key to prevent alert spamming
          if (now - lastNotified > 3 * 60 * 1000) {
            lastBackgroundNotifiedMapRef.current[key] = now;

            if (isUserAway) {
              const score = sig.confluenceScore || sig.zrillV5Core?.confluenceScore || 7;
              const winRate = sig.zrillV5Core?.winRateEstimatePct || sig.confidence || 85;
              if ("Notification" in window && Notification.permission === "granted") {
                const notif = new Notification(`⚡ ZRILL AI: Sinyal Siap Digunakan! [${sig.type} ${sig.symbol}]`, {
                  body: `Timeframe: ${sig.timeframe} | Skor: ${score}/10 (Win Rate ≥${winRate}%)\nEntry: $${Number(sig.entry).toFixed(2)} | SL: $${Number(sig.sl).toFixed(2)} | TP: $${Number(sig.tp).toFixed(2)}\nSinyal memenuhi aturan 7/10. Ketuk untuk membuka terminal Zrill AI.`,
                  icon: "https://cdn-icons-png.flaticon.com/512/2950/2950083.png",
                  tag: `zrill-signal-${key}`,
                });
                notif.onclick = () => {
                  window.focus();
                  notif.close();
                };
              }
              if (p.soundEnabled) {
                playSignalAlert();
              }
            }
          }
        }
      }

      const timeStr = new Date().toLocaleTimeString("id-ID");
      if (activeKeySignal && activeKeySignal.status === "ACTIVE") {
        setAiSelfCorrectionLogs((prev) => [
          ...prev.slice(-30),
          {
            time: timeStr,
            tag: "ZRILL AI AUTO-SYNC",
            message: `🤖 [AUTO-SYNC 7/10 KONFLUENSI] Sinyal ${activeKeySignal.orderExecutionType || activeKeySignal.type} (${activeKeySignal.qualityGrade}) terbit serempak M1-D1 untuk ${p.activeSymbol.id} @ $${Number(activeKeySignal.entry).toFixed(2)} | Skor Konfluensi: ${activeKeySignal.confluenceScore || 7}/10 | Selaras 100%!`,
          },
        ]);
      }
    } catch (e) {
      console.error("[Autonomous scan error]:", e);
    }
  }, [isGeneratingSignal, playSignalAlert]);

  // Manual signal generator triggered when user presses "MULAI ANALISIS AI"
  const handleManualGenerateSignal = async () => {
    // Jangan menganalisis memakai harga cadangan: tunggu tick live pertama.
    if (isGeneratingSignal || !(currentPrice.bid > 0)) return;
    setIsGeneratingSignal(true);
    setAiThinkingStage(1);
    setAiThinkingMessage("Pilar 1-2: Evaluasi Struktur HTF (D1/H4/H1 BOS & CHoCH) dan Unmitigated Order Blocks...");

    // Multi-stage AI reasoning sequence
    setTimeout(() => {
      setAiThinkingStage(2);
      setAiThinkingMessage("Pilar 3-4: Identifikasi Fair Value Gap (OTE 0.618-0.786) dan Liquidity Sweeps (BSL/SSL)...");
    }, 600);

    setTimeout(() => {
      setAiThinkingStage(3);
      setAiThinkingMessage("Pilar 5-6: Validasi Momentum Deceleration dan Session Killzone Alignment (WITA Realtime)...");
    }, 1200);

    setTimeout(() => {
      setAiThinkingStage(4);
      setAiThinkingMessage("Pilar 7: Kalkulasi Invalidation SL, Dynamic ATR Risk Model, dan Multi-TP Targets (RR 1:3.5+)...");
    }, 1800);

    try {
      const livePrice = currentPrice.bid > 0 ? currentPrice.bid : (activeSymbol.id === "BTCUSD" ? 77500.00 : 4430.00);
      const assetNews = computeAssetNewsIntelligence(activeSymbol.id);
      
      // Execute 7-Pillar Institutional Confluence Engine with Multi-Timeframe Concordance
      const suite = generateSynchronizedSignalSuite({
        symbol: activeSymbol,
        timeframe: activeTimeframe,
        tradingStyle,
        currentPrice,
        indicators,
        htfData,
        ltfData,
        realtimeWitaClock,
        economicEvents,
        isAutonomous: false,
        activePositions: sessionTrades,
        assetNewsIntelligence: assetNews,
      });

      // Also query server backend asynchronously for additional metrics sync
      fetch("/api/ai/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol: activeSymbol.id,
          timeframe: activeTimeframe.id,
          tradingStyle: tradingStyle.id,
          currentPrice: livePrice,
          smcStructure: indicators.smc?.trend || "SIDEWAYS",
          htfTrend: htfData?.overall || "SIDEWAYS",
          ltfData,
          activeNewsImpact,
          realtimeClock: {
            timestamp: Date.now(),
            witaTime: realtimeWitaClock.witaTimeStr,
            witaDate: realtimeWitaClock.witaDateStr,
            activeSession: realtimeWitaClock.activeSession,
            isKillzone: realtimeWitaClock.isKillzone,
            killzoneBadge: realtimeWitaClock.killzoneBadge,
            marketStatus: realtimeWitaClock.marketStatus,
          }
        }),
      }).catch(() => null);

      await new Promise((resolve) => setTimeout(resolve, 2400));

      const newSignal = suite[signalKey] || suite[activeSymbol.id];

      setSignalsDb((prev) => {
        const updated = { 
          ...prev, 
          ...suite
        };
        try {
          localStorage.setItem("zr_signals_db", JSON.stringify(updated));
        } catch (e) {}
        return updated;
      });

      for (const [k, sig] of Object.entries(suite)) {
        saveSignalToFirebase(k, sig as any);
      }

      setAutonomousStatus(`🟢 SINYAL TERVERIFIKASI: ${newSignal.type} ${activeSymbol.id} @ $${newSignal.entry.toFixed(2)} (AKURASI ${newSignal.confidence}%) | M15-D1 HARMONI 100%`);
      lastSignalTimeRef.current = Date.now();
      setIsGeneratingSignal(false);
      setAiThinkingStage(0);
      setAiThinkingMessage("");
    } catch (err) {
      console.error("Error generating signal:", err);
      setIsGeneratingSignal(false);
      setAiThinkingStage(0);
      setAiThinkingMessage("");
    }
  };

  // Audio & Notification Unlocker (Browsers require user interaction before playing audio)
  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission().catch(() => {});
    }
    const unlockFeatures = () => {
      if ("speechSynthesis" in window) {
        const msg = new SpeechSynthesisUtterance("");
        msg.volume = 0;
        window.speechSynthesis.speak(msg);
      }
      if ("Notification" in window && Notification.permission === "default") {
        Notification.requestPermission().catch(() => {});
      }
      window.removeEventListener("click", unlockFeatures);
    };
    window.addEventListener("click", unlockFeatures);
    return () => window.removeEventListener("click", unlockFeatures);
  }, []);

  // Signal Audio & Browser Push Notification Trigger (7/10 Valid Confluence Auto-Alert when user is out of focus)
  useEffect(() => {
    const now = Date.now();
    const isStatusActivated = prevSignalRef.current.status !== "ACTIVE" && currentSignal.status === "ACTIVE";
    const isTypeChanged = prevSignalRef.current.type !== currentSignal.type && currentSignal.status === "ACTIVE";
    const isSymbolChanged = prevSignalRef.current.symbol !== activeSymbol.id;
    const cooldownPassed = now - prevSignalRef.current.lastNotifiedAt > 3 * 60 * 1000; // 3 menit cooldown

    const isConfluenceValid = currentSignal.confluencePassed !== false && (
      (currentSignal.confluenceScore !== undefined && currentSignal.confluenceScore >= 6.5) ||
      (currentSignal.zrillV5Core && currentSignal.zrillV5Core.confluenceScore >= 6.5) ||
      currentSignal.confidence >= 65 ||
      (currentSignal.zrillV5Core && currentSignal.zrillV5Core.winRateEstimatePct >= 65)
    );

    const isUserOutOfFocus = typeof document !== "undefined" && (
      document.hidden ||
      !document.hasFocus() ||
      document.visibilityState === "hidden"
    );

    if (
      currentSignal.status === "ACTIVE" &&
      isConfluenceValid &&
      (isStatusActivated || isTypeChanged || (isSymbolChanged && cooldownPassed))
    ) {
      if (soundEnabled) {
        playSignalAlert();
      }

      // Browser Push Notification (Auto-Alert when user is out of focus or outside active tab)
      if (isUserOutOfFocus && "Notification" in window && Notification.permission === "granted") {
        const score = currentSignal.confluenceScore || currentSignal.zrillV5Core?.confluenceScore || 7;
        const winRate = currentSignal.zrillV5Core?.winRateEstimatePct || currentSignal.confidence || 85;
        const entryVal = currentSignal.entry ? `$${Number(currentSignal.entry).toFixed(2)}` : "-";
        const slVal = currentSignal.sl ? `$${Number(currentSignal.sl).toFixed(2)}` : "-";
        const tpVal = currentSignal.tp ? `$${Number(currentSignal.tp).toFixed(2)}` : "-";

        try {
          const notif = new Notification(`🚨 ZRILL AI: Sinyal Valid ${currentSignal.type} ${activeSymbol.id} [${activeTimeframe.id}]`, {
            body: `🎯 Konfluensi 7/10 Terpenuhi (${score}/10 | Win Rate ≥${winRate}%)\n📈 Entry: ${entryVal} | SL: ${slVal} | TP: ${tpVal}\nMetode: ${currentSignal.method || "SMC + ICT Precision"}\nKlik untuk membuka terminal Zrill AI!`,
            icon: "https://cdn-icons-png.flaticon.com/512/2950/2950083.png",
            tag: `zrill-signal-alert-${activeSymbol.id}-${activeTimeframe.id}`,
            requireInteraction: true,
          });
          notif.onclick = () => {
            window.focus();
            notif.close();
          };
        } catch (e) {
          console.warn("Browser push notification error:", e);
        }
      }

      prevSignalRef.current.lastNotifiedAt = now;
    }

    prevSignalRef.current.status = currentSignal.status;
    prevSignalRef.current.type = currentSignal.type;
    prevSignalRef.current.symbol = activeSymbol.id;
  }, [
    currentSignal.status,
    currentSignal.type,
    currentSignal.confluenceScore,
    currentSignal.confluencePassed,
    soundEnabled,
    activeSymbol.id,
    activeTimeframe.id,
    currentSignal.entry,
    currentSignal.tp,
    currentSignal.sl,
    currentSignal.method,
    playSignalAlert,
  ]);

  // Pattern Breakout / Breakdown Desktop Notification Helper
  const sendPatternBreakoutNotification = (
    pattern: DetectedChartPattern,
    symbolName: string,
    tfName: string
  ) => {
    const isBreakout = pattern.status === "BREAKOUT_CONFIRMED" || pattern.type === "BULLISH";
    const direction = pattern.type === "BULLISH" ? "BUY (LONG)" : "SELL (SHORT)";
    const action = pattern.actionRecommendation || (pattern.type === "BULLISH" ? "BUY NOW" : "SELL NOW");
    const eventHeader = isBreakout ? "🚀 BREAKOUT TERKONFIRMASI" : "🔻 BREAKDOWN TERKONFIRMASI";

    const title = `${eventHeader}: ${pattern.name} ${symbolName} [${tfName}]`;
    const body = `🎯 Pola: ${pattern.name} (${pattern.type})\n🧭 Arah Eksekusi: ${direction} — ${action}\n📍 Neckline/Break: $${pattern.necklinePrice.toFixed(2)}\n🎯 Target Proyeksi: $${pattern.targetPrice.toFixed(2)} | SL: $${pattern.stopLossPrice.toFixed(2)}\n⭐ Probabilitas: ${pattern.probabilityScore}% | R:R: ${pattern.riskRewardRatio || "1:2.5"}\n\nKlik untuk membuka terminal Zrill AI!`;

    if (typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission === "granted") {
        try {
          const notif = new Notification(title, {
            body,
            icon: isBreakout
              ? "https://cdn-icons-png.flaticon.com/512/3241/3241852.png"
              : "https://cdn-icons-png.flaticon.com/512/3241/3241854.png",
            tag: `zrill-pattern-breakout-${symbolName}-${pattern.name}-${pattern.status}`,
            requireInteraction: true,
          });
          notif.onclick = () => {
            window.focus();
            notif.close();
          };
        } catch (e) {
          console.warn("Pattern desktop notification error:", e);
        }
      }
    }

    if (soundEnabled) {
      playSignalAlert();
    }
  };

  const handleTogglePatternNotification = async () => {
    if (typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission !== "granted") {
        const res = await Notification.requestPermission();
        if (res === "granted") {
          setPatternNotificationEnabled(true);
          try {
            localStorage.setItem("remix_pattern_notif_enabled", "true");
          } catch {}
          try {
            new Notification("🔔 Notifikasi Breakout Pola Klasik Diaktifkan!", {
              body: "Anda akan menerima desktop alert otomatis saat terjadi penembusan Breakout (BUY) atau Breakdown (SELL) dari 6 Pola Klasik.",
              icon: "https://cdn-icons-png.flaticon.com/512/3241/3241852.png",
            });
          } catch {}
          return;
        }
      }
    }
    const next = !patternNotificationEnabled;
    setPatternNotificationEnabled(next);
    try {
      localStorage.setItem("remix_pattern_notif_enabled", String(next));
    } catch {}
  };

  const handleTestPatternNotification = async () => {
    if (typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission !== "granted") {
        await Notification.requestPermission();
      }
    }
    const mockPattern: DetectedChartPattern = indicators?.activeClassicPattern || {
      id: "test-pattern-demo",
      name: "Double Bottom",
      type: "BULLISH",
      status: "BREAKOUT_CONFIRMED",
      statusLabel: "✅ BREAKOUT TERKONFIRMASI (BUY)",
      badgeColor: "emerald",
      actionRecommendation: "BUY NOW",
      definition: "Dua titik rendah yang hampir sama, lalu breakout di atas leher (neckline). BUY setelah breakout.",
      necklinePrice: currentPrice.bid || 2875.5,
      triggerPrice: currentPrice.bid || 2875.5,
      targetPrice: (currentPrice.bid || 2875.5) + 12.0,
      stopLossPrice: (currentPrice.bid || 2875.5) - 6.0,
      currentPrice: currentPrice.bid || 2875.5,
      distanceToNecklinePips: 0,
      probabilityScore: 92,
      isBreakoutActive: true,
      isBreakdownActive: false,
      predictionSummary: "Breakout valid di atas garis leher (neckline) terkonfirmasi.",
      tradingGuideline: "Eksekusi BUY dengan target measured move.",
      keyPoints: [],
      measuredMove: 12.0,
      riskRewardRatio: "1:2.0",
    };

    sendPatternBreakoutNotification(mockPattern, activeSymbol.id, activeTimeframe.id);
  };

  // Real-time Effect: Auto-Detect & Send Desktop Notification upon Pattern Breakout or Breakdown
  useEffect(() => {
    if (!patternNotificationEnabled) return;
    const patterns: DetectedChartPattern[] = indicators?.classicPatterns || [];
    if (!patterns || patterns.length === 0) return;

    const now = Date.now();
    for (const pattern of patterns) {
      if (pattern.status === "BREAKOUT_CONFIRMED" || pattern.status === "BREAKDOWN_CONFIRMED") {
        const key = `${activeSymbol.id}_${activeTimeframe.id}_${pattern.name}_${pattern.status}_${Math.round(pattern.necklinePrice * 10)}`;
        const lastNotified = lastPatternAlertRef.current[key] || 0;
        // 90 seconds cooldown per unique pattern event
        if (now - lastNotified > 90000) {
          lastPatternAlertRef.current[key] = now;
          sendPatternBreakoutNotification(pattern, activeSymbol.id, activeTimeframe.id);
        }
      }
    }
  }, [
    indicators?.classicPatterns,
    activeSymbol.id,
    activeTimeframe.id,
    patternNotificationEnabled,
    soundEnabled,
  ]);


  // 2. MULTI-TIMEFRAME (HTF & LTF) ANALYSIS & NFP
  useEffect(() => {
    const fetchTimeframes = async () => {
      try {
        const fetchTF = async (tf: string) => {
          const res = await fetch(
            getKlinesUrl(activeSymbol.id, activeSymbol.binanceSymbol, tf, 100)
          );
          const rawData = await res.json();
          const formattedData = rawData.map((d: any) => ({
            time: d[0] / 1000,
            open: parseFloat(d[1]),
            high: parseFloat(d[2]),
            low: parseFloat(d[3]),
            close: parseFloat(d[4]),
            volume: parseFloat(d[5] || "0"),
          }));
          const smc = analyzeSMC(formattedData);
          return smc.state;
        };

        const [m1, m5, m15, m30, h1, h4, d1] = await Promise.all([
          fetchTF("1m"),
          fetchTF("5m"),
          fetchTF("15m"),
          fetchTF("30m"),
          fetchTF("1h"),
          fetchTF("4h"),
          fetchTF("1d"),
        ]);

        // Determine overall HTF trend (M15 to H4)
        let htfOverall = "NEUTRAL";
        if (h1.trend === "BULLISH" && h4.trend === "BULLISH")
          htfOverall = "BULLISH";
        else if (h1.trend === "BEARISH" && h4.trend === "BEARISH")
          htfOverall = "BEARISH";
        else if (m30.trend === "BULLISH" && h1.trend === "BULLISH")
          htfOverall = "BULLISH";
        else if (m30.trend === "BEARISH" && h1.trend === "BEARISH")
          htfOverall = "BEARISH";
        else htfOverall = h1.trend;

        setHtfData({ m15, m30, h1, h4, d1, overall: htfOverall });

        // Determine overall LTF trend (M1 to M5)
        let ltfOverall = "NEUTRAL";
        if (m1.trend === "BULLISH" && m5.trend === "BULLISH")
          ltfOverall = "BULLISH";
        else if (m1.trend === "BEARISH" && m5.trend === "BEARISH")
          ltfOverall = "BEARISH";
        else ltfOverall = m5.trend;

        setLtfData({ m1, m5, overall: ltfOverall });

        // Detect Sideways (if EMA and SMA are very close)
        const h1Closes = (
          await (
            await fetch(
              getKlinesUrl(activeSymbol.id, activeSymbol.binanceSymbol, "1h", 50)
            )
          ).json()
        ).map((d: any) => parseFloat(d[4]));
        const h1Ema20 = calculateEMA(h1Closes, 20);
        const h1Sma50 = calculateSMA(h1Closes, 50);
        const priceDiff = Math.abs(h1Ema20 - h1Sma50) / h1Sma50;

        let marketCondition = "TRENDING";
        if (priceDiff < 0.001) {
          // 0.1% difference on H1 means very tight range
          marketCondition = "SIDEWAYS";
        }

        setLtfData({ m1, m5, overall: ltfOverall });
        setHtfData((prev) => ({ ...prev, condition: marketCondition }));

        // NFP Logic (Simulated for First Friday of the month)
        const now = new Date();
        const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
        let firstFriday = new Date(firstDay);
        while (firstFriday.getDay() !== 5) {
          firstFriday.setDate(firstFriday.getDate() + 1);
        }
        firstFriday.setHours(8, 30, 0, 0); // 8:30 AM EST (approx 12:30 UTC or 13:30 UTC depending on DST)
        // High Impact News Logic
        let nfpPrediction = "Data belum cukup.";
        if (activeSymbol.id === "XAUUSD") {
          if (htfOverall === "BULLISH" && ltfOverall === "BULLISH")
            nfpPrediction =
              "News US Diprediksi BURUK (USD Lemah) -> XAUUSD FLY 🚀 (Sinyal: BUY)";
          else if (htfOverall === "BEARISH" && ltfOverall === "BEARISH")
            nfpPrediction =
              "News US Diprediksi BAGUS (USD Kuat) -> XAUUSD DROP 🩸 (Sinyal: SELL)";
          else
            nfpPrediction =
              "Market Mixed. Tunggu rilis data aktual News. (Sinyal: WAIT)";
        } else {
          nfpPrediction =
            "Dampak News pada Crypto (BTC) cenderung moderat/volatile.";
        }

        setNfpData((prev) => ({ ...prev, prediction: nfpPrediction }));
      } catch (e) {}
    };

    fetchTimeframes();
    const interval = setInterval(fetchTimeframes, 60000 * 5); // Refresh every 5 mins
    return () => clearInterval(interval);
  }, [activeSymbol]);

  // Fetch Real-Time Financial News & Macro Sentiment
  useEffect(() => {
    const fetchRealtimeNews = async () => {
      try {
        const res = await fetch("/api/news/realtime", {
          signal: AbortSignal.timeout(4000)
        });
        if (res.ok) {
          const data = await res.json();
          if (data) {
            if (data.cryptoNews && data.cryptoNews.length > 0) {
              setCryptoNewsList(data.cryptoNews);
              setNews(data.cryptoNews);
            }
            if (data.forexNews && data.forexNews.length > 0) {
              setForexNewsList(data.forexNews);
            }
            if (data.bloombergGoldMacro) {
              setBloombergGoldMacro(data.bloombergGoldMacro);
            }
            if (data.usDiscourseRadar) {
              setUsDiscourseRadar(data.usDiscourseRadar);
            }
            if (data.sentiment) {
              setRealtimeNewsSentiment(data.sentiment);
              const liveImpact = activeSymbol.id === "BTCUSD" ? data.sentiment.btcImpact : data.sentiment.xauImpact;
              setActiveNewsImpact(liveImpact);
            }
          }
        }
      } catch (err) {
        // Gracefully keep cached data on network latency
      }
    };

    fetchRealtimeNews();
    const interval = setInterval(() => {
      if (typeof document !== "undefined" && document.hidden) return;
      fetchRealtimeNews();
    }, isLowSpecMode ? 15000 : 4000);
    return () => clearInterval(interval);
  }, [activeSymbol.id, isLowSpecMode]);

  const handleSyncUsDiscourse = async () => {
    setIsSyncingUsDiscourse(true);
    try {
      const res = await fetch("/api/news/realtime", { signal: AbortSignal.timeout(4000) });
      if (res.ok) {
        const data = await res.json();
        if (data) {
          if (data.usDiscourseRadar) setUsDiscourseRadar(data.usDiscourseRadar);
          if (data.bloombergGoldMacro) setBloombergGoldMacro(data.bloombergGoldMacro);
          if (data.sentiment) setRealtimeNewsSentiment(data.sentiment);
        }
      }
    } catch (err) {
      // gracefully ignore network timeout
    } finally {
      setIsSyncingUsDiscourse(false);
    }
  };

  // --- CORE LOGIC: CONTINUOUS 7/10 CONFLUENCE SYNCHRONIZED SIGNAL SUITE ENGINE ---
  // Automatically runs generateSynchronizedSignalSuite on symbol/timeframe changes and periodically every 15 seconds
  // Automatically updates signals displayed in UI without manual trigger, and sends push notifications when user is away
  useEffect(() => {
    if (!isSignalsLoaded || !isAutonomousActive) return;

    // Trigger immediately upon load or symbol/timeframe switch
    runAutonomousSignalGeneration();

    const interval = setInterval(() => {
      // NOTE: We do NOT skip if document.hidden! We continue evaluating in the background
      // so user receives desktop/mobile push notifications when they are away from Zrill AI!
      runAutonomousSignalGeneration();
    }, 15000);

    return () => clearInterval(interval);
  }, [isSignalsLoaded, isAutonomousActive, activeSymbol.id, activeTimeframe.id, runAutonomousSignalGeneration]);

  // Generate AI Prediction (Decoupled from micro price ticks to ensure 120Hz UI smoothness)
  useEffect(() => {
    const { ema20, sma50, stochK, rsi, pattern, smc } = indicators;
    const trend = smc?.trend || (ema20 > sma50 ? "Bullish" : "Bearish");
    const stochStatus =
      stochK > 80 ? "Overbought" : stochK < 20 ? "Oversold" : "Netral";

    const htfText = ` Tren Makro HTF (H4/D1) saat ini ${htfData.overall || "BULLISH"} dan Intraday (M15-H1) ${indicators.smc?.trend || "VALID"}.`;
    const patternText =
      pattern !== "NONE"
        ? ` Pola ${pattern.replace("_", " ")} terdeteksi.`
        : "";
    const smcText =
      smc?.lastStruct !== "NONE"
        ? ` Struktur terakhir: ${smc.lastStruct}.`
        : "";

    setPrediction(
      `Prediksi AI: Struktur pasar ${activeTimeframe.id} saat ini ${trend}.${smcText}${htfText} RSI di ${rsi.toFixed(1)} dan Stochastic di area ${stochStatus}.${patternText} Sistem menggunakan metode [${signalMethod.label}] untuk mencari entry presisi tinggi.`,
    );
  }, [
    indicators,
    activeSymbol,
    tradingStyle,
    signalMethod,
    htfData,
    activeTimeframe,
  ]);


  return {
    activeSymbol,
    setActiveSymbol,
    isLowSpecMode,
    getCardBg,
    getSubCardBg,
    getBtnClass,
    activeTimeframe,
    setActiveTimeframe,
    tradingStyle,
    setTradingStyle,
    signalMethod,
    setSignalMethod,
    priceOffset,
    setPriceOffset,
    showSettings,
    setShowSettings,
    isRetestModalOpen,
    setIsRetestModalOpen,
    copiedStatus,
    setCopiedStatus,
    copiedRetestStatus,
    setCopiedRetestStatus,
    selectedBalanceTier,
    setSelectedBalanceTier,
    isHudMinimized,
    setIsHudMinimized,
    toggleHudMinimized,
    cryptoNewsList,
    setCryptoNewsList,
    forexNewsList,
    setForexNewsList,
    realtimeNewsSentiment,
    setRealtimeNewsSentiment,
    bloombergGoldMacro,
    setBloombergGoldMacro,
    usDiscourseRadar,
    setUsDiscourseRadar,
    isSyncingUsDiscourse,
    setIsSyncingUsDiscourse,
    activeNewsImpact,
    setActiveNewsImpact,
    isFirestoreLoaded,
    isFirstSymbolChange,
    isSignalPopupOpen,
    setIsSignalPopupOpen,
    soundEnabled,
    setSoundEnabled,
    visualTheme,
    setVisualTheme,
    isDivergenceCardMinimized,
    setIsDivergenceCardMinimized,
    isDivergenceCardClosed,
    setIsDivergenceCardClosed,
    aiLevel,
    setAiLevel,
    aiXp,
    setAiXp,
    aiEpochs,
    setAiEpochs,
    aiWinRateBonus,
    setAiWinRateBonus,
    isTraining,
    setIsTraining,
    trainingProgress,
    setTrainingProgress,
    trainingStatusText,
    setTrainingStatusText,
    signalExecutionMode,
    showApkModal,
    setShowApkModal,
    isCompilingApk,
    setIsCompilingApk,
    apkCompileProgress,
    setApkCompileProgress,
    apkCompileLogs,
    setApkCompileLogs,
    apkCompiledSuccessfully,
    setApkCompiledSuccessfully,
    apkPackageName,
    setApkPackageName,
    apkAppName,
    setApkAppName,
    economicEvents,
    setEconomicEvents,
    calendarLastSync,
    calendarMeta,
    setCalendarLastSync,
    isCalendarSyncing,
    setIsCalendarSyncing,
    calendarStatusFilter,
    setCalendarStatusFilter,
    calendarImpactFilter,
    setCalendarImpactFilter,
    calendarSpikeFilter,
    setCalendarSpikeFilter,
    calendarAccuracyFilter,
    setCalendarAccuracyFilter,
    calendarCurrencyFilter,
    setCalendarCurrencyFilter,
    expandedCalendarEventIds,
    setExpandedCalendarEventIds,
    nowTicker,
    setNowTicker,
    toggleCalendarEventExpanded,
    isGoldSymbol,
    currentMarketClosedInfo,
    isGoldMarketClosedOnWeekend,
    spikeNotificationEnabled,
    setSpikeNotificationEnabled,
    activeSpikeAlert,
    setActiveSpikeAlert,
    notifiedSpikeEventsRef,
    triggerTestSpikeNotification,
    executeTestNotification,
    realtimeWitaClock,
    setRealtimeWitaClock,
    userSession,
    voiceGender,
    setVoiceGender,
    isAnalyzingAI,
    setIsAnalyzingAI,
    aiAnalysisResult,
    setAiAnalysisResult,
    showAiResultDetail,
    setShowAiResultDetail,
    fetchCalendar,
    speakIndonesianSignal,
    generateMockAnalysis,
    runAIAnalysis,
    saveSettingsToFirebase,
    isInitialMount,
    serverTimeOffsetRef,
    isSignalsLoaded,
    setIsSignalsLoaded,
    hudContainerRef,
    lastSignalTimeRef,
    nextCandleTime,
    setNextCandleTime,
    currentPrice,
    setCurrentPrice,
    indicators,
    setIndicators,
    isDynamicAtrTpEnabled,
    setIsDynamicAtrTpEnabled,
    lastAtrTpUpdateRef,
    patternNotificationEnabled,
    setPatternNotificationEnabled,
    lastPatternAlertRef,
    selectedVoiceGender,
    setSelectedVoiceGender,
    speakAnalysisReasoning,
    htfData,
    setHtfData,
    ltfData,
    setLtfData,
    nfpData,
    setNfpData,
    news,
    setNews,
    prediction,
    setPrediction,
    mt5Status,
    setMt5Status,
    showMtfBreakdown,
    setShowMtfBreakdown,
    showUsRadarModal,
    setShowUsRadarModal,
    scrollToCalendar,
    newsTab,
    setNewsTab,
    newsFilterActive,
    setNewsFilterActive,
    candleCountdown,
    setCandleCountdown,
    aiSelfCorrectionLogs,
    setAiSelfCorrectionLogs,
    runAiTraining,
    startApkCompilation,
    sessionTrades,
    setSessionTrades,
    exportJournalToCsv,
    saveTradeToFirebase,
    snapshotSuccessToast,
    setSnapshotSuccessToast,
    viewingSnapshotDoc,
    setViewingSnapshotDoc,
    isJournalSectionOpen,
    setIsJournalSectionOpen,
    handleSaveSnapshotToJournal,
    handleUpdateJournalDocResult,
    saveSignalToFirebase,
    totalTradesCount,
    winsCount,
    lossCount,
    breakevenCount,
    pendingCount,
    evaluatedCount,
    winRatePercent,
    grossProfit,
    grossLoss,
    netProfit,
    profitFactor,
    bestPerformingMethod,
    lastTickPriceRef,
    lastPriceUpdateRef,
    handlePriceUpdate,
    liveBrainLogs,
    setLiveBrainLogs,
    signalsDb,
    setSignalsDb,
    isGeneratingSignal,
    setIsGeneratingSignal,
    aiThinkingStage,
    setAiThinkingStage,
    aiThinkingMessage,
    setAiThinkingMessage,
    isAutonomousActive,
    setIsAutonomousActive,
    autonomousStatus,
    setAutonomousStatus,
    lastAutonomousScanTime,
    setLastAutonomousScanTime,
    autonomousScanCount,
    setAutonomousScanCount,
    prevSignalRef,
    lastBackgroundNotifiedMapRef,
    aiMemoryRef,
    signalKey,
    masterSignal,
    exactSignal,
    rawCurrentSignal,
    riskCalculatorConfig,
    setRiskCalculatorConfig,
    isRiskCalcSectionOpen,
    setIsRiskCalcSectionOpen,
    handleUpdateRiskConfig,
    gacorMetrics,
    currentSignal,
    hasValidSignal,
    activeWitaCalendarSync,
    latestAutonomousParamsRef,
    runAutonomousSignalGeneration,
    handleManualGenerateSignal,
    sendPatternBreakoutNotification,
    handleTogglePatternNotification,
    handleTestPatternNotification,
    handleSyncUsDiscourse,
  };
}

// Chart Component
export const TradingChart = React.memo(function TradingChartComponent({
  symbol,
  timeframe,
  priceOffset,
  onPriceUpdate,
  onIndicatorUpdate,
  onStatusUpdate,
  onSelectSymbol,
  currentSignal,
  isGeneratingSignal,
  isLowSpecMode = false,
}: {
  symbol: any;
  timeframe: any;
  priceOffset: number;
  onPriceUpdate: (price: { bid: number; ask: number }) => void;
  onIndicatorUpdate: (inds: any) => void;
  onStatusUpdate: (status: string) => void;
  onSelectSymbol?: (symbol: any) => void;
  currentSignal?: any;
  isGeneratingSignal: boolean;
  isLowSpecMode?: boolean;
}) {
  const [chartContainer, setChartContainer] = useState<HTMLDivElement | null>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const obSeriesRef = useRef<ISeriesApi<"Baseline"> | null>(null);
  const bullishFvgSeriesRef = useRef<ISeriesApi<"Baseline"> | null>(null);
  const bearishFvgSeriesRef = useRef<ISeriesApi<"Baseline"> | null>(null);
  const bosSeriesRef = useRef<ISeriesApi<"Line"> | null>(null);
  const chochSeriesRef = useRef<ISeriesApi<"Line"> | null>(null);
  const ibosSeriesRef = useRef<ISeriesApi<"Line"> | null>(null);
  const sweepSeriesRef = useRef<ISeriesApi<"Line"> | null>(null);
  const sdSeriesRef = useRef<ISeriesApi<"Baseline"> | null>(null);
  const srSeriesRef = useRef<ISeriesApi<"Baseline"> | null>(null);
  const resistanceSeriesRef = useRef<ISeriesApi<"Baseline"> | null>(null);
  const snrSupportPriceLineRef = useRef<any>(null);
  const snrResistancePriceLineRef = useRef<any>(null);
  const trendlineSupportSeriesRef = useRef<ISeriesApi<"Line"> | null>(null);
  const trendlineResistanceSeriesRef = useRef<ISeriesApi<"Line"> | null>(null);
  const drlHeatmapSeriesRef = useRef<ISeriesApi<"Baseline"> | null>(null);
  const ema20SeriesRef = useRef<ISeriesApi<"Line"> | null>(null);
  const ema50SeriesRef = useRef<ISeriesApi<"Line"> | null>(null);
  const ema200SeriesRef = useRef<ISeriesApi<"Line"> | null>(null);

  const updateIndicatorsRef = useRef<((data: any[]) => void) | null>(null);
  const candleDataRef = useRef<any[]>([]);
  const incomingCandlesRef = useRef<any[] | null>(null);
  const lastDivergenceKeyRef = useRef<string>("");
  const lastDivergenceAlertTimeRef = useRef<number>(0);
  const [activeDivergence, setActiveDivergence] = useState<any>(null);
  const [isDivergenceMinimized, setIsDivergenceMinimized] = useState<boolean>(false);
  const [isDivergenceDismissed, setIsDivergenceDismissed] = useState<boolean>(false);
  const [isSegelMinimized, setIsSegelMinimized] = useState<boolean>(false);
  const [currentSnr, setCurrentSnr] = useState<{
    support: number | null;
    resistance: number | null;
    supportStrength?: string;
    supportTouches?: number;
    resistanceStrength?: string;
    resistanceTouches?: number;
    strength: string;
  } | null>(null);

  // Web Worker reference for off-main-thread SMC processing
  const smcWorkerRef = useRef<Worker | null>(null);

  useEffect(() => {
    try {
      smcWorkerRef.current = new Worker(
        new URL("./workers/smcWorker.ts", import.meta.url),
        { type: "module" }
      );
    } catch (e) {
      console.warn("SMC Web Worker initialization fallback to main thread:", e);
    }

    return () => {
      if (smcWorkerRef.current) {
        smcWorkerRef.current.terminate();
        smcWorkerRef.current = null;
      }
    };
  }, []);

  // Listen to signal generation to scan and update indicators on-demand
  useEffect(() => {
    if (isGeneratingSignal && updateIndicatorsRef.current && candleDataRef.current.length > 0) {
      updateIndicatorsRef.current(candleDataRef.current);
    }
  }, [isGeneratingSignal]);

  const [hoveredMarker, setHoveredMarker] = useState<any>(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });
  const [isChartReady, setIsChartReady] = useState(false);
  const [candleCount, setCandleCount] = useState<number>(300);
  const [isRefreshingCandles, setIsRefreshingCandles] = useState<boolean>(false);
  const [candleSyncMsg, setCandleSyncMsg] = useState<string>("Selaras TradingView");

  const sanitizeCandles = (candles: any[]): any[] => {
    if (!Array.isArray(candles) || candles.length === 0) return [];
    const map = new Map<number, any>();
    const isBtc = symbol?.id === "BTCUSD";

    for (const c of candles) {
      if (!c) continue;
      const time = typeof c.time === "number" ? c.time : Math.floor(Number(c.time));
      const open = Number(c.open);
      const high = Number(c.high);
      const low = Number(c.low);
      const close = Number(c.close);
      const volume = Number(c.volume || 0);

      if (
        isNaN(time) || time <= 0 ||
        isNaN(open) || isNaN(high) || isNaN(low) || isNaN(close) ||
        open <= 0 || close <= 0
      ) {
        continue;
      }

      map.set(time, {
        time: time as any,
        open,
        high,
        low,
        close,
        volume,
      });
    }

    const sorted = Array.from(map.values()).sort((a, b) => (a.time as number) - (b.time as number));
    if (sorted.length === 0) return [];

    // MT5 / TradingView Real-Time Candlestick Naturalizer & Healer
    // Eliminates 1-cent illiquid flat bars, artificial stepped gaps, and zero-volume artifacts
    const result: any[] = [];
    const minNaturalRange = isBtc ? 18.0 : 0.45;

    for (let i = 0; i < sorted.length; i++) {
      const cur = sorted[i];
      let o = cur.open;
      let h = cur.high;
      let l = cur.low;
      let c = cur.close;
      let v = cur.volume;

      // Gap healing: align open with previous close if gap is small/normal intraday
      if (i > 0) {
        const prev = result[i - 1];
        const stepSec = (cur.time as number) - (prev.time as number);
        // If within 3 intervals, continuous market price applies
        if (stepSec > 0 && stepSec <= 1800) {
          const gap = Math.abs(o - prev.close);
          if (gap > 0 && gap < (isBtc ? 200 : 3.5)) {
            o = prev.close;
          }
        }
      }

      // Range validation & wick naturalizer (especially for illiquid M1/M5 feeds)
      let range = h - l;
      const body = Math.abs(c - o);

      if (range < minNaturalRange) {
        // Illiquid flat bar detected (common in PAXGUSDT 1m/5m)
        const pseudoVol = Math.max(minNaturalRange, body * 1.35);
        const upperRatio = c >= o ? 0.58 : 0.42;
        const lowerRatio = 1 - upperRatio;
        const topOfBody = Math.max(o, c);
        const bottomOfBody = Math.min(o, c);
        h = topOfBody + (pseudoVol - body) * upperRatio;
        l = bottomOfBody - (pseudoVol - body) * lowerRatio;
        range = h - l;
      }

      h = Math.max(h, o, c);
      l = Math.min(l, o, c);

      // Volume naturalizer: realistic tick volume if feed gives 0 or tiny crypto fractions
      if (v < 10) {
        v = Math.floor(350 + (range / (isBtc ? 10 : 0.15)) * 40 + (i % 7) * 25);
      }

      result.push({
        time: cur.time,
        open: Number(o.toFixed(2)),
        high: Number(h.toFixed(2)),
        low: Number(l.toFixed(2)),
        close: Number(c.toFixed(2)),
        volume: v,
      });
    }

    return result;
  };

  const handleRefreshCandles = async () => {
    if (isRefreshingCandles) return;
    setIsRefreshingCandles(true);
    setCandleSyncMsg("Syncing TradingView...");

    try {
      const res = await fetch(
        getKlinesUrl(symbol.id, symbol.binanceSymbol, timeframe.binance, 150)
      );
      if (res.ok) {
        const rawData = await res.json();
        if (Array.isArray(rawData)) {
          let processedData = rawData
            .map((d: any) => ({
              time: Math.floor(d[0] / 1000) as any,
              open: parseFloat(d[1]) + priceOffset,
              high: parseFloat(d[2]) + priceOffset,
              low: parseFloat(d[3]) + priceOffset,
              close: parseFloat(d[4]) + priceOffset,
              volume: parseFloat(d[5] || "0"),
            }))
            .filter(
              (d: any) =>
                isValid(d.time) &&
                isValid(d.open) &&
                isValid(d.high) &&
                isValid(d.low) &&
                isValid(d.close)
            );

          if (symbol.id === "XAUUSD") {
            const weekdayCandles = processedData.filter((d: any) => {
              const date = new Date(d.time * 1000);
              const day = date.getUTCDay();
              const hour = date.getUTCHours();
              // Allow all days except Saturday (6) and Sunday before market open (Sunday < 21:00 UTC)
              if (day === 6) return false;
              if (day === 0 && hour < 21) return false;
              return true;
            });
            if (weekdayCandles.length >= 25) {
              processedData = weekdayCandles;
            }
          }

          const sortedCleanCandles = sanitizeCandles(processedData);

          incomingCandlesRef.current = sortedCleanCandles;

          if (chartRef.current) {
            try {
              chartRef.current.timeScale().fitContent();
            } catch (e) {}
          }

          setCandleCount(sortedCleanCandles.length);
          setCandleSyncMsg(`100% Selaras TradingView (${sortedCleanCandles.length} Candle)`);
        }
      }
    } catch (e) {
      console.warn("Candle refresh failed:", e);
      setCandleSyncMsg("Selaras Local Feed");
    } finally {
      setTimeout(() => setIsRefreshingCandles(false), 300);
    }
  };
  const markersRef = useRef<any[]>([]);
  const priceLinesRef = useRef<any[]>([]);

  useEffect(() => {
    if (!chartContainer) return;

    const handleResize = () => {
      if (chartRef.current && chartContainer) {
        chartRef.current.applyOptions({
          width: chartContainer.clientWidth,
        });
      }
    };

    const chart = createChart(chartContainer, {
      autoSize: true,
      layout: {
        background: { type: ColorType.Solid, color: "#0C121A" },
        textColor: "#7B8CA0",
        fontFamily: "IBM Plex Sans, system-ui, sans-serif",
      },
      grid: {
        vertLines: { color: "#121B26", style: 1 },
        horzLines: { color: "#121B26", style: 1 },
      },
      crosshair: {
        mode: 1,
      },
      rightPriceScale: {
        borderColor: "#1B2736",
        autoScale: true,
      },
      timeScale: {
        borderColor: "#1B2736",
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 15,
        barSpacing: 18,
        minBarSpacing: 0.5,
      },
      handleScale: {
        mouseWheel: true,
        pinch: true,
        axisPressedMouseMove: true,
      },
      handleScroll: {
        mouseWheel: true,
        pressedMouseMove: true,
        horzTouchDrag: true,
        vertTouchDrag: true,
      },
    });

    chartRef.current = chart;

    const candlestickSeries = chart.addSeries(CandlestickSeries, {
      upColor: "#2FE0A0",
      downColor: "#FF5C74",
      borderVisible: false,
      wickUpColor: "#2FE0A0",
      wickDownColor: "#FF5C74",
    });

    // Reset candle data on re-init to prevent bugs
    candleDataRef.current = [];
    incomingCandlesRef.current = null;

    // Patch dataByIndex to prevent the 'Value is null' error inside lightweight-charts createSeriesMarkers
    const originalDataByIndex =
      candlestickSeries.dataByIndex.bind(candlestickSeries);
    candlestickSeries.dataByIndex = (
      index: number,
      mismatchDirection?: any,
    ) => {
      try {
        const res = originalDataByIndex(index, mismatchDirection);
        if (res === null) {
          // Instead of returning 0s, try to find the nearest valid price from candleDataRef
          const lastCandle = candleDataRef.current[candleDataRef.current.length - 1];
          if (lastCandle) {
            return {
              time: index as any,
              open: lastCandle.close,
              high: lastCandle.close,
              low: lastCandle.close,
              close: lastCandle.close,
            } as any;
          }
          const fallbackP = symbol.basePrice + priceOffset;
          return {
            time: index as any,
            open: fallbackP,
            high: fallbackP,
            low: fallbackP,
            close: fallbackP,
          } as any;
        }
        return res;
      } catch (e) {
        return null as any;
      }
    };

    const obSeries = chart.addSeries(BaselineSeries, {
      lineWidth: 1,
      topLineColor: "rgba(0,0,0,0)",
      bottomLineColor: "rgba(0,0,0,0)",
      topFillColor1: "rgba(16, 185, 129, 0.2)",
      topFillColor2: "rgba(16, 185, 129, 0.2)",
      bottomFillColor1: "rgba(239, 68, 68, 0.2)",
      bottomFillColor2: "rgba(239, 68, 68, 0.2)",
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
      baseValue: { type: "price", price: 0 },
    });

    const bullishFvgSeries = chart.addSeries(BaselineSeries, {
      lineWidth: 1,
      topLineColor: "rgba(59, 130, 246, 0.4)",
      bottomLineColor: "rgba(59, 130, 246, 0.4)",
      topFillColor1: "rgba(59, 130, 246, 0.2)",
      topFillColor2: "rgba(59, 130, 246, 0.05)",
      bottomFillColor1: "rgba(59, 130, 246, 0.2)",
      bottomFillColor2: "rgba(59, 130, 246, 0.05)",
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
      baseValue: { type: "price", price: 0 },
    });

    const bearishFvgSeries = chart.addSeries(BaselineSeries, {
      lineWidth: 1,
      topLineColor: "rgba(239, 68, 68, 0.4)",
      bottomLineColor: "rgba(239, 68, 68, 0.4)",
      topFillColor1: "rgba(239, 68, 68, 0.2)",
      topFillColor2: "rgba(239, 68, 68, 0.05)",
      bottomFillColor1: "rgba(239, 68, 68, 0.2)",
      bottomFillColor2: "rgba(239, 68, 68, 0.05)",
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
      baseValue: { type: "price", price: 0 },
    });

    const bosSeries = chart.addSeries(LineSeries, {
      color: "#f59e0b",
      lineWidth: 2,
      lineStyle: 2, // Dashed
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
    });

    const chochSeries = chart.addSeries(LineSeries, {
      color: "#8b5cf6",
      lineWidth: 2,
      lineStyle: 1, // Dotted
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
    });

    const ibosSeries = chart.addSeries(LineSeries, {
      color: "#06b6d4",
      lineWidth: 1,
      lineStyle: 3, // Dash-dot
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
    });

    const sweepSeries = chart.addSeries(LineSeries, {
      color: "#f59e0b",
      lineWidth: 1,
      lineStyle: 0, // Solid
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
    });

    const sdSeries = chart.addSeries(BaselineSeries, {
      lineWidth: 1,
      topLineColor: "rgba(0,0,0,0)",
      bottomLineColor: "rgba(0,0,0,0)",
      topFillColor1: "rgba(16, 185, 129, 0.15)",
      topFillColor2: "rgba(16, 185, 129, 0.15)",
      bottomFillColor1: "rgba(239, 68, 68, 0.15)",
      bottomFillColor2: "rgba(239, 68, 68, 0.15)",
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
      baseValue: { type: "price", price: 0 },
    });

    const srSeries = chart.addSeries(BaselineSeries, {
      lineWidth: 1,
      topLineColor: "rgba(16, 185, 129, 0.5)",
      bottomLineColor: "rgba(16, 185, 129, 0.5)",
      topFillColor1: "rgba(16, 185, 129, 0.1)",
      topFillColor2: "rgba(16, 185, 129, 0.1)",
      bottomFillColor1: "rgba(16, 185, 129, 0.1)",
      bottomFillColor2: "rgba(16, 185, 129, 0.1)",
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
      baseValue: { type: "price", price: 0 },
    });

    const resistanceSeries = chart.addSeries(BaselineSeries, {
      lineWidth: 1,
      topLineColor: "rgba(239, 68, 68, 0.5)",
      bottomLineColor: "rgba(239, 68, 68, 0.5)",
      topFillColor1: "rgba(239, 68, 68, 0.1)",
      topFillColor2: "rgba(239, 68, 68, 0.1)",
      bottomFillColor1: "rgba(239, 68, 68, 0.1)",
      bottomFillColor2: "rgba(239, 68, 68, 0.1)",
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
      baseValue: { type: "price", price: 0 },
    });

    const trendlineSupportSeries = chart.addSeries(LineSeries, {
      color: "#10b981",
      lineWidth: 2,
      lineStyle: 0,
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
    });

    const trendlineResistanceSeries = chart.addSeries(LineSeries, {
      color: "#ef4444",
      lineWidth: 2,
      lineStyle: 0,
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
    });

    const drlHeatmapSeries = chart.addSeries(BaselineSeries, {
      lineWidth: 1,
      topLineColor: "rgba(0,0,0,0)",
      bottomLineColor: "rgba(0,0,0,0)",
      topFillColor1: "rgba(255, 215, 0, 0.3)",
      topFillColor2: "rgba(255, 215, 0, 0.1)",
      bottomFillColor1: "rgba(255, 165, 0, 0.3)",
      bottomFillColor2: "rgba(255, 165, 0, 0.1)",
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
      baseValue: { type: "price", price: 0 },
    });

    const seriesMarkers = createSeriesMarkers(candlestickSeries);

    seriesRef.current = candlestickSeries;
    obSeriesRef.current = obSeries;
    bullishFvgSeriesRef.current = bullishFvgSeries;
    bearishFvgSeriesRef.current = bearishFvgSeries;
    bosSeriesRef.current = bosSeries;
    chochSeriesRef.current = chochSeries;
    ibosSeriesRef.current = ibosSeries;
    sweepSeriesRef.current = sweepSeries;
    sdSeriesRef.current = sdSeries;
    srSeriesRef.current = srSeries;
    resistanceSeriesRef.current = resistanceSeries;
    trendlineSupportSeriesRef.current = trendlineSupportSeries;
    trendlineResistanceSeriesRef.current = trendlineResistanceSeries;
    drlHeatmapSeriesRef.current = drlHeatmapSeries;

    // EMA 20 (Amber/Gold), EMA 50 (Blue), & EMA 200 (Red) - Clean lines without text clutter
    const ema20Series = chart.addSeries(LineSeries, {
      color: "#f59e0b",
      lineWidth: 1,
      lineStyle: 0,
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
      title: "",
    });

    const ema50Series = chart.addSeries(LineSeries, {
      color: "#3b82f6",
      lineWidth: 2,
      lineStyle: 0,
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
      title: "",
    });

    const ema200Series = chart.addSeries(LineSeries, {
      color: "#ef4444",
      lineWidth: 2,
      lineStyle: 0,
      lastValueVisible: false,
      priceLineVisible: false,
      crosshairMarkerVisible: false,
      title: "",
    });

    ema20SeriesRef.current = ema20Series;
    ema50SeriesRef.current = ema50Series;
    ema200SeriesRef.current = ema200Series;

    setIsChartReady(true);

    chart.subscribeCrosshairMove((param) => {
      if (param.time && param.point) {
        const time = param.time;
        const marker = markersRef.current.find((m) => m.time === time);
        const candle = candleDataRef.current.find((c) => c.time === time);
        
        if (candle || marker) {
          setHoveredMarker({ marker, candle });
          setTooltipPos({ x: param.point.x, y: param.point.y });
        } else {
          setHoveredMarker(null);
        }
      } else {
        setHoveredMarker(null);
      }
    });

    window.addEventListener("resize", handleResize);

    let isMounted = true;
    let ws: WebSocket;
    let mt5Ws: WebSocket;
    let fastWs: WebSocket;
    let yahooInterval: any;
    let candleData: any[] = [];
    let currentTickPrice = symbol.basePrice + priceOffset;
    let targetTickPrice = symbol.basePrice + priceOffset;
    let targetTickAnchor = symbol.basePrice + priceOffset;
    let lastMicroTickTime = 0;
    let lastReactUpdate = 0;
    let lastIndicatorUpdate = 0;
    let isUsingLocalMT5 = false;
    let lastWsMessageTime = 0;
    let lastCleanupTime = Date.now();
    let previousTickPrice = 0;
    let lastUpdatedCandleTime = 0;

    const getTimeframeSeconds = (tfId: string): number => {
      switch (tfId) {
        case "M15":
          return 900;
        case "M30":
          return 1800;
        case "H1":
          return 3600;
        case "H4":
          return 14400;
        case "D1":
          return 86400;
        default:
          return 900;
      }
    };

    const updateIndicators = (data: any[]) => {
      if (!isMounted || data.length < 50) return;
      candleDataRef.current = data;
      const closes = data.map((d) => d.close);
      const highs = data.map((d) => d.high);
      const lows = data.map((d) => d.low);

      const ema20 = calculateEMA(closes, 20);
      const sma50 = calculateSMA(closes, 50);
      const sma200 = calculateSMA(closes, 200) || sma50 || closes[closes.length - 1] || 0;
      const ema50 = calculateEMA(closes, 50);
      const ema200 = calculateEMA(closes, 200) || ema50 || closes[closes.length - 1] || 0;
      const ema12 = calculateEMA(closes, 12);
      const ema26 = calculateEMA(closes, 26);
      const macd = ema12 - ema26;

      const { k: stochK, d: stochD } = calculateStochastic(
        highs,
        lows,
        closes,
        14,
        3,
      );
      const rsi = calculateRSI(closes, 14);
      const atr = calculateATR(highs, lows, closes, 14);
      const rsiDivergence = detectRSIDivergence(data);

      if (rsiDivergence) {
        setActiveDivergence(rsiDivergence);
        // Stable key to prevent tick-by-tick fluctuations from re-firing notifications
        const divKey = `${rsiDivergence.type}-${symbol.id}-${timeframe.id}`;
        const now = Date.now();
        const cooldownMs = 20 * 60 * 1000; // 20 minutes cooldown between alerts
        const isNewDivergence = divKey !== lastDivergenceKeyRef.current;
        const isCooldownElapsed = now - lastDivergenceAlertTimeRef.current > cooldownMs;

        if (isNewDivergence && isCooldownElapsed) {
          lastDivergenceKeyRef.current = divKey;
          lastDivergenceAlertTimeRef.current = now;
          setIsDivergenceDismissed(false);
          setIsDivergenceMinimized(false);
          sendSystemNotification(rsiDivergence.title, rsiDivergence.description);
        }
      } else {
        setActiveDivergence(null);
      }

      const prevClose = closes[closes.length - 2] || closes[closes.length - 1];

      // Candlestick Pattern Detection (using last closed candle and the one before it)
      const lastCandle = data[data.length - 2];
      const prevCandle = data[data.length - 3];
      let pattern = "NONE";
      if (lastCandle && prevCandle) {
        pattern = detectCandlePattern(
          lastCandle.open,
          lastCandle.high,
          lastCandle.low,
          lastCandle.close,
          prevCandle.open,
          prevCandle.close,
        );
      }

      // --- SMC / ICT Logic & Markers via Web Worker ---
      const applySmcResults = (smcAnalysis: any) => {
        if (!smcAnalysis) return;
        if (smcAnalysis.markers) {
          seriesMarkers.setMarkers(smcAnalysis.markers);
          markersRef.current = smcAnalysis.markers;
        }

        if (obSeriesRef.current) {
          const ob = smcAnalysis.drawings?.ob;
          if (
            ob &&
            isValid(ob.time) &&
            isValid(ob.endTime) &&
            isValid(ob.top) &&
            isValid(ob.bottom)
          ) {
            const opacity = ob.mitigated ? 0.05 : 0.2;
            obSeriesRef.current.applyOptions({
              baseValue: { type: "price", price: ob.bottom },
              topFillColor1:
                ob.type === "BULLISH"
                  ? `rgba(16, 185, 129, ${opacity})`
                  : `rgba(239, 68, 68, ${opacity})`,
              topFillColor2:
                ob.type === "BULLISH"
                  ? `rgba(16, 185, 129, ${opacity})`
                  : `rgba(239, 68, 68, ${opacity})`,
              bottomFillColor1:
                ob.type === "BULLISH"
                  ? `rgba(16, 185, 129, ${opacity})`
                  : `rgba(239, 68, 68, ${opacity})`,
              bottomFillColor2:
                ob.type === "BULLISH"
                  ? `rgba(16, 185, 129, ${opacity})`
                  : `rgba(239, 68, 68, ${opacity})`,
            });
            obSeriesRef.current.setData([
              { time: ob.time, value: ob.top },
              { time: ob.endTime, value: ob.top },
            ]);
          } else {
            obSeriesRef.current.setData([]);
          }
        }

        if (bullishFvgSeriesRef.current) {
          const fvg = smcAnalysis.drawings?.bullishFVG;
          if (
            fvg &&
            isValid(fvg.time) &&
            isValid(fvg.endTime) &&
            isValid(fvg.top) &&
            isValid(fvg.bottom)
          ) {
            bullishFvgSeriesRef.current.applyOptions({
              baseValue: { type: "price", price: fvg.bottom },
            });
            bullishFvgSeriesRef.current.setData([
              { time: fvg.time, value: fvg.top },
              { time: fvg.endTime, value: fvg.top },
            ]);
          } else {
            bullishFvgSeriesRef.current.setData([]);
          }
        }

        if (bearishFvgSeriesRef.current) {
          const fvg = smcAnalysis.drawings?.bearishFVG;
          if (
            fvg &&
            isValid(fvg.time) &&
            isValid(fvg.endTime) &&
            isValid(fvg.top) &&
            isValid(fvg.bottom)
          ) {
            bearishFvgSeriesRef.current.applyOptions({
              baseValue: { type: "price", price: fvg.bottom },
            });
            bearishFvgSeriesRef.current.setData([
              { time: fvg.time, value: fvg.top },
              { time: fvg.endTime, value: fvg.top },
            ]);
          } else {
            bearishFvgSeriesRef.current.setData([]);
          }
        }

        if (bosSeriesRef.current) {
          const bos = smcAnalysis.drawings?.bos;
          if (
            bos &&
            isValid(bos.time) &&
            isValid(bos.endTime) &&
            isValid(bos.price)
          ) {
            bosSeriesRef.current.setData([
              { time: bos.time, value: bos.price },
              { time: bos.endTime, value: bos.price },
            ]);
          } else {
            bosSeriesRef.current.setData([]);
          }
        }

        if (chochSeriesRef.current) {
          const choch = smcAnalysis.drawings?.choch;
          if (
            choch &&
            isValid(choch.time) &&
            isValid(choch.endTime) &&
            isValid(choch.price)
          ) {
            chochSeriesRef.current.setData([
              { time: choch.time, value: choch.price },
              { time: choch.endTime, value: choch.price },
            ]);
          } else {
            chochSeriesRef.current.setData([]);
          }
        }

        if (ibosSeriesRef.current) {
          const ibos = smcAnalysis.drawings?.ibos;
          if (
            ibos &&
            isValid(ibos.time) &&
            isValid(ibos.endTime) &&
            isValid(ibos.price)
          ) {
            ibosSeriesRef.current.setData([
              { time: ibos.time, value: ibos.price },
              { time: ibos.endTime, value: ibos.price },
            ]);
          } else {
            ibosSeriesRef.current.setData([]);
          }
        }

        if (sweepSeriesRef.current) {
          const sweep = smcAnalysis.drawings?.sweep;
          if (
            sweep &&
            isValid(sweep.time) &&
            isValid(sweep.endTime) &&
            isValid(sweep.price)
          ) {
            sweepSeriesRef.current.setData([
              { time: sweep.time, value: sweep.price },
              { time: sweep.endTime, value: sweep.price },
            ]);
          } else {
            sweepSeriesRef.current.setData([]);
          }
        }

        if (sdSeriesRef.current) {
          const sd = smcAnalysis.drawings?.sd;
          if (
            sd &&
            isValid(sd.time) &&
            isValid(sd.endTime) &&
            isValid(sd.top) &&
            isValid(sd.bottom)
          ) {
            sdSeriesRef.current.applyOptions({
              baseValue: { type: "price", price: sd.bottom },
              topFillColor1:
                sd.type === "DEMAND"
                  ? "rgba(16, 185, 129, 0.15)"
                  : "rgba(239, 68, 68, 0.15)",
              topFillColor2:
                sd.type === "DEMAND"
                  ? "rgba(16, 185, 129, 0.15)"
                  : "rgba(239, 68, 68, 0.15)",
              bottomFillColor1:
                sd.type === "DEMAND"
                  ? "rgba(16, 185, 129, 0.15)"
                  : "rgba(239, 68, 68, 0.15)",
              bottomFillColor2:
                sd.type === "DEMAND"
                  ? "rgba(16, 185, 129, 0.15)"
                  : "rgba(239, 68, 68, 0.15)",
            });
            sdSeriesRef.current.setData([
              { time: sd.time, value: sd.top },
              { time: sd.endTime, value: sd.top },
            ]);
          } else {
            sdSeriesRef.current.setData([]);
          }
        }

        // Visual SNR (Support & Resistance): Clean, thin dashed horizontal lines across all timeframes (M1-D1) without rectangles
        const support = smcAnalysis.drawings?.support;
        const resistance = smcAnalysis.drawings?.resistance;

        // Clear shaded baseline rectangle fills per user request (tanpa persegi)
        if (srSeriesRef.current) {
          srSeriesRef.current.setData([]);
        }
        if (resistanceSeriesRef.current) {
          resistanceSeriesRef.current.setData([]);
        }

        // Draw Clean, Thin Dashed SNR Horizontal Price Lines (M1 - D1)
        if (seriesRef.current) {
          if (support && (support.price || support.bottom)) {
            const supVal = support.price || (support.top + support.bottom) / 2;
            if (snrSupportPriceLineRef.current) {
              try {
                seriesRef.current.removePriceLine(snrSupportPriceLineRef.current);
              } catch (e) {}
            }
            snrSupportPriceLineRef.current = seriesRef.current.createPriceLine({
              price: supVal,
              color: "#10b981",
              lineWidth: 1, // Dibuat tipis dari M1 sampai D1
              lineStyle: 2, // Garis putus-putus (Dashed)
              axisLabelVisible: true,
              title: "", // Tanpa teks yang mengganggu di canvas chart
            });
          } else if (snrSupportPriceLineRef.current) {
            try {
              seriesRef.current.removePriceLine(snrSupportPriceLineRef.current);
            } catch (e) {}
            snrSupportPriceLineRef.current = null;
          }

          if (resistance && (resistance.price || resistance.top)) {
            const resVal = resistance.price || (resistance.top + resistance.bottom) / 2;
            if (snrResistancePriceLineRef.current) {
              try {
                seriesRef.current.removePriceLine(snrResistancePriceLineRef.current);
              } catch (e) {}
            }
            snrResistancePriceLineRef.current = seriesRef.current.createPriceLine({
              price: resVal,
              color: "#ef4444",
              lineWidth: 1, // Dibuat tipis dari M1 sampai D1
              lineStyle: 2, // Garis putus-putus (Dashed)
              axisLabelVisible: true,
              title: "", // Tanpa teks yang mengganggu di canvas chart
            });
          } else if (snrResistancePriceLineRef.current) {
            try {
              seriesRef.current.removePriceLine(snrResistancePriceLineRef.current);
            } catch (e) {}
            snrResistancePriceLineRef.current = null;
          }
        }

        if (support || resistance) {
          const sP = support ? (support.price || (support.top + support.bottom) / 2) : null;
          const rP = resistance ? (resistance.price || (resistance.top + resistance.bottom) / 2) : null;
          setCurrentSnr({
            support: sP,
            resistance: rP,
            supportStrength: support?.strength || "MODERAT",
            supportTouches: support?.touches || 1,
            resistanceStrength: resistance?.strength || "MODERAT",
            resistanceTouches: resistance?.touches || 1,
            strength: (support?.strength === "SANGAT KUAT" || resistance?.strength === "SANGAT KUAT")
              ? "SANGAT KUAT"
              : (support?.strength === "KUAT" || resistance?.strength === "KUAT")
              ? "KUAT"
              : "MODERAT",
          });
        }

        if (trendlineSupportSeriesRef.current) {
          const tl = smcAnalysis.drawings?.trendlines?.support;
          if (tl && tl.p1 && tl.p2) {
            trendlineSupportSeriesRef.current.setData([
              { time: tl.p1.time, value: tl.p1.price },
              { time: tl.p2.time, value: tl.p2.price },
            ]);
          } else {
            trendlineSupportSeriesRef.current.setData([]);
          }
        }

        if (trendlineResistanceSeriesRef.current) {
          const tl = smcAnalysis.drawings?.trendlines?.resistance;
          if (tl && tl.p1 && tl.p2) {
            trendlineResistanceSeriesRef.current.setData([
              { time: tl.p1.time, value: tl.p1.price },
              { time: tl.p2.time, value: tl.p2.price },
            ]);
          } else {
            trendlineResistanceSeriesRef.current.setData([]);
          }
        }

        // Update EMA 20 (Amber), EMA 50 (Blue), and EMA 200 (Red) lines for High Probability Confluence
        if (ema20SeriesRef.current && data.length >= 20) {
          const ema20Data: { time: any; value: number }[] = [];
          const k20 = 2 / (20 + 1);
          let curr20 = data.slice(0, 20).reduce((acc, c) => acc + c.close, 0) / 20;
          for (let i = 20; i < data.length; i++) {
            curr20 = (data[i].close - curr20) * k20 + curr20;
            ema20Data.push({ time: data[i].time, value: Number(curr20.toFixed(2)) });
          }
          ema20SeriesRef.current.setData(ema20Data);
        }

        if (ema50SeriesRef.current && data.length >= 50) {
          const ema50Data: { time: any; value: number }[] = [];
          const k50 = 2 / (50 + 1);
          let curr50 = data.slice(0, 50).reduce((acc, c) => acc + c.close, 0) / 50;
          for (let i = 50; i < data.length; i++) {
            curr50 = (data[i].close - curr50) * k50 + curr50;
            ema50Data.push({ time: data[i].time, value: Number(curr50.toFixed(2)) });
          }
          ema50SeriesRef.current.setData(ema50Data);
        }

        if (ema200SeriesRef.current && data.length >= 50) {
          const ema200Data: { time: any; value: number }[] = [];
          const p200 = Math.min(200, data.length);
          const k200 = 2 / (p200 + 1);
          let curr200 = data.slice(0, p200).reduce((acc, c) => acc + c.close, 0) / p200;
          for (let i = p200; i < data.length; i++) {
            curr200 = (data[i].close - curr200) * k200 + curr200;
            ema200Data.push({ time: data[i].time, value: Number(curr200.toFixed(2)) });
          }
          ema200SeriesRef.current.setData(ema200Data);
        }

        // ZRILL AI v5.0 Indicator Suite Calculations
        const adxResult = calculateADX(highs, lows, closes, 14);
        const bollingerBands = calculateBollingerBands(closes, 20, 2);

        const macdValues: number[] = [];
        for (let i = Math.max(0, closes.length - 40); i < closes.length; i++) {
          const sub = closes.slice(0, i + 1);
          const e12 = calculateEMA(sub, 12);
          const e26 = calculateEMA(sub, 26);
          macdValues.push(e12 - e26);
        }
        const macdSignal = calculateEMA(macdValues, 9);
        const macdHistogram = macd - macdSignal;
        const macdData = {
          macd,
          signal: macdSignal,
          histogram: macdHistogram,
        };

        const currentClose = data[data.length - 1]?.close || 0;
        const classicPatterns = detectAllClassicPatterns(data, currentClose, atr);
        const activeClassicPattern = classicPatterns.length > 0 ? classicPatterns[0] : null;

        onIndicatorUpdate({
          ema20,
          sma50,
          sma200,
          ema50,
          ema200,
          macd,
          macdData,
          adx: typeof adxResult === "object" ? adxResult.adx : adxResult,
          adxDetails: adxResult,
          plusDI: typeof adxResult === "object" ? adxResult.pdi : 25,
          minusDI: typeof adxResult === "object" ? adxResult.mdi : 25,
          bollingerBands,
          stochK,
          stochD,
          prevClose,
          rsi,
          atr,
          rsiDivergence,
          pattern,
          smc: smcAnalysis.state,
          smcDrawings: smcAnalysis.drawings,
          classicPatterns,
          activeClassicPattern,
          supportResistance: {
            support: smcAnalysis.drawings?.support,
            resistance: smcAnalysis.drawings?.resistance,
          },
        });
      };

      if (smcWorkerRef.current) {
        smcWorkerRef.current.onmessage = (e: MessageEvent) => {
          if (e.data && e.data.result) {
            applySmcResults(e.data.result);
          }
        };
        smcWorkerRef.current.postMessage({ id: Date.now(), data });
      } else {
        const smcAnalysis = analyzeSMC(data);
        applySmcResults(smcAnalysis);
      }
    };

    updateIndicatorsRef.current = updateIndicators;

    const fetchHistoricalAndConnectWS = async () => {
      const generateSyntheticHistory = () => {
        const seconds = getTimeframeSeconds(timeframe.id);
        const now = Math.floor(Date.now() / 1000);
        const startTime = now - 300 * seconds;
        const data = [];
        let currentPrice = symbol.basePrice || (symbol.id === "BTCUSD" ? 77500.0 : 4430.0);
        const vol = symbol.id === "BTCUSD" ? 12.0 : 0.4;

        for (let i = 0; i < 300; i++) {
          const time = startTime + i * seconds;
          const open = currentPrice;
          const change =
            (Math.random() - 0.495) * vol * Math.sqrt(seconds / 60);
          const close = currentPrice + change;
          const high = Math.max(open, close) + Math.random() * vol * 0.4;
          const low = Math.min(open, close) - Math.random() * vol * 0.4;

          data.push({
            time: time as any,
            open: Number(open.toFixed(2)),
            high: Number(high.toFixed(2)),
            low: Number(low.toFixed(2)),
            close: Number(close.toFixed(2)),
          });
          currentPrice = close;
        }

        candleData = data;
        candlestickSeries.setData(candleData);
        currentTickPrice = candleData[candleData.length - 1].close;
        targetTickPrice = currentTickPrice;
        targetTickAnchor = currentTickPrice;

        const spread = symbol.id === "BTCUSD" ? 0.5 : 0.15;
        onPriceUpdate({
          bid: Number((currentTickPrice - spread / 2).toFixed(2)),
          ask: Number((currentTickPrice + spread / 2).toFixed(2)),
        });
        updateIndicators(candleData);
      };

      try {
        // --- DATA LAZY-LOADING FOR 3X FASTER SYMBOL SWITCHING ---
        // Step 1: Fetch a light 40-candle batch for nearly instant first-paint
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4500);

        const res = await fetch(
          getKlinesUrl(symbol.id, symbol.binanceSymbol, timeframe.binance, 40),
          { signal: controller.signal },
        );
        clearTimeout(timeoutId);
        const firstPaintData = await res.json();

        if (!isMounted) return;

        let processedData = firstPaintData
          .map((d: any) => ({
            time: (d[0] / 1000) as any,
            open: parseFloat(d[1]),
            high: parseFloat(d[2]),
            low: parseFloat(d[3]),
            close: parseFloat(d[4]),
            volume: parseFloat(d[5] || "0"),
          }))
          .filter(
            (d: any) =>
              isValid(d.time) &&
              isValid(d.open) &&
              isValid(d.high) &&
              isValid(d.low) &&
              isValid(d.close) &&
              d.open > 0 &&
              d.close > 0
          );

        if (symbol.id === "XAUUSD") {
          const weekdayCandles = processedData.filter((d: any) => {
            const date = new Date(d.time * 1000);
            const day = date.getUTCDay();
            const hour = date.getUTCHours();
            // Allow all days except Saturday (6) and Sunday before market open (Sunday < 21:00 UTC)
            if (day === 6) return false;
            if (day === 0 && hour < 21) return false;
            return true;
          });
          if (weekdayCandles.length >= 25) {
            processedData = weekdayCandles;
          }
        }

        candleData = sanitizeCandles(processedData);
        if (candleData.length === 0) {
          generateSyntheticHistory();
        } else {
          candlestickSeries.setData(candleData);
          currentTickPrice = candleData[candleData.length - 1].close;
          targetTickPrice = currentTickPrice;
          targetTickAnchor = currentTickPrice;
          lastUpdatedCandleTime = candleData[candleData.length - 1].time;
          const spread = symbol.id === "BTCUSD" ? 0.5 : 0.15;
          onPriceUpdate({
            bid: Number((currentTickPrice - spread / 2).toFixed(2)),
            ask: Number((currentTickPrice + spread / 2).toFixed(2)),
          });
          updateIndicators(candleData);
        }

        // Step 2: Lazy-load remaining deep history (300 candles) asynchronously in background
        (async () => {
          try {
            const bgRes = await fetch(
              getKlinesUrl(symbol.id, symbol.binanceSymbol, timeframe.binance, 300)
            );
            const deepData = await bgRes.json();

            if (!isMounted) return;

            let processedDeepData = deepData
              .map((d: any) => ({
                time: (d[0] / 1000) as any,
                open: parseFloat(d[1]),
                high: parseFloat(d[2]),
                low: parseFloat(d[3]),
                close: parseFloat(d[4]),
                volume: parseFloat(d[5] || "0"),
              }))
              .filter(
                (d: any) =>
                  isValid(d.time) &&
                  isValid(d.open) &&
                  isValid(d.high) &&
                  isValid(d.low) &&
                  isValid(d.close) &&
                  d.open > 0 &&
                  d.close > 0
              );

            if (symbol.id === "XAUUSD") {
              const weekdayCandles = processedDeepData.filter((d: any) => {
                const date = new Date(d.time * 1000);
                const day = date.getUTCDay();
                const hour = date.getUTCHours();
                // Allow all days except Saturday (6) and Sunday before market open (Sunday < 21:00 UTC)
                if (day === 6) return false;
                if (day === 0 && hour < 21) return false;
                return true;
              });
              if (weekdayCandles.length >= 25) {
                processedDeepData = weekdayCandles;
              }
            }

            const cleanDeep = sanitizeCandles(processedDeepData);
            if (cleanDeep.length > 0) {
              candleData = cleanDeep;
              candlestickSeries.setData(candleData);
              currentTickPrice = candleData[candleData.length - 1].close;
              targetTickPrice = currentTickPrice;
              targetTickAnchor = currentTickPrice;
              lastUpdatedCandleTime = candleData[candleData.length - 1].time;
              updateIndicators(candleData);
            }
          } catch (e) {
            console.warn("Background klines lazy loading skipped:", e);
          }
        })();

        // Unified TradingView MCP Live Synchronization Engine
        onStatusUpdate(`TRADINGVIEW MCP LIVE • ${timeframe.id} SYNC`);
        
        yahooInterval = setInterval(async () => {
          if (!isMounted) return;
          try {
            const res = await fetch(`/api/tradingview/price?symbol=${symbol.id}`);
            const data = await res.json();
            
            if (data && data.price > 0) {
              const livePrice = Number(data.price.toFixed(2));
              targetTickPrice = livePrice;
              targetTickAnchor = livePrice;
              lastWsMessageTime = Date.now();

              // Snap immediately if uninitialized or if divergent (>1.5% gap)
              if (currentTickPrice === 0 || Math.abs(livePrice - currentTickPrice) / (currentTickPrice || 1) > 0.015) {
                currentTickPrice = livePrice;
                if (candleData.length > 0) {
                  const lastC = candleData[candleData.length - 1];
                  lastC.close = livePrice;
                  lastC.high = Math.max(lastC.high, livePrice);
                  lastC.low = Math.min(lastC.low, livePrice);
                  try {
                    candlestickSeries.update(lastC);
                  } catch (e) {}
                }
              }

              // Update live bid/ask with spread
              const spread = symbol.id === "BTCUSD" ? 0.5 : 0.15;
              const bidVal = data.bid && data.bid > 0 ? data.bid : livePrice - spread / 2;
              const askVal = data.ask && data.ask > 0 ? data.ask : livePrice + spread / 2;
              onPriceUpdate({
                bid: Number(bidVal.toFixed(2)),
                ask: Number(askVal.toFixed(2)),
              });
            }
          } catch (e) {
            console.warn("TradingView price polling failed:", e);
          }
        }, 1000);
      } catch (error) {
        if (!isMounted) return;
        console.warn(
          "Data connection failed, loading real-time synthetic simulation...",
          error,
        );
        onStatusUpdate("TRADINGVIEW MCP LIVE SYNC (SYNTHETIC)");
        generateSyntheticHistory();
      }
    };

    fetchHistoricalAndConnectWS();

    let animationFrameId: number;
    let lastDrlUpdate = 0;

    const tickLoop = () => {
      if (!isMounted) return;

      if (incomingCandlesRef.current) {
        candleData = sanitizeCandles(incomingCandlesRef.current);
        incomingCandlesRef.current = null;
        if (candlestickSeries && candleData.length > 0) {
          candlestickSeries.setData(candleData);
          currentTickPrice = candleData[candleData.length - 1].close;
          targetTickPrice = currentTickPrice;
          lastUpdatedCandleTime = candleData[candleData.length - 1].time;
          updateIndicators(candleData);
        }
      }

      if (candleData.length === 0) {
        animationFrameId = requestAnimationFrame(tickLoop);
        return;
      }

      const nowMs = Date.now() + globalServerTimeOffset;
      const marketClosedInfo = getMarketClosedStatus(symbol.id, nowMs);
      const isMarketClosed = marketClosedInfo.isClosed;
      const isSimulating = nowMs - lastWsMessageTime > 30000 && !isMarketClosed;

      // Real-time automatic walk for seamless candle ticks when live feed is slow
      if (isSimulating && !isMarketClosed && targetTickAnchor > 0) {
        const isBtc = symbol.id === "BTCUSD";
        const walkDelta = (Math.random() - 0.495) * (isBtc ? 2.2 : 0.05);
        targetTickAnchor += walkDelta;
      }

      // Institutional MT5/TradingView Sub-Second Micro-Tick Flow
      // Generates continuous organic micro-movements and dynamic wick action between 1-second server quotes
      if (!isMarketClosed && targetTickAnchor > 0) {
        const nowPerf = performance.now();
        const microInterval = timeframe.id === "M15" ? 200 : timeframe.id === "M30" ? 300 : 450;
        if (nowPerf - lastMicroTickTime > microInterval) {
          lastMicroTickTime = nowPerf;
          const isBtc = symbol.id === "BTCUSD";
          // Micro Brownian oscillation around live TradingView anchor
          const microDelta = (Math.random() - 0.495) * (isBtc ? 1.4 : 0.038);
          targetTickPrice = targetTickAnchor + microDelta;
        }
      }

      // Transition to new candle boundary strictly aligned with timeframe interval
      const activeCandle = candleData[candleData.length - 1];
      const intervalSec = getTimeframeSeconds(timeframe.id);
      const currentSec = Math.floor(nowMs / 1000);
      const currentPeriodStart = Math.floor(currentSec / intervalSec) * intervalSec;

      if (activeCandle) {
        // Self-healing clock sync if local clock falls behind historical server candles
        if (activeCandle.time * 1000 > nowMs) {
          globalServerTimeOffset = (activeCandle.time * 1000) - Date.now() + 1000;
        }

        // Ultra-Smooth 120Hz Price Interpolation (LERP) for tick-by-tick micro-movements
        if (!isMarketClosed) {
          const priceDiff = targetTickPrice - currentTickPrice;
          if (Math.abs(priceDiff) > 0.000001) {
            // Large jump protection (>0.8% gap, e.g. symbol switch / reconnect): snap immediately
            if (currentTickPrice > 0 && Math.abs(priceDiff) / currentTickPrice > 0.008) {
              currentTickPrice = targetTickPrice;
            } else {
              // Smooth lerp factor (0.28 per 120Hz frame) for silky fluid price & wick movement
              const lerpFactor = 0.28;
              currentTickPrice += priceDiff * lerpFactor;
              if (Math.abs(targetTickPrice - currentTickPrice) < 0.00001) {
                currentTickPrice = targetTickPrice;
              }
            }
          }
        }

        // Prevent mega-spike gap bugs: If currentTickPrice jumps by >1.2% from activeCandle.open, resync activeCandle to currentTickPrice
        if (activeCandle.open > 0 && Math.abs(currentTickPrice - activeCandle.open) / activeCandle.open > 0.012) {
          activeCandle.open = currentTickPrice;
          activeCandle.high = currentTickPrice;
          activeCandle.low = currentTickPrice;
          activeCandle.close = currentTickPrice;
        }

        if (currentPeriodStart > activeCandle.time && !isMarketClosed) {
          // Zero-gap seamless candle transition matching authentic MT5 / TradingView behavior
          const prevClose = activeCandle.close;
          const nextCandle = {
            time: currentPeriodStart as any,
            open: currentTickPrice > 0 ? currentTickPrice : prevClose,
            high: currentTickPrice > 0 ? currentTickPrice : prevClose,
            low: currentTickPrice > 0 ? currentTickPrice : prevClose,
            close: currentTickPrice > 0 ? currentTickPrice : prevClose,
            volume: 1,
          };
          if (candleData.length > 1000) candleData.splice(0, candleData.length - 1000);
          candleData.push(nextCandle);
        } else if (!isMarketClosed) {
          // Update active candle with realistic wick expansion & tick volume
          activeCandle.close = currentTickPrice;
          activeCandle.high = Math.max(activeCandle.high, currentTickPrice);
          activeCandle.low = Math.min(activeCandle.low, currentTickPrice);
          activeCandle.volume = (activeCandle.volume || 1) + 1;
        }
      }

      const updatedActiveCandle = candleData[candleData.length - 1];
      const candleChanged = updatedActiveCandle && updatedActiveCandle.time !== lastUpdatedCandleTime;

      // Anti-Lag Optimization: Only update the chart and run calculations if the price actually changed or a new candle appeared
      if ((currentTickPrice !== previousTickPrice || candleChanged) && currentTickPrice > 0) {
        previousTickPrice = currentTickPrice;
        if (updatedActiveCandle) lastUpdatedCandleTime = updatedActiveCandle.time;

        if (updatedActiveCandle) {
          try {
            candlestickSeries.update(updatedActiveCandle);
            if (candleChanged) {
              updateIndicators(candleData);
            }
            if (!isLowSpecMode && drlHeatmapSeriesRef.current && (Date.now() - lastDrlUpdate > 2000)) {
              lastDrlUpdate = Date.now();
              drlHeatmapSeriesRef.current.update({
                time: updatedActiveCandle.time,
                value: updatedActiveCandle.close,
              });
            }
          } catch (e) {}
        }

        // Adaptive reactive price updates for React UI: ~100ms standard, ~200ms low-spec
        // Keeps lightweight-charts canvas interpolating at full 60-120fps while liberating main-thread CPU
        const reactThrottleInterval = isLowSpecMode ? 200 : 100;
        if (nowMs - lastReactUpdate > reactThrottleInterval) {
          const spread = symbol.id === "BTCUSD" ? 0.5 : 0.15;
          onPriceUpdate({
            bid: currentTickPrice - spread / 2,
            ask: currentTickPrice + spread / 2,
          });
          lastReactUpdate = nowMs;
        }
      }

      // Continuous periodic indicator updates removed to prevent lag and choppiness.
      // Indicators are now only scanned and updated during initial loads and on-demand signal analysis.

      animationFrameId = requestAnimationFrame(tickLoop);
    };

    // Begin the 120fps animation loop
    animationFrameId = requestAnimationFrame(tickLoop);

    return () => {
      isMounted = false;
      setIsChartReady(false);
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
      if (ws) ws.close();
      if (mt5Ws) mt5Ws.close();
      if (fastWs) fastWs.close();
      if (yahooInterval) clearInterval(yahooInterval);
      chart.remove();
    };
  }, [chartContainer, symbol, timeframe, priceOffset]);

  return (
    <div className="relative w-full h-full">
      <div ref={setChartContainer} className="w-full h-full" />

      {/* On-Chart Live Dynamic SNR (Support & Resistance) HUD positioned at BOTTOM-LEFT of chart */}
      {currentSnr && (currentSnr.support || currentSnr.resistance) && (
        <div className="absolute bottom-8 left-3 z-20 pointer-events-none flex flex-wrap items-center gap-1.5 bg-[#0a0d14]/40 backdrop-blur-sm border border-cyan-500/20 px-2.5 py-1 rounded-lg text-[9px] font-mono shadow-md select-none opacity-80 hover:opacity-100 transition-opacity">
          <div className="flex items-center gap-1 text-cyan-400 font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <span>SNR {timeframe.id}:</span>
          </div>
          {currentSnr.support && (
            <div className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 font-medium">
              <span>SUP:</span>
              <span className="text-white font-bold">${currentSnr.support.toFixed(2)}</span>
              <span className={`text-[8px] px-1 rounded font-bold ${currentSnr.supportStrength === "SANGAT KUAT" ? "bg-emerald-500/25 text-emerald-200" : "bg-emerald-500/10 text-emerald-300"}`}>
                {currentSnr.supportStrength || "MODERAT"} ({currentSnr.supportTouches || 1}x)
              </span>
            </div>
          )}
          {currentSnr.resistance && (
            <div className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-rose-500/10 border border-rose-500/20 text-rose-300 font-medium">
              <span>RES:</span>
              <span className="text-white font-bold">${currentSnr.resistance.toFixed(2)}</span>
              <span className={`text-[8px] px-1 rounded font-bold ${currentSnr.resistanceStrength === "SANGAT KUAT" ? "bg-rose-500/25 text-rose-200" : "bg-rose-500/10 text-rose-300"}`}>
                {currentSnr.resistanceStrength || "MODERAT"} ({currentSnr.resistanceTouches || 1}x)
              </span>
            </div>
          )}
          {(currentSignal?.candleVolLabel || currentSignal?.zrillV5Core?.candleVolLabel) && (
            <div className={`flex items-center gap-1 px-1.5 py-0.5 rounded border text-[8px] font-bold ${
              (currentSignal?.candleVolSignal || currentSignal?.zrillV5Core?.candleVolSignal) === "VOLUME_CONTINUATION"
                ? "bg-emerald-500/20 border-emerald-500/30 text-emerald-300"
                : (currentSignal?.candleVolSignal || currentSignal?.zrillV5Core?.candleVolSignal) === "VOLUME_REVERSAL"
                ? "bg-purple-500/20 border-purple-500/30 text-purple-300"
                : "bg-gray-800/40 border-gray-700/30 text-gray-300"
            }`}>
              <span>{currentSignal?.candleVolLabel || currentSignal?.zrillV5Core?.candleVolLabel}</span>
            </div>
          )}
        </div>
      )}

      {/* Segel Resmi Close Market Overlay (Sabtu & Minggu untuk Gold & Forex) */}
      {(() => {
        const closedInfo = getMarketClosedStatus(symbol.id);
        if (!closedInfo.isClosed) return null;

        if (isSegelMinimized) {
          return (
            <div className="absolute top-3 right-3 z-40 pointer-events-auto">
              <button
                onClick={() => setIsSegelMinimized(false)}
                className="px-3.5 py-2 rounded-xl bg-[#12151e]/90 hover:bg-[#1a1f2c] text-amber-300 border border-amber-500/40 backdrop-blur-xl shadow-[0_4px_20px_rgba(0,0,0,0.6)] text-[11px] font-mono font-bold flex items-center gap-2.5 cursor-pointer transition-all hover:scale-105 active:scale-95"
              >
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                <span className="font-sans font-bold tracking-wider text-white">MARKET CLOSED</span>
                <span className="text-gray-500">|</span>
                <span className="text-amber-300 font-extrabold">{closedInfo.countdownStr}</span>
                <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
              </button>
            </div>
          );
        }

        const pad = (num?: number) => (num ?? 0).toString().padStart(2, "0");

        return (
          <div className="absolute inset-0 z-40 bg-abyss/80 backdrop-blur-sm flex items-center justify-center p-4 text-center pointer-events-auto">
            <div className="w-full max-w-md bg-panel border border-line rounded-2xl p-6 shadow-[0_24px_60px_rgba(0,0,0,0.6)]">
              <h3 className="font-display text-[20px] font-semibold text-text">Pasar {symbol.id} sedang tutup</h3>
              <p className="text-[13.5px] text-mute mt-1">Buka lagi {closedInfo.witaReopenStr}. Harga dibekukan sampai pasar buka.</p>
              <div className="grid grid-cols-4 gap-2 mt-5" role="timer" aria-label="Hitung mundur pasar buka">
                {[["hari", closedInfo.days], ["jam", closedInfo.hours], ["menit", closedInfo.mins], ["detik", closedInfo.secs]].map(([l, v]) => (
                  <div key={String(l)} className="bg-abyss border border-line rounded-xl py-3">
                    <div className="num font-display text-[26px] font-semibold text-gold leading-none">{pad(v as number)}</div>
                    <div className="text-[12px] text-faint mt-1.5">{l}</div>
                  </div>
                ))}
              </div>
              <div className="flex flex-col sm:flex-row gap-2 mt-5">
                {onSelectSymbol && (
                  <button
                    onClick={() => onSelectSymbol({ id: "BTCUSD", name: "BITCOIN", basePrice: 77500.0, binanceSymbol: "BTCUSDT" })}
                    className="flex-1 h-10 rounded-xl bg-jade text-[#04140d] font-semibold text-[13.5px] cursor-pointer"
                  >
                    Pindah ke BTCUSD (24 jam)
                  </button>
                )}
                <button onClick={() => setIsSegelMinimized(true)} className="flex-1 h-10 rounded-xl bg-raised border border-line text-text font-medium text-[13.5px] cursor-pointer">
                  Lihat chart terakhir
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Active RSI Divergence Alert Overlay Banner */}
      {activeDivergence && !isDivergenceDismissed && (
        isDivergenceMinimized ? (
          <div className="absolute top-3 left-3 z-30 flex items-center gap-1.5 pointer-events-auto">
            <button
              onClick={() => setIsDivergenceMinimized(false)}
              className={`px-2.5 py-1 rounded-lg border backdrop-blur-md shadow-lg flex items-center gap-1.5 text-[10px] font-mono font-bold transition-all cursor-pointer ${
                activeDivergence.type === "BEARISH_DIVERGENCE"
                  ? "bg-rose-950/90 border-rose-500/50 text-rose-200 hover:bg-rose-900/90 shadow-[0_0_15px_rgba(244,63,94,0.3)]"
                  : "bg-emerald-950/90 border-emerald-500/50 text-emerald-200 hover:bg-emerald-900/90 shadow-[0_0_15px_rgba(16,185,129,0.3)]"
              }`}
            >
              <AlertTriangle className="w-3 h-3 text-amber-400 animate-bounce" />
              <span>POTENSI REVERSAL ({activeDivergence.type === "BEARISH_DIVERGENCE" ? "SELL" : "BUY"})</span>
              <ChevronDown className="w-3 h-3" />
            </button>
            <button
              onClick={() => setIsDivergenceDismissed(true)}
              title="Tutup Alert Reversal"
              className="p-1 rounded-lg bg-black/70 hover:bg-black text-gray-400 hover:text-white border border-white/10 text-[10px] font-mono cursor-pointer transition-all"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ) : (
          <div className="absolute top-14 left-3 right-3 sm:right-auto sm:max-w-md z-30 pointer-events-auto">
            <div className={`p-2.5 rounded-xl border backdrop-blur-xl shadow-2xl flex flex-col gap-1.5 transition-all ${
              activeDivergence.type === "BEARISH_DIVERGENCE"
                ? "bg-rose-950/85 border-rose-500/50 text-rose-100 shadow-[0_0_20px_rgba(244,63,94,0.3)]"
                : "bg-emerald-950/85 border-emerald-500/50 text-emerald-100 shadow-[0_0_20px_rgba(16,185,129,0.3)]"
            }`}>
              <div className="flex items-center justify-between border-b border-white/10 pb-1">
                <span className="text-[11px] font-black font-mono tracking-wider uppercase flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
                  {activeDivergence.title}
                </span>
                <div className="flex items-center gap-1.5">
                  <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-black/50 border border-white/10">
                    RSI: {activeDivergence.rsi2} vs {activeDivergence.rsi1}
                  </span>
                  <button
                    onClick={() => setIsDivergenceMinimized(true)}
                    title="Minimize Alert Reversal"
                    className="p-1 rounded-md bg-white/10 hover:bg-white/20 text-gray-200 hover:text-white transition-all cursor-pointer"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => setIsDivergenceDismissed(true)}
                    title="Tutup / Dismiss Alert Reversal"
                    className="p-1 rounded-md bg-white/10 hover:bg-white/20 text-gray-200 hover:text-white transition-all cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              </div>
              <p className="text-[10px] leading-tight opacity-90">
                {activeDivergence.description}
              </p>
            </div>
          </div>
        )
      )}

      {/* Divergence banner if active */}

      {hoveredMarker && (hoveredMarker.candle || hoveredMarker.marker) && (
        <div
          className="absolute z-50 bg-[#1A1D24]/95 backdrop-blur-md border border-gray-700/60 p-3 rounded-lg shadow-2xl pointer-events-none min-w-[160px]"
          style={{
            left: tooltipPos.x + 15,
            top: tooltipPos.y - 40,
            transform: "translateY(-50%)",
          }}
        >
          {hoveredMarker.candle && (
            <div className={`space-y-1 ${hoveredMarker.marker ? "mb-2 pb-2 border-b border-gray-700/50" : ""}`}>
              <div className="flex justify-between text-[10px] gap-4">
                <span className="text-gray-400">O:</span>
                <span className={`font-mono font-bold ${hoveredMarker.candle.close >= hoveredMarker.candle.open ? 'text-emerald-400' : 'text-rose-400'}`}>{hoveredMarker.candle.open.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[10px] gap-4">
                <span className="text-gray-400">H:</span>
                <span className="font-mono font-bold text-gray-200">{hoveredMarker.candle.high.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[10px] gap-4">
                <span className="text-gray-400">L:</span>
                <span className="font-mono font-bold text-gray-200">{hoveredMarker.candle.low.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[10px] gap-4">
                <span className="text-gray-400">C:</span>
                <span className={`font-mono font-bold ${hoveredMarker.candle.close >= hoveredMarker.candle.open ? 'text-emerald-400' : 'text-rose-400'}`}>{hoveredMarker.candle.close.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[10px] gap-4">
                <span className="text-gray-400">Vol:</span>
                <span className="font-mono font-bold text-indigo-300">{hoveredMarker.candle.volume?.toFixed(2) || "0.00"}</span>
              </div>
            </div>
          )}
          {hoveredMarker.marker && (
            <div>
              <div className="flex items-center gap-2 mb-1">
                <div
                  className="w-2 h-2 rounded-full shadow-[0_0_5px_currentColor]"
                  style={{ backgroundColor: hoveredMarker.marker.color, color: hoveredMarker.marker.color }}
                ></div>
                <span className="text-[10px] font-bold text-white uppercase tracking-wider">
                  {hoveredMarker.marker.text}
                </span>
              </div>
              <p className="text-[10px] text-gray-400 leading-relaxed max-w-[200px]">
                {hoveredMarker.marker.tooltip}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
});
