import { useState } from "react";
import { useT } from "../TerminalContext";
import { buildSignalView } from "../lib/signal";
import { TradeLadder } from "./TradeLadder";
import { Badge, Button, Empty } from "./kit";
import { Icon } from "./Icon";
import { copyToClipboardSafely } from "../TerminalCore";
import { cx, fmtPrice } from "../lib/format";

export function useSignalView() {
  const T = useT();
  return buildSignalView(T.currentSignal, T.hasValidSignal);
}

/** Tombol analisis + indikator tahap berpikir. */
export function AnalyzeButton({ size = "md", className }: { size?: "sm" | "md" | "lg"; className?: string }) {
  const T = useT();
  const noPrice = !(T.currentPrice.bid > 0);
  return (
    <Button
      variant="primary"
      size={size}
      icon="zap"
      className={className}
      loading={T.isGeneratingSignal}
      disabled={noPrice}
      onClick={T.handleManualGenerateSignal}
      title={noPrice ? "Menunggu harga live pertama" : undefined}
    >
      {T.isGeneratingSignal ? "Menganalisis…" : noPrice ? "Menunggu harga live" : "Analisis sekarang"}
    </Button>
  );
}

export function ThinkingBar() {
  const T = useT();
  if (!T.isGeneratingSignal) return null;
  return (
    <div className="mt-3" role="status" aria-live="polite">
      <div className="flex gap-1">
        {[1, 2, 3, 4].map((i) => (
          <span key={i} className={cx("h-1 flex-1 rounded-full transition-colors", i <= T.aiThinkingStage ? "bg-jade" : "bg-line")} />
        ))}
      </div>
      <p className="text-[12.5px] text-mute mt-2 leading-snug">{T.aiThinkingMessage}</p>
    </div>
  );
}

export function signalText(T: ReturnType<typeof useT>, v: ReturnType<typeof buildSignalView>) {
  const id = T.activeSymbol.id;
  const lines = [
    `${id} ${T.activeTimeframe.id} · ${v.action.toUpperCase()}`,
    `Entry: ${fmtPrice(v.entry)}`,
    `SL: ${fmtPrice(v.sl)}`,
    ...v.tps.map((t) => `${t.label}: ${fmtPrice(t.price)}`),
    v.rrNum ? `RR ke target akhir: 1:${v.rrNum.toFixed(1)}` : "",
    "Bukan jaminan hasil. Atur risiko per transaksi.",
  ];
  return lines.filter(Boolean).join("\n");
}

export default function SignalTicket({ compact = false }: { compact?: boolean }) {
  const T = useT();
  const v = useSignalView();
  const [copied, setCopied] = useState(false);
  const price = T.currentPrice.bid;
  const id = T.activeSymbol.id;

  if (!v.isLive) {
    return (
      <div className="surface">
        <Empty
          icon="target"
          title="Belum ada setup aktif"
          action={<AnalyzeButton />}
        >
          Jalankan analisis untuk {id} di {T.activeTimeframe.id}. Hasilnya berupa entry, stop loss, dan target.
        </Empty>
        <div className="px-5 pb-4"><ThinkingBar /></div>
      </div>
    );
  }

  const tone = v.side === "BUY" ? "jade" : v.side === "SELL" ? "coral" : "mute";
  const copy = async () => {
    const ok = await copyToClipboardSafely(signalText(T, v));
    setCopied(ok);
    setTimeout(() => setCopied(false), 1800);
  };
  const ts = v.raw.timestamp ? new Date(v.raw.timestamp) : null;

  return (
    <section className="surface overflow-hidden">
      <div className={cx("h-[3px]", v.side === "BUY" ? "bg-jade" : v.side === "SELL" ? "bg-coral" : "bg-line")} />
      <div className="p-4 sm:p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge tone={tone as any}><Icon name={v.side === "BUY" ? "arrowUp" : "arrowDown"} size={12} />{v.action}</Badge>
              <span className="text-[13px] text-mute">{id} · {v.raw.timeframe || T.activeTimeframe.id}</span>
            </div>
            <p className="text-[12.5px] text-faint mt-1.5">
              Dianalisis{ts ? ` pukul ${ts.toLocaleTimeString("id-ID", { timeZone: "Asia/Makassar", hour: "2-digit", minute: "2-digit" }).replace(".", ":")} WITA` : ""}
            </p>
          </div>
          <div className="text-right shrink-0">
            <div className="text-[12px] text-mute">Reward : risk</div>
            <div className="num font-display text-[24px] font-semibold leading-none mt-0.5">{v.rrNum ? `1 : ${v.rrNum.toFixed(1)}` : "—"}</div>
          </div>
        </div>

        <div className="mt-4">
          <TradeLadder view={v} price={price} symbolId={id} height={compact ? 250 : 290} />
        </div>

        {v.isLimit && (
          <p className="text-[12.5px] text-gold mt-3 flex gap-2"><Icon name="hourglass" size={15} className="shrink-0 mt-0.5" /> Order limit: tunggu harga kembali ke zona entry, jangan kejar harga.</p>
        )}

        <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-line text-[12.5px]">
          <div><div className="text-faint">Jarak SL</div><div className="num font-medium text-[14px] mt-0.5">{fmtPrice(v.riskDist)}</div></div>
          <div><div className="text-faint">Konfluensi</div><div className="num font-medium text-[14px] mt-0.5">{v.total ? `${v.passed} dari ${v.total}` : "—"}</div></div>
          <div><div className="text-faint">Status</div><div className="font-medium text-[14px] mt-0.5">{v.raw.status === "ACTIVE" ? "Berjalan" : v.raw.status === "HIT_TP" ? "TP tercapai" : v.raw.status === "HIT_SL" ? "SL tersentuh" : "Menunggu"}</div></div>
        </div>

        {!compact && (
          <div className="flex gap-2 mt-4">
            <Button variant="soft" size="sm" icon={copied ? "check" : "copy"} onClick={copy} className="flex-1">{copied ? "Tersalin" : "Salin sinyal"}</Button>
            <Button variant="soft" size="sm" icon="book" onClick={T.handleSaveSnapshotToJournal} className="flex-1">Simpan ke jurnal</Button>
          </div>
        )}
        <div className="mt-3"><ThinkingBar /></div>
      </div>
    </section>
  );
}
