import { useMemo } from "react";
import type { SignalView } from "../lib/signal";
import { fmtPrice, cx } from "../lib/format";

/**
 * Tangga harga: semua level ditempatkan proporsional pada satu rel vertikal.
 * Label didorong menjauh bila terlalu dekat, dengan garis penghubung ke posisi asli.
 */
export function TradeLadder({ view, price, symbolId, height = 300 }: { view: SignalView; price: number; symbolId: string; height?: number }) {
  const levels = useMemo(() => {
    const L: { key: string; label: string; price: number; tone: "jade" | "coral" | "gold" }[] = [];
    view.tps.forEach((t) => L.push({ key: t.label, label: t.label, price: t.price, tone: "jade" }));
    if (view.entry > 0) L.push({ key: "ENTRY", label: "Entry", price: view.entry, tone: "gold" });
    if (view.sl > 0) L.push({ key: "SL", label: "Stop loss", price: view.sl, tone: "coral" });
    return L;
  }, [view]);

  if (levels.length < 2) return null;

  const all = [...levels.map((l) => l.price), ...(price > 0 ? [price] : [])];
  const hi = Math.max(...all), lo = Math.min(...all);
  const pad = (hi - lo) * 0.06 || 1;
  const top = hi + pad, bot = lo - pad;
  const PAD_Y = 14;
  const H = height - PAD_Y * 2;
  const yOf = (p: number) => PAD_Y + ((top - p) / (top - bot)) * H;

  // Relaksasi label
  const GAP = 30;
  const sorted = levels.map((l) => ({ ...l, y: yOf(l.price), ly: yOf(l.price) })).sort((a, b) => a.y - b.y);
  for (let i = 1; i < sorted.length; i++) sorted[i].ly = Math.max(sorted[i].ly, sorted[i - 1].ly + GAP);
  const overflow = sorted[sorted.length - 1].ly - (height - PAD_Y);
  if (overflow > 0) {
    sorted[sorted.length - 1].ly -= overflow;
    for (let i = sorted.length - 2; i >= 0; i--) sorted[i].ly = Math.min(sorted[i].ly, sorted[i + 1].ly - GAP);
  }

  const entryY = view.entry > 0 ? yOf(view.entry) : yOf((hi + lo) / 2);
  const slY = view.sl > 0 ? yOf(view.sl) : height;
  const farY = yOf(view.tps[view.tps.length - 1]?.price ?? view.entry);
  const col = { jade: "var(--color-jade)", coral: "var(--color-coral)", gold: "var(--color-gold)" };
  const priceY = price > 0 ? yOf(price) : null;
  const TRACK_X = 14;

  return (
    <div className="relative w-full" style={{ height }}>
      <svg className="absolute inset-0 w-full h-full overflow-visible" aria-hidden="true">
        {/* zona profit & loss */}
        <rect x={TRACK_X - 4} width="8" y={Math.min(entryY, farY)} height={Math.abs(farY - entryY)} rx="4" fill="var(--color-jade)" opacity="0.22" />
        <rect x={TRACK_X - 4} width="8" y={Math.min(entryY, slY)} height={Math.abs(slY - entryY)} rx="4" fill="var(--color-coral)" opacity="0.22" />
        {sorted.map((l) => (
          <g key={l.key}>
            <path d={`M ${TRACK_X + 6} ${l.y} H ${TRACK_X + 26} L ${TRACK_X + 38} ${l.ly}`} fill="none" stroke={col[l.tone]} strokeWidth="1" opacity="0.55" />
            <circle cx={TRACK_X} cy={l.y} r="4.5" fill="var(--color-panel)" stroke={col[l.tone]} strokeWidth="2" />
          </g>
        ))}
        {priceY !== null && (
          <g>
            <line x1="0" x2="30" y1={priceY} y2={priceY} stroke="var(--color-text)" strokeWidth="1.5" />
            <polygon points={`${TRACK_X + 11},${priceY} ${TRACK_X + 18},${priceY - 4} ${TRACK_X + 18},${priceY + 4}`} fill="var(--color-text)" />
          </g>
        )}
      </svg>
      {sorted.map((l) => (
        <div key={l.key} className="absolute left-[56px] right-0 -translate-y-1/2 flex items-baseline justify-between gap-3" style={{ top: l.ly }}>
          <span className={cx("text-[12.5px] font-medium", l.tone === "jade" ? "text-jade" : l.tone === "coral" ? "text-coral" : "text-gold")}>{l.label}</span>
          <span className="num text-[15px] font-semibold text-text">{fmtPrice(l.price, symbolId)}</span>
        </div>
      ))}
      {priceY !== null && (
        <div className="absolute left-0 -translate-y-1/2 text-[10.5px] text-text bg-raised border border-line rounded px-1 leading-4" style={{ top: priceY - 12 }}>
          kini
        </div>
      )}
    </div>
  );
}
