import React, { useEffect, useRef } from "react";
import { Icon, IconName } from "./Icon";
import { cx } from "../lib/format";

/* ---------- Button ---------- */
type BtnProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost" | "soft" | "danger";
  size?: "sm" | "md" | "lg";
  icon?: IconName;
  loading?: boolean;
};
export function Button({ variant = "soft", size = "md", icon, loading, className, children, disabled, ...rest }: BtnProps) {
  const base =
    "inline-flex items-center justify-center gap-2 font-medium rounded-xl transition-[background,transform,opacity] duration-150 active:scale-[0.98] disabled:opacity-45 disabled:pointer-events-none select-none cursor-pointer whitespace-nowrap";
  const sizes = { sm: "h-8 px-3 text-[12.5px]", md: "h-10 px-4 text-[13.5px]", lg: "h-12 px-5 text-[15px]" }[size];
  const v = {
    primary: "bg-jade text-[#04140d] hover:bg-[#5cebb6] font-semibold",
    soft: "bg-raised text-text border border-line hover:bg-[#182231]",
    ghost: "text-mute hover:text-text hover:bg-raised",
    danger: "bg-coral/10 text-coral border border-coral/30 hover:bg-coral/15",
  }[variant];
  return (
    <button className={cx(base, sizes, v, className)} disabled={disabled || loading} {...rest}>
      {loading ? <Icon name="refresh" size={size === "sm" ? 14 : 16} className="animate-spin" /> : icon ? <Icon name={icon} size={size === "sm" ? 14 : 16} /> : null}
      {children}
    </button>
  );
}

/* ---------- Badge ---------- */
type Tone = "jade" | "coral" | "gold" | "sky" | "mute";
const TONES: Record<Tone, string> = {
  jade: "text-jade bg-jade/10 border-jade/25",
  coral: "text-coral bg-coral/10 border-coral/25",
  gold: "text-gold bg-gold/10 border-gold/25",
  sky: "text-sky bg-sky/10 border-sky/25",
  mute: "text-mute bg-raised border-line",
};
export function Badge({ tone = "mute", children, className, dot }: { tone?: Tone; children: React.ReactNode; className?: string; dot?: boolean }) {
  return (
    <span className={cx("inline-flex items-center gap-1.5 h-[22px] px-2 rounded-md border text-[11.5px] font-medium leading-none", TONES[tone], className)}>
      {dot && <span className="w-1.5 h-1.5 rounded-full bg-current" />}
      {children}
    </span>
  );
}

/* ---------- Segmented ---------- */
export function Segmented<T extends string>({
  value, onChange, options, size = "md", className,
}: {
  value: T; onChange: (v: T) => void; options: { value: T; label: React.ReactNode }[]; size?: "sm" | "md"; className?: string;
}) {
  return (
    <div role="tablist" className={cx("inline-flex p-[3px] rounded-xl bg-abyss border border-line", className)}>
      {options.map((o) => {
        const on = o.value === value;
        return (
          <button
            key={o.value}
            role="tab"
            aria-selected={on}
            onClick={() => onChange(o.value)}
            className={cx(
              "rounded-[9px] font-medium transition-colors cursor-pointer whitespace-nowrap",
              size === "sm" ? "h-7 px-2.5 text-[12px]" : "h-8 px-3.5 text-[13px]",
              on ? "bg-raised text-text shadow-[inset_0_0_0_1px_var(--color-line)]" : "text-mute hover:text-text",
            )}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

/* ---------- Toggle ---------- */
export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cx("relative w-10 h-[22px] rounded-full transition-colors cursor-pointer shrink-0", checked ? "bg-jade" : "bg-line")}
    >
      <span className={cx("absolute top-[3px] left-[3px] w-4 h-4 rounded-full bg-white transition-transform duration-200", checked && "translate-x-[18px]")} />
    </button>
  );
}

/* ---------- Section ---------- */
export function Section({
  title, aside, children, className, pad = true,
}: { title?: React.ReactNode; aside?: React.ReactNode; children: React.ReactNode; className?: string; pad?: boolean }) {
  return (
    <section className={cx("surface", className)}>
      {(title || aside) && (
        <header className="flex items-center justify-between gap-3 px-4 pt-3.5 pb-3 border-b border-line">
          <h3 className="font-display text-[15px] font-semibold text-text">{title}</h3>
          {aside}
        </header>
      )}
      <div className={pad ? "p-4" : ""}>{children}</div>
    </section>
  );
}

/* ---------- Stat ---------- */
export function Stat({ label, value, sub, tone }: { label: string; value: React.ReactNode; sub?: React.ReactNode; tone?: "jade" | "coral" | "gold" }) {
  return (
    <div className="min-w-0">
      <div className="text-[12px] text-mute">{label}</div>
      <div className={cx("num font-display text-[22px] font-semibold leading-tight mt-0.5", tone === "jade" && "text-jade", tone === "coral" && "text-coral", tone === "gold" && "text-gold")}>{value}</div>
      {sub && <div className="text-[12px] text-faint mt-0.5 num">{sub}</div>}
    </div>
  );
}

/* ---------- Field ---------- */
export const Field = React.forwardRef<
  HTMLInputElement,
  React.InputHTMLAttributes<HTMLInputElement> & { label: string; hint?: string; icon?: IconName; trailing?: React.ReactNode; error?: string }
>(function Field({ label, hint, icon, trailing, error, className, id, ...rest }, ref) {
  const fid = id || `f_${label.replace(/\W+/g, "_")}`;
  return (
    <div className={className}>
      <label htmlFor={fid} className="block text-[13px] font-medium text-text mb-1.5">{label}</label>
      <div className={cx("flex items-center gap-2.5 h-12 px-3.5 rounded-xl bg-abyss border transition-colors focus-within:border-gold/70", error ? "border-coral/60" : "border-line")}>
        {icon && <Icon name={icon} size={17} className="text-faint shrink-0" />}
        <input id={fid} ref={ref} className="flex-1 min-w-0 bg-transparent outline-none text-[15px] text-text placeholder:text-faint" {...rest} />
        {trailing}
      </div>
      {error ? <p className="text-[12.5px] text-coral mt-1.5" role="alert">{error}</p> : hint ? <p className="text-[12.5px] text-faint mt-1.5">{hint}</p> : null}
    </div>
  );
});

/* ---------- Sheet (modal / bottom sheet) ---------- */
export function Sheet({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: React.ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    ref.current?.focus();
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-end sm:items-center justify-center" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 bg-black/65" onClick={onClose} />
      <div
        ref={ref}
        tabIndex={-1}
        className={cx("sheet-in relative w-full max-h-[88vh] overflow-y-auto bg-panel border border-line outline-none rounded-t-3xl sm:rounded-3xl", wide ? "sm:max-w-2xl" : "sm:max-w-md")}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 bg-panel border-b border-line">
          <h2 className="font-display text-[17px] font-semibold">{title}</h2>
          <button onClick={onClose} aria-label="Tutup" className="w-8 h-8 grid place-items-center rounded-lg text-mute hover:text-text hover:bg-raised cursor-pointer">
            <Icon name="x" size={18} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

/* ---------- Empty ---------- */
export function Empty({ icon = "info", title, children, action }: { icon?: IconName; title: string; children?: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center text-center py-10 px-6">
      <div className="w-11 h-11 rounded-2xl bg-raised border border-line grid place-items-center text-mute mb-3.5"><Icon name={icon} size={20} /></div>
      <h4 className="font-display text-[16px] font-semibold">{title}</h4>
      {children && <p className="text-[13.5px] text-mute mt-1 max-w-[34ch]">{children}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

/* ---------- Price text that flashes on change ---------- */
export function FlashNum({ value, children, className }: { value: number; children: React.ReactNode; className?: string }) {
  const prev = useRef(value);
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    if (prev.current !== value && ref.current && value > 0 && prev.current > 0) {
      const el = ref.current;
      el.classList.remove("flash-up", "flash-down");
      void el.offsetWidth;
      el.classList.add(value > prev.current ? "flash-up" : "flash-down");
    }
    prev.current = value;
  }, [value]);
  return <span ref={ref} className={cx("num", className)}>{children}</span>;
}
