import { cx } from "../lib/format";

export const biasLabel = (b?: string) => (b === "BULLISH" ? "Naik" : b === "BEARISH" ? "Turun" : "Netral");
export const biasTone = (b?: string) => (b === "BULLISH" ? "text-jade" : b === "BEARISH" ? "text-coral" : "text-mute");

export function ImpactDot({ level, className }: { level: number; className?: string }) {
  const c = level === 1 ? "bg-gold" : level === 0 ? "bg-sky" : "bg-faint";
  return <span className={cx("inline-block w-2 h-2 rounded-full", c, className)} aria-hidden="true" />;
}
export const impactLabel = (level: number) => (level === 1 ? "Dampak tinggi" : level === 0 ? "Dampak sedang" : "Dampak rendah");

/** Sesi pasar 24 jam dalam WITA dengan penanda waktu sekarang. */
const SESSIONS = [
  { name: "Sydney", from: 6, to: 15 },
  { name: "Tokyo", from: 8, to: 17 },
  { name: "London", from: 16, to: 25 },
  { name: "New York", from: 21, to: 30 },
];
export function SessionStrip({ hours, minutes }: { hours: number; minutes: number }) {
  const now = (hours + minutes / 60) / 24 * 100;
  const seg = (from: number, to: number) => {
    const out: { l: number; w: number }[] = [];
    const a = from % 24, len = to - from;
    if (a + len <= 24) out.push({ l: (a / 24) * 100, w: (len / 24) * 100 });
    else { out.push({ l: (a / 24) * 100, w: ((24 - a) / 24) * 100 }); out.push({ l: 0, w: ((a + len - 24) / 24) * 100 }); }
    return out;
  };
  const isActive = (s: (typeof SESSIONS)[number]) => {
    const h = hours + minutes / 60;
    return (h >= s.from && h < s.to) || (h + 24 >= s.from && h + 24 < s.to);
  };
  return (
    <div className="relative">
      <div className="space-y-2.5">
        {SESSIONS.map((s) => {
          const on = isActive(s);
          return (
            <div key={s.name} className="grid grid-cols-[68px_1fr] items-center gap-3">
              <span className={cx("text-[13px]", on ? "text-text font-medium" : "text-faint")}>{s.name}</span>
              <div className="relative h-2.5 rounded-full bg-abyss border border-line overflow-hidden">
                {seg(s.from, s.to).map((g, i) => (
                  <span key={i} className={cx("absolute top-0 bottom-0 rounded-full", on ? "bg-jade/70" : "bg-gray-600/60")} style={{ left: `${g.l}%`, width: `${g.w}%` }} />
                ))}
              </div>
            </div>
          );
        })}
      </div>
      <div className="grid grid-cols-[68px_1fr] gap-3 mt-2">
        <span />
        <div className="relative h-4 text-[11px] text-faint num">
          {[0, 6, 12, 18, 24].map((h) => (
            <span key={h} className="absolute -translate-x-1/2" style={{ left: `${(h / 24) * 100}%`, ...(h === 0 ? { transform: "none" } : h === 24 ? { transform: "translateX(-100%)" } : {}) }}>{String(h % 24).padStart(2, "0")}</span>
          ))}
        </div>
      </div>
      <div className="absolute top-0 bottom-5 pointer-events-none" style={{ left: "calc(68px + 0.75rem)", right: 0 }}>
        <div className="absolute -top-1 bottom-0 w-px bg-gold" style={{ left: `${now}%` }}>
          <span className="absolute -top-0.5 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-gold" />
        </div>
      </div>
    </div>
  );
}
