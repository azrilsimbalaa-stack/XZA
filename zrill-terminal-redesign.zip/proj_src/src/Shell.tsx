import React, { useMemo, useState } from "react";
import { useT } from "./TerminalContext";
import { useAuth, PLAN_LABEL } from "./auth/AuthContext";
import { useRoute, Route } from "./lib/router";
import { Icon, IconName } from "./ui/Icon";
import { Sheet, Segmented, FlashNum } from "./ui/kit";
import { SYMBOLS } from "./TerminalCore";
import { cx, fmtPrice, isBtc } from "./lib/format";

import RingkasanPage from "./pages/Ringkasan";
import ChartPage from "./pages/ChartPage";
import SinyalPage from "./pages/Sinyal";
import KalenderPage from "./pages/Kalender";
import BeritaPage from "./pages/Berita";
import RisikoPage from "./pages/Risiko";
import JurnalPage from "./pages/Jurnal";
import PengaturanPage from "./pages/Pengaturan";

const NAV: { id: Route; label: string; icon: IconName }[] = [
  { id: "ringkasan", label: "Ringkasan", icon: "grid" },
  { id: "chart", label: "Chart", icon: "candles" },
  { id: "sinyal", label: "Sinyal", icon: "target" },
  { id: "kalender", label: "Kalender", icon: "calendar" },
  { id: "berita", label: "Berita", icon: "newspaper" },
  { id: "risiko", label: "Risiko", icon: "calculator" },
  { id: "jurnal", label: "Jurnal", icon: "book" },
  { id: "pengaturan", label: "Pengaturan", icon: "sliders" },
];
const TABS: Route[] = ["ringkasan", "chart", "sinyal", "kalender"];
const TITLES: Record<Route, string> = {
  ringkasan: "Ringkasan pasar", chart: "Chart", sinyal: "Sinyal", kalender: "Kalender ekonomi USD",
  berita: "Berita aset", risiko: "Kalkulator risiko", jurnal: "Jurnal trading", pengaturan: "Pengaturan",
};

export default function Shell() {
  const T = useT();
  const { session, logout } = useAuth();
  const [route, go] = useRoute();
  const [more, setMore] = useState(false);

  // Rilis berdampak tinggi dalam 60 menit ke depan → tanda di menu Kalender
  const soon = useMemo(() => {
    const now = T.nowTicker;
    return (T.economicEvents as any[]).some((e) => {
      const t = new Date(e.date).getTime();
      return e.importance === 1 && !e.isReleased && t > now && t - now < 3600_000;
    });
  }, [T.economicEvents, T.nowTicker]);

  const bid = T.currentPrice.bid;
  const sym = T.activeSymbol;
  const clock = T.realtimeWitaClock;
  const live = bid > 0;

  const pickSymbol = (id: string) => {
    const s = SYMBOLS.find((x) => x.id === id);
    if (s && s.id !== sym.id) { T.setActiveSymbol(s); T.setCurrentPrice({ bid: 0, ask: 0 }); }
  };

  const NavBtn = ({ n, rail }: { n: (typeof NAV)[number]; rail?: boolean }) => {
    const on = route === n.id;
    return (
      <button
        onClick={() => { go(n.id); setMore(false); }}
        aria-current={on ? "page" : undefined}
        className={cx(
          "relative cursor-pointer transition-colors",
          rail
            ? cx("w-full flex items-center gap-3 h-10 px-3 rounded-xl text-[14px] font-medium", on ? "bg-raised text-text" : "text-mute hover:text-text hover:bg-raised/60")
            : cx("flex flex-col items-center justify-center gap-1 h-full text-[11px] font-medium", on ? "text-jade" : "text-mute"),
        )}
      >
        {rail && on && <span className="absolute left-0 top-2 bottom-2 w-[3px] rounded-full bg-jade" />}
        <span className="relative">
          <Icon name={n.icon} size={rail ? 18 : 21} />
          {n.id === "kalender" && soon && <span className="absolute -top-0.5 -right-1 w-2 h-2 rounded-full bg-gold ring-2 ring-abyss" />}
        </span>
        {n.label}
      </button>
    );
  };

  const symbolSwitch = (
    <Segmented
      size="sm"
      value={sym.id}
      onChange={pickSymbol}
      options={SYMBOLS.map((s) => ({ value: s.id, label: s.id }))}
    />
  );

  const page = (r: Route, node: React.ReactNode) => (route === r ? node : null);

  return (
    <div className="min-h-full lg:grid lg:grid-cols-[var(--rail-w)_1fr]">
      {/* Rail desktop */}
      <aside className="hidden lg:flex flex-col sticky top-0 h-screen border-r border-line bg-abyss px-3 py-4">
        <div className="flex items-center gap-2.5 px-2 pb-5">
          <img src="/zrill-icon-192.png" alt="" className="w-9 h-9 rounded-xl border border-jade/30" />
          <div className="leading-tight">
            <div className="font-display text-[18px] font-bold tracking-tight">Zrill AI</div>
            <div className="text-[11.5px] text-faint">Terminal XAUUSD · BTCUSD</div>
          </div>
        </div>
        <nav className="flex flex-col gap-1" aria-label="Navigasi utama">
          {NAV.map((n) => <NavBtn key={n.id} n={n} rail />)}
        </nav>
        <div className="mt-auto surface-inset p-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-raised border border-line grid place-items-center font-display font-semibold text-gold">
              {(session?.name || "T").slice(0, 1).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[13.5px] font-medium truncate">{session?.name}</div>
              <div className="text-[12px] text-faint">{PLAN_LABEL[session?.plan || ""] || session?.plan}</div>
            </div>
            <button onClick={logout} aria-label="Keluar" title="Keluar" className="w-8 h-8 grid place-items-center rounded-lg text-mute hover:text-coral hover:bg-raised cursor-pointer">
              <Icon name="logout" size={17} />
            </button>
          </div>
        </div>
      </aside>

      <div className="min-w-0 pb-[76px] lg:pb-0">
        {/* Top bar */}
        <header className="sticky top-0 z-30 bg-abyss/92 backdrop-blur border-b border-line">
          <div className="max-w-[1360px] mx-auto px-4 sm:px-6 h-14 flex items-center gap-3">
            <div className="lg:hidden flex items-center gap-2 mr-1">
              <img src="/zrill-icon-192.png" alt="" className="w-7 h-7 rounded-lg border border-jade/30" />
            </div>
            <h1 className="hidden lg:block font-display text-[20px] font-semibold tracking-tight mr-auto">{TITLES[route]}</h1>
            <div className="lg:hidden mr-auto">{symbolSwitch}</div>
            <div className="hidden lg:block">{symbolSwitch}</div>

            <div className="flex items-baseline gap-2 pl-1">
              <FlashNum value={bid} className="font-display text-[18px] sm:text-[20px] font-semibold">
                {live ? fmtPrice(bid, sym.id) : "Menunggu harga"}
              </FlashNum>
              {live && <span className="hidden sm:inline text-[12px] text-faint">{isBtc(sym.id) ? "24 jam" : T.currentMarketClosedInfo?.isClosed ? "pasar tutup" : "live"}</span>}
            </div>

            <div className="hidden md:flex items-center gap-2 pl-3 ml-1 border-l border-line">
              <Icon name="clock" size={15} className="text-faint" />
              <div className="leading-tight">
                <div className="num text-[13.5px] font-medium">{String(clock.witaTimeStr).replace(" WITA", "").replace(/\./g, ":")}</div>
                <div className="text-[11.5px] text-faint">WITA · {clock.activeSession.replace(/^SESI\s+/i, "").replace(/[^\w\s/&()-]/g, "").trim().toLowerCase().replace(/^\w/, (c: string) => c.toUpperCase())}</div>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-[1360px] mx-auto px-4 sm:px-6 py-5 lg:py-6">
          <h1 className="lg:hidden font-display text-[24px] font-semibold tracking-tight mb-4">{TITLES[route]}</h1>
          {page("ringkasan", <RingkasanPage go={go} />)}
          {page("sinyal", <SinyalPage go={go} />)}
          {page("kalender", <KalenderPage />)}
          {page("berita", <BeritaPage />)}
          {page("risiko", <RisikoPage />)}
          {page("jurnal", <JurnalPage />)}
          {page("pengaturan", <PengaturanPage />)}
          {/* Halaman chart selalu terpasang agar harga live tetap mengalir saat Anda berpindah halaman */}
          <div className={route === "chart" ? "" : "fixed left-0 top-0 w-[1200px] h-[900px] overflow-hidden invisible pointer-events-none -z-10"} aria-hidden={route !== "chart"}>
            <ChartPage go={go} active={route === "chart"} />
          </div>
        </main>
      </div>

      {/* Tab bar mobile */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 h-[64px] pb-[env(safe-area-inset-bottom)] bg-abyss/96 backdrop-blur border-t border-line grid grid-cols-5" aria-label="Navigasi utama">
        {NAV.filter((n) => TABS.includes(n.id)).map((n) => <NavBtn key={n.id} n={n} />)}
        <button onClick={() => setMore(true)} className={cx("flex flex-col items-center justify-center gap-1 text-[11px] font-medium cursor-pointer", !TABS.includes(route) ? "text-jade" : "text-mute")}>
          <Icon name="more" size={21} /> Lainnya
        </button>
      </nav>

      <Sheet open={more} onClose={() => setMore(false)} title="Menu lainnya">
        <div className="grid gap-1.5">
          {NAV.filter((n) => !TABS.includes(n.id)).map((n) => (
            <button key={n.id} onClick={() => { go(n.id); setMore(false); }} className="flex items-center gap-3 h-12 px-3 rounded-xl bg-raised border border-line text-[15px] cursor-pointer">
              <Icon name={n.icon} size={19} className="text-mute" /> {n.label}
              <Icon name="chevronRight" size={16} className="ml-auto text-faint" />
            </button>
          ))}
          <button onClick={logout} className="flex items-center gap-3 h-12 px-3 rounded-xl border border-coral/30 text-coral text-[15px] mt-2 cursor-pointer">
            <Icon name="logout" size={19} /> Keluar
          </button>
        </div>
      </Sheet>
    </div>
  );
}
